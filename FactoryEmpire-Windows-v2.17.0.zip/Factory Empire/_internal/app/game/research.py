"""
Forschungsbaum.

Eine Forschung kostet sofort Geld und benötigt danach Forschungszeit. Anfangs läuft eine Forschung
gleichzeitig; weitere Forschungs-Slots kann man kaufen (C.RESEARCH_SLOT_COSTS). Abgeschlossene
Technologien bleiben dauerhaft freigeschaltet (werden gespeichert).
"""

from . import config as C
from . import rules


class ResearchManager:
    def __init__(self):
        self.unlocked = set()
        self.running = []         # [[technologie, sekunden], ...] – höchstens self.slots
        self.slots = 1

    # Kompatibilität: "die" laufende Forschung = die erste
    @property
    def active(self):
        return self.running[0][0] if self.running else None

    @active.setter
    def active(self, value):
        if value is None:
            self.running = []
        else:
            self.running = [[value, 0.0]] + [r for r in self.running if r[0] != value]

    @property
    def progress(self):
        return self.running[0][1] if self.running else 0.0

    @progress.setter
    def progress(self, value):
        if self.running:
            self.running[0][1] = float(value)

    def busy(self):
        """True, wenn kein Forschungs-Slot frei ist."""
        return len(self.running) >= self.slots

    def check_start(self, tech_id, money, planet="earth"):
        if any(r[0] == tech_id for r in self.running):
            return False, f"{C.RESEARCH[tech_id]['name']} wird schon erforscht."
        ok, msg = rules.check_research(tech_id, self.unlocked, self.active if self.busy() else None, money, planet)
        if not ok and self.busy() and self.slots < C.MAX_RESEARCH_SLOTS and msg == "Es läuft bereits eine Forschung.":
            msg = "Alle Forschungs-Slots sind belegt – kaufe einen weiteren Slot im Forschungsfenster (R)."
        return ok, msg

    def start(self, tech_id):
        self.running.append([tech_id, 0.0])

    def tick(self, dt):
        """Gibt die IDs der gerade abgeschlossenen Technologien zurück (Liste, meist leer)."""
        done = []
        for r in list(self.running):
            r[1] += dt
            if r[1] >= C.RESEARCH[r[0]]["time"]:
                self.unlocked.add(r[0])
                self.running.remove(r)
                done.append(r[0])
        return done

    def next_slot_cost(self):
        if self.slots >= C.MAX_RESEARCH_SLOTS:
            return None
        return C.RESEARCH_SLOT_COSTS[self.slots - 1]

    def snapshot(self):
        running = [{"id": t, "progress": round(p, 2), "time": C.RESEARCH[t]["time"]} for t, p in self.running]
        return {"unlocked": sorted(self.unlocked), "active": running[0] if running else None,
                "running": running, "slots": self.slots, "slot_cost": self.next_slot_cost()}

    def to_dict(self):
        return {"unlocked": sorted(self.unlocked), "running": [list(r) for r in self.running], "slots": self.slots,
                "active": self.active, "progress": self.progress}

    @classmethod
    def from_dict(cls, data):
        r = cls()
        r.unlocked = {t for t in data.get("unlocked", []) if t in C.RESEARCH}
        try:
            r.slots = max(1, min(C.MAX_RESEARCH_SLOTS, int(data.get("slots", 1))))
        except (TypeError, ValueError):
            r.slots = 1
        running = data.get("running")
        if isinstance(running, list):
            for item in running:
                try:
                    t, p = item[0], float(item[1])
                except (TypeError, ValueError, IndexError):
                    continue
                if t in C.RESEARCH and t not in r.unlocked and all(x[0] != t for x in r.running):
                    r.running.append([t, p])
            r.running = r.running[:r.slots]
        else:                                           # alte Spielstände: eine Forschung
            active = data.get("active")
            if active in C.RESEARCH and active not in r.unlocked:
                r.running = [[active, float(data.get("progress", 0.0))]]
        return r
