"""
Spielwelt: Betonboden mit Bau-Raster, Erzvorkommen, hügelige Landschaft mit
See, Wäldern, Büschen, Blumen und Felsen, ziehende Wolken, Himmel, Licht und
die Avatare der Mitspieler (mit Laufanimation).

Alles wird beim Start prozedural erzeugt; gleiche Seeds ergeben auf jedem
Rechner dieselbe Landschaft.
"""

import math
import random

from panda3d.core import TransparencyAttrib
from ursina import AmbientLight, DirectionalLight, Entity, Mesh, Sky, Vec2, Vec3, camera, color, destroy

from . import config as C
from . import graphics
from . import models
from . import textures

FLOOR_TINT = (0.37, 0.56, 0.25)          # Rasen der Baufläche
SNOW_TINT = (0.86, 0.9, 0.97)            # Winter: verschneite Baufläche
WINTER = {"on": False}                   # Umgebung "Winter": Boden und Gelände mit Schnee
ORE_GROUND = {"iron_ore": (0.46, 0.33, 0.30), "copper_ore": (0.55, 0.40, 0.25), "coal": (0.20, 0.20, 0.22),
              "stone": (0.48, 0.47, 0.45), "sand": (0.80, 0.70, 0.48)}
MARGIN = 4.0                       # flacher Rand um die Fabrikfläche
LAKE = (-22.0, C.GRID_H * 0.55, 11.0)   # Mittelpunkt x, z und Radius des Sees
WATER_LEVEL = -0.35


# ----------------------------------------------------------------------------- Höhenfeld
def _hash(ix, iz, seed=97):
    n = (ix * 374761393 + iz * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def _value_noise(x, z, seed):
    ix, iz = math.floor(x), math.floor(z)
    fx, fz = x - ix, z - iz
    fx, fz = fx * fx * (3 - 2 * fx), fz * fz * (3 - 2 * fz)
    a, b = _hash(ix, iz, seed), _hash(ix + 1, iz, seed)
    c, d = _hash(ix, iz + 1, seed), _hash(ix + 1, iz + 1, seed)
    return (a * (1 - fx) + b * fx) * (1 - fz) + (c * (1 - fx) + d * fx) * fz


def fbm(x, z, seed=11, octaves=4):
    total, amp, freq, norm = 0.0, 1.0, 1.0, 0.0
    for o in range(octaves):
        total += _value_noise(x * freq, z * freq, seed + o * 31) * amp
        norm += amp
        amp *= 0.5
        freq *= 2.0
    return total / norm


def factory_distance(x, z):
    """Abstand zum Rand der Fabrikfläche (0 innerhalb)."""
    dx = max(-0.5 - x, 0.0, x - (C.GRID_W - 0.5))
    dz = max(-0.5 - z, 0.0, z - (C.GRID_H - 0.5))
    return math.hypot(dx, dz)


def terrain_height(x, z):
    d = factory_distance(x, z)
    if d <= MARGIN:
        return 0.0
    t = min(1.0, (d - MARGIN) / 18.0)
    t = t * t * (3 - 2 * t)
    hills = (fbm(x / 22.0, z / 22.0) - 0.35) * 9.0
    far = min(6.0, max(0.0, d - 70.0) * 0.08) * fbm(x / 30.0, z / 30.0, 5)   # sanfte Hügel am Horizont
    h = max(-0.2, hills) * t + far
    # geheime Baustelle (teaser.py): Gelände dort eben
    td = math.hypot(x + 9.0, z + 9.0)
    if td < 12.5:
        k = max(0.0, (td - 7.5) / 5.0)
        h *= k * k * (3 - 2 * k)
    # Landstraße hinter dem Südzaun: Gelände dort eben
    rd = abs(z - (C.GRID_H + 2.3))
    if rd < 7.0:
        k = max(0.0, (rd - 2.2) / 4.8)
        h *= k * k * (3 - 2 * k)
    lx, lz, lr = LAKE
    ld = math.hypot(x - lx, z - lz)
    if ld < lr + 6:
        k = max(0.0, 1 - max(0.0, ld - lr * 0.55) / (lr * 0.45 + 6))
        h = h * (1 - k) + (WATER_LEVEL - 1.2) * k
    return h


def in_lake(x, z, extra=0.0):
    lx, lz, lr = LAKE
    return math.hypot(x - lx, z - lz) < lr + extra


class World:
    def __init__(self, shadow_quality="medium"):
        W, H = C.GRID_W, C.GRID_H
        self.center = Vec3(W / 2 - 0.5, 0, H / 2 - 0.5)
        self.time = 0.0
        self.planet = "earth"
        self.launchpad = None          # Startrampe mit Rakete (rocket.py), sobald der Mond offen ist
        self.moon_env = None           # Mond-Landschaft (moon_world.py), beim ersten Besuch erzeugt
        lit = graphics.lit_shader()

        # Baufläche: Rasen (Collider für die Mausauswahl)
        self.ground = Entity(model=self._floor_mesh(), collider="box", shader=lit,
                             texture=textures.texture("grass"))
        self.terrain = Entity(model=self._terrain_mesh(), shader=lit, texture=textures.texture("grass"))
        self.water = Entity(model="plane", scale=(LAKE[2] * 2.6, 1, LAKE[2] * 2.6),
                            position=(LAKE[0], WATER_LEVEL, LAKE[1]), texture=textures.texture("water"),
                            texture_scale=Vec2(6, 6), color=color.rgba(1, 1, 1, 0.88), shader=lit)
        self.water.setTransparency(TransparencyAttrib.M_alpha)
        self.border = Entity(model=self._border_mesh(), shader=lit, texture=textures.texture("metal"))
        self.lamps = Entity(model=self._lamp_glow_mesh(), shader=graphics.unlit())
        self.grid = self._make_grid()
        self._build_nature(lit)
        self.clouds = self._make_clouds()
        self.deposit_entity = None

        self.sky = Sky(texture="sky_default")
        self.sky.setLightOff()
        self.sky.setFogOff()
        self._setup_lights(shadow_quality)
        from .environment import Environment
        self.env = Environment(self)          # Tageszeit und Umgebung (Wald, Stadt, Baustelle, Winter)

    # ------------------------------------------------------------------ Licht
    def _setup_lights(self, quality="medium"):
        high = graphics.high()
        self.shadow_quality = quality
        use = high and quality != "off" and not graphics.QUALITY.get("fast")
        res = graphics.shadow_resolution(quality)
        self.sun = DirectionalLight(shadows=use, shadow_map_resolution=(res, res))
        self.sun.look_at(Vec3(-0.55, -1.0, 0.4))
        self.sun.color = color.rgba(1.0, 0.95, 0.86, 1)
        self.ambient = AmbientLight(color=color.rgba(0.46, 0.49, 0.56, 1))
        # unsichtbarer Quader, der den Schattenbereich festlegt
        self._shadow_box = Entity(model="cube", visible=False, position=self.center + Vec3(0, 1.5, 0),
                                  scale=(C.GRID_W + 8, 4, C.GRID_H + 8))
        self._shadow_focus = None
        if use:
            self.sun.update_bounds(self._shadow_box)

    def set_shadow_quality(self, quality):
        """Schatten zur Laufzeit ändern (Hoch/Mittel/Niedrig/Aus)."""
        if graphics.QUALITY.get("fast"):
            return
        if not graphics.high() or quality == self.shadow_quality:
            self.shadow_quality = quality
            return
        self.shadow_quality = quality
        if quality == "off":
            self.sun.shadows = False
            return
        res = graphics.shadow_resolution(quality)
        self.sun.shadow_map_resolution = (res, res)
        self.sun.shadows = True
        self._shadow_focus = None
        self.sun.update_bounds(self._shadow_box)

    def update_shadow_focus(self, x, z, radius):
        """Schatten nur rund um den sichtbaren Bereich berechnen: schärfer und bei großen Fabriken
        viel schneller (entfernte Gebäude fallen aus dem Schattendurchlauf heraus)."""
        if not graphics.high() or self.shadow_quality == "off" or graphics.QUALITY.get("fast"):
            return
        radius = max(16.0, min(radius, max(C.GRID_W, C.GRID_H) * 0.75))
        f = self._shadow_focus
        if f is not None and abs(f[0] - x) < radius * 0.15 and abs(f[1] - z) < radius * 0.15 \
                and abs(f[2] - radius) < radius * 0.12:
            return
        self._shadow_focus = (x, z, radius)
        box = self._shadow_box
        box.position = Vec3(x, 1.5, z)
        box.scale = (radius * 2, 4, radius * 2)
        self.sun.update_bounds(box)

    # ------------------------------------------------------------------ Gelände
    def _terrain_mesh(self):
        size, step = 170.0, 3.0
        x0 = self.center.x - size
        z0 = self.center.z - size
        n = int(size * 2 / step) + 1
        verts, cols, uvs, norms, tris = [], [], [], [], []
        heights = [[0.0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                heights[i][j] = terrain_height(x0 + i * step, z0 + j * step)
        for i in range(n):
            for j in range(n):
                x, z = x0 + i * step, z0 + j * step
                h = heights[i][j]
                hl = heights[max(i - 1, 0)][j]
                hr = heights[min(i + 1, n - 1)][j]
                hd = heights[i][max(j - 1, 0)]
                hu = heights[i][min(j + 1, n - 1)]
                nx, ny, nz = hl - hr, 2 * step, hd - hu
                ln = math.sqrt(nx * nx + ny * ny + nz * nz)
                norms.append(Vec3(nx / ln, ny / ln, nz / ln))
                verts.append(Vec3(x, h - 0.04, z))
                uvs.append(Vec2(x / 6.0, z / 6.0))
                steep = 1 - ny / ln
                v = fbm(x / 9.0, z / 9.0, 3)
                if WINTER["on"] and not (steep > 0.45 or h > 18):
                    s_ = 0.9 + v * 0.08
                    col = (s_ * 0.95, s_ * 0.97, min(1.0, s_ * 1.03))           # Schnee
                elif h < WATER_LEVEL + 0.25:
                    col = (0.78, 0.72, 0.52)                                   # Sand am Ufer
                elif steep > 0.35 or h > 14:
                    g = 0.5 + v * 0.15
                    col = (g, g * 0.98, g * 0.95)                              # Fels
                else:
                    col = (0.36 + v * 0.12, 0.56 + v * 0.14, 0.26 + v * 0.06)  # Wiese
                    if factory_distance(x, z) < MARGIN + 0.5:
                        col = (0.42, 0.52, 0.30)
                cols.append(color.rgba(*col, 1))
        for i in range(n - 1):
            for j in range(n - 1):
                a = i * n + j
                b = (i + 1) * n + j
                tris += [(a, b, b + 1), (a, b + 1, a + 1)]      # Vorderseite zeigt nach oben
        return Mesh(vertices=verts, triangles=tris, colors=cols, uvs=uvs, normals=norms)

    def height_at(self, x, z):
        if factory_distance(x, z) <= 0:
            return 0.0
        if self.planet == "moon":
            from .moon_world import moon_height
            return moon_height(x, z)
        return max(WATER_LEVEL - 0.3, terrain_height(x, z))

    # ------------------------------------------------------------------ Erde / Mond
    def fog_settings(self):
        if self.planet == "moon":
            return (0.0, 0.0, 0.0), (220.0, 640.0), 0.85
        return graphics.FOG["color"], graphics.FOG["range"], 1.0

    def restore_background(self):
        from ursina import window
        window.color = color.black if self.planet == "moon" else color.rgba(*graphics.FOG["color"], 1)

    def set_sky_visible(self, on):
        self.sky.enabled = on and self.planet == "earth"
        if self.moon_env is not None:
            self.moon_env.stars.enabled = on

    def set_planet(self, planet):
        """Schaltet die ganze Umgebung zwischen Erde und Mond um."""
        planet = "moon" if planet == "moon" else "earth"
        if planet == self.planet:
            return
        self.planet = planet
        moon = planet == "moon"
        if moon and self.moon_env is None:
            from .moon_world import MoonEnvironment
            self.moon_env = MoonEnvironment(self.center)
        if self.moon_env is not None:
            self.moon_env.set_enabled(moon)
        earth_only = [self.terrain, self.water, self.forest, self.road, self.trees_trunk, self.trees_crown,
                      self.bushes, self.rocks, self.small_plants] + list(self.clouds)
        for e in earth_only:
            e.enabled = not moon
        if not moon:
            self.set_scenery(getattr(self, "scenery", True))
        self.traffic.set_visible(not moon)
        if self.teaser is not None:
            self.teaser.root.enabled = not moon and self.launchpad is None
        self.sky.enabled = not moon
        from ursina import window
        window.color = color.black if moon else color.rgba(0.55, 0.7, 0.85, 1)
        if moon:
            self.sun.color = color.rgba(1.08, 1.06, 1.02, 1)
            self.ambient.color = color.rgba(0.2, 0.21, 0.26, 1)
        else:
            self.sun.color = color.rgba(1.0, 0.95, 0.86, 1)
            self.ambient.color = color.rgba(0.46, 0.49, 0.56, 1)
        graphics.set_fog(*self.fog_settings())
        self.ground.texture = textures.texture("rock" if moon else "grass")
        if self.launchpad is not None:
            self.launchpad.root.y = self.height_at(*self._pad_xz())
            self.launchpad.set_planet(planet)
        self._last_deposits = None
        env = self.env
        env._show_theme()
        for e in (env.city, env.site, env.snow_forest, env.stars):
            if e is not None and moon:
                e.enabled = False
        env.pools.enabled = False
        if moon:
            graphics.set_ambient((1.0, 1.0, 1.0))
            self.lamps.setColorScale(1, 1, 1, 1)
            self.water.setColorScale(1, 1, 1, 1)
        else:
            env.apply(force=True)

    def _pad_xz(self):
        from . import teaser
        return teaser.CENTER

    def set_launch(self, open_):
        """Countdown läuft: Baustelle. Mond offen: Startrampe mit Rakete."""
        from . import teaser
        if open_ and self.launchpad is None:
            from .rocket import LaunchPad
            self.launchpad = LaunchPad(teaser.CENTER, 0.0, self.planet)
        if not open_ and self.launchpad is not None:
            self.launchpad.destroy()
            self.launchpad = None
        if self.teaser is not None:
            self.teaser.root.enabled = not open_ and self.planet == "earth"

    # ------------------------------------------------------------------ Raster und Rand
    def _make_grid(self):
        W, H = C.GRID_W, C.GRID_H
        verts = []
        for x in range(W + 1):
            verts += [Vec3(x - 0.5, 0.012, -0.5), Vec3(x - 0.5, 0.012, H - 0.5)]
        for y in range(H + 1):
            verts += [Vec3(-0.5, 0.012, y - 0.5), Vec3(W - 0.5, 0.012, y - 0.5)]
        grid = Entity(model=Mesh(vertices=verts, mode="line", thickness=1), shader=graphics.unlit(),
                      color=color.rgba(1, 1, 1, 0.07))
        grid.setTransparency(TransparencyAttrib.M_alpha)
        return grid

    def set_grid_visible(self, visible):
        self.grid.enabled = visible

    def _border_mesh(self):
        W, H = C.GRID_W, C.GRID_H
        mb = models.MeshBuilder()
        curb = (0.6, 0.61, 0.6)
        cx, cz = W / 2 - 0.5, H / 2 - 0.5
        for pos, scale in (((cx, 0.07, -0.68), (W + 0.7, 0.14, 0.32)), ((cx, 0.07, H - 0.32), (W + 0.7, 0.14, 0.32)),
                           ((-0.68, 0.07, cz), (0.32, 0.14, H)), ((W - 0.32, 0.07, cz), (0.32, 0.14, H))):
            mb.add("box", pos, scale, curb)
        # Warnstreifen auf dem Bordstein
        for x in range(0, W, 2):
            for z in (-0.68, H - 0.32):
                mb.add("box", (x, 0.145, z), (0.9, 0.01, 0.12), models.YELLOW)
        for z in range(0, H, 2):
            for x in (-0.68, W - 0.32):
                mb.add("box", (x, 0.145, z), (0.12, 0.01, 0.9), models.YELLOW)
        # Zaunpfosten mit Querstreben, Laternen an den Ecken und in Abständen
        def post_line(points):
            for (px, pz) in points:
                mb.add("box", (px, 0.55, pz), (0.07, 1.0, 0.07), (0.45, 0.47, 0.5))
        top = [(x - 0.5, -0.85) for x in range(0, W + 1, 3)]
        bottom = [(x - 0.5, H - 0.15) for x in range(0, W + 1, 3)]
        left = [(-0.85, z - 0.5) for z in range(0, H + 1, 3)]
        right = [(W - 0.15, z - 0.5) for z in range(0, H + 1, 3)]
        for line in (top, bottom, left, right):
            post_line(line)
        for z in (-0.85, H - 0.15):
            for y in (0.4, 0.85):
                mb.add("box", (cx, y, z), (W + 1, 0.04, 0.03), (0.5, 0.52, 0.55))
        for x in (-0.85, W - 0.15):
            for y in (0.4, 0.85):
                mb.add("box", (x, y, cz), (0.03, 0.04, H + 1), (0.5, 0.52, 0.55))
        for (lx, lz) in self._lamp_positions():
            mb.add("cyl8", (lx, 1.6, lz), (0.12, 3.2, 0.12), (0.3, 0.32, 0.36))
            mb.add("box", (lx, 3.2, lz), (0.5, 0.1, 0.22), (0.3, 0.32, 0.36))
        return mb.build()

    def _lamp_positions(self):
        W, H = C.GRID_W, C.GRID_H
        pts = []
        for x in range(0, W + 1, 12):
            pts += [(x - 0.5, -1.4), (x - 0.5, H + 0.4)]
        for z in range(12, H, 12):
            pts += [(-1.4, z - 0.5), (W + 0.4, z - 0.5)]
        return pts

    def _lamp_glow_mesh(self):
        mb = models.MeshBuilder()
        for (lx, lz) in self._lamp_positions():
            mb.add("box", (lx, 3.13, lz), (0.4, 0.05, 0.16), (1.0, 0.92, 0.65))
        return mb.build()

    # ------------------------------------------------------------------ Natur
    def _build_nature(self, lit):
        rng = random.Random(4242)
        trunks, crowns, bushes, rocks, small = (models.MeshBuilder(2.0) for _ in range(5))
        placed = []

        def free_spot(min_d, max_d, avoid_lake=2.0):
            from . import teaser
            for _ in range(30):
                x = rng.uniform(self.center.x - max_d, self.center.x + max_d)
                z = rng.uniform(self.center.z - max_d, self.center.z + max_d)
                d = factory_distance(x, z)
                if d < min_d or d > max_d or in_lake(x, z, avoid_lake) or teaser.in_area(x, z, 0.5):
                    continue
                return x, z
            return None

        # Waldgürtel rund um die Fabrik, der zum Horizont hin dünner wird und im Dunst verschwindet
        from . import scenery
        road_z = scenery.ROAD_Z

        from . import teaser

        def skip(x, z):
            return in_lake(x, z, 2.5) or abs(z - road_z) < scenery.ROAD_W / 2 + 1.6 or teaser.in_area(x, z, 1.5)

        self.forest = scenery.build_forest(self.center, terrain_height, factory_distance, skip)
        self.road = scenery.build_road(self.center)
        try:
            self.teaser = teaser.Teaser()
        except Exception as exc:
            print("[Baustelle] nicht darstellbar:", exc)
            self.teaser = None
        self.traffic = scenery.Traffic(self.center)
        # einzelne Bäume näher an der Fabrik
        for _ in range(60):
            spot = free_spot(MARGIN + 2.5, 12)
            if spot and abs(spot[1] - road_z) > scenery.ROAD_W / 2 + 1.0:
                x, z = spot
                y = terrain_height(x, z) - 0.05
                t, c = models.tree_parts(rng.choice(["oak", "birch", "pine"]), x, z, rng.uniform(0.9, 1.4), rng)
                for part in t:
                    trunks.add(part[0], (part[1][0], part[1][1] + y, part[1][2]), *part[2:])
                for part in c:
                    crowns.add(part[0], (part[1][0], part[1][1] + y, part[1][2]), *part[2:])
        for _ in range(240):
            spot = free_spot(MARGIN + 0.8, 55)
            if spot and abs(spot[1] - road_z) > scenery.ROAD_W / 2 + 0.6:
                x, z = spot
                y = terrain_height(x, z)
                for part in models.bush_parts(x, z, rng.uniform(0.6, 1.2), rng):
                    bushes.add(part[0], (part[1][0], part[1][1] + y, part[1][2]), *part[2:])
        for _ in range(110):
            spot = free_spot(MARGIN + 0.5, 70, avoid_lake=-1.5)
            if spot:
                x, z = spot
                for part in models.rock_parts(x, z, rng.uniform(0.4, 1.4), rng, terrain_height(x, z) - 0.1):
                    rocks.add(*part)
        for _ in range(320):
            spot = free_spot(MARGIN + 0.3, 40)
            if spot and abs(spot[1] - road_z) > scenery.ROAD_W / 2 + 0.4:
                x, z = spot
                y = terrain_height(x, z)
                gen = models.flower_parts if rng.random() < 0.45 else models.grass_tuft_parts
                for part in gen(x, z, rng):
                    small.add(part[0], (part[1][0], part[1][1] + y, part[1][2]), *part[2:])
        # Schilf am Seeufer
        lx, lz, lr = LAKE
        for _ in range(70):
            a = rng.uniform(0, 2 * math.pi)
            r = lr * rng.uniform(0.92, 1.12)
            x, z = lx + math.cos(a) * r, lz + math.sin(a) * r
            for k in range(4):
                h = rng.uniform(0.5, 0.9)
                small.add("cyl6", (x + rng.uniform(-0.2, 0.2), WATER_LEVEL + h / 2, z + rng.uniform(-0.2, 0.2)),
                          (0.03, h, 0.03), (0.45, 0.55, 0.25))
            small.add("cyl6", (x, WATER_LEVEL + 0.85, z), (0.06, 0.18, 0.06), (0.4, 0.26, 0.15))
        self.trees_trunk = Entity(model=trunks.build(), shader=lit, texture=textures.texture("bark"))
        self.trees_crown = Entity(model=crowns.build(), shader=lit, texture=textures.texture("leaves"))
        self.bushes = Entity(model=bushes.build(), shader=lit, texture=textures.texture("leaves"))
        self.rocks = Entity(model=rocks.build(), shader=lit, texture=textures.texture("rock"))
        self.small_plants = Entity(model=small.build(), shader=lit)
        self.tree_positions = placed

    def _make_clouds(self):
        rng = random.Random(77)
        tex = textures.texture("cloud")
        clouds = []
        for _ in range(16):
            c = Entity(model="quad", texture=tex, billboard=True, shader=graphics.unlit(),
                       position=(self.center.x + rng.uniform(-160, 160), rng.uniform(55, 85),
                                 self.center.z + rng.uniform(-160, 160)),
                       scale=(rng.uniform(30, 55), rng.uniform(14, 22)), color=color.rgba(1, 1, 1, rng.uniform(0.7, 0.95)))
            c.setTransparency(TransparencyAttrib.M_alpha)
            c.setDepthWrite(False)
            c.setLightOff()
            c.setFogOff()
            c.speed = rng.uniform(1.0, 2.5)
            clouds.append(c)
        return clouds

    def set_scenery(self, full):
        """Landschafts-Details (Büsche, Blumen, Felsen, Wolken) ein/aus – spart auf schwachen Rechnern Leistung."""
        self.scenery = bool(full)
        for e in (self.bushes, self.small_plants, self.rocks):
            e.enabled = self.scenery
        for c in self.clouds:
            c.enabled = self.scenery
        if getattr(self, "env", None) is not None:
            self.env._show_theme()

    # ------------------------------------------------------------------ Animation
    def update(self, dt):
        self.time += dt
        if self.env.theme != "winter":
            self.water.texture_offset = Vec2(self.time * 0.02, self.time * 0.013)
        try:
            self.env.update(dt)
        except Exception as exc:                     # Deko darf das Spiel nie stören
            print("[Umgebung]", exc)
        self.traffic.update(dt)
        if self.moon_env is not None:
            self.moon_env.update(dt)
        if self.launchpad is not None:
            try:
                cp = camera.world_position
                self.launchpad.update(dt, (cp.x, cp.y, cp.z))
            except Exception as exc:                 # Deko darf das Spiel nie stören
                import traceback
                traceback.print_exc()
                print("[Startrampe]", exc)
        if self.teaser is not None and self.teaser.root.enabled:
            try:
                cp = camera.world_position
                self.teaser.update(dt, (cp.x, cp.y, cp.z))
            except Exception as exc:                 # Deko darf das Spiel nie stören
                print("[Baustelle]", exc)
                self.teaser = None
        if not getattr(self, "scenery", True):
            return
        for c in self.clouds:
            c.x += c.speed * dt
            if c.x > self.center.x + 180:
                c.x = self.center.x - 180

    # ------------------------------------------------------------------ Erz
    def _floor_mesh(self, deposits=()):
        """Rasen mit großflächigen Farbunterschieden (Flecken, Abnutzung) und den Erzfeldern.

        Die Erzfelder sind direkt in die Bodenfarbe eingerechnet (weiche, ausgefranste Ränder).
        Früher lagen sie als durchsichtige Schicht knapp über dem Boden – das verschwand auf
        manchen Grafikkarten (z. B. Macs) im Boden, weil die Tiefengenauigkeit nicht reichte."""
        W, H = C.GRID_W, C.GRID_H
        N = 3                                         # Unterteilung je Feld (für weiche Erzränder)
        occ = {}
        for x, y, item in deposits:
            if item in C.ITEMS:
                occ[(x, y)] = item
        near = set()
        for (x, y) in occ:
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    near.add((x + dx, y + dy))
        # Grundfarbe (Rasen) nur an den Feldecken berechnen, dazwischen interpolieren (schnell):
        # große hellere/dunklere Flächen, trockene gelbliche Stellen und leichte Mähstreifen
        tint = {}
        moon = self.planet == "moon"
        if moon:
            from .moon_world import ORE_GROUND as MOON_ORE, floor_tint
        for j in range(H + 1):
            for i in range(W + 1):
                if moon:
                    tint[(i, j)] = floor_tint(i, j)
                    continue
                x, z = i - 0.5, j - 0.5
                big = fbm(x * 0.045, z * 0.045, seed=301, octaves=3)
                dry = max(0.0, fbm(x * 0.11, z * 0.11, seed=377, octaves=2) - 0.58) * 2.2
                lush = _value_noise(x * 0.08, z * 0.08, 411)
                stripe = 0.045 if (i // 3) % 2 == 0 else -0.045
                k = 0.92 + (big - 0.5) * 0.28 + stripe
                r, g, b = FLOOR_TINT
                r, g, b = r + dry * 0.20, g + dry * 0.06 - (lush - 0.5) * 0.04, b + dry * 0.02
                if WINTER["on"]:
                    r, g, b = SNOW_TINT
                    k = 0.97 + (big - 0.5) * 0.1 + stripe * 0.3
                tint[(i, j)] = (r * k, g * k * (1.0 + (lush - 0.5) * 0.12), b * k)

        def cov(px, pz, item):
            x0, z0 = math.floor(px), math.floor(pz)
            fx, fz = px - x0, pz - z0
            a = occ.get((x0, z0)) == item
            b = occ.get((x0 + 1, z0)) == item
            c = occ.get((x0, z0 + 1)) == item
            d = occ.get((x0 + 1, z0 + 1)) == item
            return (a * (1 - fx) + b * fx) * (1 - fz) + (c * (1 - fx) + d * fx) * fz

        verts, cols, uvs, norms, tris = [], [], [], [], []
        nx, nz = W * N + 1, H * N + 1
        for j in range(nz):
            for i in range(nx):
                x, z = i / N - 0.5, j / N - 0.5
                ci, cj = min(i // N, W - 1), min(j // N, H - 1)
                fi, fj = i / N - ci, j / N - cj
                t00, t10, t01, t11 = tint[(ci, cj)], tint[(ci + 1, cj)], tint[(ci, cj + 1)], tint[(ci + 1, cj + 1)]
                col = [(t00[k] * (1 - fi) + t10[k] * fi) * (1 - fj) + (t01[k] * (1 - fi) + t11[k] * fi) * fj
                       for k in range(3)]
                tile = (int(math.floor(x + 0.5)), int(math.floor(z + 0.5)))
                if occ and (tile in near or (tile[0] - 1, tile[1]) in near or (tile[0], tile[1] - 1) in near):
                    best, best_a = None, 0.0
                    n = fbm(x * 0.9, z * 0.9, seed=523, octaves=2) - 0.5
                    for item in {occ.get((tile[0] + dx, tile[1] + dy)) for dx in (-1, 0, 1) for dy in (-1, 0, 1)}:
                        if item is None:
                            continue
                        c = cov(x, z, item) + n * 0.55
                        a = max(0.0, min(1.0, (c - 0.28) / 0.32))
                        a = a * a * (3 - 2 * a)
                        if a > best_a:
                            best, best_a = item, a
                    if best is not None:
                        base = (MOON_ORE if moon else ORE_GROUND).get(best, (0.3, 0.3, 0.3))
                        sh = 0.8 + _value_noise(x * 2.3, z * 2.3, 611) * 0.4
                        col = [col[k] * (1 - best_a) + base[k] * sh * 1.25 * best_a for k in range(3)]
                verts.append(Vec3(x, 0, z))
                uvs.append(Vec2((x + 0.5) / 1.5, (z + 0.5) / 1.5))
                norms.append(Vec3(0, 1, 0))
                cols.append((min(1.0, col[0]), min(1.0, col[1]), min(1.0, col[2]), 1))
        for j in range(nz - 1):
            for i in range(nx - 1):
                a = j * nx + i
                tris += [(a, a + 1, a + nx + 1), (a, a + nx + 1, a + nx)]      # Vorderseite oben
        return Mesh(vertices=verts, triangles=tris, colors=cols, uvs=uvs, normals=norms)

    def rebuild_ground(self):
        """Boden und Gelände neu färben (z. B. Schnee im Winter)."""
        self.terrain.model = self._terrain_mesh()
        if self.planet == "earth" and getattr(self, "_deposits", None) is not None:
            self.set_deposits(self._deposits)

    def set_deposits(self, deposits):
        if self.deposit_entity:
            destroy(self.deposit_entity)
        self._deposits = list(deposits)
        key = (self.planet, WINTER["on"], hash(tuple(sorted((x, y, i) for x, y, i in deposits))))
        cache = self.__dict__.setdefault("_floor_cache", {})
        mesh = cache.get(key)
        if mesh is None:
            mesh = self._floor_mesh(deposits)
            if len(cache) >= 2:                       # Menü-Beispielfabrik + aktuelle Welt
                cache.pop(next(iter(cache)))
            cache[key] = mesh
        self.ground.model = mesh
        mb = models.MeshBuilder(2.5)
        for x, y, item in deposits:
            if item not in C.ITEMS:
                continue
            rng = random.Random(x * 7919 + y * 104729)
            ore = C.ITEMS[item]["color"]
            for _ in range(rng.randint(2, 4)):
                s = rng.uniform(0.1, 0.22)
                mb.add("pebble", (x + rng.uniform(-0.33, 0.33), 0.02 + s * 0.25, y + rng.uniform(-0.33, 0.33)),
                       (s, s * 0.7, s * 0.9), tuple(min(1, c * rng.uniform(0.85, 1.25)) for c in ore),
                       (rng.uniform(-20, 20), rng.uniform(0, 90), rng.uniform(-20, 20)))
        self.deposit_entity = Entity(model=mb.build(), shader=graphics.lit_shader(),
                                     texture=textures.texture("rock")) if mb.verts else None


class PlayerCursor:
    """Mitspieler im Mehrspieler: nur sein Mauszeiger (in Spielerfarbe, mit Namen) und ein
    leuchtender Ring auf dem Feld, auf das er gerade zeigt – keine Spielfigur."""

    SIZE = 0.062

    def __init__(self, pid, name, color_index, admin=False, scale=1.0):
        from ursina import camera
        from .ui_base import Label
        self.id = pid
        self.name = name
        rgb = C.PLAYER_COLORS[color_index % len(C.PLAYER_COLORS)]
        self.rgb = rgb
        # 2D-Zeiger im Bild (liegt über der 3D-Welt, unter Fenstern)
        self.ui = Entity(parent=camera.ui, z=-0.1, enabled=False, scale=scale)
        s = self.SIZE
        self.arrow = Entity(parent=self.ui, model="quad", texture=textures.texture("cursor"), origin=(-0.5, 0.5),
                            position=(-6 / 64 * s, 4 / 64 * s), scale=s, color=color.rgba(*rgb, 1))
        label_text = name + (" · Admin" if admin else "")
        self.tag_bg = Entity(parent=self.ui, model="quad", origin=(-0.5, 0.5), position=(0.026, -0.03, 0.001),
                             scale=(0.02 + 0.0105 * len(label_text), 0.028), color=color.rgba(*rgb, 0.92))
        self.tag = Label(self.ui, label_text, 0.033, -0.033, size=0.62, col=color.rgba(0.05, 0.05, 0.07, 1))
        self.tool_icon = Entity(parent=self.ui, model="quad", origin=(-0.5, 0.5), position=(0.026, -0.062, 0.001),
                                scale=0.03, enabled=False)
        self.tool = None
        # Ring auf dem Boden
        self.ring = Entity(model="circle", rotation_x=90, y=0.04, scale=0.95, shader=graphics.unlit(),
                           color=color.rgba(*rgb, 0.55))
        self.ring.setTransparency(TransparencyAttrib.M_alpha)
        self.ring.setLightOff()
        self.ring.setDepthWrite(False)
        self.pos = None                       # weich geglättete Position
        self.target = None
        self.visible_k = 0.0                  # Ein-/Ausblenden
        self.wanted = False
        self.t = random.random() * 10

    def set_target(self, x, z, visible=True, tool=None):
        self.target = Vec3(x, 0, z)
        self.wanted = bool(visible)
        if self.pos is None or self.visible_k <= 0.01:
            self.pos = Vec3(self.target)
        if tool != self.tool:
            self.tool = tool
            tex = textures.icon(tool) if tool and tool in C.BUILDINGS else None
            self.tool_icon.enabled = tex is not None
            if tex is not None:
                self.tool_icon.texture = tex

    def update(self, dt):
        from ursina import application, camera, window
        from panda3d.core import Point2, Point3
        from . import anim
        self.t += dt
        target_k = 1.0 if self.wanted and self.target is not None else 0.0
        self.visible_k += (target_k - self.visible_k) * min(1.0, dt * 8)
        if self.target is None:
            return
        k = 1 - math.exp(-16 * dt)
        self.pos += (self.target - self.pos) * k
        a = self.visible_k
        # Ring auf dem Feld unter dem Zeiger
        tx, tz = round(self.pos.x), round(self.pos.z)
        self.ring.position = Vec3(tx, 0.04, tz)
        pulse = 0.9 + 0.08 * math.sin(self.t * 5)
        self.ring.scale = pulse
        self.ring.color = color.rgba(*self.rgb, 0.5 * a)
        self.ring.enabled = a > 0.02
        # 3D-Punkt auf den Bildschirm projizieren
        base = application.base
        cam_np = base.cam
        p3 = cam_np.getRelativePoint(base.render, Point3(self.pos.x, 0.05, self.pos.z))
        p2 = Point2()
        on_screen = camera.lens.project(p3, p2) if a > 0.02 else False
        self.ui.enabled = bool(on_screen)
        if on_screen:
            self.ui.position = (p2.x * window.aspect_ratio / 2, p2.y * 0.5, -0.1)
            anim.set_alpha(self.ui, a)

    def set_scale(self, scale):
        """Größe von Zeiger und Namensschild (Einstellung „Mitspieler-Zeiger“)."""
        self.ui.scale = scale

    def destroy(self):
        destroy(self.ui)
        destroy(self.ring)
