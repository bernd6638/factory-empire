"""
Spiegel des Serverzustands im Client.

Enthält nur Daten, keine Grafik. Wird aus den Server-Snapshots gefüllt und
für Anzeige und Platzierungsvorschau genutzt. Verbindlich ist immer der Server.
"""

from . import config as C
from . import rules


class ClientState:
    def __init__(self):
        self.deposits = {}
        self.static = {}           # id -> [id, type, x, y, rot, level, recipe, owner]
        self.dynamic = {}          # id -> [status, progress, extra]
        self.grid = {}             # (x, y) -> id
        self.money = 0.0
        self.available = 0.0
        self.energy_min = 0.0
        self.energy_due = 0.0
        self.energy_next = 0.0
        self.inventory = {i: 0 for i in C.ITEMS}
        self.capacity = 0
        self.unlocked = set()
        self.research_active = None
        self.research_running = []      # alle laufenden Forschungen (mehrere Slots)
        self.research_slots = 1
        self.research_slot_cost = None
        self.market = {}
        self.freight = {}
        self.produced = {}
        self.mods = {"speed": 1.0, "miner": 1.0, "belt": 1.0, "price": 1.0, "cost": 1.0, "storage": 1.0}
        self.players = []          # [id, name, color, x, z, tool, yaw, moving, fp, admin]
        self.revision = -1
        self.has_state = False
        self.planet = "earth"
        self.rocket_unlocked = False

    def set_deposits(self, deposits):
        self.deposits = {(x, y): item for x, y, item in deposits}

    def apply(self, msg):
        """Übernimmt einen Snapshot. Gibt (static_changed: bool) zurück."""
        s = msg.get("sum", {})
        self.planet = s.get("planet", self.planet)
        if "rocket" in s:
            self.rocket_unlocked = bool(s["rocket"])
        self.money = s.get("money", self.money)
        self.available = s.get("avail", self.money)
        self.energy_min = s.get("energy_min", 0.0)
        self.energy_due = s.get("energy_due", 0.0)
        self.energy_next = s.get("energy_next", 0.0)
        self.inventory = s.get("inv", self.inventory)
        self.capacity = s.get("cap", self.capacity)
        research = s.get("research", {})
        self.unlocked = set(research.get("unlocked", []))
        self.research_active = research.get("active")
        self.research_running = research.get("running") or ([self.research_active] if self.research_active else [])
        self.research_slots = int(research.get("slots", 1) or 1)
        self.research_slot_cost = research.get("slot_cost")
        self.market = s.get("market", self.market)
        self.freight = s.get("freight", self.freight)
        self.produced = s.get("produced", self.produced)
        self.mods = s.get("mods", self.mods)
        self.players = msg.get("players", self.players)
        static_changed = False
        if "static" in msg:
            self.static = {row[0]: row for row in msg["static"]}
            self.grid = {(row[2], row[3]): row[0] for row in msg["static"]}
            self.revision = msg.get("rev", self.revision)
            static_changed = True
        rows = {row[0]: row[1:] for row in msg.get("dyn", [])}
        if msg.get("dpart"):                # nur geänderte Gebäude – Rest bleibt
            self.dynamic.update(rows)
        else:
            self.dynamic = rows
        self.has_state = True
        return static_changed

    # ------------------------------------------------------------------
    def building_at(self, x, y):
        bid = self.grid.get((x, y))
        return self.static.get(bid) if bid is not None else None

    def check_build(self, btype, x, y, rot):
        return rules.check_build(
            btype, x, y, rot,
            occupied=lambda a, b: (a, b) in self.grid,
            deposit_at=lambda a, b: self.deposits.get((a, b)),
            unlocked=self.unlocked,
            money=self.available,
            planet=self.planet,
        )

    def inventory_total(self):
        return sum(self.inventory.values())

    def storage_fill(self):
        return self.inventory_total() / self.capacity if self.capacity else 0.0

    def status_counts(self):
        counts = {"ok": 0, "warn": 0, "error": 0, "off": 0}
        for bid, (status, _progress, _extra) in self.dynamic.items():
            row = self.static.get(bid)
            if row is None or row[1] in C.BELT_LIKE:
                continue
            counts[C.STATUS.get(status, {"level": "warn"})["level"]] += 1
        return counts

    def check_move(self, bid, x, y, rot):
        row = self.static.get(bid)
        if row is None:
            return False, "Gebäude existiert nicht mehr."
        return rules.check_move(row[1], (row[2], row[3]), x, y, rot,
                                occupied=lambda a, b: (a, b) in self.grid,
                                deposit_at=lambda a, b: self.deposits.get((a, b)))

    def belt_counts(self):
        blocked = 0
        total = 0
        for bid, (status, _p, _e) in self.dynamic.items():
            row = self.static.get(bid)
            if row is not None and row[1] in C.BELT_LIKE:
                total += 1
                if C.STATUS.get(status, {}).get("level") == "error":
                    blocked += 1
        return total, blocked
