"""
Skins: Farb-Looks für alles, was man platzieren kann (und für die Rakete).

Jeder Skin ist "<gebäude>:<stil>". Stile haben eine Seltenheit, die den Preis in Erfolgspunkten
bestimmt (1 Erfolg = 1 Punkt). Server und Client nutzen dieselben Tabellen.
"""

from . import config as C

RARITIES = [
    # id, Name, Preis (Erfolgspunkte), Farbe in der Oberfläche, Gewicht im Glücksrad
    ("rare", "Selten", 7, (0.35, 0.65, 1.0), 60),
    ("super", "Superselten", 15, (0.55, 0.4, 1.0), 25),
    ("epic", "Episch", 23, (0.95, 0.35, 0.85), 11),
    ("legendary", "Legendär", 50, (1.0, 0.72, 0.2), 4),
]
RARITY = {r[0]: {"name": r[1], "price": r[2], "color": r[3], "weight": r[4]} for r in RARITIES}

STYLES = [
    # id, Name, Seltenheit, dunkle Farbe, helle Farbe – die Grundfarben des Gebäudes werden nach ihrer
    # Helligkeit auf diesen Farbverlauf gelegt (zweifarbige Lackierung statt einfacher Tönung)
    ("cherry", "Kirschrot", "rare", (0.35, 0.05, 0.07), (0.95, 0.35, 0.38)),
    ("sky", "Himmelblau", "rare", (0.08, 0.2, 0.42), (0.55, 0.82, 1.0)),
    ("mint", "Mintgrün", "rare", (0.06, 0.3, 0.2), (0.55, 0.98, 0.75)),
    ("sand", "Wüstensand", "rare", (0.38, 0.27, 0.13), (0.98, 0.88, 0.62)),
    ("rust", "Rost", "rare", (0.25, 0.1, 0.05), (0.82, 0.45, 0.22)),
    ("olive", "Oliv", "rare", (0.16, 0.19, 0.08), (0.62, 0.68, 0.36)),
    ("pink", "Rosa", "rare", (0.42, 0.12, 0.3), (1.0, 0.68, 0.86)),
    ("snow", "Schnee", "rare", (0.48, 0.52, 0.58), (1.0, 1.0, 1.0)),
    ("carbon", "Carbon", "super", (0.04, 0.04, 0.05), (0.42, 0.44, 0.48)),
    ("copper", "Kupfer", "super", (0.3, 0.12, 0.05), (1.0, 0.62, 0.38)),
    ("violet", "Violett", "super", (0.2, 0.06, 0.35), (0.85, 0.6, 1.0)),
    ("ocean", "Ozean", "super", (0.02, 0.1, 0.28), (0.25, 0.92, 0.9)),
    ("sunset", "Sonnenuntergang", "super", (0.35, 0.05, 0.35), (1.0, 0.62, 0.2)),
    ("jungle", "Dschungel", "super", (0.03, 0.18, 0.06), (0.72, 1.0, 0.25)),
    ("gold", "Gold", "epic", (0.35, 0.22, 0.02), (1.0, 0.88, 0.38)),
    ("ice", "Eis", "epic", (0.12, 0.3, 0.55), (0.88, 0.98, 1.0)),
    ("lava", "Lava", "epic", (0.12, 0.02, 0.01), (1.0, 0.45, 0.08)),
    ("toxic", "Toxisch", "epic", (0.02, 0.06, 0.02), (0.5, 1.0, 0.15)),
    ("royal", "Königlich", "epic", (0.2, 0.03, 0.35), (1.0, 0.8, 0.25)),
    ("chrome", "Chrom", "epic", (0.2, 0.22, 0.26), (1.0, 1.0, 1.0)),
    ("diamond", "Diamant", "legendary", (0.25, 0.55, 0.75), (0.92, 1.0, 1.0)),
    ("midnight", "Mitternacht", "legendary", (0.02, 0.02, 0.1), (0.35, 0.45, 1.0)),
    ("galaxy", "Galaxie", "legendary", (0.08, 0.02, 0.22), (0.3, 0.95, 1.0)),
    ("inferno", "Inferno", "legendary", (0.05, 0.0, 0.0), (1.0, 0.55, 0.05)),
]
STYLE = {s[0]: {"name": s[1], "rarity": s[2], "dark": s[3], "light": s[4],
              "tint": tuple(round((a + b) / 2 * 1.35, 3) for a, b in zip(s[3], s[4]))} for s in STYLES}

ROCKET = "rocket"


def targets():
    """Alles, wofür es Skins gibt: jedes platzierbare Gebäude plus die Rakete."""
    return list(C.BUILDINGS) + [ROCKET]


def skin_id(target, style):
    return f"{target}:{style}"


def parse(sid):
    if not isinstance(sid, str) or ":" not in sid:
        return None, None
    target, style = sid.split(":", 1)
    if (target in C.BUILDINGS or target == ROCKET) and style in STYLE:
        return target, style
    return None, None


def valid(sid):
    return parse(sid)[0] is not None


def all_ids():
    return [skin_id(t, s[0]) for t in targets() for s in STYLES]


def price(sid):
    _, style = parse(sid)
    return RARITY[STYLE[style]["rarity"]]["price"] if style else None


def rarity(sid):
    _, style = parse(sid)
    return STYLE[style]["rarity"] if style else None


def tint(sid):
    """Einfache Tönung (für bewegliche Teile und die Rakete)."""
    _, style = parse(sid)
    return STYLE[style]["tint"] if style else None


def palette(sid):
    """(dunkel, hell) – die zweifarbige Lackierung des Skins."""
    _, style = parse(sid)
    return (STYLE[style]["dark"], STYLE[style]["light"]) if style else None


def style_of(sid):
    return parse(sid)[1]


# ----------------------------------------------------------------------------- Kisten
CRATES = {
    # id: Name, Preis (Erfolgspunkte), Gewichte je Seltenheit
    "basic": {"name": "Werkskiste", "price": 5, "weights": {"rare": 70, "super": 22, "epic": 7, "legendary": 1}},
    "premium": {"name": "Premiumkiste", "price": 12, "weights": {"rare": 25, "super": 42, "epic": 25, "legendary": 8}},
}


def target_name(target, planet="earth"):
    if target == ROCKET:
        return "Rakete"
    from . import rules
    return rules.building_name(target, planet)


def display_name(sid, planet="earth"):
    target, style = parse(sid)
    if not target:
        return "?"
    return f"{target_name(target, planet)} „{STYLE[style]['name']}“"


# ----------------------------------------------------------------------------- Glücksrad
WHEEL = [
    # Art, Wert, Beschriftung
    ("money", 2_500, "2.500"),
    ("skin", "rare", "Skin"),
    ("money", 10_000, "10.000"),
    ("skin", "super", "Skin+"),
    ("money", 5_000, "5.000"),
    ("skin", "rare", "Skin"),
    ("money", 25_000, "25.000"),
    ("skin", "epic", "Skin!"),
]
WHEEL_WEIGHTS = [16, 15, 11, 8, 15, 15, 6, 4]
