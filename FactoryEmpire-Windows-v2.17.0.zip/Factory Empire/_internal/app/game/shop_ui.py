"""
Shop-Fenster (K): Skins für alle Gebäude und die Rakete, das tägliche Glücksrad und das Konto
(Account anlegen, einloggen, Skins verschenken).
"""

import math

from ursina import Entity, InputField, Mesh, Quad, Vec3, color

from . import anim
from . import skins as K
from .ui_base import (ACCENT, BUTTON, BUTTON_ACCENT, BUTTON_GOOD, BUTTON_LOCKED, FAINT, GOLD, MUTED, PANEL_LIGHT,
                      TEXT, Btn, Label, Window, panel, rect)

PER_PAGE = 11


def _rc(rarity, a=1.0):
    r, g, b = K.RARITY[rarity]["color"]
    return color.rgba(r, g, b, a)


def swatch(parent, x, y, size, style, z=-0.02):
    """Zweifarbiges Farbmuster eines Skins (dunkel | hell)."""
    st = K.STYLE[style]
    for k, col in enumerate((st["dark"], st["light"])):
        Entity(parent=parent, model=Quad(radius=0.25), origin=(-0.5, 0), position=(x + k * size / 2, y, z),
               scale=(size / 2 + 0.002, size), color=color.rgba(*col, 1))


class ShopWindow(Window):
    def __init__(self, anchors, cb):
        super().__init__(anchors, "Shop", 1.36, 0.86, cb["close"], z=-0.5, icon_name="ui_market")
        self.cb = cb
        self.tab = "shop"
        self.target = "miner"
        self.page = 0
        self.gift_idx = 0
        self.account = None
        self.planet = "earth"
        self.content = None
        self.user = self.pw = self.gift_to = None
        self.wheel = None
        self.spinning = False
        self.rocket_ok = False             # Raketen-Skins erst, wenn der Mond offen ist (kein Spoiler)
        w, h = self.w, self.h
        self.tab_btns = {}
        for i, (key, label) in enumerate((("shop", "Skins"), ("crates", "Kisten"), ("wheel", "Glücksrad"),
                                          ("account", "Konto"))):
            self.tab_btns[key] = Btn(self.root, label, -w / 2 + 0.11 + i * 0.2, h / 2 - 0.1, 0.19, 0.046,
                                     (lambda k=key: self.set_tab(k)), size=0.8)
        self.points_l = Label(self.root, "", w / 2 - 0.03, h / 2 - 0.1, size=0.82, col=GOLD, origin=(0.5, 0))

    # ------------------------------------------------------------------ allgemein
    def typing(self):
        return any(f is not None and f.enabled and f.active for f in (self.user, self.pw, self.gift_to))

    def set_tab(self, tab):
        self._finish_spin()
        self.tab = tab
        self.refresh(self.account, self.planet)

    def _finish_spin(self):
        """Rad dreht noch: sofort anhalten und das Ergebnis zeigen (z. B. beim Reiterwechsel)."""
        if self.spinning:
            anim.cancel("wheel")
            self.spinning = False
            text, self._spin_text = getattr(self, "_spin_text", ""), ""
            if text:
                self.cb["toast"](text)
                self.cb["won"]()

    def hide(self):
        self._finish_spin()
        super().hide()

    def show_tab(self, tab):
        self.tab = tab
        self.show()

    def refresh(self, account, planet="earth"):
        self.account = account
        self.planet = planet
        for key, b in self.tab_btns.items():
            b.set_color(BUTTON_ACCENT if key == self.tab else BUTTON)
        if account:
            if account.get("all"):
                self.points_l.set("Entwickler: alle Skins freigeschaltet")
            else:
                self.points_l.set(f"Erfolgspunkte: {account.get('avail', 0)}")
        else:
            self.points_l.set("Nicht eingeloggt")
        if self.spinning:
            return
        if self.content is not None:
            self.content.enabled = False
            self.content.parent = None
        self.user = self.pw = self.gift_to = None
        self.wheel = None
        self.content = Entity(parent=self.root)
        if self.tab == "shop":
            self._build_shop()
        elif self.tab == "crates":
            self._build_crates()
        elif self.tab == "wheel":
            self._build_wheel()
        else:
            self._build_account()

    def _need_login(self, c, y):
        Label(c, "Für Shop und Glücksrad brauchst du einen Account auf diesem Server.", -self.w / 2 + 0.04, y,
              size=0.9, col=MUTED)
        Btn(c, "Zum Konto: Account anlegen oder einloggen", 0, y - 0.09, 0.56, 0.054, lambda: self.set_tab("account"),
            col=BUTTON_ACCENT, size=0.82)

    def _targets(self):
        return [t for t in K.targets() if t != K.ROCKET or self.rocket_ok]

    def _owned(self, sid):
        a = self.account or {}
        return bool(a.get("all")) or sid in a.get("owned", [])

    # ------------------------------------------------------------------ Skins
    def _build_shop(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.03, h / 2 - 0.16
        Label(c, "1 Erfolg = 1 Punkt  ·  Selten 7  ·  Superselten 15  ·  Episch 23  ·  Legendär 50", x0, top,
              size=0.68, col=FAINT)
        if not self.account:
            self._need_login(c, top - 0.08)
            return
        targets = self._targets()
        if self.target not in targets:
            self.target = targets[0]
        pages = max(1, math.ceil(len(targets) / PER_PAGE))
        self.page = min(self.page, pages - 1)
        lw = 0.3
        y = top - 0.07
        equip = self.account.get("equip", {})
        for t in targets[self.page * PER_PAGE:(self.page + 1) * PER_PAGE]:
            name = K.target_name(t, self.planet)
            mark = " •" if t in equip else ""
            Btn(c, name + mark, x0 + lw / 2, y, lw, 0.046, (lambda tt=t: self._pick(tt)), size=0.72,
                col=BUTTON_ACCENT if t == self.target else BUTTON)
            y -= 0.054
        Btn(c, "«", x0 + 0.03, y, 0.06, 0.04, lambda: self._page(-1), size=0.8)
        Label(c, f"{self.page + 1}/{pages}", x0 + lw / 2, y, size=0.7, col=MUTED, origin=(0, 0))
        Btn(c, "»", x0 + lw - 0.03, y, 0.06, 0.04, lambda: self._page(1), size=0.8)

        gx = x0 + lw + 0.04
        gw = w / 2 - 0.03 - gx
        Label(c, K.target_name(self.target, self.planet), gx, top - 0.05, size=1.05, col=ACCENT, raw=True)
        cur = equip.get(self.target)
        Btn(c, "Standard-Look", gx + gw - 0.09, top - 0.065, 0.18, 0.042, lambda: self.cb["equip"](self.target, None),
            size=0.7, col=BUTTON_GOOD if cur is None else BUTTON)
        cols = 6
        cw, ch = (gw - 0.01 * (cols - 1)) / cols, 0.122
        for i, (style, sname, rarity, _dark, _light) in enumerate(K.STYLES):
            sid = K.skin_id(self.target, style)
            cx = gx + (i % cols) * (cw + 0.01)
            cy = top - 0.105 - (i // cols) * (ch + 0.01)
            panel(c, cx, cy, cw, ch, PANEL_LIGHT, radius=0.01, z=-0.01)
            rect(c, cx + 0.006, cy - 0.003, cw - 0.012, 0.005, _rc(rarity), z=-0.015)
            swatch(c, cx + 0.01, cy - 0.034, 0.034, style)
            Label(c, sname, cx + 0.05, cy - 0.022, size=0.6, col=TEXT, max_w=cw - 0.055)
            Label(c, K.RARITY[rarity]["name"], cx + 0.05, cy - 0.046, size=0.5, col=_rc(rarity), max_w=cw - 0.055)
            bx, by, bw, bh = cx + cw / 2, cy - ch + 0.024, cw - 0.014, 0.034
            if sid == cur:
                Btn(c, "Angelegt", bx, by, bw, bh, lambda: None, col=BUTTON_GOOD, size=0.56)
            elif self._owned(sid):
                Btn(c, "Anlegen", bx, by, bw, bh, (lambda s=sid: self.cb["equip"](self.target, s)),
                    col=BUTTON_ACCENT, size=0.56)
            else:
                price = K.RARITY[rarity]["price"]
                ok = self.account.get("avail", 0) >= price
                Btn(c, f"Kaufen · {price} P", bx, by, bw, bh, (lambda s=sid: self.cb["buy"](s)),
                    col=BUTTON_ACCENT if ok else BUTTON_LOCKED, size=0.56)

    # ------------------------------------------------------------------ Kisten
    def _build_crates(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.03, h / 2 - 0.16
        if not self.account:
            self._need_login(c, top - 0.04)
            return
        Label(c, "Kiste kaufen, Walze dreht, Skin gewinnen! Doppelte Skins geben die Hälfte der Punkte zurück.",
              x0, top, size=0.74, col=MUTED)
        cards_w = (w - 0.09) / 2
        for k, (kind, crate) in enumerate(K.CRATES.items()):
            cx = x0 + k * (cards_w + 0.03)
            cy = top - 0.05
            accent = (0.95, 0.6, 0.15) if kind == "basic" else (0.6, 0.4, 1.0)
            panel(c, cx, cy, cards_w, 0.25, PANEL_LIGHT, radius=0.014, z=-0.01)
            rect(c, cx + 0.008, cy - 0.004, cards_w - 0.016, 0.006, color.rgba(*accent, 1), z=-0.015)
            # gezeichnete Kiste
            bx, by = cx + 0.08, cy - 0.125
            Entity(parent=c, model=Quad(radius=0.12), position=(bx, by, -0.02), scale=(0.11, 0.09),
                   color=color.rgba(accent[0] * 0.55, accent[1] * 0.55, accent[2] * 0.55, 1))
            Entity(parent=c, model=Quad(radius=0.2), position=(bx, by + 0.03, -0.025), scale=(0.12, 0.03),
                   color=color.rgba(*accent, 1))
            Entity(parent=c, model=Quad(radius=0.3), position=(bx, by - 0.005, -0.03), scale=(0.022, 0.03),
                   color=color.rgba(1, 0.92, 0.6, 1))
            Label(c, crate["name"], cx + 0.16, cy - 0.04, size=1.0, col=TEXT)
            odds = "  ·  ".join(f"{K.RARITY[r]['name']} {p} %" for r, p in crate["weights"].items())
            Label(c, odds, cx + 0.16, cy - 0.085, size=0.58, col=FAINT, max_w=cards_w - 0.18)
            price = crate["price"]
            ok = self.account.get("all") or self.account.get("avail", 0) >= price
            Btn(c, f"Öffnen · {price} P", cx + 0.16 + 0.13, cy - 0.19, 0.26, 0.05,
                (lambda kd=kind: self._open_crate(kd)), col=BUTTON_ACCENT if ok else BUTTON_LOCKED, size=0.8)
        # Walze
        self.reel_y = top - 0.47
        panel(c, -w / 2 + 0.03, self.reel_y + 0.09, w - 0.06, 0.18, color.rgba(0.05, 0.05, 0.07, 1), radius=0.012,
              z=-0.005, collider=False)
        Entity(parent=c, model="quad", position=(0, self.reel_y, -0.06), scale=(0.004, 0.19), color=GOLD)
        self.reel = Entity(parent=c)
        self.reel_cards = []
        self.result_l = Label(c, "", 0, self.reel_y - 0.13, size=0.85, col=GOLD, origin=(0, 0))

    def _open_crate(self, kind):
        if self.spinning:
            return
        self.cb["crate"](kind)

    def crate_result(self, kind, sid, text):
        """Antwort vom Server: Walze mit zufälligen Skins füllen, ausrollen und auf dem Gewinn stoppen."""
        import random
        if self.tab != "crates" or getattr(self, "reel", None) is None or not sid:
            self.cb["toast"](text)
            return
        for e in self.reel_cards:
            e.parent = None
        self.reel_cards = []
        crate = K.CRATES.get(kind) or K.CRATES["basic"]
        rar = list(crate["weights"])
        n, win = 44, 38
        cw, gap = 0.12, 0.012
        strip = []
        for i in range(n):
            if i == win:
                strip.append(sid)
                continue
            r = random.choices(rar, [crate["weights"][x] for x in rar])[0]
            style = random.choice([st[0] for st in K.STYLES if st[2] == r])
            strip.append(K.skin_id(random.choice(self._targets()), style))
        for i, s in enumerate(strip):
            card = Entity(parent=self.reel)
            r = K.rarity(s)
            panel(card, -cw / 2, 0.075, cw, 0.15, PANEL_LIGHT, radius=0.01, z=-0.01, collider=False)
            rect(card, -cw / 2 + 0.005, -0.068, cw - 0.01, 0.007, _rc(r), z=-0.015)
            swatch(card, -0.025, 0.025, 0.05, K.style_of(s))
            Label(card, K.STYLE[K.style_of(s)]["name"], 0, -0.025, size=0.55, col=TEXT, origin=(0, 0), max_w=cw - 0.01)
            Label(card, K.target_name(K.parse(s)[0], self.planet), 0, -0.048, size=0.45, col=FAINT, origin=(0, 0),
                  max_w=cw - 0.01)
            card.idx = i
            self.reel_cards.append(card)
        step = cw + gap
        end = win * step + random.uniform(-0.4, 0.4) * cw
        half = self.w / 2 - 0.06 - cw / 2
        y = self.reel_y
        self.spinning = True
        self._spin_text = text

        def place(off):
            for card in self.reel_cards:
                x = card.idx * step - off
                card.enabled = abs(x) <= half
                card.position = (x, y, -0.03)

        def f(v):
            place(end * v)

        def done():
            self.spinning = False
            self._spin_text = ""
            for card in self.reel_cards:
                if card.idx == win:
                    card.scale = 1.12
            self.result_l.set(text)
            self.cb["toast"](text)
            self.cb["won"]()
            if self.account:
                self.points_l.set("Entwickler: alle Skins freigeschaltet" if self.account.get("all")
                                  else f"Erfolgspunkte: {self.account.get('avail', 0)}")
        place(0)
        anim.tween(f, 5.0, ease=anim.out_cubic, done=done, key="wheel")

    def _pick(self, target):
        self.target = target
        self.refresh(self.account, self.planet)

    def _page(self, d):
        pages = max(1, math.ceil(len(self._targets()) / PER_PAGE))
        self.page = (self.page + d) % pages
        self.refresh(self.account, self.planet)

    # ------------------------------------------------------------------ Glücksrad
    def _wheel_mesh(self):
        n = len(K.WHEEL)
        verts, tris, cols = [Vec3(0, 0, 0)], [], [color.rgba(0.1, 0.1, 0.12, 1)]
        palette = [(0.95, 0.55, 0.15), (0.3, 0.55, 0.95), (0.95, 0.75, 0.2), (0.6, 0.4, 0.95),
                   (0.9, 0.45, 0.2), (0.3, 0.7, 0.9), (1.0, 0.82, 0.25), (0.9, 0.35, 0.8)]
        seg = 8
        for i in range(n):
            base = len(verts)
            r, g, b = palette[i % len(palette)]
            for k in range(seg + 1):
                a = math.radians(90 - (i + k / seg) * 360 / n)
                verts.append(Vec3(math.cos(a) * 0.5, math.sin(a) * 0.5, 0))
                cols.append(color.rgba(r, g, b, 1))
            for k in range(seg):
                tris.append((0, base + k, base + k + 1))
        return Mesh(vertices=verts, triangles=tris, colors=cols)

    def _build_wheel(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.03, h / 2 - 0.16
        if not self.account:
            self._need_login(c, top - 0.04)
            return
        Label(c, "Einmal am Tag drehen: Gratis-Skin oder Geld-Boost für die Firma!", x0, top, size=0.85, col=MUTED)
        cx, cy, size = -0.18, -0.1, 0.52
        Entity(parent=c, model=Quad(radius=0.5), position=(cx, cy, -0.005), scale=size + 0.03,
               color=color.rgba(1, 0.75, 0.3, 1))
        self.wheel = Entity(parent=c, position=(cx, cy, -0.01), scale=size)
        Entity(parent=self.wheel, model=self._wheel_mesh(), double_sided=True)
        n = len(K.WHEEL)
        for i, (kind, value, label) in enumerate(K.WHEEL):
            a = math.radians(90 - (i + 0.5) * 360 / n)
            txt = label + (" €" if kind == "money" else "")
            Label(self.wheel, txt, math.cos(a) * 0.33, math.sin(a) * 0.33, size=1.5 / size * 0.5, col=TEXT,
                  origin=(0, 0), z=-0.01, raw=True)
        Entity(parent=c, model=Quad(radius=0.5), position=(cx, cy, -0.03), scale=0.07, color=color.rgba(0.1, 0.1, 0.12, 1))
        # Zeiger oben
        Entity(parent=c, model=Mesh(vertices=[Vec3(-0.025, 0.03, 0), Vec3(0.025, 0.03, 0), Vec3(0, -0.03, 0)],
                                    triangles=[(0, 1, 2)]), position=(cx, cy + size / 2 + 0.01, -0.04),
               color=color.rgba(1, 1, 1, 1), double_sided=True)
        rx = 0.2
        ready = bool(self.account.get("wheel"))
        Label(c, "Gewinne", rx, top - 0.08, size=1.0, col=ACCENT)
        lines = ["Gratis-Skin (selten bis episch)", "2.500 € bis 25.000 € für die Firma",
                 "Neuer Versuch: jeden Tag ab Mitternacht"]
        for i, t in enumerate(lines):                     # Punkt getrennt – sonst greift die Übersetzung nicht
            Label(c, "•", rx, top - 0.14 - i * 0.045, size=0.75, col=MUTED, raw=True)
            Label(c, t, rx + 0.022, top - 0.14 - i * 0.045, size=0.75, col=MUTED)
        Btn(c, "Drehen!" if ready else "Heute schon gedreht", rx + 0.22, top - 0.36, 0.42, 0.07,
            self._spin if ready else (lambda: None), col=BUTTON_ACCENT if ready else BUTTON_LOCKED, size=1.1)
        self.result_l = Label(c, "", rx, top - 0.45, size=0.8, col=GOLD, wordwrap=40)

    def _spin(self):
        if self.spinning:
            return
        self.cb["spin"]()

    def spin_to(self, seg, text):
        """Antwort vom Server: Rad dreht sich und bleibt beim gewonnenen Feld stehen."""
        if self.wheel is None or seg is None:
            if text:
                self.cb["toast"](text)
            return
        import random
        n = len(K.WHEEL)
        start = self.wheel.rotation_z
        # Feld i liegt (ungedreht) bei 90° - (i + 0.5) * 360/n; rotation_z dreht im Uhrzeigersinn. Damit das
        # gewonnene Feld oben unter dem Zeiger stehen bleibt, muss das Rad um -(i + 0.5) * 360/n gedreht sein.
        seg_w = 360 / n
        stop = (-(seg + 0.5) * seg_w + random.uniform(-0.32, 0.32) * seg_w) % 360
        target = start - (start % 360) + 360 * 5 + stop
        wheel = self.wheel
        self.spinning = True
        self._spin_text = text

        def f(v):
            wheel.rotation_z = start + (target - start) * v

        def done():
            self.spinning = False
            self._spin_text = ""
            self.cb["toast"](text)
            self.cb["won"]()
            if self.visible and self.tab == "wheel":
                self.refresh(self.account, self.planet)
                if getattr(self, "result_l", None):
                    self.result_l.set(text)
        anim.tween(f, 4.0, ease=anim.out_cubic, done=done, key="wheel")

    # ------------------------------------------------------------------ Konto
    def _build_account(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.04, h / 2 - 0.17
        a = self.account
        if not a:
            Label(c, "Account anlegen oder einloggen", x0, top, size=1.1, col=ACCENT)
            Label(c, "Dein Account gilt auf diesem Server. Damit kaufst du Skins mit Erfolgspunkten, drehst das "
                     "Glücksrad und kannst anderen Spielern Skins schenken.", x0, top - 0.06, size=0.78, col=MUTED,
                  wordwrap=90)
            y = top - 0.19
            Label(c, "Benutzername", x0, y, size=0.85, col=MUTED)
            self.user = InputField(parent=c, position=(x0 + 0.45, y - 0.012, -0.02), scale=(0.4, 0.05),
                                   character_limit=16)
            y -= 0.08
            Label(c, "Passwort", x0, y, size=0.85, col=MUTED)
            self.pw = InputField(parent=c, position=(x0 + 0.45, y - 0.012, -0.02), scale=(0.4, 0.05),
                                 character_limit=64)
            self.pw.hide_content = True
            y -= 0.1
            Btn(c, "Einloggen", x0 + 0.35, y, 0.2, 0.054, lambda: self.cb["login"](self.user.text, self.pw.text),
                col=BUTTON_ACCENT)
            Btn(c, "Registrieren", x0 + 0.57, y, 0.2, 0.054,
                lambda: self.cb["register"](self.user.text, self.pw.text), col=BUTTON_GOOD)
            Label(c, "Passwörter werden nur verschlüsselt (als Hash) auf dem Server gespeichert. "
                     "Nimm kein Passwort, das du woanders benutzt.", x0, y - 0.07, size=0.68, col=FAINT, wordwrap=100)
            return
        Label(c, f"Eingeloggt als {a['name']}", x0, top, size=1.1, col=ACCENT)
        owned = sorted(s for s in (K.all_ids() if a.get("all") else a.get("owned", []))
                       if K.parse(s)[0] in self._targets())
        Label(c, f"Erfolgspunkte: {a.get('points', 0)} gesammelt, {a.get('spent', 0)} ausgegeben  ·  "
                 f"Skins: {len(owned)}", x0, top - 0.06, size=0.8, col=MUTED)
        Btn(c, "Ausloggen", w / 2 - 0.14, top - 0.01, 0.2, 0.046, self.cb["logout"], size=0.8)
        y = top - 0.16
        Label(c, "Skin verschenken", x0, y, size=1.0, col=ACCENT)
        y -= 0.07
        if not owned:
            Label(c, "Du hast noch keine Skins – kaufe welche oder dreh das Glücksrad.", x0, y, size=0.8, col=FAINT)
            return
        self.gift_idx %= len(owned)
        sid = owned[self.gift_idx]
        Btn(c, "«", x0 + 0.03, y, 0.06, 0.046, lambda: self._gift_step(-1), size=0.9)
        panel(c, x0 + 0.07, y + 0.023, 0.5, 0.046, PANEL_LIGHT, radius=0.008, collider=False)
        Label(c, K.display_name(sid, self.planet), x0 + 0.32, y, size=0.8, col=_rc(K.rarity(sid)), origin=(0, 0),
              raw=True, max_w=0.48)
        Btn(c, "»", x0 + 0.6, y, 0.06, 0.046, lambda: self._gift_step(1), size=0.9)
        y -= 0.08
        Label(c, "An (Benutzername)", x0, y, size=0.85, col=MUTED)
        self.gift_to = InputField(parent=c, position=(x0 + 0.45, y - 0.012, -0.02), scale=(0.4, 0.05),
                                  character_limit=16)
        Btn(c, "Verschenken", x0 + 0.78, y - 0.012, 0.22, 0.05, lambda: self.cb["gift"](sid, self.gift_to.text),
            col=BUTTON_ACCENT)
        if a.get("all"):
            Label(c, "Als Entwickler verschenkst du Kopien – du behältst alle Skins.", x0, y - 0.07, size=0.7, col=FAINT)

    def _gift_step(self, d):
        self.gift_idx += d
        self.refresh(self.account, self.planet)
