"""
Logistik: Übergabe von Gegenständen zwischen Gebäuden, Förderbänder und Verteiler.

Regeln:
* Produktionsgebäude geben nur in Blickrichtung (vorne) aus.
* Förderbänder nehmen von hinten und von den Seiten an, aber nie von dem
  Feld, in das sie selbst hineinfördern.
* Splitter, T-Stück und Sortierer nehmen nur von hinten an und geben nach
  vorne / links / rechts aus (Splitter und T-Stück abwechselnd, der
  Sortierer je nach eingestellter Richtung pro Warenart).
* Ein Gegenstand wird nur übergeben, wenn das Ziel ihn grundsätzlich
  verarbeiten kann ("kompatibel") und gerade Platz hat.
"""

from . import config as C
from . import rules

ERROR_STATES = ("no_output", "bad_output")


def accepts_type(state, target, item):
    """Kann `target` diesen Gegenstandstyp grundsätzlich jemals annehmen?"""
    t = target.type
    if t in C.BELT_LIKE or t in ("storage", "seller", "freight"):
        return True
    if t == "smelter":
        return any(item in r["inputs"] for rid, r in C.RECIPES.items()
                   if r["machine"] == "smelter" and rules.recipe_unlocked(rid, state.research.unlocked))
    if t in C.MACHINE_RECIPES:
        recipe = C.RECIPES.get(target.recipe)
        return bool(recipe) and item in recipe["inputs"]
    return False


def accepts_from(target, src_xy):
    """Nimmt `target` überhaupt etwas von diesem Nachbarfeld an?"""
    t = target.type
    if t == "miner":
        return False
    if t == "conveyor":
        return rules.front_tile(target.x, target.y, target.rot) != tuple(src_xy)
    if t in C.ROUTER_TYPES:
        return rules.back_tile(target.x, target.y, target.rot) == tuple(src_xy)
    return True


def target_at(state, x, y, src_xy):
    """Gibt (ziel, fehlercode) für einen Ausgang auf Feld (x, y) zurück."""
    target = state.building_at(x, y)
    if target is None:
        return None, "no_output"
    if not accepts_from(target, src_xy):
        return None, "bad_output"
    return target, None


def output_target(state, b):
    fx, fy = rules.front_tile(b.x, b.y, b.rot)
    return target_at(state, fx, fy, (b.x, b.y))


def _get(state):
    def get(x, y):
        b = state.building_at(x, y)
        return (b.type, b.rot) if b is not None else None
    return get


def is_curve_from(state, belt, src_xy):
    side = rules.curve_side(belt.x, belt.y, belt.rot, _get(state))
    return side is not None and rules.side_tile(belt.x, belt.y, belt.rot, side) == tuple(src_xy)


def accept(state, target, item, src_xy):
    """Versucht, `item` aus Feld `src_xy` an `target` zu übergeben."""
    if not target.enabled or not accepts_from(target, src_xy):
        return False
    t = target.type
    if t == "conveyor":
        if len(target.items) >= C.BUILDINGS["conveyor"]["capacity"]:
            return False
        entry = 0.0 if rules.back_tile(target.x, target.y, target.rot) == tuple(src_xy) else 0.5
        if entry and is_curve_from(state, target, src_xy):
            entry = 0.0                       # Kurve: Waren laufen den ganzen Bogen entlang
        for _, pos in target.items:
            if abs(pos - entry) < C.BELT_SPACING:
                return False
        target.items.append([item, entry])
        target.items.sort(key=lambda it: -it[1])
        return True

    if t in C.ROUTER_TYPES:
        if len(target.items) >= C.BUILDINGS[t]["capacity"]:
            return False
        if any(pos < 0.5 for _, pos in target.items):
            return False                    # Eingang noch belegt
        target.items.append([item, 0.0])
        return True

    if t == "smelter" or t in C.MACHINE_RECIPES:
        if not accepts_type(state, target, item):
            return False
        cap = C.BUILDINGS[t]["in_cap"]
        need = max((r["inputs"].get(item, 0) for rid, r in C.RECIPES.items() if r["machine"] == t), default=1)
        cap = max(cap, need * 2)
        if target.inbuf.get(item, 0) >= cap:
            return False
        target.inbuf[item] = target.inbuf.get(item, 0) + 1
        return True

    if t == "storage":
        if state.inventory_total() >= state.storage_capacity():
            return False
        state.inventory[item] = state.inventory.get(item, 0) + 1
        target.stored += 1
        return True

    if t == "freight":
        return state.freight.station_accept(state, target, item)

    if t == "seller":
        if len(target.items) >= C.BUILDINGS["seller"]["in_cap"]:
            return False
        target.items.append(item)
        return True

    return False


def push_outputs(state, b):
    """Schiebt höchstens einen Gegenstand aus dem Ausgangspuffer nach vorne.

    Rückgabe: None (alles gut / nichts zu tun), "blocked", "no_output" oder "bad_output".
    """
    target, error = output_target(state, b)
    if error:
        return error
    if not b.outbuf:
        return None
    incompatible = True
    for item in list(b.outbuf.keys()):
        if not accepts_type(state, target, item):
            continue
        incompatible = False
        if accept(state, target, item, (b.x, b.y)):
            b.outbuf[item] -= 1
            if b.outbuf[item] <= 0:
                del b.outbuf[item]
            return None
    return "bad_output" if incompatible else "blocked"


def tick_conveyor(state, b, dt):
    step = C.BELT_SPEED * state.belt_mult * dt * C.BELT_LEVEL_SPEED.get(b.level, 1.0)
    items = b.items
    for i, it in enumerate(items):
        limit = 1.0 if i == 0 else items[i - 1][1] - C.BELT_SPACING
        new_pos = min(it[1] + step, limit)
        if new_pos > it[1]:
            it[1] = new_pos

    target, error = output_target(state, b)
    if items and items[0][1] >= 1.0:
        if error:
            b.status = error
            return
        head = items[0][0]
        if not accepts_type(state, target, head):
            b.status = "bad_output"
            return
        if accept(state, target, head, (b.x, b.y)):
            items.pop(0)
            b.status = "working"
        else:
            b.status = "blocked"
        return

    if error:
        b.status = error
    else:
        b.status = "working" if items else "idle"


def router_sides(b, item):
    """Mögliche Ausgänge für `item` in der Reihenfolge, in der sie versucht werden."""
    if b.type == "sorter":
        return [b.filters.get(item, "F")]
    outs = C.BUILDINGS[b.type]["outputs"]
    start = b.rr % len(outs)
    return outs[start:] + outs[:start]


def tick_router(state, b, dt):
    """Splitter, T-Stück und Sortierer."""
    step = C.BELT_SPEED * state.belt_mult * dt * 1.5 * C.BELT_LEVEL_SPEED.get(b.level, 1.0)
    for i, it in enumerate(b.items):
        limit = 1.0 if i == 0 else b.items[i - 1][1] - 0.5
        it[1] = max(it[1], min(it[1] + step, limit))

    connected = any(state.building_at(*rules.side_tile(b.x, b.y, b.rot, s)) is not None
                    for s in C.BUILDINGS[b.type]["outputs"])
    if not b.items:
        b.status = "idle" if connected else "no_output"
        return
    if b.items[0][1] < 1.0:
        b.status = "working"
        return

    item = b.items[0][0]
    outs = C.BUILDINGS[b.type]["outputs"]
    errors = []
    for side in router_sides(b, item):
        tx, ty = rules.side_tile(b.x, b.y, b.rot, side)
        target, error = target_at(state, tx, ty, (b.x, b.y))
        if error:
            errors.append(error)
            continue
        if not accepts_type(state, target, item):
            errors.append("bad_output")
            continue
        if accept(state, target, item, (b.x, b.y)):
            b.items.pop(0)
            if b.type != "sorter":
                b.rr = (outs.index(side) + 1) % len(outs)
            b.status = "working"
            return
        errors.append("blocked")
    if "blocked" in errors:
        b.status = "blocked"
    elif "bad_output" in errors:
        b.status = "bad_output"
    else:
        b.status = "no_output"
