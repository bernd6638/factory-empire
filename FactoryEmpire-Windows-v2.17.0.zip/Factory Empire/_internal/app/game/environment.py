"""
Umgebung rund um die Fabrik: Tageszeit (Tag, Abend, Nacht, Tageszyklus) und Themen
(Wald, Stadt, Baustelle, Winter). Alles ist reine Deko auf der Erde und wird nur bei Bedarf gebaut.
"""

import math
import random

from panda3d.core import TransparencyAttrib
from ursina import Entity, camera, color, scene, window

from . import config as C
from . import graphics
from . import models
from . import textures

THEMES = ["forest", "city", "construction", "winter"]
TIMES = ["day", "evening", "night", "cycle"]
CYCLE_SECONDS = 720.0                    # ein ganzer Tag im Tageszyklus (12 Minuten)

DAY_SUN = (1.0, 0.95, 0.86)
EVENING_SUN = (1.0, 0.58, 0.32)
NIGHT_SUN = (0.22, 0.3, 0.52)            # Mondlicht
DAY_FOG = (0.74, 0.81, 0.88)
EVENING_FOG = (0.86, 0.6, 0.5)
NIGHT_FOG = (0.035, 0.05, 0.1)


def _lerp(a, b, t):
    return tuple(x + (y - x) * t for x, y in zip(a, b))


def cycle_phase(t):
    """Tageszyklus: gibt (nacht 0..1, abendrot 0..1) für die Zeit t zurück."""
    p = (t / CYCLE_SECONDS) % 1.0
    if p < 0.42:                          # Tag
        return 0.0, 0.0
    if p < 0.52:                          # Sonnenuntergang
        k = (p - 0.42) / 0.10
        return max(0.0, (k - 0.5) * 2) * 0.6, math.sin(k * math.pi)
    if p < 0.88:                          # Nacht
        k = min(1.0, (p - 0.52) / 0.06)
        return 0.6 + 0.4 * k, 0.0
    k = (p - 0.88) / 0.12                 # Morgengrauen
    return (1 - k), math.sin(k * math.pi) * 0.7


def mode_phase(mode, t):
    if mode == "evening":
        return 0.25, 1.0
    if mode == "night":
        return 1.0, 0.0
    if mode == "cycle":
        return cycle_phase(t)
    return 0.0, 0.0


class Environment:
    def __init__(self, world):
        self.world = world
        self.theme = "forest"
        self.mode = "day"
        self.t = CYCLE_SECONDS * 0.2
        self.night = 0.0
        self.glow = 0.0
        self._applied = None
        self.city = None
        self.site = None
        self.snow_forest = None
        self.stars = None
        self.snow = None
        self.flakes = []
        self.pools = self._lamp_pools()

    # ------------------------------------------------------------------ Einstellungen
    def set_theme(self, theme):
        theme = theme if theme in THEMES else "forest"
        if theme == self.theme and self._applied is not None:
            return
        self.theme = theme
        w = self.world
        if theme == "city" and self.city is None:
            self.city = self._build_city()
        if theme == "construction" and self.site is None:
            self.site = self._build_site()
        if theme == "winter" and self.snow_forest is None:
            from . import scenery
            from .world import factory_distance, in_lake, terrain_height
            from . import teaser

            def skip(x, z):
                return in_lake(x, z, 2.5) or abs(z - scenery.ROAD_Z) < scenery.ROAD_W / 2 + 1.6 or teaser.in_area(x, z, 1.5)
            self.snow_forest = scenery.build_forest(w.center, terrain_height, factory_distance, skip, snow=True)
        self._show_theme()
        self._applied = None

    def set_mode(self, mode):
        self.mode = mode if mode in TIMES else "day"
        self._applied = None

    def _show_theme(self):
        w, th = self.world, self.theme
        earth = w.planet == "earth"
        winter, city = th == "winter", th == "city"
        w.forest.enabled = earth and th in ("forest", "construction")
        if self.snow_forest is not None:
            self.snow_forest.enabled = earth and winter
        for e in (w.trees_trunk, w.trees_crown):
            e.enabled = earth and not city and not winter
        for e in (w.bushes, w.small_plants):
            e.enabled = earth and getattr(w, "scenery", True) and not winter and th != "construction"
        if self.city is not None:
            self.city.enabled = earth and city
        if self.site is not None:
            self.site.enabled = earth and th == "construction"
        from . import world as world_mod
        if world_mod.WINTER["on"] != (winter and earth):
            world_mod.WINTER["on"] = winter and earth
            w.rebuild_ground()
        tex = textures.texture("snow" if winter and earth else "grass")
        for e in (w.ground, w.terrain):
            e.texture = tex
        w.water.color = color.rgba(0.82, 0.9, 1.0, 1.0) if winter else color.rgba(1, 1, 1, 0.88)
        w.water.texture = textures.texture("snow" if winter else "water")
        if winter and self.snow is None:
            from .sprites import SpriteBatch
            self.snow = SpriteBatch(None, name="snow", bin_order=8)
            rng = random.Random(3)
            self.flakes = [[rng.uniform(-40, 40), rng.uniform(0, 30), rng.uniform(-40, 40),
                            rng.uniform(0.6, 1.4), rng.uniform(0, 6.3)] for _ in range(700)]
        if self.snow is not None:
            self.snow.set_visible(earth and winter)

    # ------------------------------------------------------------------ Licht
    def apply(self, force=False):
        """Licht, Himmel, Nebel und Leuchten passend zur Tageszeit setzen (nur auf der Erde)."""
        w = self.world
        if w.planet != "earth":
            return
        n, e = mode_phase(self.mode, self.t)
        key = (round(n, 3), round(e, 3), self.theme)
        if key == self._applied and not force:
            return
        self._applied = key
        self.night, self.glow = n, e
        sun = _lerp(_lerp(DAY_SUN, EVENING_SUN, e), NIGHT_SUN, n)
        w.sun.color = color.rgba(*sun, 1)
        amb = (1 - 0.22 * e) * (1 - n) + 0.38 * n
        amb_rgb = (amb * (1 - 0.15 * n), amb * (1 - 0.08 * n), amb * (1 + 0.25 * n))
        graphics.set_ambient(amb_rgb)
        w.ambient.color = color.rgba(0.46 * amb_rgb[0], 0.49 * amb_rgb[1], 0.56 * amb_rgb[2], 1)
        day_fog = (0.86, 0.9, 0.95) if self.theme == "winter" else DAY_FOG
        fog = _lerp(_lerp(day_fog, EVENING_FOG, e), NIGHT_FOG, n)
        rng = _lerp((55.0, 240.0), (38.0, 185.0), n)
        if self.theme == "winter":
            rng = (rng[0] * 0.8, rng[1] * 0.8)
        graphics.FOG["color"], graphics.FOG["range"] = fog, rng
        graphics.set_fog(fog, rng, 1.0)
        window.color = color.rgba(*fog, 1)
        sky = _lerp(_lerp((1, 1, 1), (1.0, 0.72, 0.58), e), (0.07, 0.09, 0.2), n)
        w.sky.color = color.rgba(*sky, 1)
        for c in w.clouds:
            c.setColorScale(*_lerp(_lerp((1, 1, 1), (1.0, 0.7, 0.6), e), (0.18, 0.2, 0.3), n), 1)
        # Sterne
        if n > 0.2 and self.stars is None:
            from .space import star_field
            self.stars = star_field(scene, radius=760, count=1300, seed=31)
        if self.stars is not None:
            self.stars.enabled = n > 0.2
            self.stars.setColorScale(1, 1, 1, max(0.0, min(1.0, (n - 0.2) / 0.6)))
        # Laternen und Lichtkegel am Boden
        glow = max(n, e * 0.5)
        w.lamps.setColorScale(1 + 1.5 * glow, 1 + 1.3 * glow, 1 + 0.8 * glow, 1)
        self.pools.enabled = glow > 0.05
        self.pools.setColorScale(1, 1, 1, min(1.0, glow * 1.1))
        if self.city is not None and hasattr(self.city, "windows"):
            self.city.windows.setColorScale(*_lerp((0.42, 0.48, 0.58), (1.6, 1.4, 1.0), n), 1)
        if self.site is not None and hasattr(self.site, "lights"):
            self.site.lights.setColorScale(*_lerp((0.6, 0.6, 0.6), (1.8, 1.7, 1.4), n), 1)
            self.site.cones.enabled = n > 0.3
            self.site.cones.setColorScale(1, 1, 1, min(1.0, n))
        w.water.setColorScale(*_lerp((1, 1, 1), (0.3, 0.35, 0.55), n), 1)

    # ------------------------------------------------------------------ pro Bild
    def update(self, dt):
        w = self.world
        if w.planet != "earth":
            return
        self.t += dt
        if self.mode == "cycle":
            self.apply()
        if self.stars is not None and self.stars.enabled:
            self.stars.world_position = camera.world_position
        if self.snow is not None and self.theme == "winter" and getattr(w, "scenery", True):
            cp = camera.world_position
            out = []
            for f in self.flakes:
                f[1] -= dt * 2.2 * f[3]
                f[4] += dt * 1.3
                if f[1] < -2:
                    f[1] += 32
                x = cp.x + (f[0] + math.sin(f[4]) * 0.6 - cp.x) % 80 - 40
                z = cp.z + (f[2] - cp.z) % 80 - 40
                y = max(0.0, cp.y - 18) + f[1]
                if abs(x - cp.x) < 5 and abs(z - cp.z) < 5 and abs(y - cp.y) < 5:
                    continue                                  # nicht direkt vor der Kamera (große Flocken)
                s = 0.045 * f[3]
                out.append((x, y, z, s, s, 0.95, 0.97, 1.0, 0.8))
            self.snow.write(out)

    # ------------------------------------------------------------------ Bauten
    def _lamp_pools(self):
        """Lichtkegel der Zaun-Laternen auf dem Boden (nur abends/nachts sichtbar)."""
        mb = models.MeshBuilder()
        for (lx, lz) in self.world._lamp_positions():
            for r, a in ((2.6, 0.18), (1.6, 0.25), (0.8, 0.3)):
                mb.add("cyl", (lx, 0.03, lz), (r * 2, 0.01, r * 2), (1.0, 0.85, 0.5), alpha=a)
        e = Entity(model=mb.build(), shader=graphics.unlit())
        e.setTransparency(TransparencyAttrib.M_alpha)
        e.setDepthWrite(False)
        e.setLightOff()
        e.enabled = False
        return e

    def _ring_spots(self, rng, count, dmin, dmax, cell, avoid=2.0):
        from . import scenery
        from . import teaser
        from .world import factory_distance, in_lake
        cx, cz = self.world.center.x, self.world.center.z
        spots = []
        tries = 0
        while len(spots) < count and tries < count * 40:
            tries += 1
            a = rng.uniform(0, 2 * math.pi)
            d = rng.uniform(dmin, dmax)
            x, z = cx + math.cos(a) * (d + C.GRID_W / 2), cz + math.sin(a) * (d + C.GRID_H / 2)
            fd = factory_distance(x, z)
            if fd < dmin or in_lake(x, z, cell + avoid) or abs(z - scenery.ROAD_Z) < scenery.ROAD_W / 2 + cell \
                    or teaser.in_area(x, z, cell + 2):
                continue
            if any(abs(x - sx) < (cell + sc) * 0.6 and abs(z - sz) < (cell + sc) * 0.6 for sx, sz, sc in spots):
                continue
            spots.append((x, z, cell))
        return spots

    def _build_city(self):
        from .world import terrain_height
        rng = random.Random(1907)
        body, wins = models.MeshBuilder(2.0), models.MeshBuilder(1.0)
        palette = [(0.62, 0.62, 0.64), (0.55, 0.5, 0.46), (0.68, 0.6, 0.52), (0.45, 0.48, 0.55),
                   (0.72, 0.7, 0.66), (0.5, 0.36, 0.3), (0.35, 0.42, 0.5)]
        spots = self._ring_spots(rng, 170, 16, 85, 6.0)
        spots += self._ring_spots(rng, 120, 85, 170, 9.0)
        for x, z, cell in spots:
            far = cell > 7
            fw, fd = rng.uniform(0.55, 0.9) * cell, rng.uniform(0.55, 0.9) * cell
            d = math.hypot(x - self.world.center.x, z - self.world.center.z)
            fdist = d - C.GRID_W / 2
            if fdist < 40:
                h = rng.uniform(3.5, 8)                        # vorne: niedrige Häuser, freie Sicht
            elif fdist < 75:
                h = rng.uniform(7, 18)
            else:
                h = rng.uniform(14, 40 if far else 30)         # hinten: Skyline
                if rng.random() < 0.12:
                    h *= 1.6                                   # einzelne Hochhäuser
            y = terrain_height(x, z) - 1.5
            col = rng.choice(palette)
            body.add("box", (x, y + h / 2 + 0.75, z), (fw, h + 1.5, fd), col)
            body.add("box", (x, y + h + 1.6, z), (fw * 0.6, 0.8, fd * 0.6), (col[0] * 0.8, col[1] * 0.8, col[2] * 0.8))
            if rng.random() < 0.4:                             # Antenne / Dachaufbau
                body.add("cyl6", (x + fw * 0.2, y + h + 3.0, z), (0.12, 2.6, 0.12), (0.3, 0.3, 0.32))
            # Fensterbänder je Etage auf allen vier Seiten
            floors = int(h / 2.6)
            for f in range(1, floors + 1):
                fy = y + 1.5 + f * 2.6 - 0.9
                for side in range(4):
                    if rng.random() < 0.18:
                        continue
                    lit = rng.random() < 0.65
                    wc = (1.0, 0.86, 0.55) if lit else (0.25, 0.3, 0.38)
                    if side < 2:
                        sz = fd / 2 + 0.02
                        wins.add("box", (x, fy, z + (sz if side == 0 else -sz)), (fw * 0.82, 0.9, 0.04), wc)
                    else:
                        sx = fw / 2 + 0.02
                        wins.add("box", (x + (sx if side == 2 else -sx), fy, z), (0.04, 0.9, fd * 0.82), wc)
        root = Entity()
        Entity(parent=root, model=body.build(), shader=graphics.lit_shader(), texture=textures.texture("metal"))
        root.windows = Entity(parent=root, model=wins.build(), shader=graphics.unlit())
        root.windows.setLightOff()
        root.enabled = False
        return root

    def _build_site(self):
        from .world import terrain_height
        rng = random.Random(77)
        mb, lights, cones = models.MeshBuilder(2.0), models.MeshBuilder(1.0), models.MeshBuilder(1.0)
        YEL, DARK, STEEL = (0.95, 0.72, 0.1), (0.15, 0.15, 0.17), (0.55, 0.57, 0.6)
        for x, z, cell in self._ring_spots(rng, 70, 6, 46, 5.0):
            y = terrain_height(x, z)
            kind = rng.random()
            if kind < 0.1:                                     # Turmdrehkran
                H = rng.uniform(16, 26)
                a = rng.uniform(0, 360)
                for k in range(int(H / 2)):
                    mb.add("box", (x, y + k * 2 + 1, z), (0.9, 2.0, 0.9), YEL if k % 2 else (0.85, 0.62, 0.08))
                ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
                mb.add("box", (x + ca * 6, y + H + 0.4, z + sa * 6), (16, 0.6, 0.6), YEL, (0, -a, 0))
                mb.add("box", (x - ca * 3.5, y + H, z - sa * 3.5), (1.6, 1.4, 1.6), (0.5, 0.5, 0.52))
                mb.add("box", (x, y + H + 1.4, z), (1.2, 1.4, 1.2), YEL)
                hx, hz = x + ca * 11, z + sa * 11
                mb.add("cyl6", (hx, y + H / 2 + 2, hz), (0.05, H - 3, 0.05), DARK)
                lights.add("box", (x, y + H + 2.3, z), (0.3, 0.3, 0.3), (1.0, 0.25, 0.15))
            elif kind < 0.3:                                   # Container-Stapel
                cols = [(0.75, 0.2, 0.15), (0.15, 0.35, 0.6), (0.2, 0.5, 0.3), (0.85, 0.55, 0.15)]
                rot = rng.choice((0, 90))
                for k in range(rng.randint(1, 3)):
                    mb.add("box", (x, y + 0.65 + k * 1.3, z), (3.0, 1.25, 1.25), rng.choice(cols), (0, rot, 0))
            elif kind < 0.48:                                  # Erdhügel
                s = rng.uniform(2, 4)
                mb.add("ico", (x, y - s * 0.2, z), (s * 1.6, s * 0.8, s * 1.4), (0.42, 0.32, 0.22))
            elif kind < 0.6:                                   # Bagger
                rot = rng.uniform(0, 360)
                mb.add("box", (x, y + 0.45, z), (2.2, 0.7, 1.4), DARK, (0, rot, 0))
                mb.add("box", (x, y + 1.2, z), (1.7, 0.9, 1.3), YEL, (0, rot, 0))
                ca, sa = math.cos(math.radians(rot)), math.sin(math.radians(rot))
                mb.add("box", (x + ca * 1.6, y + 1.7, z - sa * 1.6), (2.2, 0.3, 0.3), YEL, (0, rot, 30))
                mb.add("box", (x + ca * 2.7, y + 1.0, z - sa * 2.7), (0.6, 0.5, 0.6), DARK, (0, rot, 0))
            elif kind < 0.75:                                  # Rohbau mit Gerüst
                w, d, h = rng.uniform(4, 7), rng.uniform(4, 7), rng.uniform(4, 9)
                mb.add("box", (x, y + 0.2, z), (w + 1, 0.4, d + 1), (0.6, 0.6, 0.6))
                for px in (-1, 1):
                    for pz in (-1, 1):
                        mb.add("box", (x + px * w / 2, y + h / 2, z + pz * d / 2), (0.35, h, 0.35), (0.7, 0.7, 0.7))
                for fy in range(1, int(h / 3) + 1):
                    mb.add("box", (x, y + fy * 3, z), (w, 0.3, d), (0.68, 0.68, 0.68))
                for k in range(int(h)):
                    mb.add("box", (x + w / 2 + 0.6, y + k + 0.5, z), (0.05, 1.0, d + 1), STEEL)
            elif kind < 0.88:                                  # Bauzaun mit Warnbaken
                rot = rng.choice((0, 90))
                for k in range(-3, 4):
                    ox, oz = (k * 1.2, 0) if rot == 0 else (0, k * 1.2)
                    mb.add("box", (x + ox, y + 0.5, z + oz), (1.1 if rot == 0 else 0.05, 1.0, 0.05 if rot == 0 else 1.1),
                           (0.8, 0.8, 0.82))
                    mb.add("cone", (x + ox, y + 0.35, z + oz + 0.8), (0.4, 0.7, 0.4), (1.0, 0.45, 0.1))
            else:                                              # Flutlichtmast
                mb.add("cyl6", (x, y + 4, z), (0.2, 8, 0.2), STEEL)
                mb.add("box", (x, y + 8.1, z), (1.4, 0.5, 0.4), DARK)
                lights.add("box", (x, y + 8.0, z + 0.22), (1.2, 0.35, 0.05), (1.0, 0.95, 0.8))
                for r, a in ((7.0, 0.12), (4.5, 0.16), (2.5, 0.2)):
                    cones.add("cyl", (x, y + 0.05, z + 2.5), (r * 2, 0.01, r * 2), (1.0, 0.95, 0.8), alpha=a)
        root = Entity()
        Entity(parent=root, model=mb.build(), shader=graphics.lit_shader(), texture=textures.texture("metal"))
        root.lights = Entity(parent=root, model=lights.build(), shader=graphics.unlit())
        root.lights.setLightOff()
        root.cones = Entity(parent=root, model=cones.build(), shader=graphics.unlit())
        root.cones.setTransparency(TransparencyAttrib.M_alpha)
        root.cones.setDepthWrite(False)
        root.cones.setLightOff()
        root.enabled = False
        return root
