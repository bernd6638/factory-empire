"""
Darstellung der Gebäude im Client.

BuildingView zeigt ein Gebäude inklusive Animationen, Partikeln,
Statuslampe, Warnsymbol, Ausbaustufe, An/Aus-Zustand und transportierten
Gegenständen. Die eigentliche Spiellogik läuft auf dem Server – hier wird
nur dargestellt.
"""

import math
import random
import time

from panda3d.core import NodePath, Point3, TextureStage, TransparencyAttrib
from ursina import Entity, Text, Vec2, Vec3, color, destroy

from . import config as C
from . import effects
from . import graphics
from . import models
from . import textures

STATUS_COLORS = {
    "ok": color.rgba(0.30, 0.95, 0.45, 1),
    "warn": color.rgba(1.00, 0.78, 0.20, 1),
    "error": color.rgba(1.00, 0.25, 0.20, 1),
    "off": color.rgba(0.35, 0.36, 0.40, 1),
}
OUTPUT_TYPES = ("miner", "smelter", "conveyor") + tuple(C.MACHINE_RECIPES)
# Öfen mit Glut-Öffnung: (Position Glut, Größe, Position Leuchten, Rauch-Austritt)
FURNACES = {
    "smelter": ((0, 0.31, 0.406), (0.38, 0.28), (0, 0.33, 0.55), (0.22, 1.5, -0.22)),
    "kiln": ((-0.08, 0.31, 0.416), (0.3, 0.18), (-0.08, 0.32, 0.56), (-0.3, 1.32, -0.3)),
    "blast_furnace": ((0, 0.3, 0.424), (0.26, 0.16), (0, 0.32, 0.58), (0, 1.45, -0.05)),
}
SIDE_OFFSETS = {"F": (0.0, 0.5), "L": (-0.5, 0.0), "R": (0.5, 0.0)}

_mesh_cache = {}


def _E(**kwargs):
    """Entity, die Ursina NICHT in seine Jeden-Frame-Liste aufnimmt.

    Gebäudeteile brauchen kein eigenes update() – die Animation steuert der Client gezielt.
    Ohne diese Liste bleibt Ursinas Hauptschleife auch bei tausenden Gebäudeteilen schnell,
    und Abreißen hinterlässt keine Leichen in der Liste (die das Spiel mit der Zeit bremsten)."""
    return Entity(add_to_scene_entities=False, **kwargs)


def _T(**kwargs):
    from ursina import scene
    t = Text(**kwargs)
    try:                                   # Text trägt sich selbst ein – wieder austragen
        scene.entities.remove(t)
    except ValueError:
        pass
    return t


def _mesh(key, factory):
    moon = models.PLANET["cur"] == "moon" and not (isinstance(key, tuple) and key[0] == "item")
    if moon:
        key = ("moon", key)                       # Mond-Look: eigene, umgefärbte Meshes
    mesh = _mesh_cache.get(key)
    if mesh is None:
        models.TINT["on"] = moon
        try:
            mesh = _mesh_cache[key] = factory()
        finally:
            models.TINT["on"] = False
    return mesh


def recolor_mesh(src, dark, light):
    """Zweifarbige Skin-Lackierung: jede Vertex-Farbe wird nach ihrer Helligkeit auf den Verlauf
    dunkel -> hell gelegt (ein wenig der Originalfarbe bleibt für Details erhalten)."""
    from panda3d.core import GeomNode, GeomVertexReader, GeomVertexRewriter
    np = src.copyTo(NodePath("skin"))
    nodes = [n for n in [np] + list(np.findAllMatches("**")) if isinstance(n.node(), GeomNode)]
    lums = []
    for n in nodes:                                   # 1. Durchgang: Helligkeitsbereich bestimmen
        gn = n.node()
        for i in range(gn.getNumGeoms()):
            vd = gn.getGeom(i).getVertexData()
            if not vd.hasColumn("color"):
                continue
            rd = GeomVertexReader(vd, "color")
            while not rd.isAtEnd():
                c = rd.getData4()
                lums.append(0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2])
    if not lums:
        return np
    lums.sort()
    lo, hi = lums[len(lums) // 20], lums[-1 - len(lums) // 20]
    span = max(0.05, hi - lo)
    for n in nodes:                                   # 2. Durchgang: umfärben
        gn = n.node()
        for i in range(gn.getNumGeoms()):
            geom = gn.modifyGeom(i)
            vd = geom.modifyVertexData()
            if not vd.hasColumn("color"):
                continue
            rw = GeomVertexRewriter(vd, "color")
            while not rw.isAtEnd():
                c = rw.getData4()
                lum = 0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]
                t = max(0.0, min(1.0, (lum - lo) / span))
                t = t * t * (3 - 2 * t)
                out = [dark[k] + (light[k] - dark[k]) * t for k in range(3)]
                rw.setData4(*(min(1.0, out[k] * 0.82 + c[k] * 0.18) for k in range(3)), c[3])
    return np


def instanced(parent, key, factory, **kwargs):
    """Entity mit geteiltem Mesh. Jedes Mesh wird nur einmal erzeugt und dann
    per Instanzierung wiederverwendet – schnell, auch bei hunderten Gebäuden."""
    e = _E(parent=parent, **kwargs)
    mesh = _mesh(key, factory)
    mesh.instanceTo(e)
    e.mesh_src = mesh                     # für das Zusammenfassen (batching.py)
    return e


BATCHER = {"inst": None}                  # wird vom Client gesetzt (batching.Batcher)


# Waren auf Bändern: einfache Panda-Knoten aus einem Pool statt Ursina-Entities.
# Erzeugen/Löschen kostet so praktisch nichts – vorher war das bei großen Fabriken der Hauptgrund für Ruckler.
_item_pool = {}


def acquire_item(holder, item):
    pool = _item_pool.get(item)
    if pool:
        np = pool.pop()
    else:
        np = NodePath("item")
        _mesh(("item", item), lambda: models.item_mesh(item, C.ITEMS[item]["color"])).instanceTo(np)
    np.reparentTo(holder)
    return np


def release_item(np, item):
    np.detachNode()
    _item_pool.setdefault(item, []).append(np)


def apply_texture(entity, name):
    tex = textures.texture(name)
    if tex is not None:
        entity.setTexture(tex._texture, 1)


def make_item_entity(parent, item):
    """Einzelne Ware als Entity (Vorschau/Deko außerhalb der Bänder)."""
    e = instanced(parent, ("item", item), lambda: models.item_mesh(item, C.ITEMS[item]["color"]),
                  shader=graphics.lit_shader())
    apply_texture(e, "metal")
    e.item = item
    return e


def badge(parent, text, bg, pos, w, h, text_scale, enabled=True):
    """Schild in der 3D-Welt, das sich immer zur Kamera dreht (Hintergrund + Text)."""
    from ursina import Quad
    root = _E(parent=parent, position=pos, billboard=True, enabled=enabled)
    back = _E(parent=root, model=Quad(radius=0.5 if w == h else 0.35, aspect=w / h), scale=(w, h), color=bg,
                  shader=graphics.unlit())
    back.setLightOff()
    root.badge_text = _T(parent=root, text=text, origin=(0, 0), scale=text_scale, z=-0.01, color=color.white)
    root.badge_bg = back
    return root


SIGNS = {"on": True}                      # Schilder über Maschinen: was wird hier hergestellt?


# Warn- und "Aus"-Schilder aller Gebäude: werden vom Client gesammelt in je EIN Modell geschrieben
# (sprites.SpriteBatch) – früher war jedes Schild ein eigener Zeichenaufruf.
BADGES = {"warn": set(), "off": set()}
TRUCK_EVENTS = {"cb": None}
CURVE_SIGN = -1                           # Drehsinn Ursina (Grad im Uhrzeigersinn) -> Panda3D-Heading               # Client: LKW fährt ab / kommt an (für Verkehr auf der Straße)


def badge_sprites(t):
    """Sprite-Listen (warn, off) für sprites.SpriteBatch.write."""
    warn = [(v.x, v.height + 0.45 + 0.06 * math.sin(t * 5 + v.x * 0.7), v.y, 0.17, 0.17, 1.0, 1.0, 1.0, 1.0)
            for v in BADGES["warn"]]
    off = [(v.x, v.height + 0.42, v.y, 0.25, 0.11, 1.0, 1.0, 1.0, 1.0) for v in BADGES["off"]]
    return warn, off


def status_level(status):
    return C.STATUS.get(status, {"level": "warn"})["level"]


def static_row_parts(row):
    """Entpackt eine Zeile aus dem Server-Snapshot (robust gegen ältere Formate)."""
    bid, btype, x, y, rot, level, recipe, owner = row[:8]
    enabled = row[8] if len(row) > 8 else True
    cfg = row[9] if len(row) > 9 and isinstance(row[9], dict) else {}
    return bid, btype, x, y, rot, level, recipe, owner, enabled, cfg


class BuildingView:
    def __init__(self, data, animate_spawn=False):
        bid, btype, x, y, rot, level, recipe, owner, enabled, cfg = static_row_parts(data)
        self.id = bid
        self.type = btype
        self.x, self.y = x, y
        self.rot = rot
        self.level = 0
        self.recipe = recipe
        self.owner = owner
        self.enabled = enabled
        self.cfg = cfg
        self.status = "idle"
        self.progress = 0.0
        self.extra = {}
        self._dyn_seen = False
        self.on_screen = True        # vom Client gesetzt (sichtbar im Bild?)
        self.anim_t = random.random() * 10
        self.fx_t = random.random()
        self.spawn_t = 0.0 if animate_spawn else 1.0
        self.height = models.HEIGHTS[btype]
        self.last_earned = None
        self.last_made = None
        lit = graphics.lit_shader()

        self.root = _E(position=Vec3(x, 0, y), rotation_y=rot * 90)
        self.skin_sid = None
        self.body = self._make_body(("static", btype), lambda: models.static_mesh(btype), lit)

        self.parts = {}
        self.items = []                    # Band/Verteiler: Liste von [entity, item, pos]
        self.pips = []
        self._build_animated_parts(lit)

        if btype not in C.BELT_LIKE:
            self.lamp = _E(parent=self.root, model="sphere", scale=0.085, shader=graphics.unlit(),
                               position=(0.39, 0.2, 0.39), color=STATUS_COLORS["warn"])
        else:
            self.lamp = None
        # Warn-/Aus-Schilder erst bei Bedarf erzeugen
        self._badges = set()
        self.curve = None                  # Förderband-Kurve: "L" / "R" / None
        self.join = None                   # gerades Band mit seitlichem Zulauf: "L" / "R" / None
        self.batched = False               # unbewegliche Teile stecken im Abschnitts-Bündel (batching.py)
        self.far = False
        self.chunk = None
        self.changed_at = time.time()
        self.set_level(level)
        self.set_enabled(enabled)
        if self.type in C.MACHINE_RECIPES:
            self.update_sign()
        if animate_spawn:
            self.root.scale = 0.2
            effects.get().emit(Vec3(x, 0.1, y), "poof", 10, force=True)

    # ------------------------------------------------------------------ Aufbau
    def _build_animated_parts(self, lit):
        t = self.type
        if t == "miner":
            self.parts["rotor"] = instanced(self.root, "rotor", lambda: models.mesh_from_parts([
                ("cyl6", (0, 0, 0), (0.24, 0.34, 0.24), models.STEEL),
                ("box", (0, 0.05, 0), (0.38, 0.06, 0.06), models.YELLOW),
                ("box", (0, -0.05, 0), (0.06, 0.06, 0.38), models.YELLOW),
                ("cone6", (0, -0.3, 0), (0.12, 0.26, 0.12), models.DARK, (180, 0, 0))]),
                position=(0, 1.0, -0.2), shader=lit)
            self.parts["piston"] = instanced(self.root, "piston", lambda: models.mesh_from_parts([
                ("cyl8", (0, 0, 0), (0.06, 0.3, 0.06), models.LIGHT_STEEL)]), position=(0.28, 0.95, 0.12), shader=lit)
        elif t in FURNACES:
            gpos, gscale, hpos, _ = FURNACES[t]
            glow = _E(parent=self.root, model="quad", position=gpos, scale=gscale,
                          rotation_y=180, shader=graphics.unlit(), color=color.rgba(0.25, 0.1, 0.05, 1),
                          double_sided=True)
            glow.setLightOff()
            self.parts["glow"] = glow
            halo = _E(parent=self.root, model="quad", texture=textures.texture("glow"), position=hpos,
                          scale=0.9, billboard=True, shader=graphics.unlit(), color=color.rgba(1, 0.5, 0.15, 0))
            halo.setTransparency(TransparencyAttrib.M_alpha)
            halo.setDepthWrite(False)
            halo.setLightOff()
            self.parts["halo"] = halo
        elif t == "conveyor":
            moon = models.PLANET["cur"] == "moon"           # Magnetband: bläulich, Pfeile leuchten türkis
            belt = _E(parent=self.root, model="quad", texture=textures.texture("belt"), position=(0, 0.103, 0),
                          rotation=(90, 0, 0), scale=(0.82, 1.0), shader=graphics.lit_shader(),
                          color=color.rgba(0.62, 0.8, 1.0, 1) if moon else color.rgba(1, 1, 1, 1))
            self.parts["belt"] = belt
            arrows = _E(parent=self.root, model="quad", texture="arrow_right", position=(0, 0.108, 0),
                            rotation=(90, -90, 0), scale=(0.9, 0.5), shader=graphics.unlit(),
                            color=color.rgba(0.25, 0.9, 1.0, 0.65) if moon else color.rgba(0.98, 0.75, 0.2, 0.55))
            arrows.setTransparency(TransparencyAttrib.M_alpha)
            arrows.setDepthWrite(False)
            self.parts["arrows"] = arrows
            self.tex_offset = 0.0
        elif t in C.ROUTER_TYPES:
            spinner = instanced(self.root, ("spinner", t), lambda: models.mesh_from_parts([
                ("box", (0, 0, 0.1), (0.05, 0.03, 0.2), models.YELLOW),
                ("cyl8", (0, 0, 0), (0.1, 0.04, 0.1), models.DARK)]), position=(0, 0.42, 0), shader=lit)
            self.parts["spinner"] = spinner
            self.parts["side_marks"] = {}
            for side in C.BUILDINGS[t]["outputs"]:
                ox, oz = SIDE_OFFSETS[side]
                mark = _E(parent=self.root, model="quad", texture="arrow_right", shader=graphics.unlit(),
                              position=(ox * 0.78, 0.12, oz * 0.78), scale=0.24,
                              rotation=(90, {"F": -90, "L": 180, "R": 0}[side], 0),
                              color=color.rgba(0.4, 1, 0.5, 0.8))
                mark.setTransparency(TransparencyAttrib.M_alpha)
                self.parts["side_marks"][side] = mark
            if t == "sorter":
                self.parts["labels"] = {}
                for side in ("L", "R", "F"):
                    ox, oz = SIDE_OFFSETS[side]
                    lbl = _T(parent=self.root, text="", origin=(0, 0), billboard=True, scale=4,
                               position=(ox * 0.95, 0.6, oz * 0.95), color=color.white)
                    self.parts["labels"][side] = lbl
        elif t == "seller":
            self.parts["coin"] = instanced(self.root, "coin", lambda: models.mesh_from_parts([
                ("cyl", (0, 0, 0), (0.3, 0.05, 0.3), models.GOLD, (90, 0, 0)),
                ("cyl", (0, 0, 0), (0.2, 0.06, 0.2), (0.95, 0.68, 0.15), (90, 0, 0))]),
                position=(0, 1.15, -0.12), shader=lit)
        elif t == "storage":
            _E(parent=self.root, model="cube", position=(-0.455, 0.44, 0.18), scale=(0.02, 0.5, 0.08),
                   color=color.rgba(0.08, 0.08, 0.1, 1), shader=graphics.unlit())
            self.parts["fill"] = _E(parent=self.root, model="cube", position=(-0.468, 0.19, 0.18),
                                        scale=(0.02, 0.0, 0.06), origin_y=-0.5, shader=graphics.unlit(),
                                        color=STATUS_COLORS["ok"])
            crates = []
            for i, (cx, cz) in enumerate(((0.33, 0.44), (0.13, 0.47), (0.33, 0.44), (-0.3, 0.46))):
                crate = instanced(self.root, "crate", lambda: models.mesh_from_parts([
                    ("box", (0, 0, 0), (0.17, 0.17, 0.12), models.WOOD),
                    ("box", (0, 0, 0.061), (0.13, 0.03, 0.01), models.DARK),
                    ("box", (0, 0, 0.061), (0.03, 0.13, 0.01), models.DARK)]),
                    shader=lit, position=(cx, 0.21 + (0.18 if i == 2 else 0), cz), enabled=False)
                apply_texture(crate, "wood")
                crates.append(crate)
            self.parts["crates"] = crates
        elif t == "freight":
            truck = instanced(self.root, "truck", lambda: models.mesh_from_parts(models.truck_parts()),
                              position=(0, 0.08, 0.13), shader=lit)
            self.parts["truck"] = truck
            cargo = []
            for cx, cz in ((-0.06, -0.02), (0.06, -0.02), (-0.06, -0.18), (0.06, -0.18)):
                box = instanced(truck, "cargo_box", lambda: models.mesh_from_parts([
                    ("box", (0, 0, 0), (0.1, 0.1, 0.13), (1, 1, 1)),
                    ("box", (0, 0.051, 0), (0.1, 0.004, 0.02), (0.55, 0.45, 0.3))]),
                    shader=lit, position=(cx, 0.235, cz), enabled=False)
                cargo.append(box)
            self.parts["cargo"] = cargo
            self.truck_home = True                  # LKW steht am Bahnhof
        elif t == "assembler":
            self.parts["arm"] = instanced(self.root, "arm", lambda: models.mesh_from_parts([
                ("box", (0, 0.06, -0.12), (0.06, 0.06, 0.26), models.ORANGE),
                ("box", (0, 0.02, -0.25), (0.05, 0.12, 0.05), models.ORANGE),
                ("box", (0, -0.04, -0.25), (0.09, 0.03, 0.09), models.DARK)]),
                position=(0.22, 0.4, 0.17), shader=lit)
            self.parts["gear"] = instanced(self.root, "gear", lambda: models.mesh_from_parts(
                [("cyl", (0, 0, 0), (0.26, 0.06, 0.26), models.STEEL)] +
                [("box", (0, 0, 0), (0.34, 0.05, 0.06), models.STEEL, (0, a, 0)) for a in (0, 45, 90, 135)]),
                position=(-0.1, 0.79, -0.17), shader=lit)
        elif t == "chemical":
            self.parts["mixer"] = instanced(self.root, "chem_mixer", lambda: models.mesh_from_parts(
                [("cyl8", (0, 0, 0), (0.04, 0.12, 0.04), models.DARK)] +
                [("box", (0, 0.05, 0), (0.2, 0.02, 0.04), models.ORANGE, (0, a, 0)) for a in (0, 90)]),
                position=(-0.22, 0.95, -0.2), shader=lit)
        elif t == "electronics":
            self.parts["fan"] = instanced(self.root, "factory_fan", lambda: models.mesh_from_parts(
                [("cyl8", (0, 0, 0), (0.06, 0.05, 0.06), models.DARK)] +
                [("box", (0, 0, 0), (0.26, 0.02, 0.06), models.LIGHT_STEEL, (0, a, 0)) for a in (0, 60, 120)]),
                position=(0.24, 0.86, -0.2), shader=lit, scale=0.8)
        elif t == "factory":
            self.parts["fan"] = instanced(self.root, "factory_fan", lambda: models.mesh_from_parts(
                [("cyl8", (0, 0, 0), (0.06, 0.05, 0.06), models.DARK)] +
                [("box", (0, 0, 0), (0.26, 0.02, 0.06), models.LIGHT_STEEL, (0, a, 0)) for a in (0, 60, 120)]),
                position=(-0.22, 0.9, -0.06), shader=lit)
            self.parts["lift"] = instanced(self.root, "factory_lift", lambda: models.mesh_from_parts([
                ("box", (0, 0, 0), (0.16, 0.1, 0.12), models.ORANGE),
                ("box", (0, -0.08, 0), (0.03, 0.12, 0.03), models.DARK)]),
                position=(0.0, 0.32, 0.38), shader=lit)

    def set_level(self, level):
        if level == self.level:
            return
        upgraded = self.level > 0 and level > self.level
        self.level = level
        if upgraded:                          # Ausbau: kurzes Aufpumpen und Funken
            from . import anim
            root = self.root

            def f(v):
                if self.spawn_t >= 1.0:
                    k = 1 + 0.2 * math.sin(v * math.pi) * (1 - v * 0.5)
                    root.scale = Vec3(k, 1 + (k - 1) * 1.4, k)
            def end():
                if self.spawn_t >= 1.0:
                    root.scale = 1
                    self._settle_items()
            anim.tween(f, 0.45, ease=anim.linear, key=("lvl", id(self)), done=end)
            effects.get().emit(root.position + Vec3(0, self.height, 0), "spark", 16, force=True)
        for p in self.pips:
            destroy(p)
        self.pips = []
        if C.BUILDINGS[self.type]["max_level"] > 1:
            # alle Stufen-Lämpchen als EIN Modell (ein Zeichenaufruf)
            self.pips.append(instanced(self.root, ("pips", level), lambda: models.mesh_from_parts(
                [("box", (-0.38 + i * 0.09, 0.14, 0.46), (0.06, 0.03, 0.03), (1.0, 0.8, 0.2)) for i in range(level)]),
                shader=graphics.lit_shader()))

    def _set_badge(self, kind, on):
        if on:
            BADGES[kind].add(self)
            self._badges.add(kind)
        elif kind in self._badges:
            BADGES[kind].discard(self)
            self._badges.discard(kind)

    # ------------------------------------------------------------------ Bündelung (batching.py)
    def touch(self):
        self.changed_at = time.time()

    def _notify_changed(self):
        b = BATCHER["inst"]
        if b is not None and self.chunk is not None:
            b.changed(self)

    def body_mesh(self):
        return self.body.mesh_src

    def mesh_parts(self):
        return [p for p in self.parts.values() if isinstance(p, Entity) and hasattr(p, "mesh_src") and p.enabled]

    def lamp_rgba(self):
        c = STATUS_COLORS.get(getattr(self, "_lamp_lvl", "warn"), STATUS_COLORS["warn"])
        return (c[0], c[1], c[2], 1.0)

    def set_batched(self, batched):
        if batched == self.batched:
            return
        self.batched = batched
        nodes = [self.body] + [self.parts[k] for k in ("belt", "arrows") if k in self.parts]
        if self.lamp is not None:
            nodes.append(self.lamp)
        for n in nodes:
            n.hide() if batched else n.show()
        self.set_far(self.far, force=True)

    def set_items_visible(self, show):
        h = self.parts.get("items")
        if h is not None and show != getattr(self, "_items_shown", True):
            self._items_shown = show
            h.show() if show else h.hide()

    def set_far(self, far, force=False):
        """Ferner Abschnitt: ist das Gebäude gebündelt, übernimmt das Fern-Bündel die komplette Darstellung."""
        if far == self.far and not force:
            return
        self.far = far
        if far and self.batched:
            self.root.hide()
        else:
            self.root.show()

    def _make_body(self, key, factory, lit=None):
        """Grundkörper – mit Skin als eigene, einmal umgefärbte Variante (geteilt von allen gleichen)."""
        from . import skins as K
        self._body_src = (key, factory)
        pal = K.palette(self.skin_sid) if getattr(self, "skin_sid", None) else None
        if pal:
            style = K.style_of(self.skin_sid)
            body = instanced(self.root, ("skin", style, key),
                             lambda: recolor_mesh(_mesh(key, factory), pal[0], pal[1]), shader=lit or graphics.lit_shader())
        else:
            body = instanced(self.root, key, factory, shader=lit or graphics.lit_shader())
        apply_texture(body, "metal")
        if not getattr(self, "enabled", True):
            body.setColorScale(0.55, 0.56, 0.6, 1)
        return body

    def color_tint(self):
        """Tönung des Grundkörpers (der Skin steckt schon in den Farben): abgeschaltet grau."""
        return (1, 1, 1, 1) if self.enabled else (0.55, 0.56, 0.6, 1)

    def set_skin(self, sid):
        """sid: Skin-ID des Besitzers für diesen Gebäudetyp (oder None = Standard-Look)."""
        from . import skins as K
        if sid == self.skin_sid:
            return
        self.skin_sid = sid
        self.skin_rarity = K.rarity(sid) if sid else None
        old = self.body
        self.body = self._make_body(*self._body_src)
        if self.batched:
            self.body.hide()
        destroy(old)
        t = K.tint(sid) if sid else None
        for p in self.mesh_parts():                 # bewegliche Teile (Rotor, Greifarm ...) passend tönen
            p.setColorScale(*(t + (1,))) if t else p.clearColorScale()
        self.touch()
        self._notify_changed()

    def set_enabled(self, enabled):
        if enabled != self.enabled:
            self.touch()
        self.enabled = enabled
        self.body.setColorScale(*self.color_tint())
        self._set_badge("off", not enabled)

    # ------------------------------------------------------------------ Updates vom Server
    def update_static(self, data):
        _, _, x, y, rot, level, recipe, owner, enabled, cfg = static_row_parts(data)
        changed = (x, y) != (self.x, self.y) or rot != self.rot or level != self.level or enabled != self.enabled
        if changed:
            self.touch()
            self._notify_changed()             # aus dem Bündel nehmen, solange es sich bewegt
        if (x, y) != (self.x, self.y):
            self.x, self.y = x, y
            self.root.position = Vec3(x, 0, y)
            effects.get().emit(Vec3(x, 0.1, y), "poof", 6, force=True)
            self._notify_changed()
            self._settle_items()
        if rot != self.rot:
            from . import anim
            a0 = self.root.rotation_y
            a1 = rot * 90
            diff = (a1 - a0 + 180) % 360 - 180            # kürzester Weg
            root = self.root
            self.rot = rot
            anim.tween(lambda v: setattr(root, "rotation_y", a0 + diff * v), 0.28, ease=anim.out_back,
                       key=("rot", id(self)), done=self._settle_items)
        self.set_level(level)
        self.recipe = recipe
        if self.type in C.MACHINE_RECIPES:
            self.update_sign()
        if enabled != self.enabled:
            self.set_enabled(enabled)
        self.cfg = cfg
        if self.type == "sorter":
            filters = cfg.get("filters", {})
            for side, lbl in self.parts["labels"].items():
                names = [C.ITEMS[i]["name"] for i, s in filters.items() if s == side]
                lbl.text = "\n".join(names[:3])

    def sign_item(self):
        """Ware, die diese Maschine herstellt (für das Schild) – None, wenn keins nötig ist."""
        rid = None
        if self.type in C.MACHINE_RECIPES and self.recipe in C.RECIPES:
            rid = self.recipe
        elif self.type == "smelter" and isinstance(self.extra, dict):
            rid = self.extra.get("ar") or getattr(self, "_last_ar", None)
            if rid:
                self._last_ar = rid
        if rid not in C.RECIPES:
            return None
        outs = list(C.RECIPES[rid]["outputs"])
        return outs[0] if outs else None

    def update_sign(self):
        item = self.sign_item() if SIGNS["on"] else None
        if item == getattr(self, "_sign_item", None):
            return
        self._sign_item = item
        sign = self.parts.get("sign")
        if item is None:
            if sign is not None:
                sign.enabled = False
            return
        tex = textures.icon(item)
        if sign is None:
            from ursina import Quad
            sign = self.parts["sign"] = _E(parent=self.root, position=(0, self.height + 1.05, 0), billboard=True)
            back = _E(parent=sign, model=Quad(radius=0.25), scale=0.56, color=color.rgba(0.07, 0.08, 0.11, 0.88),
                      shader=graphics.unlit())
            rim = _E(parent=sign, model=Quad(radius=0.25, mode="line", thickness=2), scale=0.56, z=-0.005,
                     color=color.rgba(1, 0.7, 0.25, 0.9), shader=graphics.unlit())
            for e in (back, rim):
                e.setLightOff()
            sign.icon = _E(parent=sign, model="quad", scale=0.46, z=-0.01, shader=graphics.unlit())
            sign.icon.setLightOff()
            sign.icon.setTransparency(TransparencyAttrib.M_alpha)
        sign.icon.texture = tex
        sign.enabled = tex is not None

    def update_dynamic(self, status, progress, extra, storage_fill=0.0):
        if status == self.status and extra == self.extra and self._dyn_seen:
            self.progress = progress                 # nichts Sichtbares geändert: schneller Weg
            return
        self._dyn_seen = True
        self.status = status
        self.progress = progress
        self.extra = extra
        lvl = status_level(status)
        if self.lamp and lvl != getattr(self, "_lamp_lvl", None):
            self._lamp_lvl = lvl
            self.lamp.color = STATUS_COLORS.get(lvl, STATUS_COLORS["warn"])
            b = BATCHER["inst"]
            if b is not None and self.batched:
                b.set_lamp(self, self.lamp_rgba())
        self._set_badge("warn", lvl == "error")
        if self.type == "smelter":
            self.update_sign()
        if self.type in C.BELT_LIKE:
            if self.on_screen or not self.items:
                self._pending_items = None
                self._sync_belt_items(extra if isinstance(extra, list) else [])
            else:                                    # nicht im Bild: erst abgleichen, wenn es sichtbar wird
                self._pending_items = extra if isinstance(extra, list) else []
        elif self.type == "storage":
            self.set_storage_fill(storage_fill)
        elif self.type == "freight" and isinstance(extra, dict):
            self._sync_trucks(extra.get("trucks") or [])
        elif self.type == "seller" and isinstance(extra, dict):
            earned = extra.get("earned", 0)
            if self.last_earned is not None and earned > self.last_earned:
                effects.get().emit(self.root.position + Vec3(0, 1.2, 0), "coin", 3)
            self.last_earned = earned

    def _item_holder(self):
        h = self.parts.get("items")
        if h is None:
            h = self.parts["items"] = _E(parent=self.root, shader=graphics.lit_shader())
            apply_texture(h, "metal")
        return h

    def _items_parent(self):
        """Waren hängen am Abschnitts-Bündel (ein Zeichenaufruf für alle Waren des Abschnitts,
        auch aus der Ferne sichtbar). Ohne Abschnitt (Menü-Beispielfabrik): am Gebäude selbst."""
        b = BATCHER["inst"]
        if b is not None and self.chunk is not None:
            return b.items_node(self.chunk), True
        return self._item_holder(), False

    def _take_item(self, item):
        b = BATCHER["inst"]
        if b is not None and self.chunk is not None:
            return b.take_item(self.chunk, item, acquire_item)
        return acquire_item(self._item_holder(), item)

    def _drop_item(self, np, item):
        b = BATCHER["inst"]
        if b is not None and self.chunk is not None:
            b.park_item(self.chunk, np, item)
        else:
            release_item(np, item)

    def clear_items(self):
        """Alle Waren freigeben (Gebäude weg oder in einen anderen Abschnitt versetzt)."""
        for np, item, _ in self.items:
            self._drop_item(np, item)
        self.items = []

    def _sync_belt_items(self, server_items):
        server_items = [it for it in server_items if it[0] in C.ITEMS]
        items = self.items
        new = moved = False
        while len(items) > len(server_items):
            np, item, _ = items.pop()
            self._drop_item(np, item)
        for i, (item, pos) in enumerate(server_items):
            if i < len(items):
                cur = items[i]
                if cur[1] != item:
                    self._drop_item(cur[0], cur[1])
                    cur[0] = self._take_item(item)
                    cur[1] = item
                    cur[2] = pos
                    new = True
                elif abs(cur[2] - pos) > 0.12:       # nur größere Abweichungen korrigieren (kein Zittern)
                    cur[2] = pos
                    moved = True
            else:
                items.append([self._take_item(item), item, pos])
                new = True
        if (new or moved) and self.on_screen:
            # sonst schieben animate()/move_items() die Waren ohnehin jedes Bild weiter;
            # Bänder außerhalb des Bildes werden erst platziert, wenn sie ins Bild kommen
            self._place_items(orient=new)
        elif new:
            self._item_orient = None

    def _place_items(self, orient=False):
        if not self.items:
            return
        parent, world = self._items_parent()
        conveyor = self.type == "conveyor"
        if world and conveyor and self.curve:
            # Kurve: Waren folgen dem Bogen und drehen sich mit
            mat = self.root.getMat(parent)
            base_h = self.root.getH(parent)
            side = self.curve
            for np, item, pos in self.items:
                t = pos if pos < 1.0 else 1.0
                x, z = models.curve_point(side, t)
                np.setPos(mat.xformPoint(Point3(x, 0.19, z)))
                np.setHpr(base_h + CURVE_SIGN * models.curve_heading(side, t), 0, 0)
            self._item_orient = None
        elif world:
            mat = self.root.getMat(parent)
            o = mat.xformPoint(Point3(0, 0.19, -0.5))
            d = mat.xformVec(Vec3(0, 0, 1))
            ox, oy, oz, dx, dy, dz = o.x, o.y, o.z, d.x, d.y, d.z
            k = 1.0 if conveyor else 0.5
            for np, item, pos in self.items:
                t = (pos if pos < 1.0 else 1.0) * k
                np.setPos(ox + dx * t, oy + dy * t, oz + dz * t)
            key = (round(self.root.getH(), 1), self.spawn_t >= 1.0)
            if orient or key != getattr(self, "_item_orient", None):
                self._item_orient = key
                quat = self.root.getQuat(parent)
                for np, item, pos in self.items:
                    np.setQuat(quat)
        else:
            for np, item, pos in self.items:
                np.setPos(0, 0.19, min(1.0, pos) - 0.5 if conveyor else -0.5 + min(1.0, pos) * 0.5)

    def move_items(self, dt, belt_speed):
        """Nur die Waren weiterschieben (für Bänder in fernen Abschnitten – günstig)."""
        if not self.items or not self.enabled:
            return
        belt_speed *= C.BELT_LEVEL_SPEED.get(self.level, 1.0)
        if self.type == "conveyor":
            if self.status in ("blocked", "no_output", "bad_output", "off"):
                return
            step, gap = belt_speed * dt, C.BELT_SPACING
        else:
            if self.status in ("blocked", "off"):
                return
            step, gap = belt_speed * dt * 1.5, 0.5
        items = self.items
        for i, it in enumerate(items):
            limit = 1.0 if i == 0 else items[i - 1][2] - gap
            it[2] = max(it[2], min(it[2] + step, limit))
        self._place_items()

    # ------------------------------------------------------------------ Förderband-Kurven
    def set_curve(self, side, join=None):
        """side: "L", "R" oder None (gerade). join: seitlicher Zulauf bei geradem Band (T-Stück-Optik).
        Tauscht Grundkörper, Bandfläche und Pfeile aus."""
        if side is not None:
            join = None
        if self.type != "conveyor" or (side == getattr(self, "curve", None) and join == getattr(self, "join", None)):
            return
        shape_only = side == getattr(self, "curve", None)
        self.curve = side
        self.join = join
        lit = graphics.lit_shader()
        if side is None and join is not None:
            key = ("conveyor_join", join)
            factory = (lambda j=join: models.mesh_from_parts(models.join_frame(j), ao=True))
        elif side is None:
            key = ("static", "conveyor")
            factory = (lambda: models.static_mesh("conveyor"))
        else:
            key = ("conveyor_curve", side)
            factory = (lambda s=side: models.mesh_from_parts(models.curve_frame(s), ao=True))
        old = self.body
        self.body = self._make_body(key, factory, lit)
        if self.batched:
            self.body.hide()
        destroy(old)
        if shape_only:
            self.touch()
            self._notify_changed()
            return
        belt, arrows = self.parts["belt"], self.parts["arrows"]
        if side is None:
            belt.model = "quad"
            belt.position, belt.rotation, belt.scale = (0, 0.103, 0), (90, 0, 0), (0.82, 1.0)
            arrows.model = "quad"
            arrows.position, arrows.rotation, arrows.scale = (0, 0.108, 0), (90, -90, 0), (0.9, 0.5)
        else:
            for part, mkey, make in (
                    (belt, ("curve_belt", side), lambda s=side: models.curve_strip(s, 0.09, 0.91, 0.103, 0.785)),
                    (arrows, ("curve_arrows", side),
                     lambda s=side: models.curve_strip(s, 0.25, 0.75, 0.108, 0.87, u_along=True))):
                np = NodePath("curve")
                np.setTwoSided(True)                   # bleibt auch im Abschnitts-Bündel erhalten
                _mesh(mkey, make).instanceTo(np)
                part.model = np
                part.position, part.rotation, part.scale = (0, 0, 0), (0, 0, 0), (1, 1, 1)
                part.setTwoSided(True)
        self._place_items(orient=True)
        self.touch()
        self._notify_changed()

    def _sync_trucks(self, trucks):
        """Angedockter LKW mit sichtbarer Ladung; fährt ab bzw. kommt zurück (Animation)."""
        docked = [t for t in trucks if t[0] in ("loading", "free")]
        loading = next((t for t in trucks if t[0] == "loading"), None)
        home = bool(docked)
        truck = self.parts["truck"]
        if home != self.truck_home:
            self.truck_home = home
            self._drive_truck(away=not home)
        frac = (loading[2] / loading[3]) if loading and loading[3] else 0.0
        n = int(math.ceil(frac * 4 - 1e-6)) if loading else 0
        tint = C.ITEMS.get(loading[1], {}).get("color", (1, 1, 1)) if loading else (1, 1, 1)
        for i, box in enumerate(self.parts["cargo"]):
            box.enabled = i < n
            if i < n:
                box.setColorScale(tint[0] * 1.1, tint[1] * 1.1, tint[2] * 1.1, 1)
        truck.enabled = home or getattr(self, "_truck_driving", False)

    def _drive_truck(self, away):
        """Abfahrt: LKW fährt vorwärts weg und blendet aus. Rückkehr: umgekehrt."""
        from . import anim
        truck = self.parts["truck"]
        self._truck_driving = True
        truck.enabled = True
        self._notify_changed()
        z0, z1 = (0.13, 3.0) if away else (3.0, 0.13)

        def f(v):
            truck.z = z0 + (z1 - z0) * v
            anim.set_alpha(truck, (1 - v) if away else v)

        def done():
            self._truck_driving = False
            anim.set_alpha(truck, 1.0)
            truck.z = 0.13
            truck.enabled = self.truck_home
        if away:
            effects.get().emit(self.root.position + Vec3(0, 0.2, 0), "dust", 6, force=True)
            effects.get().emit(self.root.position + self._local(0.1, 0.35, 0.3), "smoke", 2, force=True)
        anim.tween(f, 2.2, ease=anim.in_cubic if away else anim.out_cubic, done=done, key=("truck", id(self)))
        on_truck = TRUCK_EVENTS.get("cb")
        if on_truck:
            on_truck(self, away)

    def set_storage_fill(self, fill):
        fill = max(0.0, min(1.0, fill))
        bar = self.parts["fill"]
        bar.scale_y = 0.48 * fill
        bar.color = STATUS_COLORS["error"] if fill >= 0.999 else (STATUS_COLORS["warn"] if fill > 0.8 else STATUS_COLORS["ok"])
        for i, crate in enumerate(self.parts["crates"]):
            crate.enabled = fill > (i + 0.5) / 5

    # ------------------------------------------------------------------ Animation je Frame
    def animate(self, dt, belt_speed):
        working = self.status == "working" and self.enabled
        if self.type in C.BELT_LIKE:
            belt_speed *= C.BELT_LEVEL_SPEED.get(self.level, 1.0)
        self.anim_t += dt
        p = self.parts
        if self.spawn_t < 1.0:
            self._animate_spawn(dt)
        fx = effects.get()
        self.fx_t += dt
        world = self.root.position
        if getattr(self, "skin_rarity", None) == "legendary" and random.random() < dt * 2.2:
            # legendäre Skins funkeln
            fx.emit(world + Vec3(random.uniform(-0.45, 0.45), random.uniform(0.2, self.height + 0.2),
                                 random.uniform(-0.45, 0.45)), "spark", 1)

        if self.type == "miner":
            if working:
                speed = C.LEVEL_SPEED.get(self.level, 1)
                p["rotor"].rotation_y += dt * 420 * speed
                p["rotor"].y = 1.0 + math.sin(self.anim_t * 14) * 0.02
                p["piston"].y = 0.95 + abs(math.sin(self.anim_t * 6 * speed)) * 0.08
                if self.fx_t > 0.35:
                    self.fx_t = 0
                    fx.emit(world + Vec3(random.uniform(-0.3, 0.3), 0.18, random.uniform(-0.3, 0.3)), "dust", 1)
                    fx.emit(world + self._local(-0.3, 1.1, 0.12), "smoke", 1)
        elif self.type in FURNACES:
            target = 1.0 if working else 0.12
            flicker = 0.85 + 0.15 * math.sin(self.anim_t * 11) if working else 1
            p["glow"].color = color.rgba(min(1, 0.25 + target * flicker), 0.1 + 0.45 * target * flicker,
                                         0.05 + 0.08 * target, 1)
            p["halo"].color = color.rgba(1, 0.5, 0.15, 0.35 * target * flicker if working else 0)
            if working and self.fx_t > 0.28:
                self.fx_t = 0
                fx.emit(world + self._local(*FURNACES[self.type][3]), "smoke", 1)
                if random.random() < 0.35:
                    fx.emit(world + self._local(0, 0.3, 0.45), "spark", 2)
        elif self.type == "chemical":
            p["mixer"].rotation_y += dt * (260 if working else 15)
            if working and self.fx_t > 0.45:
                self.fx_t = 0
                fx.emit(world + self._local(0.24, 0.8, -0.22), "steam", 1)
        elif self.type == "electronics":
            p["fan"].rotation_y += dt * (380 if working else 20)
        elif self.type == "conveyor":
            items = self.items
            moving = self.enabled and self.status not in ("blocked", "no_output", "bad_output", "off")
            if moving:
                step = belt_speed * dt
                for i, it in enumerate(items):
                    limit = 1.0 if i == 0 else items[i - 1][2] - C.BELT_SPACING
                    it[2] = max(it[2], min(it[2] + step, limit))
                self._place_items()
                self.tex_offset = (self.tex_offset - step) % 1.0
                for key in ("belt", "arrows"):
                    part = p[key]
                    if part.model:
                        u, v = (0, self.tex_offset) if key == "belt" else (self.tex_offset, 0)
                        part.model.setTexOffset(TextureStage.getDefault(), u, v)
                        part.set_shader_input("texture_offset", Vec2(u, v))
        elif self.type in C.ROUTER_TYPES:
            if self.enabled and self.status not in ("blocked", "off"):
                step = belt_speed * dt * 1.5
                for i, it in enumerate(self.items):
                    limit = 1.0 if i == 0 else self.items[i - 1][2] - 0.5
                    it[2] = max(it[2], min(it[2] + step, limit))
                self._place_items()
            if working:
                p["spinner"].rotation_y += dt * 240
        elif self.type == "seller":
            p["coin"].rotation_y += dt * (260 if working else 30)
            p["coin"].y = 1.15 + (0.05 * math.sin(self.anim_t * 6) if working else 0)
        elif self.type == "assembler":
            if working:
                p["arm"].rotation_y = math.sin(self.anim_t * 3.2) * 70
                p["arm"].y = 0.4 + abs(math.sin(self.anim_t * 6.4)) * 0.04
                p["gear"].rotation_y += dt * 140
                if self.fx_t > 0.5 and random.random() < 0.5:
                    self.fx_t = 0
                    fx.emit(world + self._local(-0.2, 0.3, 0.3), "spark", 3)
        elif self.type == "factory":
            if working:
                p["fan"].rotation_y += dt * 300
                p["lift"].y = 0.32 + abs(math.sin(self.anim_t * 2.4)) * 0.12
                if self.fx_t > 0.35:
                    self.fx_t = 0
                    fx.emit(world + self._local(0.32, 1.28, -0.3), "smoke", 1)
            else:
                p["fan"].rotation_y += dt * 20

    def _local(self, x, y, z):
        """Lokale Position (relativ zum Gebäude, berücksichtigt Drehung) -> Weltversatz."""
        a = math.radians(self.rot * 90)
        return Vec3(x * math.cos(a) + z * math.sin(a), y, -x * math.sin(a) + z * math.cos(a))

    SPAWN_TIME = 0.75
    DROP_END = 0.38                       # Anteil der Zeit, in der das Gebäude herabfällt

    def _animate_spawn(self, dt):
        """Bauanimation: Gebäude fällt von oben herab, staucht beim Aufsetzen und federt nach."""
        before = self.spawn_t
        self.spawn_t = min(1.0, self.spawn_t + dt / self.SPAWN_TIME)
        k, d = self.spawn_t, self.DROP_END
        base = Vec3(self.x, 0, self.y)
        if k < d:
            u = k / d
            self.root.position = base + Vec3(0, 3.2 * (1 - u * u), 0)
            self.root.scale = Vec3(0.88, 1.18, 0.88)
        else:
            if before < d:                # gerade aufgesetzt: Staubring
                fx = effects.get()
                for i in range(14):
                    a = i / 14 * math.tau
                    fx.emit(base + Vec3(math.cos(a) * 0.45, 0.06, math.sin(a) * 0.45), "dust", 1, force=True,
                            direction=Vec3(math.cos(a) * 1.6, -0.15, math.sin(a) * 1.6))
            u = (k - d) / (1 - d)
            wob = math.exp(-5.5 * u) * math.cos(u * 15)
            self.root.position = base
            self.root.scale = Vec3(1 + 0.16 * wob, 1 - 0.24 * wob, 1 + 0.16 * wob)
        if self.spawn_t >= 1.0:
            self.root.position = base
            self.root.scale = 1
            self._settle_items()

    def flush_pending(self):
        """Aufgeschobenen Waren-Abgleich nachholen (Band ist gerade ins Bild gekommen)."""
        pend = getattr(self, "_pending_items", None)
        if pend is not None:
            self._pending_items = None
            self._sync_belt_items(pend)

    def _settle_items(self):
        """Waren nach Bewegung/Drehung/Bauanimation neu auf das Band setzen – sonst schweben sie
        an der alten Stelle, solange das Band steht (z. B. blockiert)."""
        if self.items and not getattr(self, "_destroyed", False):
            try:
                self._place_items(orient=True)
            except Exception:
                pass

    def destroy(self, effect=False):
        self.clear_items()
        for kind in list(self._badges):
            self._set_badge(kind, False)
        self.root.show()
        self.body.show()
        if not effect:
            destroy(self.root)
            return
        effects.get().emit(self.root.position + Vec3(0, 0.2, 0), "poof", 14, force=True)
        effects.get().emit(self.root.position + Vec3(0, 0.1, 0), "dust", 8, force=True)
        from . import anim
        root = self.root
        base = Vec3(root.position)
        rot0 = root.rotation_y

        def f(v):
            s = 1 - v
            root.scale = Vec3(1 + 0.12 * math.sin(v * math.pi), max(0.001, s * s), 1 + 0.12 * math.sin(v * math.pi))
            root.position = base + Vec3(0, -0.15 * v, 0)
            root.rotation_y = rot0 + 30 * v
        anim.tween(f, 0.32, ease=anim.in_cubic, done=lambda: destroy(root))


# ---------------------------------------------------------------------------
class TileFrame(Entity):
    """Quadratischer Rahmen um eine Kachel (Auswahl / Mauszeiger)."""

    def __init__(self, col, thickness=0.05, height=0.03, **kwargs):
        super().__init__(**kwargs)
        self.parts = []
        for pos, scale in (((0, 0, 0.5), (1.04, height, thickness)), ((0, 0, -0.5), (1.04, height, thickness)),
                           ((0.5, 0, 0), (thickness, height, 1.04)), ((-0.5, 0, 0), (thickness, height, 1.04))):
            self.parts.append(Entity(parent=self, model="cube", position=pos, scale=scale,
                                     shader=graphics.unlit(), color=col))
        for part in self.parts:
            part.setLightOff()

    def set_color(self, col):
        for p in self.parts:
            p.color = col


class Ghost(Entity):
    """Halbtransparente Vorschau des zu bauenden oder zu verschiebenden Gebäudes."""

    VALID = color.rgba(0.45, 1.0, 0.55, 0.5)
    INVALID = color.rgba(1.0, 0.3, 0.25, 0.5)

    def __init__(self):
        super().__init__(enabled=False)
        self.btype = None
        self.body = None
        self.arrows = []
        self.frame = TileFrame(color.rgba(1, 1, 1, 0.9), parent=self, y=0.02)
        self.t = 0.0

    def set_type(self, btype):
        if btype == self.btype:
            return
        self.btype = btype
        if self.body:
            destroy(self.body)
            self.body = None
        for a in self.arrows:
            destroy(a)
        self.arrows = []
        if btype:
            self.body = Entity(parent=self, model=models.static_mesh(btype), shader=graphics.unlit(), color=self.VALID)
            self.body.setTransparency(TransparencyAttrib.M_alpha)
            self.body.setDepthWrite(False)
            self.body.setLightOff()
            if btype in C.ROUTER_TYPES:
                sides = C.BUILDINGS[btype]["outputs"]
            elif btype in OUTPUT_TYPES:
                sides = ["F"]
            else:
                sides = []
            for side in sides:
                ox, oz = SIDE_OFFSETS[side]
                a = Entity(parent=self, model="quad", texture="arrow_right", shader=graphics.unlit(),
                           position=(ox * 1.9, 0.06, oz * 1.9), scale=0.55,
                           rotation=(90, {"F": -90, "L": 180, "R": 0}[side], 0), color=self.VALID)
                a.setTransparency(TransparencyAttrib.M_alpha)
                a.setLightOff()
                self.arrows.append(a)

    def show(self, x, y, rot, valid, dt=0.016):
        snap = not self.enabled
        self.enabled = True
        self.t += dt
        # weich zum Zielfeld gleiten und drehen
        if snap or not hasattr(self, "_gx"):
            self._gx, self._gz, self._grot = float(x), float(y), rot * 90.0
        k = 1 - math.exp(-28 * dt)
        self._gx += (x - self._gx) * k
        self._gz += (y - self._gz) * k
        diff = (rot * 90 - self._grot + 180) % 360 - 180
        self._grot += diff * (1 - math.exp(-20 * dt))
        self.position = Vec3(self._gx, 0.01 + abs(math.sin(self.t * 4)) * 0.03, self._gz)
        self.rotation_y = self._grot
        pulse = 0.38 + 0.14 * math.sin(self.t * 5)
        base = self.VALID if valid else self.INVALID
        col = color.rgba(base[0], base[1], base[2], pulse)
        if self.body:
            self.body.color = col
        for a in self.arrows:
            a.color = col
        self.frame.set_color(color.rgba(col[0], col[1], col[2], 1))
