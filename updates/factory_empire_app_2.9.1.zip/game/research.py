"""
Forschungsbaum.

Eine Forschung kostet sofort Geld und benötigt danach Forschungszeit.
Es läuft immer genau eine Forschung gleichzeitig. Abgeschlossene
Technologien bleiben dauerhaft freigeschaltet (werden gespeichert).
"""

from . import config as C
from . import rules


class ResearchManager:
    def __init__(self):
        self.unlocked = set()
        self.active = None        # Technologie-ID oder None
        self.progress = 0.0       # Sekunden

    def check_start(self, tech_id, money):
        return rules.check_research(tech_id, self.unlocked, self.active, money)

    def start(self, tech_id):
        self.active = tech_id
        self.progress = 0.0

    def tick(self, dt):
        """Gibt die ID einer gerade abgeschlossenen Technologie zurück."""
        if not self.active:
            return None
        self.progress += dt
        if self.progress >= C.RESEARCH[self.active]["time"]:
            done = self.active
            self.unlocked.add(done)
            self.active = None
            self.progress = 0.0
            return done
        return None

    def snapshot(self):
        active = None
        if self.active:
            active = {
                "id": self.active,
                "progress": round(self.progress, 2),
                "time": C.RESEARCH[self.active]["time"],
            }
        return {"unlocked": sorted(self.unlocked), "active": active}

    def to_dict(self):
        return {"unlocked": sorted(self.unlocked), "active": self.active, "progress": self.progress}

    @classmethod
    def from_dict(cls, data):
        r = cls()
        r.unlocked = {t for t in data.get("unlocked", []) if t in C.RESEARCH}
        active = data.get("active")
        if active in C.RESEARCH and active not in r.unlocked:
            r.active = active
            r.progress = float(data.get("progress", 0.0))
        return r
