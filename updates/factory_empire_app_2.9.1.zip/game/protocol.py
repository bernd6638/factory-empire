"""
Netzwerkprotokoll: zeilenbasiertes JSON über TCP.

Jede Nachricht ist ein JSON-Objekt in einer eigenen Zeile (UTF-8, '\\n').
Das Feld "t" bestimmt den Nachrichtentyp.

Client -> Server
    hello   {name, version}                 Anmeldung (muss erste Nachricht sein)
    action  {a, rid, ...}                   Spielaktion, Server antwortet mit "result"
    admin   {cmd, rid, ...}                 Admin-Befehl (nur für Admins), Antwort "result"
    pos     {x, z, yaw, moving, fp, tool}   Avatar-Position (ca. 10x pro Sekunde)
    chat    {text}
    ping    {ts}
    bye     {}

Server -> Client
    welcome {id, name, color, version, grid, deposits, server_version, admin}
    you     {admin}                         Admin-Status hat sich geändert
    bans    {list}                          Bannliste (Antwort auf admin/bans)
    world   {deposits}                      nach dem Laden eines anderen Spielstands
    state   {sum, dyn, rev, players, [static]}
    result  {rid, ok, msg}
    event   {kind, text}
    chat    {name, color, text}
    pong    {ts}
    error   {msg}                           schwerwiegender Fehler, Verbindung wird getrennt
    kicked  {msg}                           vom Admin entfernt
"""

import json

from . import config as C


class ProtocolError(Exception):
    pass


def encode(message):
    return (json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


def decode(line):
    if len(line) > C.MAX_MESSAGE_BYTES:
        raise ProtocolError("Nachricht zu groß.")
    try:
        message = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError(f"Ungültiges JSON: {exc}") from exc
    if not isinstance(message, dict) or not isinstance(message.get("t"), str):
        raise ProtocolError("Nachricht ohne gültigen Typ.")
    return message


# Erwartete Felder und Typen für Spielaktionen.
# Typ "bool" wird ausdrücklich angegeben, sonst werden Wahrheitswerte abgelehnt
# (in Python ist bool eine Unterklasse von int).
NONE = type(None)
ACTION_SCHEMA = {
    "build":         {"btype": str, "x": int, "y": int, "rot": int},
    "demolish":      {"id": int},
    "rotate":        {"id": int},
    "move":          {"id": int, "x": int, "y": int, "rot": int},
    "set_enabled":   {"id": int, "enabled": bool},
    "set_all_enabled": {"enabled": bool},
    "upgrade":       {"id": int},
    "set_recipe":    {"id": int, "recipe": str},
    "set_filter":    {"id": int, "item": str, "side": str},
    "set_threshold": {"id": int, "pct": (int, NONE)},
    "research":      {"tech": str},
    "sell":          {"item": str, "amount": (int, str)},
    "order_accept":  {"oid": int},
    "order_cancel":  {"cid": int},
    "order_load":    {"cid": int},
    "save":          {},
    "load":          {},
}

# Admin-Befehle (Nachrichtentyp "admin", Feld "cmd")
ADMIN_SCHEMA = {
    "login":      {"password": str},
    "give_money": {"amount": (int, float)},
    "kick":       {"pid": int, "reason": str},
    "ban":        {"pid": int, "reason": str},
    "unban":      {"key": str},
    "bans":       {},
    "set_admin":  {"pid": int, "admin": bool},
}


def _validate_fields(schema, message):
    for field, expected in schema.items():
        if field not in message:
            return f"Feld '{field}' fehlt."
        value = message[field]
        allowed = expected if isinstance(expected, tuple) else (expected,)
        if isinstance(value, bool):
            if bool not in allowed:
                return f"Feld '{field}' hat einen ungültigen Typ."
        elif not isinstance(value, allowed):
            return f"Feld '{field}' hat einen ungültigen Typ."
        if isinstance(value, str) and len(value) > 64:
            return f"Feld '{field}' ist zu lang."
    return None


def validate_action(message):
    """Prüft Aufbau und Datentypen einer Aktion. Gibt Fehlertext oder None zurück."""
    action = message.get("a")
    if not isinstance(action, str) or action not in ACTION_SCHEMA:
        return "Unbekannte Aktion."
    error = _validate_fields(ACTION_SCHEMA[action], message)
    if error:
        return error
    if action == "sell" and isinstance(message["amount"], str) and message["amount"] != "all":
        return "Ungültige Menge."
    return None


def validate_admin(message):
    cmd = message.get("cmd")
    if not isinstance(cmd, str) or cmd not in ADMIN_SCHEMA:
        return "Unbekannter Admin-Befehl."
    return _validate_fields(ADMIN_SCHEMA[cmd], message)
