"""
Spieler-Statistiken und Erfolge (lokal auf diesem Rechner, über alle Welten hinweg).

Gespeichert in saves/stats.json. Der Client zählt mit, was der Spieler tut (bauen, ausbauen,
verdienen, liefern ...). Erfolge werden einmalig freigeschaltet und im Spiel angezeigt.
"""

import json
import os
import time

from . import config as C

PATH = os.path.join(C.DATA_DIR, "stats.json")

COUNTERS = {
    # Schlüssel: (Anzeigename, Format)
    "playtime":       ("Spielzeit gesamt", "time"),
    "longest":        ("Längste Sitzung", "time"),
    "sessions":       ("Gespielte Partien", "int"),
    "worlds":         ("Erstellte Welten", "int"),
    "multiplayer":    ("Mehrspieler-Partien", "int"),
    "built":          ("Gebaute Maschinen", "int"),
    "upgrades":       ("Ausgebaute Maschinen", "int"),
    "demolished":     ("Abgerissene Gebäude", "int"),
    "earned":         ("Verdientes Geld gesamt", "money"),
    "max_money":      ("Höchster Kontostand", "money"),
    "produced":       ("Hergestellte Waren", "int"),
    "research":       ("Abgeschlossene Forschungen", "int"),
    "orders":         ("Angenommene Aufträge", "int"),
    "deliveries":     ("Gelieferte Aufträge", "int"),
    "delivery_money": ("Einnahmen aus Aufträgen", "money"),
}
ORDER = ["playtime", "longest", "sessions", "worlds", "multiplayer", "built", "upgrades", "demolished",
         "earned", "max_money", "produced", "research", "orders", "deliveries", "delivery_money"]

# Erfolge: (id, Name, Beschreibung, Bedingung)
ACHIEVEMENTS = [
    ("first_build", "Grundstein", "Die erste Maschine gebaut", lambda s: s["built"] >= 1),
    ("builder_100", "Baulöwe", "100 Maschinen gebaut", lambda s: s["built"] >= 100),
    ("builder_500", "Industriegigant", "500 Maschinen gebaut", lambda s: s["built"] >= 500),
    ("upgrade_25", "Aufrüster", "25 Maschinen ausgebaut", lambda s: s["upgrades"] >= 25),
    ("money_1m", "Millionär", "1 Mio. € auf dem Konto", lambda s: s["max_money"] >= 1_000_000),
    ("money_100m", "Tycoon", "100 Mio. € auf dem Konto", lambda s: s["max_money"] >= 100_000_000),
    ("earned_10m", "Goldesel", "Insgesamt 10 Mio. € verdient", lambda s: s["earned"] >= 10_000_000),
    ("first_delivery", "Spediteur", "Den ersten Auftrag geliefert", lambda s: s["deliveries"] >= 1),
    ("deliveries_25", "Logistik-Profi", "25 Aufträge geliefert", lambda s: s["deliveries"] >= 25),
    ("research_20", "Forscherdrang", "20 Forschungen abgeschlossen", lambda s: s["research"] >= 20),
    ("produced_10k", "Fließband", "10.000 Waren hergestellt", lambda s: s["produced"] >= 10_000),
    ("hour_1", "Dranbleiben", "1 Stunde gespielt", lambda s: s["playtime"] >= 3600),
    ("hour_10", "Fabrik-Veteran", "10 Stunden gespielt", lambda s: s["playtime"] >= 36000),
    ("worlds_3", "Weltenbauer", "3 Welten erstellt", lambda s: s["worlds"] >= 3),
    ("multiplayer", "Teamarbeit", "Eine Mehrspieler-Partie gespielt", lambda s: s["multiplayer"] >= 1),
]


def fmt(key, value):
    kind = COUNTERS[key][1]
    if kind == "time":
        value = int(value)
        h, m = value // 3600, value % 3600 // 60
        return f"{h} h {m:02d} min" if h else f"{m} min"
    if kind == "money":
        from . import rules
        return rules.format_money(value)
    return f"{int(value):,}".replace(",", ".")


class Stats:
    def __init__(self, path=None):
        self.path = path or PATH
        self.data = {k: 0 for k in COUNTERS}
        self.data["first"] = ""
        self.unlocked = {}               # id -> Datum
        self.session = 0.0
        self._dirty = False
        self._save_t = 0.0
        self.load()

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                raw = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(raw, dict):
            return
        for k in COUNTERS:
            v = raw.get(k, 0)
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0:
                self.data[k] = v
        self.data["first"] = str(raw.get("first", ""))[:20]
        ach = raw.get("achievements", {})
        if isinstance(ach, dict):
            self.unlocked = {k: str(v)[:20] for k, v in ach.items() if any(a[0] == k for a in ACHIEVEMENTS)}

    def save(self):
        out = dict(self.data)
        out["achievements"] = self.unlocked
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(out, f, indent=1)
            os.replace(tmp, self.path)
            self._dirty = False
        except OSError:
            pass

    # ------------------------------------------------------------------ Zählen
    def add(self, key, amount=1):
        """Gibt die Liste neu freigeschalteter Erfolge zurück: [(name, beschreibung)]."""
        if amount <= 0:
            return []
        self.data[key] = self.data.get(key, 0) + amount
        self._dirty = True
        return self.check()

    def peak(self, key, value):
        if value > self.data.get(key, 0):
            self.data[key] = value
            self._dirty = True
            return self.check()
        return []

    def start_session(self, new_world=False, multiplayer=False):
        self.session = 0.0
        if not self.data["first"]:
            self.data["first"] = time.strftime("%d.%m.%Y")
        out = self.add("sessions")
        if new_world:
            out += self.add("worlds")
        if multiplayer:
            out += self.add("multiplayer")
        return out

    def tick(self, dt, in_game):
        """Spielzeit mitzählen; speichert etwa alle 30 Sekunden."""
        out = []
        if in_game:
            self.data["playtime"] += dt
            self.session += dt
            if self.session > self.data["longest"]:
                self.data["longest"] = self.session
            self._dirty = True
            self._save_t += dt
            if self._save_t >= 30.0:
                self._save_t = 0.0
                out = self.check()
                self.save()
        return out

    def check(self):
        new = []
        for aid, name, desc, cond in ACHIEVEMENTS:
            if aid not in self.unlocked:
                try:
                    ok = cond(self.data)
                except (KeyError, TypeError):
                    ok = False
                if ok:
                    self.unlocked[aid] = time.strftime("%d.%m.%Y")
                    new.append((name, desc))
        return new

    def flush(self):
        if self._dirty:
            self.save()
