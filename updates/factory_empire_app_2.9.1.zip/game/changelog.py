"""
Neuigkeiten je Version – wird nach einem Update im Spiel angezeigt und für die Update-Datei
(update.json) verwendet. Neueste Version oben.
"""

CHANGELOG = [
    ("2.9.1", [
        "Förderbänder machen jetzt schöne Kurven, wenn sie um die Ecke gehen – die Waren fahren den Bogen entlang",
        "Chat: T drücken, Nachricht schreiben, Enter – mit Verlauf und Spielerfarben",
        "Realistischere Beleuchtung: Himmelslicht, Glanzlichter und kräftigere Farben",
        "Geheimnisvolle Baustelle vor der Nordwest-Ecke – mit Countdown bis zum nächsten großen Update …",
    ]),
    ("2.9.0", [
        "Automatische Updates: Neue Versionen werden direkt im Spiel heruntergeladen – kein neuer Download nötig",
        "Nach jedem Update zeigt dieses Fenster, was neu ist",
    ]),
    ("2.8.1", [
        "Discord-Status: Discord zeigt „Spielt Factory Empire“ mit Logo, Spielmodus, Geld und Spielzeit",
        "Abschaltbar unter Optionen → „Status in Discord zeigen“",
    ]),
    ("2.8.0", [
        "Aufträge (O): Städte bestellen Waren, LKW liefern sie gegen hohe Belohnungen",
        "Neues Gebäude Frachtbahnhof mit LKW, Speditions-Ruf und Forschung „Autobahnanbindung“",
        "Dichter Wald bis zum Horizont, Dunst in der Ferne und eine Landstraße mit Verkehr",
        "Statistiken & 15 Erfolge im Hauptmenü",
    ]),
    ("2.7.1", [
        "Fehler behoben, durch den man nichts mehr anklicken konnte",
        "Weniger Zeichenaufrufe: Rauch, Funken und Warnschilder gebündelt – mehr FPS",
    ]),
    ("2.7.0", [
        "Rasen statt grauem Boden",
        "Materialien auf Bändern auch weit herausgezoomt sichtbar",
        "Eigener Mauszeiger im Vollbild (F11)",
        "Mehrspieler mit 5 Welten-Plätzen",
    ]),
]


def _key(v):
    return tuple(int(p) for p in v.split("."))


def notes_since(old, new=None):
    """Alle Einträge neuer als `old` (bis einschließlich `new`): [(version, [zeilen])]."""
    out = []
    for version, lines in CHANGELOG:
        if old and _key(version) <= _key(old):
            continue
        if new and _key(version) > _key(new):
            continue
        out.append((version, lines))
    return out
