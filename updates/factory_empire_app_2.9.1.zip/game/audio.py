"""
Soundeffekte – hier kommt Pygame zum Einsatz.

Pygame wird ausschließlich für Audio verwendet (pygame.mixer). Die Klänge
werden beim Start prozedural erzeugt (Sinus/Rauschen), daher sind keine
Audiodateien nötig. Grafik und Eingabe laufen komplett über Ursina, es
gibt also keine zwei konkurrierenden Fenster- oder Rendersysteme.

Ist Pygame nicht installiert oder hat das System kein Audiogerät, läuft
das Spiel einfach ohne Ton weiter.
"""

import math
import os
import random
import struct

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

RATE = 22050


def _render(duration, func, volume=0.35):
    n = int(RATE * duration)
    frames = bytearray()
    for i in range(n):
        t = i / RATE
        env = min(1.0, t * 200) * max(0.0, 1.0 - t / duration) ** 1.6
        v = max(-1.0, min(1.0, func(t) * env * volume))
        s = int(v * 32767)
        frames += struct.pack("<hh", s, s)
    return bytes(frames)


def _tone(freq):
    return lambda t: math.sin(2 * math.pi * freq * t)


def _sweep(f0, f1, duration):
    return lambda t: math.sin(2 * math.pi * (f0 + (f1 - f0) * t / duration / 2) * t)


class Audio:
    def __init__(self, enabled=True):
        self.enabled = False
        self.sounds = {}
        self.volume = 0.8
        if not enabled:
            return
        try:
            import pygame
            pygame.mixer.pre_init(RATE, -16, 2, 512)
            pygame.mixer.init()
            self._pygame = pygame
        except Exception as exc:          # kein Audiogerät, kein Pygame ...
            print(f"[Audio] Ton deaktiviert: {exc}")
            return
        rng = random.Random(7)
        defs = {
            "click": _render(0.05, _tone(1200), 0.18),
            "build": _render(0.22, lambda t: 0.7 * math.sin(2 * math.pi * 140 * t) + 0.3 * rng.uniform(-1, 1), 0.5),
            "demolish": _render(0.35, lambda t: rng.uniform(-1, 1) * 0.8 + 0.4 * math.sin(2 * math.pi * 70 * t), 0.4),
            "error": _render(0.25, lambda t: 0.6 * math.sin(2 * math.pi * 160 * t) + 0.4 * math.sin(2 * math.pi * 166 * t), 0.4),
            "sell": _render(0.3, lambda t: math.sin(2 * math.pi * (1318 if t > 0.08 else 988) * t), 0.25),
            "research": _render(0.6, lambda t: math.sin(2 * math.pi * (523 if t < 0.15 else 659 if t < 0.3 else 784) * t), 0.3),
            "upgrade": _render(0.35, _sweep(400, 900, 0.35), 0.3),
            "message": _render(0.12, _tone(880), 0.15),
        }
        try:
            for name, data in defs.items():
                self.sounds[name] = pygame.mixer.Sound(buffer=data)
            self.enabled = True
        except Exception as exc:
            print(f"[Audio] Ton deaktiviert: {exc}")

    def play(self, name):
        if not self.enabled:
            return
        snd = self.sounds.get(name)
        if snd:
            snd.set_volume(self.volume)
            snd.play()

    def shutdown(self):
        if self.enabled:
            try:
                self._pygame.mixer.quit()
            except Exception:
                pass
