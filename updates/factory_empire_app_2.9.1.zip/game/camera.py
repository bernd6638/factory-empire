"""
Strategiekamera
    WASD / Pfeil hoch-runter   bewegen (Shift = schneller)
    Rechte Maustaste halten    drehen und neigen
    Pfeil links/rechts         drehen
    Mausrad                    zoomen,  mittlere Maustaste: verschieben

"""

import math

from ursina import Entity, Vec3, camera, clamp, held_keys, mouse, time

from . import config as C


class RTSCamera(Entity):
    def __init__(self, target=Vec3(0, 0, 0)):
        super().__init__(position=target)
        self.yaw = 35.0
        self.pitch = 52.0
        self.distance = 22.0
        self.target_distance = self.distance
        self.arm = Entity(parent=self, rotation_x=self.pitch)
        self.input_blocked = False        # z. B. während Texteingabe
        self.move_speed = 14.0
        self.sensitivity = 1.0
        self.auto_orbit = False           # Hauptmenü-Hintergrund
        self.active = True
        self.moving = False
        self._vel = Vec3(0, 0, 0)          # weiches Anfahren/Abbremsen
        self._focus = None                 # Ziel für weiches Hinfahren (Minimap-Klick)
        self.attach()

    def attach(self):
        camera.parent = self.arm
        camera.position = (0, 0, -self.distance)
        camera.rotation = (0, 0, 0)
        camera.fov = 55
        camera.clip_plane_near = 0.1
        camera.clip_plane_far = 900

    def _forward_right(self):
        a = math.radians(self.yaw)
        f = Vec3(math.sin(a), 0, math.cos(a))
        r = Vec3(f.z, 0, -f.x)
        return f, r

    def update(self):
        if not self.active:
            return
        dt = min(time.dt, 0.1)
        self.moving = False
        if self.auto_orbit:
            self.yaw += dt * 4
            self.rotation_y = self.yaw
            return
        if not self.input_blocked:
            f, r = self._forward_right()
            move = Vec3(0, 0, 0)
            move += f * (held_keys["w"] + held_keys["up arrow"] - held_keys["s"] - held_keys["down arrow"])
            move += r * (held_keys["d"] - held_keys["a"])
            speed = self.move_speed * (2.2 if held_keys["shift"] else 1.0) * (0.5 + self.distance / 30)
            want = move.normalized() * speed if move.length() > 0 else Vec3(0, 0, 0)
            k = 1 - math.exp(-(14 if move.length() > 0 else 9) * dt)
            self._vel += (want - self._vel) * k
            if self._vel.length() > 0.03:
                self.position += self._vel * dt
                self.moving = True
                if move.length() > 0:
                    self._focus = None
            turn = held_keys["right arrow"] - held_keys["left arrow"]
            if turn:
                self.yaw += turn * 90 * dt

            if mouse.right:
                self.yaw += mouse.velocity[0] * 220 * self.sensitivity
                self.pitch = clamp(self.pitch - mouse.velocity[1] * 150 * self.sensitivity, 15, 86)
            if mouse.middle:
                pan = (-r * mouse.velocity[0] - f * mouse.velocity[1]) * self.distance * 1.6
                self.position += pan

        if self._focus is not None:
            k = 1 - math.exp(-7 * dt)
            self.position += (self._focus - self.position) * k
            self.moving = True
            if (self._focus - self.position).length() < 0.02:
                self.position = self._focus
                self._focus = None
        self.x = clamp(self.x, -6, C.GRID_W + 5)
        self.z = clamp(self.z, -6, C.GRID_H + 5)
        self.rotation_y = self.yaw
        self.arm.rotation_x = self.pitch
        self.distance += (self.target_distance - self.distance) * min(1.0, dt * 10)
        camera.z = -self.distance

    def input(self, key):
        if self.input_blocked or self.auto_orbit or not self.active:
            return
        if key == "scroll up":
            self.target_distance = clamp(self.target_distance * 0.88, 4, 80)
        elif key == "scroll down":
            self.target_distance = clamp(self.target_distance * 1.14, 4, 80)

    def focus(self, x, z, smooth=False):
        if smooth:
            self._focus = Vec3(x, 0, z)
        else:
            self._focus = None
            self._vel = Vec3(0, 0, 0)
            self.position = Vec3(x, 0, z)
