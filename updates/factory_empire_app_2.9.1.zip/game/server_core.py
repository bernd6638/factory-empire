"""
Dedizierter Spielserver (asyncio, TCP, JSON).

Der Server ist die einzige Instanz, die den Spielzustand verändert.
Er simuliert mit TICK_RATE Hz, sendet SNAPSHOT_RATE-mal pro Sekunde den
Zustand an alle Clients, prüft jede Aktion und speichert regelmäßig.
"""

import asyncio
import hmac
import ipaddress
import json
import logging
import math
import os
import time

from . import config as C
from . import protocol
from .save_system import SaveError, load_game, save_exists, save_game
from .simulation import GameState

log = logging.getLogger("factory.server")

# Aktionen, deren Erfolg allen Spielern gemeldet wird
BROADCAST_ACTIONS = {"research", "upgrade", "sell", "save", "load", "set_recipe", "set_all_enabled",
                     "order_accept", "order_cancel"}


def peer_ip(addr):
    """IP-Adresse aus einer Socket-Adresse, IPv4-in-IPv6 wird normalisiert."""
    if not addr:
        return ""
    host = str(addr[0])
    if len(addr) > 1 and host in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
        from . import relay
        if relay.is_relayed(addr[1]):
            return "relay"              # Mitspieler kommt über den Vermittlungsserver (Raum-Code)
    try:
        ip = ipaddress.ip_address(host.split("%")[0])
        if ip.version == 6 and ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        return str(ip)
    except ValueError:
        return host


def is_loopback(ip):
    try:
        return ipaddress.ip_address(ip).is_loopback
    except ValueError:
        return False


class ClientConnection:
    def __init__(self, cid, reader, writer):
        self.id = cid
        self.reader = reader
        self.writer = writer
        self.name = "?"
        self.color = 0
        self.addr = writer.get_extra_info("peername")
        self.queue = asyncio.Queue(maxsize=256)
        self.pos = [C.GRID_W / 2, C.GRID_H / 2]
        self.yaw = 0.0
        self.moving = False
        self.fp = False
        self.cursor = False              # zeigt die Maus gerade auf die Baufläche?
        self.tool = ""
        self.ip = peer_ip(self.addr)
        self.admin = False
        self.last_rev = -1
        self.tokens = float(C.CLIENT_MSG_BURST)
        self.last_refill = time.monotonic()
        self.violations = 0
        self.dropped = 0
        self.alive = True

    def send(self, message_bytes, droppable=False):
        if not self.alive:
            return
        try:
            self.queue.put_nowait(message_bytes)
            self.dropped = 0
        except asyncio.QueueFull:
            self.dropped += 1
            if not droppable or self.dropped > 50:
                # Client liest nicht mehr – Verbindung beenden
                self.alive = False
                self.writer.close()

    def allow_message(self):
        now = time.monotonic()
        self.tokens = min(C.CLIENT_MSG_BURST, self.tokens + (now - self.last_refill) * C.CLIENT_MSG_RATE)
        self.last_refill = now
        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True
        self.violations += 1
        return False


class FactoryServer:
    def __init__(self, host="0.0.0.0", port=C.DEFAULT_PORT, save_path=C.DEFAULT_SAVE_FILE,
                 new_game=False, seed=C.WORLD_SEED, autosave=True, password=None,
                 admin_password=None, local_admin=True, bans_path=None):
        # "" oder "*" = auf allen Netzwerkkarten lauschen, IPv4 UND IPv6
        self.host = None if host in ("", "*", None) else host
        self.password = password or None
        self.online_info = None          # Adressen für Freunde (nur im Online-Modus)
        self.admin_password = admin_password or None
        self.local_admin = local_admin
        self.bans_path = bans_path or os.path.join(os.path.dirname(os.path.abspath(save_path)), "bans.json")
        self.bans = self._load_bans()
        self.port = port
        self.save_path = save_path
        self.autosave_enabled = autosave
        self.clients = {}
        self._next_client_id = 1
        self._server = None
        self._tasks = []
        self._running = False
        self._snap_n = 0                 # Zähler für gestaffelte Teil-Übertragungen
        self._dyn_keys = {}              # zuletzt gesendeter "Kern" jeder Gebäudezeile
        self.state = self._initial_state(new_game, seed)

    # ------------------------------------------------------------------ Bannliste
    def _load_bans(self):
        try:
            with open(self.bans_path, encoding="utf-8") as f:
                data = json.load(f)
            return [b for b in data if isinstance(b, dict)] if isinstance(data, list) else []
        except FileNotFoundError:
            return []
        except (OSError, ValueError) as exc:
            log.error("Bannliste nicht lesbar (%s) – starte mit leerer Liste.", exc)
            return []

    def _save_bans(self):
        try:
            os.makedirs(os.path.dirname(self.bans_path), exist_ok=True)
            tmp = self.bans_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.bans, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.bans_path)
        except OSError as exc:
            log.error("Bannliste konnte nicht gespeichert werden: %s", exc)

    def ban_entry_for(self, name, ip):
        lname = str(name).strip().lower()
        for entry in self.bans:
            if (entry.get("ip") and entry.get("ip") == ip and ip != "relay" and not is_loopback(ip)) or \
                    (entry.get("name") and entry.get("name", "").lower() == lname):
                return entry
        return None

    # ------------------------------------------------------------------ Start
    def _initial_state(self, new_game, seed):
        if not new_game and save_exists(self.save_path):
            try:
                state, info = load_game(self.save_path)
                log.info(info)
                return state
            except SaveError as exc:
                log.error("%s – starte neue Fabrik. Alte Datei bleibt erhalten.", exc)
                broken = self.save_path + ".defekt"
                if os.path.exists(self.save_path):
                    os.replace(self.save_path, broken)
                    log.error("Defekte Datei umbenannt in %s", broken)
        elif new_game and save_exists(self.save_path):
            backup = self.save_path + f".{time.strftime('%Y%m%d-%H%M%S')}.alt"
            if os.path.exists(self.save_path):
                os.replace(self.save_path, backup)
                log.info("Neues Spiel: alter Spielstand gesichert als %s", backup)
        log.info("Neue Fabrik erstellt (Seed %s).", seed)
        return GameState(seed=seed)

    async def start(self):
        try:
            self._server = await asyncio.start_server(
                self._handle_client, self.host, self.port, limit=C.MAX_MESSAGE_BYTES)
        except OSError:
            if self.host is not None:
                raise
            # System ohne IPv6: nur IPv4 verwenden
            self.host = "0.0.0.0"
            self._server = await asyncio.start_server(
                self._handle_client, self.host, self.port, limit=C.MAX_MESSAGE_BYTES)
        self._running = True
        self._tasks = [
            asyncio.create_task(self._simulation_loop()),
            asyncio.create_task(self._snapshot_loop()),
        ]
        if self.autosave_enabled:
            self._tasks.append(asyncio.create_task(self._autosave_loop()))
        addrs = ", ".join(str(s.getsockname()) for s in self._server.sockets)
        log.info("Server läuft auf %s (Protokoll v%s)", addrs, C.PROTOCOL_VERSION)
        if self.autosave_enabled and not save_exists(self.save_path):
            self.save()                    # neue Welt sofort anlegen (erscheint gleich in der Weltenliste)

    @property
    def bound_port(self):
        return self._server.sockets[0].getsockname()[1] if self._server else self.port

    async def stop(self, save=True):
        if not self._running:
            return
        self._running = False
        for task in self._tasks:
            task.cancel()
        for client in list(self.clients.values()):
            client.send(protocol.encode({"t": "error", "msg": "Server wurde beendet."}))
        await asyncio.sleep(0.2)
        for client in list(self.clients.values()):
            client.alive = False
            client.writer.close()
        if self._server:
            self._server.close()
            try:
                await asyncio.wait_for(self._server.wait_closed(), 2.0)
            except asyncio.TimeoutError:
                pass
        if save:
            self.save()

    def save(self):
        try:
            path = save_game(self.state, self.save_path)
            log.info("Gespeichert: %s", path)
            return True, "Spielstand gespeichert."
        except SaveError as exc:
            log.error(str(exc))
            return False, str(exc)

    # ------------------------------------------------------------------ Schleifen
    async def _simulation_loop(self):
        dt = 1.0 / C.TICK_RATE
        loop = asyncio.get_running_loop()
        next_tick = loop.time()
        while self._running:
            try:
                self.state.tick(dt)
            except Exception:                      # Simulation darf den Server nie beenden
                log.exception("Fehler in der Simulation")
            for ev in self.state.drain_events():
                self.broadcast({"t": "event", **ev})
            next_tick += dt
            delay = next_tick - loop.time()
            if delay < -1.0:                       # stark im Rückstand: nicht nachholen
                next_tick = loop.time()
                delay = 0
            await asyncio.sleep(max(0.0, delay))

    async def _snapshot_loop(self):
        interval = 1.0 / C.SNAPSHOT_RATE
        while self._running:
            await asyncio.sleep(interval)
            if not self.clients:
                continue
            rows = self.state.dynamic_snapshot()
            part = self._partial_rows(rows)
            full_round = self._snap_n % C.FULL_SNAPSHOT_EVERY == 0
            base = {
                "t": "state",
                "rev": self.state.revision,
                "sum": self.state.summary_snapshot(),
                "dyn": rows if full_round else part,
                "players": [[c.id, c.name, c.color, round(c.pos[0], 2), round(c.pos[1], 2), c.tool,
                             round(c.yaw, 1), c.moving, c.fp, c.admin, c.cursor]
                            for c in self.clients.values()],
            }
            if not full_round:
                base["dpart"] = True
            plain = protocol.encode(base)
            full = None
            for client in list(self.clients.values()):
                if client.last_rev != self.state.revision:
                    if full is None:
                        full = protocol.encode({**base, "dyn": rows, "dpart": False,
                                                "static": self.state.static_snapshot()})
                    client.send(full, droppable=True)
                    client.last_rev = self.state.revision
                else:
                    client.send(plain, droppable=True)

    @staticmethod
    def _row_key(row):
        status, extra = row[1], row[3]
        if isinstance(extra, list):                      # Band: Warenarten (Positionen ändern sich ständig)
            return status, tuple(it[0] for it in extra)
        if isinstance(extra, dict):
            return status, extra.get("ar"), len(extra.get("q", ())) if "q" in extra else None
        return status, None

    def _partial_rows(self, rows):
        """Nur Gebäude, deren Zustand sich sichtbar geändert hat – plus gestaffelt jedes Gebäude
        alle STAGGER Übertragungen (für Positionen, Fortschritt, Zähler). Spart bei großen
        Fabriken den Großteil der Bandbreite und Rechenzeit auf beiden Seiten."""
        self._snap_n += 1
        n = self._snap_n
        stagger = C.SNAPSHOT_STAGGER
        keys = self._dyn_keys
        part = []
        alive = set()
        for row in rows:
            bid = row[0]
            alive.add(bid)
            key = self._row_key(row)
            if keys.get(bid) != key or (bid + n) % stagger == 0:
                keys[bid] = key
                part.append(row)
        if len(keys) > len(alive):
            for bid in [b for b in keys if b not in alive]:
                del keys[bid]
        return part

    async def _autosave_loop(self):
        while self._running:
            await asyncio.sleep(C.AUTOSAVE_INTERVAL)
            ok, _ = self.save()
            if ok:
                self.broadcast({"t": "event", "kind": "info", "text": "Automatisch gespeichert."})

    # ------------------------------------------------------------------ Verbindungen
    def set_online_info(self, info):
        """Speichert, wie Freunde beitreten können, und teilt es allen verbundenen Spielern mit."""
        self.online_info = dict(info) if info else None
        if self.online_info is not None:
            self.online_info["password"] = self.password is not None
            data = protocol.encode({"t": "online", "info": self.online_info})
            for client in list(self.clients.values()):
                if client.admin:            # nur der Host bzw. Admins brauchen die Adressen
                    client.send(data)

    def broadcast(self, message, exclude=None):
        data = protocol.encode(message)
        for client in list(self.clients.values()):
            if client is not exclude:
                client.send(data)

    def _unique_name(self, wanted):
        name = "".join(ch for ch in str(wanted) if ch.isprintable()).strip()[:16] or "Spieler"
        taken = {c.name for c in self.clients.values()}
        candidate, n = name, 2
        while candidate in taken:
            candidate = f"{name[:13]}#{n}"
            n += 1
        return candidate

    def _free_color(self):
        used = {c.color for c in self.clients.values()}
        for i in range(len(C.PLAYER_COLORS)):
            if i not in used:
                return i
        return 0

    async def _writer_task(self, client):
        try:
            while client.alive:
                data = await client.queue.get()
                client.writer.write(data)
                await client.writer.drain()
        except (ConnectionError, OSError, asyncio.CancelledError):
            pass
        finally:
            client.alive = False

    async def _reject(self, writer, msg):
        try:
            writer.write(protocol.encode({"t": "error", "msg": msg}))
            await asyncio.wait_for(writer.drain(), 2.0)
        except (ConnectionError, OSError, asyncio.TimeoutError):
            pass
        writer.close()

    async def _handle_client(self, reader, writer):
        peer = writer.get_extra_info("peername")
        # ---- Handshake
        try:
            line = await asyncio.wait_for(reader.readline(), C.HANDSHAKE_TIMEOUT)
            hello = protocol.decode(line)
        except asyncio.TimeoutError:
            await self._reject(writer, "Keine Anmeldung erhalten (Zeitüberschreitung).")
            return
        except (protocol.ProtocolError, ValueError, ConnectionError, asyncio.LimitOverrunError) as exc:
            await self._reject(writer, f"Ungültige Anmeldung: {exc}")
            return
        if hello.get("t") != "hello":
            await self._reject(writer, "Erste Nachricht muss 'hello' sein.")
            return
        if hello.get("version") != C.PROTOCOL_VERSION:
            await self._reject(writer, f"Versionskonflikt: Server nutzt Protokoll v{C.PROTOCOL_VERSION}, "
                                       f"Client v{hello.get('version')}. Bitte gleiche Spielversion verwenden.")
            return
        if self.password is not None:
            given = hello.get("password")
            if not isinstance(given, str) or not hmac.compare_digest(given.encode(), self.password.encode()):
                log.warning("Anmeldung mit falschem Passwort abgelehnt (%s)", peer)
                await asyncio.sleep(1.0)        # bremst Passwort-Raten
                await self._reject(writer, "Falsches Server-Passwort." if given else
                                   "Dieser Server ist passwortgeschützt. Bitte Passwort eingeben.")
                return
        ban = self.ban_entry_for(hello.get("name", ""), peer_ip(peer))
        if ban:
            reason_txt = f" Grund: {ban['reason']}" if ban.get("reason") else ""
            log.warning("Gebannter Spieler abgelehnt: %s (%s)", hello.get("name"), peer)
            await self._reject(writer, "Du wurdest von diesem Server gebannt." + reason_txt)
            return
        if len(self.clients) >= C.MAX_PLAYERS:
            await self._reject(writer, f"Server ist voll ({C.MAX_PLAYERS} Spieler).")
            return

        client = ClientConnection(self._next_client_id, reader, writer)
        self._next_client_id += 1
        client.name = self._unique_name(hello.get("name", "Spieler"))
        client.color = self._free_color()
        client.admin = self.local_admin and is_loopback(client.ip)
        self.clients[client.id] = client
        writer_task = asyncio.create_task(self._writer_task(client))
        client.send(protocol.encode({
            "t": "welcome", "id": client.id, "name": client.name, "color": client.color,
            "version": C.PROTOCOL_VERSION, "server_version": C.GAME_VERSION,
            "grid": [C.GRID_W, C.GRID_H], "deposits": self.state.deposits_list(),
            "admin": client.admin, "admin_login": self.admin_password is not None,
            "online": self.online_info if client.admin else None,
        }))
        log.info("%s verbunden (%s), %d Spieler online", client.name, peer, len(self.clients))
        self.broadcast({"t": "event", "kind": "info", "text": f"{client.name} ist beigetreten."}, exclude=client)

        reason = "Verbindung getrennt"
        try:
            while self._running and client.alive:
                try:
                    line = await reader.readline()
                except (asyncio.LimitOverrunError, ValueError):
                    client.send(protocol.encode({"t": "error", "msg": "Nachricht zu groß."}))
                    reason = "Nachricht zu groß"
                    break
                if not line:
                    break
                if not client.allow_message():
                    if client.violations > 400:
                        client.send(protocol.encode({"t": "error", "msg": "Zu viele Nachrichten – Verbindung getrennt."}))
                        reason = "Spam"
                        break
                    continue
                try:
                    message = protocol.decode(line)
                except protocol.ProtocolError as exc:
                    client.send(protocol.encode({"t": "result", "rid": None, "ok": False, "msg": str(exc)}))
                    continue
                if message["t"] == "bye":
                    reason = "abgemeldet"
                    break
                self._handle_message(client, message)
        except (ConnectionError, OSError):
            reason = "Verbindungsabbruch"
        finally:
            await asyncio.sleep(0.05)  # ausstehende Fehlermeldungen noch senden
            client.alive = False
            writer_task.cancel()
            self.clients.pop(client.id, None)
            try:
                writer.close()
            except Exception:
                pass
            log.info("%s getrennt (%s), %d Spieler online", client.name, reason, len(self.clients))
            if not self.clients and self._running and self.autosave_enabled:
                self.save()          # letzter Spieler weg -> sofort sichern
            self.broadcast({"t": "event", "kind": "warn", "text": f"{client.name} hat das Spiel verlassen."})

    # ------------------------------------------------------------------ Nachrichten
    def _handle_message(self, client, message):
        kind = message["t"]
        if kind == "pos":
            x, z = message.get("x"), message.get("z")
            if _num(x) and _num(z):
                client.pos = [max(-40.0, min(C.GRID_W + 40.0, float(x))), max(-40.0, min(C.GRID_H + 40.0, float(z)))]
            yaw = message.get("yaw", 0.0)
            client.yaw = float(yaw) % 360 if _num(yaw) else 0.0
            client.moving = message.get("moving") is True
            client.fp = message.get("fp") is True
            client.cursor = message.get("cur") is True
            tool = message.get("tool", "")
            client.tool = tool if isinstance(tool, str) and len(tool) <= 16 else ""
        elif kind == "ping":
            client.send(protocol.encode({"t": "pong", "ts": message.get("ts")}))
        elif kind == "chat":
            text = message.get("text")
            if isinstance(text, str):
                text = "".join(ch for ch in text if ch.isprintable()).strip()[:160]
                if text:
                    self.broadcast({"t": "chat", "name": client.name, "color": client.color, "text": text})
        elif kind == "action":
            self._handle_action(client, message)
        elif kind == "admin":
            self._handle_admin(client, message)
        else:
            client.send(protocol.encode({"t": "result", "rid": None, "ok": False,
                                         "msg": f"Unbekannter Nachrichtentyp '{kind[:20]}'."}))

    def _handle_action(self, client, m):
        rid = m.get("rid") if isinstance(m.get("rid"), int) else None
        error = protocol.validate_action(m)
        if error:
            client.send(protocol.encode({"t": "result", "rid": rid, "ok": False, "msg": error}))
            return
        a = m["a"]
        s = self.state
        try:
            if a == "build":
                ok, msg = s.action_build(m["btype"], m["x"], m["y"], m["rot"], client.name)
            elif a == "demolish":
                ok, msg = s.action_demolish(m["id"], client.name)
            elif a == "rotate":
                ok, msg = s.action_rotate(m["id"], client.name)
            elif a == "move":
                ok, msg = s.action_move(m["id"], m["x"], m["y"], m["rot"], client.name)
            elif a == "set_enabled":
                ok, msg = s.action_set_enabled(m["id"], m["enabled"], client.name)
            elif a == "set_all_enabled":
                ok, msg = s.action_set_all_enabled(m["enabled"], client.name)
            elif a == "set_filter":
                ok, msg = s.action_set_filter(m["id"], m["item"], m["side"], client.name)
            elif a == "set_threshold":
                ok, msg = s.action_set_threshold(m["id"], m["pct"], client.name)
            elif a == "upgrade":
                ok, msg = s.action_upgrade(m["id"], client.name)
            elif a == "set_recipe":
                ok, msg = s.action_set_recipe(m["id"], m["recipe"], client.name)
            elif a == "research":
                ok, msg = s.action_research(m["tech"], client.name)
            elif a == "sell":
                ok, msg = s.action_sell(m["item"], m["amount"], client.name)
            elif a == "order_accept":
                ok, msg = s.action_order_accept(m["oid"], client.name)
            elif a == "order_cancel":
                ok, msg = s.action_order_cancel(m["cid"], client.name)
            elif a == "order_load":
                ok, msg = s.action_order_load(m["cid"], client.name)
            elif a == "save":
                ok, msg = self.save()
            elif a == "load":
                ok, msg = self._load()
            else:
                ok, msg = False, "Unbekannte Aktion."
        except Exception:
            log.exception("Fehler bei Aktion %s", a)
            ok, msg = False, "Interner Serverfehler bei der Aktion."
        client.send(protocol.encode({"t": "result", "rid": rid, "ok": ok, "msg": msg, "a": a}))
        if ok and a in BROADCAST_ACTIONS:
            self.broadcast({"t": "event", "kind": "info", "text": f"{client.name}: {msg}"}, exclude=client)

    # ------------------------------------------------------------------ Admin
    def _handle_admin(self, client, m):
        rid = m.get("rid") if isinstance(m.get("rid"), int) else None

        def reply(ok, msg, **extra):
            client.send(protocol.encode({"t": "result", "rid": rid, "ok": ok, "msg": msg, "a": "admin", **extra}))

        error = protocol.validate_admin(m)
        if error:
            reply(False, error)
            return
        cmd = m["cmd"]
        if cmd == "login":
            if self.admin_password is None:
                reply(False, "Auf diesem Server ist kein Admin-Passwort eingerichtet.")
            elif hmac.compare_digest(m["password"].encode(), self.admin_password.encode()):
                client.admin = True
                client.send(protocol.encode({"t": "you", "admin": True}))
                log.info("%s hat sich als Admin angemeldet.", client.name)
                reply(True, "Du bist jetzt Admin.")
            else:
                log.warning("Falsches Admin-Passwort von %s (%s)", client.name, client.ip)
                reply(False, "Falsches Admin-Passwort.")
            return
        if not client.admin:
            reply(False, "Keine Admin-Rechte.")
            return
        if cmd == "give_money":
            ok, msg = self.state.admin_give_money(m["amount"])
            if ok:
                log.info("Admin %s: %s", client.name, msg)
                self.broadcast({"t": "event", "kind": "info", "text": f"Admin {client.name}: {msg}"}, exclude=client)
            reply(ok, msg)
        elif cmd in ("kick", "ban"):
            target = self.clients.get(m["pid"])
            if target is None:
                reply(False, "Spieler ist nicht (mehr) online.")
                return
            if target is client:
                reply(False, "Du kannst dich nicht selbst entfernen.")
                return
            reason = "".join(ch for ch in m["reason"] if ch.isprintable()).strip()[:60]
            if cmd == "ban":
                self.bans.append({"name": target.name, "ip": target.ip, "reason": reason,
                                  "by": client.name, "time": time.strftime("%Y-%m-%d %H:%M")})
                self._save_bans()
            verb = "gebannt" if cmd == "ban" else "gekickt"
            text = f"Du wurdest vom Server {verb}." + (f" Grund: {reason}" if reason else "")
            target.send(protocol.encode({"t": "kicked", "msg": text}))
            asyncio.get_running_loop().call_later(0.3, self._drop_client, target)
            log.info("Admin %s hat %s %s (%s)", client.name, target.name, verb, reason or "ohne Grund")
            self.broadcast({"t": "event", "kind": "warn", "text": f"{target.name} wurde {verb}."}, exclude=target)
            reply(True, f"{target.name} wurde {verb}.")
        elif cmd == "set_admin":
            target = self.clients.get(m["pid"])
            if target is None:
                reply(False, "Spieler ist nicht (mehr) online.")
                return
            if target is client:
                reply(False, "Deine eigenen Rechte kannst du nicht ändern.")
                return
            if not m["admin"] and self.local_admin and is_loopback(target.ip):
                reply(False, f"{target.name} spielt am Server-PC (Host) und bleibt Admin.")
                return
            target.admin = bool(m["admin"])
            target.send(protocol.encode({"t": "you", "admin": target.admin}))
            text = (f"{client.name} hat {target.name} zum Admin gemacht." if target.admin
                    else f"{client.name} hat {target.name} die Admin-Rechte entzogen.")
            log.info(text)
            self.broadcast({"t": "event", "kind": "info", "text": text})
            reply(True, text)
        elif cmd == "unban":
            key = m["key"].strip().lower()
            before = len(self.bans)
            self.bans = [b for b in self.bans if b.get("name", "").lower() != key and b.get("ip", "") != key]
            if len(self.bans) == before:
                reply(False, "Kein passender Eintrag in der Bannliste.")
                return
            self._save_bans()
            reply(True, f"Bann für '{m['key']}' aufgehoben.")
        elif cmd == "bans":
            client.send(protocol.encode({"t": "bans", "list": self.bans[-50:]}))
            reply(True, f"{len(self.bans)} Einträge in der Bannliste.")

    def _drop_client(self, client):
        client.alive = False
        try:
            client.writer.close()
        except Exception:
            pass

    def _load(self):
        try:
            state, info = load_game(self.save_path)
        except SaveError as exc:
            return False, str(exc)
        state.revision = self.state.revision + 1   # Clients müssen alles neu aufbauen
        self.state = state
        for c in self.clients.values():
            c.last_rev = -1
        self.broadcast({"t": "world", "deposits": state.deposits_list()})
        return True, info


def _num(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
