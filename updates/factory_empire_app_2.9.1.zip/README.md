# Factory Empire

Ein 3D-Fabrik-Tycoon für mehrere Spieler. Ihr baut gemeinsam eine Fabrik: Miner fördern Erz, Förderbänder transportieren es zu Schmelzen und Montageanlagen, Verkäufer bringen die Produkte auf den Markt – und mit den Einnahmen erforscht ihr neue Technologien.

- Echte 3D-Welt (Ursina/Panda3D) mit Strategiekamera, weichen Animationen und Tutorial für neue Spiele
- **Aufträge mit LKW-Lieferungen**: Städte bestellen Waren („13× Batterie nach Köln“), der **Frachtbahnhof** belädt einen LKW, der fährt los und bringt nach einigen Minuten eine dicke Belohnung; Speditions-Ruf mit steigenden Belohnungen
- **Automatische Updates**: neue Versionen werden direkt im Spiel installiert (Fenster „Update verfügbar“), danach zeigt das Spiel, was neu ist
- **Discord-Status**: Discord zeigt „Spielt Factory Empire“ mit Logo, Spielmodus, Geld, Maschinen und Spielzeit (abschaltbar in den Optionen)
- **Statistiken & Erfolge** im Hauptmenü (Spielzeit, Welten, gebaute und ausgebaute Maschinen, verdientes Geld …, 15 Erfolge)
- Dichter **Wald** rund um die Fabrik, der zum Horizont hin im Dunst verschwindet, eine **Landstraße mit Verkehr** hinter dem Zaun
- Fabrikfläche aus **Rasen** mit eingebetteten Erzfeldern, hügelige Landschaft mit See, Wäldern, Büschen, Blumen, Felsen, ziehenden Wolken
- Animierte Maschinen mit Rauch, Funken, Staub und Münzeffekten, Bau- und Abriss-Animationen
- Dedizierter Server – die gesamte Wirtschaft und Produktion läuft serverseitig
- Multiplayer **online per Raum-Code** (keine IP, keine Router-Freigabe), im Heimnetz oder klassisch per IP; **5 Welten-Plätze** wie im Einzelspieler, Mitspieler als farbige **Mauszeiger**, Chat, Server-Passwort
- **Admin-Panel**: Geld geben, **Mitspielern Admin-Rechte geben oder entziehen**, Spieler kicken und bannen, Bannliste
- Förderbänder mit **Kurven** (gehen sie um die Ecke, entsteht automatisch ein Bogen)
- **Chat** im Mehrspieler: **T** drücken, schreiben, Enter
- Förderbänder plus **Splitter, T-Stück und Sortierer** (Richtung je Ware einstellbar)
- Maschinen **an- und ausschalten**, **versetzen**, Ausbaustufen mit **Produktion pro Minute je Stufe**
- **Große Welt (96 × 96 Felder)** mit fünf Rohstoffen: Eisen, Kupfer, Kohle, Stein, Sand
- **24 Waren** in langen Produktionsketten bis zu Computern, Solarmodulen, Fertighäusern, Robotern und Elektroautos; **sieben Fabriktypen** – jedes Material hat seine eigene Fabrik
- Forschungsbaum mit **41 Technologien** in zwei Reitern (Gebäude & Produkte, Verbesserungen), dynamischer Markt, Verkäufer mit **Mindestpreis**
- Energiekosten werden **alle 5 Sekunden** abgerechnet
- Neue Oberfläche: Kaufmenü (Q), Hotbar mit 3D-Icons, Minimap, Einstellungen mit **GUI-Größe**, Vollbild (F11)
- **Läuft auch mit sehr großen Fabriken flüssig** (nur sichtbare Gebäude werden animiert, Detailstufen, sparsame Netzwerk-Übertragung); Optionen für **V-Sync, FPS-Begrenzer und Schatten**
- Speichern und Laden (JSON, atomar, mit Sicherungskopie und Autosave)
- Keine kostenpflichtigen Assets: Modelle, Texturen, Icons und Sounds sind selbst erzeugt

---

## Inhalt

1. [Schnellstart](#1-schnellstart)
2. [Python installieren](#2-python-installieren)
3. [Installation unter Windows](#3-installation-unter-windows)
4. [Installation unter macOS](#4-installation-unter-macos)
5. [Server und Spiel starten](#5-server-und-spiel-starten)
6. [Mehrspieler im lokalen Netzwerk](#6-mehrspieler-im-lokalen-netzwerk)
   - [Online spielen über IP und Port](#online-spielen-über-ip-und-port)
7. [Firewall](#7-firewall)
8. [Speichern, Laden und Beenden](#8-speichern-laden-und-beenden)
9. [Steuerung](#9-steuerung)
10. [Spielanleitung](#10-spielanleitung)
11. [Fehlerbehebung](#11-fehlerbehebung)
12. [Projektaufbau und technische Entscheidungen](#12-projektaufbau-und-technische-entscheidungen)
13. [Tests](#13-tests)
14. [Bekannte Einschränkungen](#14-bekannte-einschränkungen)

---

## 1. Schnellstart

**Ohne Python (empfohlen zum Spielen):** Es gibt fertige Pakete, die alles mitbringen:

| | Windows | macOS (Apple Silicon und Intel) |
|---|---|---|
| Paket | `FactoryEmpire-Windows.zip` | `FactoryEmpire-macOS.zip` |
| Spielen | ZIP entpacken, Doppelklick auf `Factory Empire.exe` | ZIP entpacken, `Factory Empire.app` öffnen |
| Online-Server | `Online-Server starten.exe` | `Online-Server starten.command` |
| Spielstände | Ordner `saves` neben der .exe | `~/Library/Application Support/Factory Empire` |

Die Programme sind nicht kostenpflichtig signiert: Windows zeigt beim ersten Start „Der Computer wurde durch Windows geschützt“ → „Weitere Informationen“ → „Trotzdem ausführen“. macOS blockiert den ersten Start → Systemeinstellungen → Datenschutz & Sicherheit → „Trotzdem öffnen“. Details stehen in der `LIESMICH.txt` im jeweiligen Paket. Gebaut werden die Pakete mit `tools/packaging/build_portable.py` (unter Linux; Anleitung im Kopf der Datei).

**Mit installiertem Python:**

| | Windows | macOS |
|---|---|---|
| Spiel starten (installiert beim ersten Mal alles automatisch) | Doppelklick auf `start_game_windows.bat` | Doppelklick auf `start_game_mac.command` |
| Nur Server starten | `start_server_windows.bat` | `start_server_mac.command` |

### Das Hauptmenü

Hinter dem großen Titel arbeitet eine kleine Beispielfabrik. Unten stehen vier Knöpfe:

| Knopf | Was passiert |
|---|---|
| **Einzelspieler** | **5 Spielstand-Plätze** – jeder Platz ist eine eigene Welt (mit eigener Karte). Pro Platz „Spielen“ oder „Neu“ (zum Ersetzen zweimal klicken, eine Sicherung bleibt). Der Server läuft unsichtbar im Hintergrund und nur auf deinem PC, niemand sonst kann beitreten. Dateien: `singleplayer.json` (Platz 1, auch dein bisheriger Stand) und `singleplayer_2.json` … `singleplayer_5.json`. |
| **Mehrspieler → Spiel hosten** | Wie im Einzelspieler **5 Plätze** („Platz 1“ … „Platz 5“): Platz anklicken, die Zeile darunter zeigt Gebäude, Geld und wann zuletzt gespielt wurde. „Server starten & spielen“ lädt die Welt, **„Neu“** ersetzt sie durch eine neue Welt (zweimal klicken, eine Sicherung bleibt); auf einem leeren Platz heißt der Knopf „Neue Welt starten“. Dateien: `factory.json` (Platz 1, auch dein bisheriger Mehrspieler-Stand) und `multiplayer_2.json` … `multiplayer_5.json`. Welten aus Version 2.5/2.6 (Ordner `saves/worlds/`) werden beim ersten Start automatisch auf freie Plätze verschoben. Passwort eintragen (empfohlen), „Server starten & spielen“. Mit **„Online mit Raum-Code“** (Standard) bekommst du einen Code wie **FE-41234** – oben im Spiel, im Esc-Menü mit Knopf **„Kopieren“**. **Keine IP, keine Router-Freigabe nötig**, funktioniert auch mit DS-Lite-Anschlüssen. Schaltest du den Raum-Code aus, läuft es klassisch über IP + Portfreigabe (das Spiel versucht die Freigabe per UPnP selbst). |
| **Mehrspieler → Spiel beitreten** | Raum-Code (oder IP-Adresse) und ggf. Passwort eintragen, „Beitreten“. |

**Wie funktioniert der Raum-Code?** Dein Spiel verbindet sich nach außen mit einem kostenlosen öffentlichen Vermittlungsserver (bore.pub). Der vergibt eine Nummer – das ist der Raum-Code – und leitet die Verbindungen deiner Freunde zu dir durch. Weil nur ausgehende Verbindungen nötig sind, braucht der Router keine Einstellungen. Hinweise: bore.pub wird von Freiwilligen betrieben, es gibt keine Garantie, dass der Dienst immer erreichbar ist – ist er es nicht, meldet das Spiel das und versucht automatisch den klassischen Weg (IP + Port). Wer einen eigenen Vermittlungsserver betreibt (`bore server`), kann ihn mit der Umgebungsvariable `FACTORY_EMPIRE_RELAY=<adresse>` verwenden – Host und Mitspieler müssen dann dieselbe Adresse eingestellt haben. Spieler, die über den Raum-Code kommen, werden nie automatisch Admin; nutze ein Passwort, damit nur deine Freunde beitreten.
| **Optionen** | GUI-Größe, Vollbild, **V-Sync** (wirkt nach Neustart), **FPS-Begrenzer**, **Schatten** (Hoch/Mittel/Niedrig/Aus), **Landschafts-Details**, Maus, Lautstärke, **Größe der Mitspieler-Zeiger** … |
| **Beenden** | Spiel schließen (ein selbst gestarteter Server speichert und wird mit beendet). |

Über **Esc → „Verbindung trennen“** kommst du jederzeit zurück ins Hauptmenü; ein eigener Server wird dabei gespeichert und beendet.

---

## 2. Python installieren

**Benötigt wird Python 3.10 bis 3.13. Empfohlen: Python 3.12.**
(Entwickelt und getestet mit Python 3.13; Panda3D, Ursina und Pygame bieten für 3.10–3.13 fertige Pakete für Windows und macOS an.)

### Windows

1. <https://www.python.org/downloads/windows/> öffnen und den **Windows installer (64-bit)** für Python 3.12 herunterladen.
2. Installer starten und **unbedingt „Add python.exe to PATH“ anhaken**.
3. „Install Now“ wählen.
4. Prüfen (Eingabeaufforderung oder PowerShell öffnen):
   ```bat
   py --version
   ```
   Es sollte `Python 3.12.x` erscheinen.

### macOS

1. <https://www.python.org/downloads/macos/> öffnen und den **macOS 64-bit universal2 installer** für Python 3.12 herunterladen (läuft auf Intel und Apple Silicon).
2. Das `.pkg` installieren.
3. Prüfen (Programm **Terminal** öffnen):
   ```bash
   python3 --version
   ```

Alternativ mit Homebrew: `brew install python@3.12` (dann `python3.12` statt `python3` verwenden).

---

## 3. Installation unter Windows

Projektordner entpacken, z. B. nach `C:\Spiele\FactoryEmpire`. Dann **Eingabeaufforderung** (cmd) öffnen:

```bat
cd C:\Spiele\FactoryEmpire
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Die virtuelle Umgebung ist aktiv, wenn vor der Eingabezeile `(.venv)` steht. In jedem neuen Fenster muss sie erneut aktiviert werden:

```bat
cd C:\Spiele\FactoryEmpire
.venv\Scripts\activate
```

> PowerShell: Falls `activate` mit „Ausführung von Skripts ist deaktiviert“ abbricht, entweder cmd verwenden oder einmalig
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` ausführen und dann `.venv\Scripts\Activate.ps1` starten.

## 4. Installation unter macOS

Projektordner entpacken, z. B. nach `~/Spiele/FactoryEmpire`. Dann **Terminal** öffnen:

```bash
cd ~/Spiele/FactoryEmpire
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

In jedem neuen Terminalfenster erneut aktivieren:

```bash
cd ~/Spiele/FactoryEmpire
source .venv/bin/activate
```

> Lassen sich die `.command`-Dateien nicht per Doppelklick starten, einmalig ausführbar machen:
> `chmod +x start_game_mac.command start_server_mac.command`.
> Meldet macOS „kann nicht geöffnet werden, da der Entwickler nicht verifiziert werden kann“: Rechtsklick → **Öffnen** → **Öffnen**.

---

## 5. Server und Spiel starten

Alle Befehle im Projektordner mit **aktivierter virtueller Umgebung**.

### Server starten

| Windows | macOS |
|---|---|
| `python server.py` | `python server.py` |

Der Server lauscht standardmäßig auf **Port 5600** auf allen Netzwerkkarten und lädt automatisch `saves/factory.json` (falls vorhanden). Ausgabe:

```
=== Factory Empire Server 1.0.0 ===
19:05:49 [INFO] Spielstand geladen: factory.json
19:05:49 [INFO] Server läuft auf ('0.0.0.0', 5600) (Protokoll v1)
```

Nützliche Optionen:

```bash
python server.py --port 6000            # anderer Port
python server.py --new                  # neue Fabrik (alter Stand wird umbenannt, nicht gelöscht)
python server.py --save saves/firma2.json   # anderer Spielstand
python server.py --seed 42 --new        # andere Karte
```

Während der Server läuft, versteht er Konsolenbefehle: `save`, `players`, `money`, `quit`.

### Spiel (Client) starten

```bash
python main.py
```

Im Hauptmenü **Mehrspieler → Spiel beitreten**: IP, Port und ggf. Passwort eintragen und **„Beitreten“** klicken – oder **Mehrspieler → Spiel hosten**, dann startet das Spiel den Server selbst im Hintergrund (Protokoll in `server.log` im Spielstand-Ordner).

Direktstart ohne Menü:

```bash
python main.py --local                                   # lokaler Server + spielen
python main.py --connect --host 192.168.1.20 --name Anna # direkt verbinden
python main.py --graphics low                            # ohne Schatten (alte Grafikkarten)
python main.py --size 1280x720 --aa --fps                # Fenstergröße, Kantenglättung, FPS
python main.py --help                                    # alle Optionen
```

---

## 6. Mehrspieler im lokalen Netzwerk

Ein Rechner ist der **Host**: Er startet den Server (oder im Spiel „Mehrspieler → Spiel hosten“). Alle anderen verbinden sich mit der lokalen IP-Adresse des Hosts.

### Lokale IP-Adresse des Hosts ermitteln

**Windows** – in der Eingabeaufforderung:
```bat
ipconfig
```
Gesucht ist beim aktiven Adapter (WLAN oder Ethernet) die Zeile **IPv4-Adresse**, z. B. `192.168.178.23`.

**macOS** – im Terminal:
```bash
ipconfig getifaddr en0      # WLAN (bei manchen Macs: en1)
ipconfig getifaddr en1
```
Oder: **Systemeinstellungen → WLAN → Details → TCP/IP → IP-Adresse**.

### Verbinden

1. Host startet den Server (bzw. „Mehrspieler → Spiel hosten“).
2. Mitspieler starten `python main.py`, tragen die IP des Hosts (z. B. `192.168.178.23`) und den Port (`5600`) ein und klicken **Beitreten**.
3. Oben rechts erscheint die Spielerliste, Mitspieler sind als kleine Bauarbeiter in ihrer Spielerfarbe in der Welt zu sehen. **Enter** öffnet den Chat.

Alle Spieler bauen an **derselben Fabrik** mit **gemeinsamem Firmenkonto**. Jede Aktion wird vom Server geprüft; wer zuerst klickt, bekommt das Feld.

Bricht die Verbindung ab, zeigt das Spiel „Verbindung verloren“ mit dem Grund und einem Knopf zum erneuten Verbinden. Die Fabrik läuft auf dem Server weiter.

### Online spielen über IP und Port

Freunde von woanders treten über die **öffentliche IP** (oder eine Adresse wie `meinefabrik.duckdns.org`) und den **Port** bei. Dafür gibt es zwei Wege.

#### A) Dein eigener PC ist der Server

**Windows:** Doppelklick auf `start_online_server_windows.bat`
**macOS:** Doppelklick auf `start_online_server_mac.command`
(oder im Terminal: `python server.py --online --password geheim`)

Das Skript fragt nach einem **Passwort** (empfohlen, leer lassen = ohne Passwort) und startet den Server im Online-Modus. Der Server:
1. versucht, den Port **automatisch im Router freizugeben** (UPnP) – bei Erfolg musst du am Router nichts tun,
2. zeigt dir deine **öffentliche IP** und alle anderen Adressen an,
3. erkennt, ob dein Anschluss überhaupt eine öffentliche IPv4-Adresse hat (DS-Lite/Carrier-NAT),
4. entfernt die Router-Freigabe beim Beenden (Strg+C) wieder.

Beispielausgabe:
```
==================================================================
  ONLINE-MODUS – so können Freunde beitreten
==================================================================
  Im selben WLAN/LAN:   192.168.178.23   Port 5600
  Über das Internet:    87.123.45.67   Port 5600

  [OK] Port 5600 wurde automatisch im Router freigegeben (UPnP).
       Freunde geben im Spiel ein:  87.123.45.67  und Port 5600
==================================================================
```

Dein Freund startet das Spiel, trägt **IP, Port und ggf. Passwort** ein und klickt **Beitreten**. Im IP-Feld geht auch `87.123.45.67:5600` in einem Stück.

**Falls die automatische Freigabe nicht klappt** (`[!] Automatische Portfreigabe nicht möglich`):
- **FritzBox:** Entweder unter *Internet → Freigaben → Portfreigaben → (dein PC) → „Selbstständige Portfreigaben für dieses Gerät erlauben“* anhaken und den Server neu starten – **oder** die Freigabe von Hand anlegen: *Neue Freigabe → Portfreigabe → Protokoll TCP, Port 5600 bis 5600, an Port 5600*.
- **Andere Router:** Menüpunkt „Port Forwarding“, „NAT“ oder „Virtueller Server“: TCP 5600 → lokale IP deines PCs (steht in der Ausgabe).
- **Windows-Firewall** (Eingabeaufforderung als Administrator):
  `netsh advfirewall firewall add rule name="Factory Empire" dir=in action=allow protocol=TCP localport=5600 profile=any`

**Wichtig:**
- Teste nicht mit deiner eigenen öffentlichen IP aus deinem eigenen WLAN – das klappt bei vielen Routern nicht. Lass den Freund testen oder nimm den Handy-Hotspot.
- Meldet der Server **„DS-Lite/Carrier-NAT“**, hat dein Anschluss keine eigene öffentliche IPv4 (häufig bei Kabel/Vodafone, O2, Glasfaser). Dann geht es nur über **IPv6** (der Server lauscht automatisch auch auf IPv6; im Router muss dafür eine IPv6-Freigabe für deinen PC angelegt werden und dein Freund braucht ebenfalls IPv6) oder über Weg B.
- Die öffentliche IP ändert sich oft täglich. Eine feste Adresse bekommst du kostenlos mit **MyFRITZ!** oder **duckdns.org**; die tragen Freunde dann statt der IP ein.
- Dein PC muss laufen, solange gespielt wird.

#### B) Gemieteter Server (läuft rund um die Uhr)

Ein kleiner Linux-Server (VPS) für ca. 4–5 €/Monat (z. B. Hetzner, Netcup, IONOS) hat eine feste öffentliche IP. Der Spielserver braucht **nur Python 3** – keine Grafikkarte, keine weiteren Pakete.

```bash
# Projekt hochladen (z. B. mit WinSCP / scp), dann auf dem Server:
sudo apt install -y unzip && unzip FactoryEmpire.zip && cd FactoryEmpire
sudo bash deploy/install_linux_server.sh geheim123     # Passwort optional
```

Das Skript richtet einen Systemdienst ein (startet automatisch nach Neustarts, speichert beim Stoppen), öffnet den Port in der Firewall und zeigt die IP an, mit der sich alle verbinden. Beim Anbieter ggf. zusätzlich Port 5600/TCP in dessen Cloud-Firewall freigeben.

#### Sicherheit

Ohne Passwort kann jeder beitreten, der IP und Port kennt, und in eurer Fabrik bauen oder abreißen. Für Online-Server daher immer `--password` verwenden. Falsche Passwörter werden abgelehnt und gebremst. Die Verbindung selbst ist nicht verschlüsselt – das Passwort schützt vor Fremden, nicht vor Mitlesern im Netz. Bei Sorge: eigene Passwörter nicht wiederverwenden.

## 7. Firewall

Nur der **Host-Rechner** muss eingehende Verbindungen auf **TCP-Port 5600** erlauben.

**Windows:** Beim ersten Serverstart erscheint „Windows-Sicherheit: Einige Features dieser App wurden blockiert“. **Private Netzwerke** anhaken und **Zugriff zulassen** klicken. Falls der Dialog nicht kam, als Administrator in der Eingabeaufforderung:
```bat
netsh advfirewall firewall add rule name="Factory Empire" dir=in action=allow protocol=TCP localport=5600 profile=private
```
Wichtig: Das Netzwerk muss in Windows als **Privates Netzwerk** eingestuft sein (Einstellungen → Netzwerk und Internet → WLAN/Ethernet → Netzwerkprofiltyp).

**macOS:** Ist die Firewall aktiv (Systemeinstellungen → Netzwerk → Firewall), fragt macOS beim ersten Start „Soll das Programm Python eingehende Netzwerkverbindungen akzeptieren?“ → **Erlauben**. Alternativ unter Firewall → Optionen „Python“ hinzufügen und eingehende Verbindungen erlauben.

Andere Port-Nummer? Dann überall `5600` durch eure Nummer ersetzen (`--port`).

---

## 8. Speichern, Laden und Beenden

Der Spielstand liegt auf dem **Server** in `saves/factory.json` und enthält Geld, Lagerbestände, alle Gebäude mit Position, Ausrichtung, Ausbaustufe und Produktionsfortschritt, Gegenstände auf den Förderbändern, Rezepte, Forschung (inkl. laufender Forschung), Marktpreise und Statistiken.

Gespeichert wird:
- automatisch **alle 60 Sekunden**,
- mit **F5** im Spiel (oder Menü → Speichern, oder Konsolenbefehl `save`),
- wenn der **letzte Spieler** den Server verlässt,
- beim **Beenden des Servers** mit **Strg+C** bzw. `quit`,
- beim Beenden des Spiels, wenn ihr den Server über „Spiel hosten“ bzw. „Einzelspieler“ gestartet habt.

Jedes Speichern schreibt zuerst in eine temporäre Datei und ersetzt dann die alte – ein Absturz kann den Spielstand nicht zerstören. Die vorherige Version bleibt als `factory.json.bak` erhalten und wird automatisch genutzt, falls die Hauptdatei beschädigt ist. Ein Serverneustart lädt immer den letzten Stand; `--new` benennt den alten Stand um (`factory.json.<Datum>.alt`), statt ihn zu löschen.

**F9** lädt den letzten Speicherstand für **alle** Spieler (zur Sicherheit zweimal innerhalb von 4 Sekunden drücken).

**Beenden:** Esc → „Spiel beenden“ oder Fenster schließen. Den Server mit **Strg+C** (macOS: **Ctrl+C**) im Serverfenster oder mit `quit` beenden. Backups: einfach den Ordner `saves/` kopieren.

---

## 9. Steuerung

**Kamera (Strategieansicht)**

| Taste | Funktion |
|---|---|
| **W A S D** / Pfeil hoch-runter | Kamera bewegen (Shift = schneller) |
| **Rechte Maustaste** halten | Kamera drehen und neigen |
| Pfeil links/rechts | Kamera drehen |
| **Mausrad** / mittlere Maustaste | Zoomen / Verschieben |
| Klick auf die **Minimap** | Kamera fährt weich dorthin |

Im Mehrspieler siehst du von den anderen Spielern nur ihren **Mauszeiger** in ihrer Spielerfarbe mit Namen (und dem Gebäude, das sie gerade in der Hand haben) sowie einen Ring auf dem Feld, auf das sie zeigen.

**Große Fabriken (ab 2.5.1):** Die unbeweglichen Teile aller Gebäude eines Kartenabschnitts werden zu wenigen großen Modellen zusammengefasst; nur rund um den Blickpunkt werden Gebäude einzeln mit allen beweglichen Teilen gezeigt. Das spart rund 80 % der Zeichenaufrufe.

**Ruckelt es?** Optionen → Leistung: Schatten auf „Aus“ (Standard seit 2.7 – dann nutzt das Spiel eine besonders schnelle Beleuchtung, gedacht für 120 FPS und mehr), V-Sync aus, FPS-Begrenzer auf „Unbegrenzt“ oder 120/144. Waren auf Förderbändern werden je Kartenabschnitt zusammengefasst und sind dadurch auch aus der Ferne sichtbar, ohne Leistung zu kosten. Große Fabriken sind seit Version 2.5 deutlich schneller: Nur Gebäude im Bild werden animiert, aus der Ferne werden Kleinteile ausgeblendet, Schatten werden nur rund um den sichtbaren Bereich berechnet, und der Server überträgt pro Sekunde nur noch, was sich geändert hat.

**Bauen und Verwalten**

| Taste | Funktion |
|---|---|
| **Q** | Kaufmenü mit allen Gebäuden |
| **1** … **9** | Miner, Schmelze, Förderband, Verkäufer, Lager, Montageanlage, Splitter, T-Stück, Sortierer |
| **Linksklick** | Platzieren · Auswählen · Abreißen (je nach Werkzeug) |
| Linksklick **ziehen** | Förderbänder in Zugrichtung verlegen (Kurven automatisch) |
| **E** / **Shift+E** | Vor dem Bau oder beim Versetzen drehen (Pfeile zeigen die Ausgänge) |
| **X** | Abrisswerkzeug (50 % Rückerstattung) |
| **Leertaste** | Auswahlwerkzeug (in der Strategieansicht) |
| **P** | Ausgewähltes Gebäude an/aus |
| **G** | Ausgewähltes Gebäude versetzen (Zielfeld anklicken) |
| **U / E / Entf** | Ausgewähltes Gebäude ausbauen / drehen / abreißen |

**Menüs**

| Taste | Funktion |
|---|---|
| **Esc** | Fenster schließen → Werkzeug abbrechen → Menü & Einstellungen |
| **R** / **M** | Forschungsbaum / Markt |
| **F1** / **F2** | Hilfe / Admin-Panel |
| **F5** / **F9** | Speichern / Laden (zweimal drücken) |
| **F11** | Vollbild an/aus (randlos; im Vollbild zeichnet das Spiel einen eigenen Mauszeiger, damit er immer sichtbar ist; Esc verlässt das Vollbild nicht) |
| **Enter** | Chat |

**Einstellungen (Esc):** GUI-Größe (60–160 %), Vollbild, Bau-Raster, Partikeleffekte, FPS-Anzeige, Maus-Empfindlichkeit, Lautstärke. Sie werden in `saves/client_settings.json` gespeichert.

---

## 10. Spielanleitung

**Aufträge & Frachtbahnhof (ab Version 2.8):** Nach der Forschung **„Spedition“** (R) erscheinen in der **Auftragsbörse (O)** Bestellungen aus Städten wie Leipzig, Berlin, Hamburg, München, Wien oder Paris – z. B. „20× Kupferbarren nach Berlin, Fahrzeit 4 Minuten, 1.350 €“. Ablauf:
1. Auftrag annehmen (höchstens 6 gleichzeitig). Oben links zeigt eine Leiste, was gerade läuft.
2. **Frachtbahnhof** bauen (Kaufmenü Q → Lager & Handel). Jede Ausbaustufe bringt einen LKW mehr (1/2/3).
3. Der LKW am Bahnhof wird mit der bestellten Ware beladen: per **Förderband** (der Bahnhof nimmt von allen Seiten an, man sieht die Ladung auf der Pritsche wachsen) oder mit **„Aus Lager“** direkt aus dem Firmenlager.
4. Ist er voll, fährt der LKW los (er biegt auf die Landstraße ab). Nach der Fahrzeit kommt die Lieferung an und die Belohnung wird gutgeschrieben – meist das 3- bis 6-Fache des Marktpreises. Danach fährt er leer zurück.

Alle 5 Lieferungen steigt der **Speditions-Ruf** (+4 % Belohnung je Stufe, bis Stufe 10). Die Forschung **„Autobahnanbindung“** verkürzt alle Fahrten um 30 %. Angebote laufen nach einigen Minuten ab, neue kommen etwa alle halbe Minute. Stornieren geht, solange der LKW noch nicht losgefahren ist (die Ladung kommt zurück ins Lager, soweit Platz ist).

**Statistiken (Hauptmenü):** Spielzeit, längste Sitzung, Partien, erstellte Welten, gebaute/ausgebaute/abgerissene Maschinen, verdientes Geld, höchster Kontostand, hergestellte Waren, Forschungen, Aufträge – über alle Welten hinweg, gespeichert in `saves/stats.json`. Dazu 15 **Erfolge** (z. B. „Millionär“, „Spediteur“, „Baulöwe“), die im Spiel mit einer Einblendung freigeschaltet werden.

**Tutorial (ab Version 2.4):** Bei jedem neuen Spiel – Einzelspieler oder Mehrspieler – startet automatisch ein Tutorial mit 10 Schritten. Es erkennt selbst, wann ein Schritt erledigt ist, hebt den passenden Knopf in der Hotbar hervor und zeigt mit einem Pfeil in der Welt, wohin gebaut werden soll. Abschaltbar unter Optionen → „Tutorial bei neuem Spiel“, jederzeit neu startbar über F1 → „Tutorial starten“.

**Start:** 2.500 € und eine große, leere Fläche (96 × 96 Felder). Rötliche Felder sind **Eisenerz**, orange **Kupfererz**, schwarze **Kohle**, graue **Stein**, gelbe **Sand**. Nahe der Kartenmitte liegt von jedem Rohstoff ein Vorkommen, weitere sind über die ganze Karte verteilt (Minimap unten links).

1. **Miner (1)** auf ein Erzfeld setzen, mit Q/E so drehen, dass der Pfeil zu einem freien Feld zeigt.
2. Direkt davor ein **Lager (5)** bauen. Das Erz landet im Firmenlager (oben in der Leiste).
3. Im **Markt (M)** das Erz verkaufen.
4. **Forschung (R):** zuerst *Logistik* (Förderbänder) und *Schmelztechnik* (Schmelzen).
5. Kette bauen: **Miner → Förderbänder → Schmelze → Förderband → Lager**. Barren sind dreimal so viel wert wie Erz.
6. *Automatischer Verkauf* schaltet **Verkäufer (4)** frei – die verkaufen ohne Zutun.
7. Später: *Fortgeschrittene Produktion* (**Montageanlage (6)**: Zahnräder, Draht) und *Elektronik* (Schaltkreise).
8. Ab hier wird es groß – die Produktionsketten:

| Produkt | Fabrik | Zutaten | Forschung |
|---|---|---|---|
| Eisenbarren | Schmelze | 1 Eisenerz | – |
| Kupferbarren | Schmelze | 1 Kupfererz | – |
| Stahl | Hochofen | 1 Eisenbarren + 1 Kohle | Stahlverhüttung |
| Stahl | Hochofen | 2 Eisenbarren | Stahlverhüttung |
| Stahlträger | Hochofen | 2 Stahl | Bauindustrie |
| Ziegel | Baustoffwerk | 2 Stein | Baustoffe |
| Glas | Baustoffwerk | 2 Sand | Baustoffe |
| Beton | Baustoffwerk | 1 Stein + 1 Sand | Bauindustrie |
| Zahnrad | Montageanlage | 2 Eisenbarren | – |
| 2 Kupferdraht | Montageanlage | 1 Kupferbarren | – |
| Motor | Montageanlage | 2 Zahnrad + 1 Stahl + 2 Kupferdraht | Motorenbau |
| Kunststoff | Chemiewerk | 2 Kohle | Chemie |
| Batterie | Chemiewerk | 1 Kupferbarren + 1 Kohle + 1 Kupferdraht | Akkutechnik |
| Schaltkreis | Elektronikwerk | 3 Kupferdraht + 1 Kunststoff | Elektronik |
| Prozessor | Elektronikwerk | 2 Schaltkreis + 1 Glas | Computertechnik |
| Computer | Elektronikwerk | 1 Prozessor + 2 Kunststoff + 1 Glas + 2 Kupferdraht | Computertechnik |
| Solarmodul | Großfabrik | 2 Glas + 1 Schaltkreis + 1 Stahlträger | Solarmodule |
| Fertighaus | Großfabrik | 4 Ziegel + 2 Beton + 2 Glas + 1 Stahlträger | Fertighausbau |
| Roboter | Großfabrik | 1 Motor + 1 Computer + 1 Stahlträger | Robotik |
| Elektroauto | Großfabrik | 2 Motor + 4 Batterie + 2 Stahlträger + 1 Computer + 2 Kunststoff | Elektromobilität |

Je weiter hinten in der Kette, desto wertvoller: Ein Elektroauto bringt rund 2.900 €, ein Eisenerz 4 €. Seit Version 2.6 hat jedes Material seine eigene Fabrik: **Baustoffwerk** (Ziegel, Glas, Beton), **Hochofen** (Stahl, Stahlträger), **Montageanlage** (Zahnräder, Draht, Motoren), **Chemiewerk** (Kunststoff, Batterien), **Elektronikwerk** (Schaltkreise, Prozessoren, Computer) und **Großfabrik** (Endprodukte). Alle nehmen von allen Seiten an; das Rezept wählst du im Infofenster. Die neuen Fabriken haben keine Zifferntaste – du findest sie in der Hotbar und im Kaufmenü (Q). Alte Spielstände werden übernommen; Maschinen mit einem Rezept, das jetzt in eine andere Fabrik gehört, stellen automatisch auf ihr erstes Rezept um. Die Leiste oben zeigt nur die Waren, die gerade im Lager sind.

Alte Spielstände (kleine Karte) laufen weiter: die bisherigen Erzfelder bleiben, die Karte wird nur größer und bekommt die neuen Rohstoffe dazu.

**Regeln:**
- Gebäude geben nur **nach vorne** aus (Pfeilrichtung). Schmelzen, Montageanlagen, Lager und Verkäufer nehmen von allen Seiten an.
- Förderbänder nehmen von hinten und von den Seiten an; mehrere Bänder lassen sich zusammenführen.
- **Splitter** (nach *Verteiltechnik*): nimmt von hinten an und verteilt abwechselnd nach vorne, links und rechts.
- **T-Stück** (nach *Verteiltechnik*): nimmt von hinten an und verteilt abwechselnd nach links und rechts.
- **Sortierer** (nach *Sortiertechnik*): im Infofenster für jede Ware „Links“, „Vorne“ oder „Rechts“ wählen; nicht eingestellte Waren gehen nach vorne.
- Schmelzen und Montageanlagen kosten pro Arbeitsgang **Energie**. Sie wird gesammelt und **alle 5 Sekunden** abgebucht (Anzeige oben links). Gebäude, die das Geld nicht mehr decken würde, warten.
- Jedes Gebäude (außer Bändern und Verteilern) lässt sich bis **Stufe 3** ausbauen (+50 % / +100 % Tempo bzw. Lagerplatz). Das Infofenster zeigt für jede Stufe die **Produktion pro Minute**, die Energiekosten und die tatsächlich gemessene Leistung.
- **Verkäufer** lassen sich auf einen Mindestpreis einstellen (z. B. „+10 %“): Sie verkaufen dann erst, wenn der Marktpreis mindestens 10 % über dem Grundpreis liegt.
- Jede Maschine kann mit **P** ausgeschaltet werden (graue Lampe, „AUS“-Schild) und mit **G** an einen anderen Platz versetzt werden – Inhalt und Ausbaustufe bleiben erhalten.
- Der Markt reagiert auf Verkäufe: Große Mengen drücken den Preis, er erholt sich mit der Zeit. Mehrere Produkte zu verkaufen lohnt sich.

**Statusanzeige:** Jede Maschine hat eine Lampe – **grün** = produziert, **gelb** = wartet auf Material, **rot + schwebendes „!“** = Problem. Anklicken zeigt die Ursache und einen Lösungstipp („Keine Ausgangsverbindung“, „Ungültige Verbindung“, „Ausgang blockiert“, „Lager voll“, „Kein Geld für Energie“). Links unten fasst die Produktionsübersicht alle Störungen zusammen.

---

### Admin-Panel (F2)

Admin ist automatisch, **wer auf dem Server-PC spielt** (Verbindung über 127.0.0.1, also auch „Mehrspieler → Spiel hosten“). Weitere Admins:
- In der **Serverkonsole** `admin <Name>` eingeben, oder
- den Server mit `--admin-password <passwort>` starten; Spieler melden sich dann im Admin-Panel an.

Im Admin-Panel: Geld geben oder abziehen, Spieler **kicken** oder **bannen** (nach Name und IP, gespeichert in `saves/bans.json`), Bannliste mit „Entbannen“, alle Gebäude an/aus.
Dieselben Befehle gibt es in der Serverkonsole: `give <betrag>`, `kick <name>`, `ban <name>`, `unban <name oder ip>`, `bans`, `players`.

---

## 11. Fehlerbehebung

| Problem | Lösung |
|---|---|
| `'py'` bzw. `'python'` wird nicht erkannt (Windows) | Python neu installieren und **„Add python.exe to PATH“** anhaken. Danach neues Fenster öffnen. |
| `python3: command not found` (macOS) | Python von python.org installieren (Abschnitt 2). |
| `pip install` scheitert bei panda3d/pygame (`No matching distribution`) | Python-Version prüfen: 3.10–3.13 nötig, **64-Bit**. Python 3.14+ hat evtl. noch keine fertigen Pakete → Python 3.12 verwenden. |
| `ModuleNotFoundError: No module named 'ursina'` | Virtuelle Umgebung ist nicht aktiv: `.venv\Scripts\activate` (Windows) bzw. `source .venv/bin/activate` (macOS). |
| „Verbindung zu … abgelehnt“ | Server läuft nicht oder falscher Port. Serverfenster prüfen. |
| „Falsches Server-Passwort“ / „passwortgeschützt“ | Unter Mehrspieler → Spiel beitreten das Passwort des Servers eintragen. |
| Freund von außen kommt nicht rein | Serverausgabe im Online-Modus lesen: Portfreigabe ok? DS-Lite? Firewall zugelassen? Nicht aus dem eigenen WLAN mit der öffentlichen IP testen. Siehe „Online spielen“ in Abschnitt 6. |
| „Zeitüberschreitung“ | Falsche IP, anderes Netzwerk (Gast-WLAN!), fehlende Portfreigabe oder Firewall blockiert (Abschnitte 6 und 7). Test vom Mitspieler-PC: Windows `Test-NetConnection 192.168.x.y -Port 5600` (PowerShell), macOS `nc -vz 192.168.x.y 5600`. |
| „Server konnte nicht starten … Port belegt“ | Läuft schon ein Server? Sonst anderen Port: `python server.py --port 5556` (und im Spiel 5556 eintragen). |
| „Versionskonflikt“ | Alle Spieler und der Server müssen dieselbe Version von Factory Empire verwenden. |
| Schwarzes/weißes Bild, Absturz beim Start, Grafikfehler | `python main.py --graphics low` (ohne Schatten). Grafiktreiber aktualisieren. In virtuellen Maschinen/Remote-Desktop wird automatisch „niedrig“ gewählt. |
| Niedrige Bildrate | `--graphics low`, kleineres Fenster (`--size 1280x720`), Kantenglättung aus lassen. |
| Kein Ton | Pygame nicht installiert oder kein Audiogerät – das Spiel läuft trotzdem. Mit `--no-sound` stumm starten. |
| „Spiel hosten“ bzw. „Einzelspieler“ schlägt fehl | Details stehen in `saves/server.log`. Oft ist der Port belegt. |
| Spielstand kaputt | Der Server lädt automatisch `factory.json.bak`. Ist auch das defekt, wird die Datei in `factory.json.defekt` umbenannt und eine neue Fabrik begonnen. |

---

## 12. Projektaufbau und technische Entscheidungen

```
FactoryEmpire/
├── main.py                  Spielclient (Startpunkt, Optionen)
├── server.py                Dedizierter Server (Startpunkt, Konsolenbefehle)
├── requirements.txt
├── start_*_windows.bat / start_*_mac.command   Startskripte (Spiel, Server, Online-Server)
├── deploy/                  Einrichtung auf einem gemieteten Linux-Server (systemd)
├── game/
│   ├── config.py            Alle Spielwerte: Gebäude, Rezepte, Forschung, Preise
│   ├── rules.py             Gemeinsame Regeln (Server prüft, Client zeigt Vorschau)
│   ├── simulation.py        Autoritativer Spielzustand + Spieleraktionen
│   ├── production.py        Maschinenlogik (Miner, Schmelze, Montage, Verkäufer, Lager)
│   ├── logistics.py         Förderbänder und Übergabe zwischen Gebäuden
│   ├── research.py          Forschungsbaum
│   ├── market.py            Dynamischer Markt
│   ├── save_system.py       Atomares JSON-Speichern mit Sicherung
│   ├── protocol.py          Netzwerkprotokoll (JSON-Zeilen) + Eingabeprüfung
│   ├── server_core.py       asyncio-TCP-Server, Tick-Schleife, Snapshots, Autosave, Passwort
│   ├── online.py            Online-Modus: UPnP-Portfreigabe, öffentliche IP, DS-Lite-Erkennung
│   ├── networking.py        Netzwerk-Client (Hintergrund-Thread)
│   ├── client_state.py      Spiegel des Serverzustands im Client
│   ├── client.py            Spielclient: Eingabe, Netzwerk, Darstellung zusammenführen
│   ├── world.py             Boden, Raster, Erz, Umgebung, Licht, Himmel, Mitspieler-Mauszeiger
│   ├── worlds.py            Spielstand-Plätze (Kurzinfo, Übernahme alter Welten)
│   ├── freight.py           Auftragsbörse, Frachtbahnhof, LKW (Server)
│   ├── stats.py             Statistiken und Erfolge (lokal)
│   ├── scenery.py           Waldgürtel, Landstraße und Verkehr
│   ├── sprites.py           gebündelte Billboards (Partikel, Warnschilder)
│   ├── tutorial.py          Tutorial für neue Spiele
│   ├── anim.py              Animationen der Oberfläche
│   ├── models.py            Prozedurale 3D-Modelle mit Texturkoordinaten (Gebäude, Natur, Figuren)
│   ├── buildings.py         Gebäudedarstellung, Animationen, Statuslampen, Vorschau
│   ├── effects.py           Partikel (Rauch, Funken, Staub, Münzen)
│   ├── camera.py            Strategiekamera (weiches Anfahren, Minimap-Fahrt)
│   ├── mousecapture.py      Vollbild-sichere Fenstereinstellungen
│   ├── ui_base.py           UI-Bausteine: Anker (GUI-Größe), Panels, Knöpfe, Regler, Schalter, Fenster
│   ├── ui.py                HUD, Hotbar, Minimap, Kaufmenü, Infofenster, Forschung, Markt,
│   │                        Einstellungen, Admin-Panel, Verbindungsbildschirm
│   ├── settings.py          Client-Einstellungen (saves/client_settings.json)
│   ├── textures.py          Laden von Texturen und Icons
│   ├── graphics.py          Grafikqualität (Schatten an/aus)
│   └── audio.py             Prozedurale Soundeffekte (Pygame)
├── tests/                   Automatische Tests (Logik + echtes Netzwerk)
├── assets/                  Selbst erzeugte Texturen (textures/) und 3D-Icons (icons/)
├── tools/                   Generatoren für Texturen und Icons (nur für Entwickler)
└── saves/                   Spielstände und Server-Log
```

**Entscheidungen:**
- **Autoritativer Server:** Simulation (20 Ticks/s) läuft nur im Server. Clients senden Aktionswünsche (`build`, `upgrade`, `research`, …), der Server prüft Typen, Wertebereiche, Geld, Belegung und Freischaltung und antwortet mit Erfolg oder einer verständlichen Fehlermeldung. Betrug durch manipulierte Clients ist damit wirkungslos.
- **Protokoll:** Zeilenweises JSON über TCP. Zustandsupdates 10×/s; die selten veränderliche Gebäudeliste wird nur bei Änderungen mitgeschickt. Nachrichtenlimit 64 KB, Rate-Limit pro Client, Versionsprüfung beim Verbinden.
- **Gemeinsame Regeln (`rules.py`):** Die Bauvorschau im Client nutzt exakt dieselben Prüfungen wie der Server – rote Vorschau und Servermeldung stimmen immer überein.
- **Grafik:** Jedes Gebäude ist ein einziges, einmal erzeugtes Mesh mit Vertexfarben, das per Instanzierung wiederverwendet wird – hunderte Gebäude bleiben flüssig. Schatten über Ursinas `lit_with_shadows_shader`; auf schwacher Hardware automatisch klassische Beleuchtung.
- **Pygame** wird nur für Audio genutzt (prozedural erzeugte Soundeffekte über `pygame.mixer`). Fenster, Grafik und Eingabe laufen ausschließlich über Ursina – es gibt keine zwei konkurrierenden Rendersysteme.
- **Mauszeiger statt Figuren:** Jeder Client schickt 10-mal pro Sekunde den Punkt auf der Baufläche, auf den seine Maus zeigt; die anderen sehen dort einen farbigen Zeiger mit Namen.
- **Große Fabriken:** Der Server schickt Gebäudezustände gestaffelt (jedes Gebäude spätestens alle 0,5 s, Änderungen sofort, alle 3 s alles). Der Client animiert nur sichtbare Gebäude, nutzt Detailstufen und verwendet Waren auf Bändern aus einem Pool wieder.
- **GUI-Skalierung über Anker:** Alle Oberflächenelemente hängen an Bildschirmecken und -kanten. Die GUI-Größe skaliert nur diese Anker; große Fenster verkleinern sich automatisch, wenn sie sonst nicht auf den Bildschirm passen.
- **Texturen und Icons:** Die Texturen (`tools/generate_textures.py`) und die 3D-Icons (`tools/render_icons.py`, gerendert aus den echten Spielmodellen) sind selbst erzeugt und liegen fertig in `assets/`.
- **Speicherformat JSON** (lesbar, versioniert über `save_version`), atomares Schreiben + `.bak`.

**Balancing ändern:** Alle Werte (Startgeld, Kosten, Zeiten, Preise, Forschung) stehen in `game/config.py`.

---

## 13. Tests

```bash
python -m unittest discover -s tests -t . -v
```

- `tests/test_relay.py`: Raum-Codes erkennen, Mitspieler tritt über einen (nachgebauten) Vermittlungsserver bei und ist dabei kein Admin.
- `tests/test_features.py` enthält zusätzlich Tests für die neuen Produktionsketten, die Großfabrik, die große Karte und alte Spielstände.
- `tests/test_network.py` enthält zusätzlich einen Test, dass die Host-Adressen (Online-Hosting) nur der Host/Admin bekommt.
- `tests/test_mouse.py` (4 Tests): Maussteuerung – Zeiger verstecken/zeigen, ohne Fenstergröße oder Vollbild anzufassen.
- `tests/test_v25.py` (3 Tests): Teil-Übertragungen ergeben beim Client den vollständigen Zustand, Mauszeiger-Sichtbarkeit wird an Mitspieler verteilt, Mehrspieler-Plätze und Übernahme alter Welten.
- `tests/test_features.py` (25 Tests): Splitter, T-Stück und Sortierer, Verbindungen von der falschen Seite, An/Aus (einzeln und alle), Versetzen inkl. Miner-Regeln, Energieabrechnung alle 5 s und Schutz vor Überziehen, Verkäufer-Mindestpreis, Leistung pro Stufe und gemessene Leistung, Forschungsbaum (gültig und vollständig erreichbar), Speichern der neuen Felder und Laden alter Spielstände, Admin über echtes Netzwerk: Geld geben, Login, Kick, Bann (inkl. Wiederverbinden verhindert) und Entbannen.
- `tests/test_simulation.py` (22 Tests): Bauen, Geldschutz, ungültige Eingaben, komplette Kette Erz → verkaufter Barren, fehlende/ungültige/blockierte Verbindungen, Energiekosten, Lagerkapazität, Montage, Forschung mit Voraussetzungen und Freischaltungen, Markt, Speichern/Laden inkl. beschädigter Datei.
- `tests/test_online.py` (7 Tests): Passwortschutz, IPv4/IPv6-Server, Adresseingaben wie `IP:Port`, Carrier-NAT-Erkennung, UPnP-Portfreigabe gegen einen simulierten Router.
- `tests/test_network.py` (7 Tests): echter Server mit zwei echten Clients über TCP, gemeinsame Sicht auf den Zustand, Mauszeiger-Positionen, Chat, Verbindungsabbruch, 13 Arten ungültiger Aktionen und kaputtes JSON, Forschung und Produktion über das Netzwerk, Speichern/Laden, Serverneustart, Fehlermeldungen bei Verbindungsproblemen, Versionskonflikt.

---

## 14. Bekannte Einschränkungen

- Getestet wurde unter Linux (Python 3.13): alle automatischen Tests, Server, Client-Rendering mit Software-OpenGL inklusive Maussteuerung, Förderband-Ziehen, Bauen/Drehen/Versetzen/An-Aus per Tastatur und Maus, Kaufmenü, Einstellungen (GUI-Größe 60–160 %), Admin-Panel und Lokal-Server-Start. **Auf echten Windows- und macOS-Rechnern konnte ich das Spiel nicht selbst starten.** Der Code nutzt nur plattformunabhängige Bibliotheken; Windows/macOS-spezifisch sind nur die Startskripte, das Beenden des Hintergrund-Servers und unter macOS die Anforderung eines OpenGL-3.2-Kontexts.
- Die **Schattendarstellung** (Grafik „hoch“, auf echten Grafikkarten Standard) ließ sich in meiner Testumgebung ohne Grafikkarte nicht darstellen. Alle Objekte werden in diesem Modus fehlerfrei erzeugt, sichtbar geprüft habe ich aber nur die Darstellung ohne Schatten. Falls es Grafikprobleme gibt: `python main.py --graphics low`.
- Server und Spiel müssen dieselbe Version haben (Protokoll v6 ab Version 2.8). Ältere Clients werden mit einer verständlichen Meldung abgewiesen. Alte Spielstände (Version 1) werden automatisch übernommen.
- Alle Spieler teilen sich ein Firmenkonto (kooperatives Spiel). Optionaler Passwortschutz, aber keine Verschlüsselung der Verbindung.
- Die automatische Router-Freigabe (UPnP) und die Erreichbarkeit aus dem Internet konnte ich nur gegen einen simulierten Router testen, nicht an einem echten Internetanschluss. Ob es bei dir klappt, hängt vom Router (UPnP an/aus) und vom Anschluss (DS-Lite) ab – der Server sagt es dir beim Start.
- Die Fensteroberfläche ist für Seitenverhältnisse ab 16:10 ausgelegt; sehr schmale Fenster können Texte überlappen.
- Sehr große Fabriken (über 1.000 Gebäude) laufen auf dem Server problemlos (~5 ms pro Tick), können auf schwachen Grafikkarten aber die Bildrate senken.
