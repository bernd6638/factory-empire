"""
Factory Empire – dedizierter Server.

Start:
    python server.py                    # lädt saves/factory.json oder erstellt eine neue Fabrik
    python server.py --port 6000
    python server.py --new              # neue Fabrik (alter Stand wird umbenannt, nicht gelöscht)
    python server.py --online           # Online: Router-Port automatisch freigeben, öffentliche IP anzeigen
    python server.py --online --password geheim

Konsolenbefehle während der Server läuft:
    save, players, money, give <betrag>, admin <name>, kick <name>, ban <name>, unban <name>, bans, quit
"""

import argparse
import asyncio
import logging
import os
import sys
import threading

# Projektordner als Arbeitsverzeichnis, damit relative Pfade (saves/) überall gleich sind
os.chdir(os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import bootstrap_update  # noqa: E402
    bootstrap_update.run_newer("server.py")

from game import config as C  # noqa: E402
from game.server_core import FactoryServer  # noqa: E402


def parse_args():
    p = argparse.ArgumentParser(description="Factory Empire Server")
    p.add_argument("--host", default="", help="Netzwerkadresse (Standard: alle Netzwerkkarten, IPv4 und IPv6)")
    p.add_argument("--port", type=int, default=C.DEFAULT_PORT, help=f"TCP-Port (Standard: {C.DEFAULT_PORT})")
    p.add_argument("--save", default=C.DEFAULT_SAVE_FILE, help="Pfad zur Spielstanddatei")
    p.add_argument("--new", action="store_true", help="Neue Fabrik beginnen (alter Stand wird gesichert)")
    p.add_argument("--seed", type=int, default=C.WORLD_SEED, help="Karten-Seed für neue Fabriken")
    p.add_argument("--no-console", action="store_true", help="Keine Konsolenbefehle einlesen")
    p.add_argument("--online", action="store_true",
                   help="Online-Modus: Port per UPnP im Router freigeben und öffentliche IP anzeigen")
    p.add_argument("--no-upnp", action="store_true", help="Im Online-Modus keine automatische Router-Freigabe")
    p.add_argument("--relay", action="store_true",
                   help="Online per Raum-Code über einen Vermittlungsserver (keine Router-Freigabe nötig)")
    p.add_argument("--password", default=None, help="Server-Passwort (empfohlen für Online-Server)")
    p.add_argument("--admin-password", default=None,
                   help="Admin-Passwort: damit können sich Spieler im Admin-Panel (F2) als Admin anmelden")
    p.add_argument("--no-local-admin", action="store_true",
                   help="Spieler auf diesem PC (127.0.0.1) nicht automatisch zum Admin machen")
    p.add_argument("--ask", action="store_true",
                   help="Port und Passwort beim Start abfragen (für die Doppelklick-Starter)")
    return p.parse_args()


def ask_settings(args):
    """Fragt Port und Passwort im Konsolenfenster ab. Enter übernimmt jeweils den Vorschlag."""
    print()
    while True:
        raw = input(f"Port (Enter = {args.port}): ").strip()
        if not raw:
            break
        if raw.isdigit() and 1 <= int(raw) <= 65535:
            args.port = int(raw)
            break
        print("Bitte eine Zahl zwischen 1 und 65535 eingeben.")
    pw = input("Server-Passwort (leer = jeder mit Code bzw. IP darf beitreten): ").strip()
    args.password = pw or None
    print()


HELP = ("Befehle: save | players | money | give <betrag> | admin <name> | kick <name> | ban <name> | "
        "unban <name oder ip> | bans | quit")


def run_console_command(server, line):
    """Führt einen Konsolenbefehl im Event-Loop des Servers aus und gibt die Antwort zurück."""
    from game import protocol
    parts = line.strip().split(maxsplit=1)
    if not parts:
        return ""
    cmd, arg = parts[0].lower(), (parts[1].strip() if len(parts) > 1 else "")

    def find(name):
        for c in server.clients.values():
            if c.name.lower() == name.lower():
                return c
        return None

    if cmd == "save":
        return server.save()[1]
    if cmd == "players":
        names = [f"{c.name} ({c.ip}{', Admin' if c.admin else ''})" for c in server.clients.values()]
        return f"{len(names)} Spieler online: " + (", ".join(names) or "-")
    if cmd == "money":
        return f"Geld: {server.state.money:.2f} €"
    if cmd == "give":
        try:
            amount = float(arg.replace(",", "."))
        except ValueError:
            return "Aufruf: give <betrag>"
        return server.state.admin_give_money(amount)[1]
    if cmd == "admin":
        c = find(arg)
        if c is None:
            return f"Spieler '{arg}' ist nicht online."
        c.admin = True
        c.send(protocol.encode({"t": "you", "admin": True}))
        return f"{c.name} ist jetzt Admin."
    if cmd in ("kick", "ban"):
        c = find(arg)
        if c is None:
            return f"Spieler '{arg}' ist nicht online."
        if cmd == "ban":
            server.bans.append({"name": c.name, "ip": c.ip, "reason": "", "by": "Konsole",
                                "time": __import__("time").strftime("%Y-%m-%d %H:%M")})
            server._save_bans()
        verb = "gebannt" if cmd == "ban" else "gekickt"
        c.send(protocol.encode({"t": "kicked", "msg": f"Du wurdest vom Server {verb}."}))
        asyncio.get_running_loop().call_later(0.3, server._drop_client, c)
        return f"{c.name} wurde {verb}."
    if cmd == "unban":
        key = arg.lower()
        before = len(server.bans)
        server.bans = [b for b in server.bans if b.get("name", "").lower() != key and b.get("ip", "") != key]
        server._save_bans()
        return "Bann aufgehoben." if len(server.bans) < before else "Kein passender Eintrag."
    if cmd == "bans":
        return "\n".join(f"{b.get('name')} {b.get('ip')} {b.get('reason', '')}" for b in server.bans) or "Bannliste leer."
    return HELP


def console_thread(loop, server, stop_event):
    print(HELP)
    while not stop_event.is_set():
        try:
            line = input()
        except (EOFError, KeyboardInterrupt):
            return
        if line.strip().lower() in ("quit", "exit", "stop"):
            loop.call_soon_threadsafe(stop_event.set)
            return
        if not line.strip():
            continue

        async def run(cmd=line):
            print(run_console_command(server, cmd), flush=True)
        asyncio.run_coroutine_threadsafe(run(), loop)


class _StopFlag:
    """Thread-sicheres Stopp-Signal, das auch ein asyncio.Event setzt."""

    def __init__(self, loop):
        self._loop = loop
        self.event = asyncio.Event()
        self._set = False

    def set(self):
        self._set = True
        self.event.set()

    def is_set(self):
        return self._set


async def _start_relay(args, server, loop):
    """Meldet den Server beim Vermittlungsserver an. Gibt den RelayHost zurück oder None."""
    from game import relay

    def info_for(h, lost=False):
        return {"relay": True, "code": relay.format_room_code(h.public_port), "relay_host": h.host,
                "relay_port": h.public_port, "port": args.port, "relay_lost": lost}

    holder = {}

    def on_status(state):
        h = holder.get("h")
        if h is not None:
            loop.call_soon_threadsafe(server.set_online_info, info_for(h, lost=(state == "lost")))

    def start():
        h = relay.RelayHost(args.port, on_status=on_status)
        h.start()
        holder["h"] = h
        return h

    try:
        h = await loop.run_in_executor(None, start)
    except (relay.RelayError, OSError) as exc:
        server._relay_error = str(exc)
        logging.warning("Online per Raum-Code nicht möglich: %s", exc)
        if not args.online:
            server.set_online_info({"relay": False, "relay_error": str(exc), "port": args.port})
        return None
    code = relay.format_room_code(h.public_port)
    print("\n" + "=" * 66 + f"\n  ONLINE – Raum-Code für deine Freunde:   {code}\n"
          "  Freunde: Mehrspieler > Spiel beitreten > Code eingeben. Keine Router-Freigabe nötig.\n"
          + "=" * 66, flush=True)
    server.set_online_info(info_for(h))
    if not args.password:
        logging.warning("Kein Passwort gesetzt – jeder mit dem Raum-Code kann beitreten.")
    return h


async def run(args):
    server = FactoryServer(args.host, args.port, args.save, new_game=args.new, seed=args.seed,
                           password=args.password, admin_password=args.admin_password,
                           local_admin=not args.no_local_admin, bans_path=C.BANS_FILE)
    try:
        await server.start()
    except OSError as exc:
        logging.error("Server konnte nicht starten: %s", exc)
        logging.error("Ist der Port %s bereits belegt? Starte mit --port <andere Nummer>.", args.port)
        return 1
    loop = asyncio.get_running_loop()
    mapper = None
    relay_host = None
    if args.relay:
        relay_host = await _start_relay(args, server, loop)
    if args.online and relay_host is None:
        from game.online import setup_online
        report = {}
        mapper = await loop.run_in_executor(None, setup_online, args.port, not args.no_upnp, report)
        if args.relay:
            report["relay"] = False
            report["relay_error"] = getattr(server, "_relay_error", None)
        server.set_online_info(report)
        if not args.password:
            logging.warning("Kein Passwort gesetzt – jeder mit IP und Port kann beitreten. "
                            "Schutz: --password <passwort>")
    elif args.password:
        logging.info("Server ist passwortgeschützt.")
    stop = _StopFlag(loop)
    if not args.no_console and sys.stdin and sys.stdin.isatty():
        threading.Thread(target=console_thread, args=(loop, server, stop), daemon=True).start()
    try:
        await stop.event.wait()
    finally:
        logging.info("Server wird beendet, speichere ...")
        await server.stop(save=True)
        if mapper:
            mapper.remove_mapping()
        if relay_host:
            relay_host.stop()
    return 0


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    args = parse_args()
    print(f"=== {C.GAME_TITLE} Server {C.GAME_VERSION} ===")
    if args.ask:
        try:
            ask_settings(args)
        except (EOFError, KeyboardInterrupt):
            return 0
    try:
        code = asyncio.run(run(args))
    except KeyboardInterrupt:
        # asyncio.run bricht die Tasks ab; stop() im finally-Block hat bereits gespeichert
        code = 0
    print("Server beendet.")
    sys.exit(code)


if __name__ == "__main__":
    main()
