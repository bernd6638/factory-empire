"""
Factory Empire – Spielclient.

Start:
    python main.py                         # Hauptmenü
    python main.py --local                 # lokalen Server starten und sofort spielen
    python main.py --connect --host 192.168.1.20 --name Anna
    python main.py --graphics low          # ohne Schatten (alte Grafikkarten)

Alle Optionen: python main.py --help
"""

import argparse
import getpass
import os
import sys

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(PROJECT_DIR)
sys.path.insert(0, PROJECT_DIR)

if __name__ == "__main__":
    # Automatische Updates: liegt im Spielstand-Ordner eine neuere Version, wird diese gestartet
    import bootstrap_update  # noqa: E402
    bootstrap_update.run_newer("main.py")

from game import config as C  # noqa: E402


def _redirect_output_if_windowless():
    """Ohne Konsolenfenster (pythonw / macOS-App) gehen Ausgaben und Fehler in eine Logdatei."""
    if sys.stdout is not None and sys.stderr is not None and not os.environ.get("FACTORY_EMPIRE_LOG"):
        return
    try:
        os.makedirs(C.DATA_DIR, exist_ok=True)
        path = os.path.join(C.DATA_DIR, "client.log")
        try:                                   # Protokoll des letzten Starts aufheben (z. B. nach einem Absturz)
            if os.path.getsize(path) > 0:
                os.replace(path, os.path.join(C.DATA_DIR, "client.previous.log"))
        except OSError:
            pass
        log = open(path, "w", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log
    except OSError:
        pass


_redirect_output_if_windowless()

if os.environ.get("FACTORY_EMPIRE_DEBUG"):
    # Fehlersuche: Stacktraces ins Log; mit einer Zahl (Sekunden) beendet sich das Spiel danach selbst,
    # auch wenn es in der Grafik festhängt (der Wachhund läuft ohne Python-Sperre).
    import faulthandler
    faulthandler.enable(file=sys.stderr)
    _quit_after = os.environ.get("FACTORY_EMPIRE_DEBUG", "")
    if _quit_after.replace(".", "", 1).isdigit() and float(_quit_after) > 1:
        faulthandler.dump_traceback_later(float(_quit_after), exit=True, file=sys.stderr)
    else:
        faulthandler.dump_traceback_later(30, repeat=True, file=sys.stderr)


def default_name():
    try:
        name = getpass.getuser()
    except Exception:
        name = ""
    name = "".join(ch for ch in name if ch.isalnum() or ch in "-_")[:16]
    return name or "Spieler"


def parse_args():
    p = argparse.ArgumentParser(description="Factory Empire – Spielclient")
    p.add_argument("--name", default=None, help="Spielername")
    p.add_argument("--host", default=None, help="IP-Adresse des Servers")
    p.add_argument("--port", type=int, default=None, help="Port des Servers")
    p.add_argument("--password", default="", help="Server-Passwort (falls der Server eines verlangt)")
    p.add_argument("--connect", action="store_true", help="Direkt verbinden (ohne Hauptmenü)")
    p.add_argument("--local", action="store_true", help="Lokalen Server starten und verbinden")
    p.add_argument("--graphics", default="auto", choices=["auto", "high", "low", "hoch", "niedrig"],
                   help="Grafikqualität: high = Schatten, low = ohne Schatten")
    p.add_argument("--no-sound", action="store_true", help="Ton abschalten")
    p.add_argument("--fullscreen", action="store_true", help="Im Vollbild starten (umschalten mit F11)")
    p.add_argument("--size", default=None, help="Fenstergröße, z. B. 1280x720 (sonst aus den Einstellungen)")
    p.add_argument("--aa", action="store_true", help="Kantenglättung (Multisampling) aktivieren")
    p.add_argument("--fps", action="store_true", help="FPS-Anzeige einblenden")
    return p.parse_args()


def main():
    args = parse_args()
    from game.settings import Settings
    settings = Settings()
    # Startwerte: Kommandozeile > gespeicherte Einstellungen > Standard
    args.name = args.name or settings["name"] or default_name()
    args.host = args.host or settings["host"] or C.DEFAULT_HOST
    args.port = args.port or int(settings["port"] or C.DEFAULT_PORT)
    from panda3d.core import loadPrcFileData
    prc = f"window-title {C.GAME_TITLE}\n"
    if os.environ.get("FACTORY_EMPIRE_LOG"):
        # Meldungen von Panda3D (z. B. Grafikfehler) zusätzlich in eine Datei schreiben
        prc += "notify-output " + os.path.join(C.DATA_DIR, "panda.log").replace("\\", "/") + "\n"
    if sys.platform == "darwin":
        # macOS liefert ohne diese Angabe nur OpenGL 2.1 – Ursinas Shader benötigen 3.2 (Core Profile)
        prc += "gl-version 3 2\n"
    # 24-Bit-Tiefenpuffer: sonst flimmern/verschwinden flache Dinge knapp über dem Boden (v. a. auf Macs)
    prc += "depth-bits 24\n"
    from game.settings import msaa_samples
    samples = 4 if args.aa else msaa_samples(settings["msaa"], sys.platform)
    if samples > 0:
        prc += f"framebuffer-multisample 1\nmultisamples {samples}\n"
    # Zusätzliche Panda3D-Einstellungen zur Fehlersuche, Zeilen getrennt durch "|"
    prc += os.environ.get("FACTORY_EMPIRE_PRC", "").replace("|", "\n") + "\n"
    loadPrcFileData("", prc)

    from game import glsl_compat
    glsl_compat.apply()
    from ursina import Ursina, Vec2, color, window
    from game.settings import parse_resolution
    wanted = parse_resolution(args.size) if args.size else parse_resolution(settings["resolution"])
    size = Vec2(*(wanted or (1280, 720)))          # "Automatisch": wird gleich an den Bildschirm angepasst
    app = Ursina(title=C.GAME_TITLE, development_mode=False, fullscreen=False, borderless=False,
                 size=size, vsync=bool(settings["vsync"]))
    glsl_compat.refresh_entities()
    from game import i18n
    i18n.install()
    if settings["language"] not in i18n.CODES:
        settings["language"] = i18n.detect()
        settings.save()
    i18n.set_language(settings["language"])
    # Ursinas eingebaute Entwickler-Tasten (F10/F11/F12) abschalten – F11 übernimmt das Spiel selbst
    if getattr(window, "input_entity", None) is not None:
        window.input_entity.enabled = False
    if samples > 0:
        from panda3d.core import AntialiasAttrib
        import builtins
        builtins.render.setAntialias(AntialiasAttrib.MMultisample)

    renderer = ""
    import builtins
    try:
        renderer = builtins.base.win.gsg.getDriverRenderer()
    except Exception:
        pass
    from game import graphics
    high = graphics.configure(args.graphics, renderer)
    graphics.set_fast(settings["shadows"] == "off")
    graphics.setup_fog(builtins.base.render)
    mode = "niedrig" if not high else ("hoch (schnell)" if settings["shadows"] == "off" else "hoch (Schatten)")
    print(f"[Grafik] Renderer: {renderer or 'unbekannt'} – Qualität: {mode}")

    window.color = color.rgba(0.55, 0.7, 0.85, 1)
    window.exit_button.visible = False
    window.fps_counter.enabled = False
    if args.fps:
        settings["show_fps"] = True
    window.entity_counter.enabled = False
    window.collider_counter.enabled = False

    from game.client import GameClient
    GameClient(args, settings)
    if os.environ.get("FACTORY_EMPIRE_DEBUG"):
        import time as _time
        import builtins
        _t = {"n": 0, "t": _time.time()}

        _t["frames"] = 0

        def _fps_task(task):
            _t["n"] += 1
            _t["frames"] += 1
            if _t["frames"] in (240, 600):
                from panda3d.core import Filename
                shot = os.path.join(C.DATA_DIR, f"debug_shot_{_t['frames']}.png")
                builtins.base.win.saveScreenshot(Filename.fromOsSpecific(shot))
            now = _time.time()
            if now - _t["t"] >= 2.0:
                print(f"[debug] {_t['n'] / (now - _t['t']):.1f} FPS", flush=True)
                _t["n"], _t["t"] = 0, now
            return task.cont
        builtins.base.taskMgr.add(_fps_task, "fe-debug-fps")
    app.run()


if __name__ == "__main__":
    main()
