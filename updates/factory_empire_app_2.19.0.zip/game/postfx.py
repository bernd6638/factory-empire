"""
Bild-Nachbearbeitung (Post-Processing) der 3D-Szene – die Oberfläche bleibt davon unberührt.

Ein einziger Vollbild-Durchgang macht aus dem gerenderten Bild einen „Kino-Look“:
  * Kantenglättung (FXAA) – keine Treppchen an Dächern, Bändern und Bäumen,
  * Kontaktschatten (Ambient Occlusion aus dem Tiefenpuffer) – Gebäude stehen sichtbar auf dem
    Boden, Ecken und Spalten bekommen Tiefe,
  * Leuchten (Bloom) – Lampen, Funken, Sonnenglanz und Fenster strahlen in die Umgebung,
  * Farbstimmung – sanfte Kontrastkurve, kühle Schatten, warme Lichter, leichte Vignette.

Stufen (Optionen » Leistung » Bildverbesserung): "high", "medium" (ohne Kontaktschatten), "off".
"""

from . import graphics

LEVELS = ("high", "medium", "off")

_VERTEX = """#version 150
uniform mat4 p3d_ModelViewProjectionMatrix;
in vec4 p3d_Vertex;
in vec2 p3d_MultiTexCoord0;
out vec2 uv;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * p3d_Vertex;
    uv = p3d_MultiTexCoord0;
}
"""

_FRAGMENT = """#version 150
uniform sampler2D tex;
uniform sampler2D dtex;
uniform vec2 fe_px;          // Größe eines Bildpunkts in UV (1/Breite, 1/Höhe)
uniform vec2 fe_clip;        // near, far
uniform float fe_focal;      // Brennweite in Bildpunkten (für den Kontaktschatten-Radius)
uniform float fe_ao;         // Stärke Kontaktschatten (0 = aus)
uniform float fe_bloom;      // Stärke Leuchten
uniform float fe_vig;        // Vignette
uniform float fe_night;      // 0 = Tag, 1 = Nacht (mehr Leuchten, kühlere Schatten)
uniform float fe_debug;      // 1 = nur Kontaktschatten anzeigen (Entwickler)
in vec2 uv;
out vec4 o_color;

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

float lin_depth(float d) {
    float n = fe_clip.x, f = fe_clip.y;
    return n * f / (f - d * (f - n));
}

// ---------------------------------------------------------------- FXAA (vereinfachte 3.11-Variante)
vec3 fxaa(vec2 p) {
    vec3 rgbM = texture(tex, p).rgb;
    vec3 rgbNW = texture(tex, p + vec2(-1.0, -1.0) * fe_px).rgb;
    vec3 rgbNE = texture(tex, p + vec2( 1.0, -1.0) * fe_px).rgb;
    vec3 rgbSW = texture(tex, p + vec2(-1.0,  1.0) * fe_px).rgb;
    vec3 rgbSE = texture(tex, p + vec2( 1.0,  1.0) * fe_px).rgb;
    float lM = luma(rgbM), lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin < max(0.0312, lMax * 0.125)) return rgbM;
    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
    float reduce = max((lNW + lNE + lSW + lSE) * 0.03125, 1.0 / 128.0);
    float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + reduce);
    dir = clamp(dir * rcp, vec2(-8.0), vec2(8.0)) * fe_px;
    vec3 a = 0.5 * (texture(tex, p + dir * (1.0 / 3.0 - 0.5)).rgb + texture(tex, p + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture(tex, p - dir * 0.5).rgb + texture(tex, p + dir * 0.5).rgb);
    float lB = luma(b);
    return (lB < lMin || lB > lMax) ? a : b;
}

// ---------------------------------------------------------------- Kontaktschatten
// Paarweiser Vergleich: 1/Tiefe ist auf ebenen Flächen im Bild linear. Liegen zwei gegenüberliegende
// Nachbarn im Mittel näher an der Kamera als der Bildpunkt selbst, steckt er in einer Ecke/Mulde.
// Ebenen (Boden, Wände) bleiben dadurch hell, nur Kanten und Kontaktstellen werden dunkler.
float ambient_occlusion(vec2 p, float d) {
    if (d >= 0.99999) return 1.0;                       // Himmel
    float z = lin_depth(d);
    float invc = 1.0 / z;
    float r_px = clamp(0.55 * fe_focal / z, 3.0, 48.0); // ca. eine halbe Kachel in der Welt
    float occ = 0.0;
    float wsum = 0.0;
    // ruhiges, gleichmäßiges Muster statt Zufallsrauschen (kein Körnchen-Flimmern)
    vec2 pix = p / fe_px;
    float ign = fract(52.9829189 * fract(dot(pix, vec2(0.06711056, 0.00583715))));
    float ang = ign * 0.3927;                           // innerhalb eines Richtungsschritts drehen
    for (int i = 0; i < 8; i++) {
        float a = ang + float(i) * 0.3927;              // 8 Richtungen über 180°
        vec2 dir = vec2(cos(a), sin(a));
        for (int k = 1; k <= 2; k++) {
            vec2 o = dir * r_px * (float(k) * 0.5) * (0.9 + 0.2 * ign) * fe_px;
            float z1 = lin_depth(texture(dtex, p + o).r);
            float z2 = lin_depth(texture(dtex, p - o).r);
            float crease = (0.5 / z1 + 0.5 / z2) - invc;   // > 0: Nachbarn im Mittel näher
            float dz = crease * z * z;                     // in Welt-Einheiten
            float range = 1.0 - smoothstep(0.35, 1.2, abs(z - min(z1, z2)));  // keine Halos hinter Kanten
            occ += clamp(dz / 0.16, 0.0, 1.0) * range;
            wsum += 1.0;
        }
    }
    float o = occ / wsum;
    return 1.0 - fe_ao * clamp(o * 1.6, 0.0, 1.0);
}

// ---------------------------------------------------------------- Leuchten
vec3 bloom(vec2 p) {
    vec3 acc = vec3(0.0);
    float thr = mix(0.93, 0.6, fe_night);              // tagsüber nur echte Glanzlichter, nachts Lampen & Fenster
    for (int i = 0; i < 12; i++) {
        float a = float(i) * 0.5236 + (i >= 6 ? 0.26 : 0.0);
        float r = (i < 6) ? 7.0 : 16.0;
        vec3 c = texture(tex, p + vec2(cos(a), sin(a)) * r * fe_px).rgb;
        float l = luma(c);
        acc += c * (max(l - thr, 0.0) / max(l, 0.001)) * ((i < 6) ? 1.0 : 0.6);
    }
    return acc / 9.6;
}

void main() {
    float d = texture(dtex, uv).r;
    vec3 c = fxaa(uv);
    if (fe_ao > 0.0) {
        float ao = ambient_occlusion(uv, d);
        if (fe_debug > 0.5) { o_color = vec4(vec3(ao), 1.0); return; }
        c *= ao;
    }
    if (fe_bloom > 0.0) {
        c += bloom(uv) * fe_bloom * (1.0 + fe_night * 1.5);
    }
    // Farbstimmung: sanfte S-Kurve, kühle Schatten, warme Lichter, etwas kräftigere Farben
    float l = luma(c);
    vec3 cool = vec3(0.92, 0.97, 1.08);
    vec3 warm = vec3(1.05, 1.0, 0.93);
    c *= mix(cool, warm, smoothstep(0.15, 0.85, l));
    c = clamp(c, 0.0, 1.0);
    c = mix(c, c * c * (3.0 - 2.0 * c), 0.35);           // Kontrast (S-Kurve)
    c = mix(vec3(luma(c)), c, 1.12);                       // Sättigung
    // Vignette
    vec2 q = uv - 0.5;
    float v = 1.0 - fe_vig * smoothstep(0.25, 0.85, dot(q, q) * 2.2);
    c *= v;
    o_color = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""

STATE = {"level": "off", "shader": None, "size": None, "night": 0.0}


def supported():
    """Nur mit Shadern (Grafik „hoch“); Software-Renderer schaffen den Vollbild-Durchgang nicht flüssig."""
    return graphics.high()


def default_level(renderer=""):
    name = (renderer or "").lower()
    if not supported() or any(s in name for s in graphics.SOFTWARE_RENDERERS):
        return "off"
    import sys
    if sys.platform == "darwin":
        return "medium"          # Macs: Grafikchips oft schwächer – ohne Kontaktschatten (in den Optionen änderbar)
    return "high"


def _shader():
    if STATE["shader"] is None:
        from ursina.shader import Shader
        STATE["shader"] = Shader(name="fe_post", language=Shader.GLSL, vertex=_VERTEX, fragment=_FRAGMENT)
    return STATE["shader"]


def apply(level):
    """Stufe setzen ("high" | "medium" | "off"). Gibt die tatsächlich aktive Stufe zurück."""
    from ursina import camera
    level = level if level in LEVELS else "off"
    if level != "off" and not supported():
        level = "off"
    if level == "off":
        if STATE["level"] != "off":
            try:
                camera.shader = None
            except Exception as exc:                       # pragma: no cover - nur Grafiktreiber
                print("[Grafik] Bildverbesserung ließ sich nicht abschalten:", exc)
        STATE["level"] = "off"
        return "off"
    try:
        if STATE["level"] == "off":
            camera.shader = _shader()
        STATE["level"] = level
        STATE["size"] = None
        _set_inputs()
    except Exception as exc:                               # pragma: no cover - nur Grafiktreiber
        print("[Grafik] Bildverbesserung nicht verfügbar:", exc)
        STATE["level"] = "off"
        try:
            camera.shader = None
        except Exception:
            pass
    return STATE["level"]


def set_night(amount):
    """Tageszeit: nachts leuchten Lampen und Fenster stärker."""
    STATE["night"] = max(0.0, min(1.0, float(amount)))
    if STATE["level"] != "off":
        from ursina import camera
        camera.set_shader_input("fe_night", STATE["night"])


def _set_inputs():
    from ursina import camera
    high = STATE["level"] == "high"
    camera.set_shader_input("fe_ao", 0.75 if high else 0.0)
    camera.set_shader_input("fe_bloom", 0.8)
    camera.set_shader_input("fe_vig", 0.32)
    camera.set_shader_input("fe_night", STATE["night"])
    import os
    camera.set_shader_input("fe_debug", 1.0 if os.environ.get("FE_POST_DEBUG") else 0.0)
    update()


def update():
    """Jedes Bild aufrufen: Fenstergröße, Sichtfeld und Clipping können sich ändern (billig, nur bei Änderung)."""
    if STATE["level"] == "off":
        return
    import builtins
    import math
    from ursina import camera
    win = builtins.base.win
    w, h = max(1, win.getXSize()), max(1, win.getYSize())
    key = (w, h, round(camera.fov, 2), camera.clip_plane_near, camera.clip_plane_far)
    if key == STATE["size"]:
        return
    STATE["size"] = key
    from panda3d.core import Vec2
    camera.set_shader_input("fe_px", Vec2(1.0 / w, 1.0 / h))
    camera.set_shader_input("fe_clip", Vec2(camera.clip_plane_near, camera.clip_plane_far))
    # Ursinas fov ist horizontal: Brennweite in Bildpunkten = (Breite/2) / tan(fov/2)
    camera.set_shader_input("fe_focal", (w * 0.5) / math.tan(math.radians(camera.fov) * 0.5))
