"""
Client-Einstellungen (GUI-Größe, Vollbild, Lautstärke, Maus ...).

Werden in saves/client_settings.json gespeichert und beim nächsten Start
wieder geladen. Fehlerhafte oder fehlende Dateien führen nie zum Absturz –
dann gelten die Standardwerte.
"""

import json
import os

from .config import DATA_DIR

PATH = os.path.join(DATA_DIR, "client_settings.json")

DEFAULTS = {
    "gui_scale": 1.0,
    "fullscreen": False,
    "resolution": "auto",
    "environment": "forest",  # Umgebung: forest / city / construction / winter
    "time_of_day": "day",     # Tageszeit: day / evening / night / cycle   # Fenstergröße: "auto" (passend zum Bildschirm) oder z. B. "1280x720"
    "show_grid": True,
    "show_fps": False,
    "signs": True,
    "money_popups": True,   # schwebende „+€“-Zahlen über Verkäufern
    "volume": 0.8,
    "music_volume": 0.45,   # Hintergrundmusik
    "ambient_volume": 0.7,  # Vögel, Wind, Fabrikgeräusche
    "rocket_volume": 0.35,  # Raketenstart, Landung, Countdown
    "achievement_volume": 0.6,  # Klang, wenn ein Erfolg freigeschaltet wird
    "mouse_sensitivity": 1.0,
    "particles": True,
    "name": "",
    "host": "",
    "port": 0,
    "host_port": 5600,      # Port beim Hosten über Multiplayer
    "upnp": True,           # beim Hosten Port automatisch im Router freigeben
    "relay": True,
    "tutorial": True,
    "discord": True,
    "seen_version": "",     # Neuigkeiten-Fenster wurde für diese Version schon gezeigt        # Discord-Status ("spielt Factory Empire") anzeigen       # Tutorial automatisch starten, wenn man eine neue Welt betritt
    "vsync": False,         # Bildsynchronisation (wirkt nach Neustart; aus = mehr als 60 FPS möglich)
    "fps_limit": 120,       # 0 = unbegrenzt, sonst maximale Bilder pro Sekunde
    "shadows": "off",       # high / medium / low / off  (aus = schneller Licht-Shader, viel mehr FPS)
    "postfx": "auto",       # Bildverbesserung: auto / high / medium / off (Kantenglättung, Kontaktschatten, Leuchten)
    "world": "",            # zuletzt gehostete Mehrspieler-Welt
    "sp_slot": 1,           # zuletzt gespielter Einzelspieler-Platz (1-5)
    "mp_slot": 1,           # zuletzt gehosteter Mehrspieler-Platz (1-5)
    "perf_rev": 0,          # Stand der Leistungs-Standardwerte (für einmalige Umstellung alter Einstellungen)
    "cursor_scale": 0.7,    # Größe der Mauszeiger von Mitspielern
    "scenery": True,        # Landschafts-Details (Büsche, Blumen, Felsen, Wolken)
    "language": "",         # Sprache (de, en, fr ...); leer = Systemsprache beim ersten Start
    "msaa": -1,             # Kantenglättung: 0 aus, 2/4/8-fach; -1 = automatisch (wirkt nach Neustart)
    "reveal_seen": [],      # Enthüllung der Rakete schon gesehen ("release" = nach dem Countdown, "test")
    "test_code": "",        # geheimer Code der Test-Welt (Mond-Vorschau), falls eingegeben
    "keys": {},             # eigene Tastenbelegung: Aktion -> Taste (nur Abweichungen vom Standard)
    "accounts": {},         # automatische Anmeldung je Server: "host:port" -> "benutzer|token"
}
FPS_CHOICES = [0, 30, 60, 75, 90, 120, 144, 165, 240]
SHADOW_CHOICES = ["high", "medium", "low", "off"]
POSTFX_CHOICES = ["auto", "high", "medium", "off"]
RESOLUTIONS = ["auto", "1024x576", "1152x648", "1280x720", "1366x768", "1440x810", "1600x900", "1920x1080",
               "2560x1440"]


def parse_resolution(value):
    """"1280x720" -> (1280, 720); "auto" oder Unsinn -> None."""
    try:
        w, h = (int(v) for v in str(value).lower().split("x"))
        return (w, h) if 640 <= w <= 7680 and 360 <= h <= 4320 else None
    except ValueError:
        return None
MSAA_CHOICES = [-1, 0, 2, 4, 8]


def msaa_samples(value, platform):
    """Automatisch: 2-fach (auf allen Systemen unkritisch)."""
    if value == -1:
        return 2
    return value
LIMITS = {
    "gui_scale": (0.6, 1.6),
    "volume": (0.0, 1.0),
    "music_volume": (0.0, 1.0),
    "ambient_volume": (0.0, 1.0),
    "rocket_volume": (0.0, 1.0),
    "achievement_volume": (0.0, 1.0),
    "mouse_sensitivity": (0.2, 3.0),
    "cursor_scale": (0.3, 2.0),
}


class Settings:
    def __init__(self, path=PATH):
        self.path = path
        self.values = dict(DEFAULTS)
        self.load()

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        for key, default in DEFAULTS.items():
            value = data.get(key, default)
            if isinstance(default, bool):
                value = value if isinstance(value, bool) else default
            elif isinstance(default, (int, float)):
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    value = default
                if key in LIMITS:
                    lo, hi = LIMITS[key]
                    value = max(lo, min(hi, float(value)))
            elif isinstance(default, str):
                value = value[:40] if isinstance(value, str) else default
            elif isinstance(default, dict) and key == "accounts":     # Server -> "benutzer|token"
                value = {str(k)[:80]: str(v)[:100] for k, v in value.items()} if isinstance(value, dict) else {}
            elif isinstance(default, dict):
                value = {str(k)[:20]: str(v)[:20] for k, v in value.items()} if isinstance(value, dict) else {}
            elif isinstance(default, list):
                value = [str(v)[:20] for v in value][:10] if isinstance(value, list) else list(default)
            if key == "fps_limit" and value not in FPS_CHOICES:
                value = default
            if key in ("sp_slot", "mp_slot") and value not in (1, 2, 3, 4, 5):
                value = default
            if key == "msaa" and value not in MSAA_CHOICES:
                value = default
            if key == "environment" and value not in ("forest", "city", "construction", "winter"):
                value = default
            if key == "time_of_day" and value not in ("day", "evening", "night", "cycle"):
                value = default
            if key == "resolution" and value not in RESOLUTIONS and parse_resolution(value) is None:
                value = default
            if key == "shadows" and value not in SHADOW_CHOICES:
                value = default
            if key == "postfx" and value not in POSTFX_CHOICES:
                value = default
            self.values[key] = value
        # Version 2.7: einmalig auf die schnellen Standardwerte umstellen (Ziel: 120+ FPS)
        if self.values.get("perf_rev", 0) < 1:
            self.values["perf_rev"] = 1
            self.values["shadows"] = "off"
            self.values["vsync"] = False
            self.values["fps_limit"] = 0
        # Version 2.17: V-Sync greift jetzt wirklich – Standard 120 FPS (statt fest 60)
        if self.values.get("perf_rev", 0) < 2:
            self.values["perf_rev"] = 2
            self.values["vsync"] = False
            if self.values.get("fps_limit", 0) in (0, 60):
                self.values["fps_limit"] = 120

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.values, f, indent=1, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError as exc:
            print(f"[Einstellungen] Speichern fehlgeschlagen: {exc}")

    def __getitem__(self, key):
        return self.values[key]

    def __setitem__(self, key, value):
        if key in LIMITS:
            lo, hi = LIMITS[key]
            value = max(lo, min(hi, value))
        self.values[key] = value
