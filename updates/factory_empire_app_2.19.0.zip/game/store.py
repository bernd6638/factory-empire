"""
Store-Version des Spiels (z. B. Epic Games Store).

Die Store-Pakete enthalten neben main.py eine Datei "store.txt" mit dem Namen des Stores ("epic").
Dann übernimmt der Store die Updates (das eigene Auto-Update ist aus) und Erfolge werden zusätzlich
an den Store gemeldet.

Epic-Erfolge: Sobald das Epic-Online-Services-SDK (EOSSDK-Win64-Shipping.dll) und die Zugangsdaten
(Product ID, Sandbox ID, Deployment ID, Client ID) vorliegen, wird hier die Anbindung eingehängt.
Bis dahin werden Freischaltungen nur gesammelt und beim Start erneut gemeldet.
"""

import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read_store():
    env = os.environ.get("FACTORY_EMPIRE_STORE")
    if env:
        return env.strip().lower()
    try:
        with open(os.path.join(ROOT, "store.txt"), encoding="utf-8") as f:
            return f.read().strip().lower()[:20]
    except OSError:
        return ""


STORE = _read_store()


def is_store_build():
    """True, wenn ein Store (Epic, Steam ...) die Updates übernimmt."""
    return bool(STORE)


class _Backend:
    """Meldet Erfolge an den Store. Ohne SDK passiert nichts."""

    def __init__(self):
        self.ready = False
        self.pending = set()

    def unlock(self, aid):
        self.pending.add(aid)
        if self.ready:
            self._flush()

    def _flush(self):          # wird mit dem EOS-SDK gefüllt
        self.pending.clear()


backend = _Backend()


def unlock_achievement(aid):
    if STORE:
        try:
            backend.unlock(aid)
        except Exception as exc:      # Store-Probleme dürfen das Spiel nie stören
            print(f"[Store] Erfolg {aid} nicht gemeldet: {exc}")


def sync_achievements(unlocked_ids):
    """Beim Start: alle schon freigeschalteten Erfolge melden (der Store ignoriert doppelte)."""
    for aid in unlocked_ids:
        unlock_achievement(aid)
