"""
Produktionslogik der Maschinen (läuft ausschließlich auf dem Server).

Jede Funktion bekommt den Spielzustand, das Gebäude und die Zeitspanne dt.
Maschinen produzieren nur, wenn alle Voraussetzungen erfüllt sind:
eingeschaltet, Rohstoffe im Eingang, Platz im Ausgang und genug Geld für die
Energie. Energiekosten werden nicht sofort, sondern gesammelt alle
ENERGY_INTERVAL Sekunden abgebucht (siehe GameState.tick).
"""

from . import config as C
from . import logistics
from . import rules


def machine_speed(state, b):
    return rules.machine_speed(b.type, b.level, state.speed_mult, state.miner_mult)


def tick_miner(state, b, dt):
    ore = state.deposits.get((b.x, b.y))
    if ore is None:
        b.status = "no_deposit"
        return
    push_state = logistics.push_outputs(state, b)
    spec = C.BUILDINGS["miner"]
    cap = spec["out_cap"]
    held = sum(b.outbuf.values())
    if held < cap:
        b.progress += dt * machine_speed(state, b) / spec["time"]
        # Auf hohen Stufen schafft ein Miner mehr als ein Erz pro Takt – Überschuss nicht verwerfen
        made = 0
        while b.progress >= 1.0 and held + made < cap:
            b.progress -= 1.0
            made += 1
        if made:
            b.outbuf[ore] = b.outbuf.get(ore, 0) + made
            b.produced += made
            state.count_production(b, ore, made)
        if held + made >= cap:
            b.progress = min(b.progress, 1.0)
        b.status = "working"
    else:
        b.status = push_state or "blocked"
    if push_state in logistics.ERROR_STATES:
        b.status = push_state


def _available_recipes(state, b):
    if b.type in C.MACHINE_RECIPES:
        rid = b.recipe
        if rid in C.RECIPES and rules.recipe_unlocked(rid, state.research.unlocked):
            return [rid]
        return []
    return [rid for rid, r in C.RECIPES.items()
            if r["machine"] == b.type and rules.recipe_unlocked(rid, state.research.unlocked)]


def _inputs_ready(b, recipe):
    return all(b.inbuf.get(item, 0) >= qty for item, qty in recipe["inputs"].items())


def _start_recipe(state, b):
    """Startet das passende Rezept, wenn alle Zutaten da sind. Rückgabe: Statuscode oder None (gestartet)."""
    candidates = [rid for rid in _available_recipes(state, b) if _inputs_ready(b, C.RECIPES[rid])]
    if not candidates:
        return "no_input"
    # Rezept mit dem größten Vorrat zuerst (verhindert Verstopfen eines Eingangs)
    candidates.sort(key=lambda rid: -sum(b.inbuf.get(i, 0) for i in C.RECIPES[rid]["inputs"]))
    rid = candidates[0]
    recipe = C.RECIPES[rid]
    energy = recipe["cost"] * state.cost_mult
    if not state.can_afford_energy(energy):
        return "no_money"
    state.add_energy(energy)
    for item, qty in recipe["inputs"].items():
        b.inbuf[item] -= qty
        if b.inbuf[item] <= 0:
            del b.inbuf[item]
    b.active_recipe = rid
    b.progress = 0.0
    return None


def tick_crafter(state, b, dt):
    """Gemeinsame Logik aller verarbeitenden Maschinen.

    Die Zeit eines Takts wird vollständig genutzt: Ist ein Arbeitsgang mitten im Takt fertig, startet der
    nächste sofort mit der restlichen Zeit. Vorher ging auf hohen Ausbaustufen bis zu die Hälfte der
    Leistung verloren, weil zwischen zwei Arbeitsgängen immer ein ganzer Takt Pause lag."""
    spec = C.BUILDINGS[b.type]
    push_state = logistics.push_outputs(state, b)
    budget = dt
    worked = False
    status = None
    for _ in range(8):
        if not b.active_recipe:
            status = _start_recipe(state, b)
            if status:
                break
            worked = True
            continue
        recipe = C.RECIPES[b.active_recipe]
        if b.progress < 1.0:
            rate = machine_speed(state, b) / recipe["time"]
            need = (1.0 - b.progress) / rate if rate > 0 else float("inf")
            if budget < need:
                b.progress = min(1.0, b.progress + budget * rate)
                status = "working"
                break
            budget -= need
            b.progress = 1.0
        out_needed = sum(recipe["outputs"].values())
        if sum(b.outbuf.values()) + out_needed > spec["out_cap"]:
            status = push_state or "blocked"
            break
        for item, qty in recipe["outputs"].items():
            b.outbuf[item] = b.outbuf.get(item, 0) + qty
            state.count_production(b, item, qty)
        b.produced += out_needed
        b.active_recipe = None
        b.progress = 0.0
        worked = True
        status = "working"
    if worked and status == "no_input":
        status = "working"                   # in diesem Takt wurde gearbeitet
    b.status = status or "working"
    if push_state in logistics.ERROR_STATES:
        b.status = push_state


def tick_seller(state, b, dt):
    if not b.items:
        b.progress = 0.0
        b.status = "no_input"
        return
    item = b.items[0]
    current = state.market.prices.get(item, 0.0)
    if not rules.price_ok(current, state.market.base_price(item), b.min_pct):
        b.progress = 0.0
        b.status = "waiting_price"
        return
    b.progress += dt * machine_speed(state, b) / C.BUILDINGS["seller"]["time"]
    b.status = "working"
    while b.progress >= 1.0 and b.items:
        item = b.items[0]
        current = state.market.prices.get(item, 0.0)
        if not rules.price_ok(current, state.market.base_price(item), b.min_pct):
            break
        b.progress -= 1.0
        b.items.pop(0)
        revenue = state.market.sell(item, 1, state.price_mult, state.time)
        state.money += revenue
        b.earned += revenue
        state.count_production(b, item, 1, track_global=False)
    if not b.items:
        b.progress = 0.0
    elif b.progress > 1.0:
        b.progress = 1.0


def tick_storage(state, b, dt):
    b.status = "full" if state.inventory_total() >= state.storage_capacity() else "ok"


TICK_FUNCTIONS = {
    "miner": tick_miner,
    "smelter": tick_crafter,
    "assembler": tick_crafter,
    "factory": tick_crafter,
    "seller": tick_seller,
    "storage": tick_storage,
    "freight": lambda state, b, dt: state.freight.tick_station(state, b, dt),
    "conveyor": logistics.tick_conveyor,
    "splitter": logistics.tick_router,
    "tpiece": logistics.tick_router,
    "sorter": logistics.tick_router,
}
for _machine in C.MACHINE_RECIPES:              # alle Fabriken mit wählbarem Rezept
    TICK_FUNCTIONS.setdefault(_machine, tick_crafter)
