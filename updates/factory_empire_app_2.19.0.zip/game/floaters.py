"""
Schwebende Zahlen über Gebäuden – z. B. „+120 €“, wenn ein Verkäufer Ware verkauft hat.

Ein kleiner Pool an Text-Objekten wird wiederverwendet. Pro Gebäude werden Beträge kurz gesammelt,
damit auch schnelle Verkäufer nur etwa eine Zahl pro Sekunde zeigen (gut lesbar, kaum Aufwand).
"""

import time

from ursina import Text, Vec3, color, scene

from . import rules

MAX_ACTIVE = 16
LIFE = 1.5                # Sekunden sichtbar
RISE = 0.85               # Kacheln pro Sekunde nach oben
INTERVAL = 0.9            # höchstens eine Zahl pro Gebäude in diesem Abstand
BASE_SCALE = 8.5


class Floaters:
    def __init__(self):
        self.enabled = True
        self.distant = False
        self.active = []           # [text, alter, startposition]
        self.free = []
        self.pending = {}          # Gebäude-ID -> [betrag, letzte_anzeige, position]

    def _make(self):
        t = Text("", parent=scene, billboard=True, origin=(0, 0), scale=BASE_SCALE, color=color.rgb(1, 0.86, 0.32))
        t.setLightOff()
        t.setDepthWrite(False)
        t.setBin("fixed", 60)
        return t

    def money(self, key, pos, amount):
        """Betrag für ein Gebäude vormerken; erscheint gesammelt höchstens alle INTERVAL Sekunden."""
        if not self.enabled or amount <= 0:
            return
        now = time.monotonic()
        p = self.pending.get(key)
        if p is None:
            p = self.pending[key] = [0.0, 0.0, pos]
        p[0] += amount
        p[2] = pos
        if now - p[1] >= INTERVAL:
            total = p[0]
            p[0] = 0.0
            p[1] = now
            if total >= 1 and not self.distant:
                self.show(pos, "+" + rules.format_money(total))

    def show(self, pos, text, rgb=(1, 0.86, 0.32)):
        if not self.enabled:
            return
        if len(self.active) >= MAX_ACTIVE:
            old = self.active.pop(0)
            old[0].enabled = False
            self.free.append(old[0])
        t = self.free.pop() if self.free else self._make()
        t.text = text
        t.color = color.rgb(*rgb)
        # dunkles, abgerundetes Schild dahinter: gut lesbar auf hellen Dächern und auf Gras
        t.create_background(padding=(0.012, 0.006), radius=0.4, color=color.rgba(0.06, 0.07, 0.1, 0.72))
        t.background_entity.setBin("fixed", 59)
        t.background_entity.setDepthWrite(False)
        t.enabled = True
        start = Vec3(pos[0], pos[1], pos[2])
        t.position = start
        t.setColorScale(1, 1, 1, 1)
        self.active.append([t, 0.0, start])

    def update(self, dt):
        if not self.active:
            return
        still = []
        for entry in self.active:
            t, age, start = entry
            age += dt
            if age >= LIFE:
                t.enabled = False
                self.free.append(t)
                continue
            entry[1] = age
            t.y = start[1] + age * RISE
            pop = 1 + 0.45 * max(0.0, 1 - age * 7)              # kurzes Aufploppen am Anfang
            t.scale = BASE_SCALE * pop
            fade = 1.0 - max(0.0, (age - LIFE * 0.55) / (LIFE * 0.45))
            t.setColorScale(1, 1, 1, fade)
            still.append(entry)
        self.active = still

    def clear(self):
        for t, _, _ in self.active:
            t.enabled = False
            self.free.append(t)
        self.active = []
        self.pending.clear()


_INST = {"inst": None}


def get():
    if _INST["inst"] is None:
        _INST["inst"] = Floaters()
    return _INST["inst"]
