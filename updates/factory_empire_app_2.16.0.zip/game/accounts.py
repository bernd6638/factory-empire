"""
Accounts auf dem Spielserver (accounts.json neben dem Spielstand).

Ein Account hat Benutzername + Passwort (nur als gesalzener PBKDF2-Hash gespeichert), die gekauften
bzw. geschenkten Skins, die angelegten Skins je Gebäude, die Erfolgspunkte und das Datum der letzten
Glücksrad-Drehung. Admins des Servers besitzen automatisch alle Skins.
"""

import datetime
import hashlib
import hmac
import json
import logging
import os
import random
import re
import secrets
import time

from . import skins as K

log = logging.getLogger("factory.accounts")

NAME_RE = re.compile(r"^[A-Za-z0-9_\-äöüÄÖÜß]{3,16}$")
MAX_POINTS = 500


def _hash(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), 120_000).hex()


def today():
    return datetime.date.today().isoformat()


class AccountStore:
    def __init__(self, path):
        self.path = path
        self.accounts = {}           # kleingeschriebener Name -> Account
        self.player_skins = {}       # Spielername (klein) -> angelegte Skins (für Gebäude auch offline)
        self._load()

    # ------------------------------------------------------------------ Datei
    def _load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return
        for key, a in (data.get("accounts") or {}).items():
            if isinstance(a, dict) and a.get("name") and a.get("hash") and a.get("salt"):
                a.setdefault("owned", [])
                a.setdefault("equip", {})
                a.setdefault("spent", 0)
                a.setdefault("points", 0)
                a.setdefault("wheel", "")
                a["owned"] = [s for s in a["owned"] if K.valid(s)]
                a["equip"] = {t: s for t, s in a["equip"].items() if K.valid(s) and K.parse(s)[0] == t}
                self.accounts[key.lower()] = a
        ps = data.get("player_skins") or {}
        self.player_skins = {k: {t: s for t, s in v.items() if K.valid(s)} for k, v in ps.items() if isinstance(v, dict)}

    def save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"accounts": self.accounts, "player_skins": self.player_skins}, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError as exc:
            log.warning("Accounts nicht gespeichert: %s", exc)

    # ------------------------------------------------------------------ Anmelden
    def get(self, name):
        return self.accounts.get(str(name).lower()) if name else None

    def register(self, name, pw):
        name = str(name or "").strip()
        if not NAME_RE.match(name):
            return None, "Benutzername: 3–16 Zeichen (Buchstaben, Zahlen, _ oder -)."
        if not isinstance(pw, str) or len(pw) < 4 or len(pw) > 64:
            return None, "Passwort: mindestens 4 Zeichen."
        if name.lower() in self.accounts:
            return None, "Diesen Benutzernamen gibt es schon."
        salt = secrets.token_hex(16)
        acc = {"name": name, "salt": salt, "hash": _hash(pw, salt), "token": secrets.token_hex(24),
               "owned": [], "equip": {}, "spent": 0, "points": 0, "wheel": "", "created": time.time()}
        self.accounts[name.lower()] = acc
        self.save()
        return acc, f"Account „{name}“ angelegt – du bist eingeloggt."

    def login(self, name, pw):
        acc = self.get(name)
        if acc is None or not isinstance(pw, str) or not hmac.compare_digest(_hash(pw, acc["salt"]), acc["hash"]):
            return None, "Benutzername oder Passwort falsch."
        if not acc.get("token"):
            acc["token"] = secrets.token_hex(24)
            self.save()
        return acc, f"Willkommen zurück, {acc['name']}!"

    def login_token(self, name, token):
        acc = self.get(name)
        if acc is None or not isinstance(token, str) or not acc.get("token") or \
                not hmac.compare_digest(token, acc["token"]):
            return None, "Automatische Anmeldung abgelaufen – bitte neu einloggen."
        return acc, f"Eingeloggt als {acc['name']}."

    # ------------------------------------------------------------------ Skins
    @staticmethod
    def owns(acc, sid, admin=False):
        return admin or sid in acc["owned"]

    @staticmethod
    def available_points(acc, admin=False):
        return 9999 if admin else max(0, acc["points"] - acc["spent"])

    def set_points(self, acc, n):
        try:
            n = max(0, min(MAX_POINTS, int(n)))
        except (TypeError, ValueError):
            return
        if n > acc["points"]:
            acc["points"] = n
            self.save()

    def buy(self, acc, sid, admin=False):
        if not K.valid(sid):
            return False, "Diesen Skin gibt es nicht."
        if self.owns(acc, sid, admin):
            return False, "Den Skin hast du schon."
        cost = K.price(sid)
        if self.available_points(acc) < cost:
            return False, f"Nicht genug Erfolgspunkte ({cost} nötig, du hast {self.available_points(acc)})."
        acc["spent"] += cost
        acc["owned"].append(sid)
        self.save()
        return True, f"Gekauft: {K.display_name(sid)} (-{cost} Punkte)."

    def equip(self, acc, player, target, sid, admin=False):
        if sid is None:
            acc["equip"].pop(target, None)
            msg = f"Standard-Look für {K.target_name(target)}."
        else:
            t, _ = K.parse(sid)
            if t != target or not self.owns(acc, sid, admin):
                return False, "Diesen Skin besitzt du nicht."
            acc["equip"][target] = sid
            msg = f"Angelegt: {K.display_name(sid)}."
        self.player_skins[player.lower()] = dict(acc["equip"])
        self.save()
        return True, msg

    def bind_player(self, acc, player):
        """Spielername übernimmt die Skins des Accounts (auch für seine Gebäude, wenn er offline ist)."""
        self.player_skins[player.lower()] = dict(acc["equip"])
        self.save()

    def gift(self, acc, sid, to_name, admin=False):
        if not K.valid(sid):
            return False, "Diesen Skin gibt es nicht."
        if not self.owns(acc, sid, admin):
            return False, "Diesen Skin besitzt du nicht."
        to = self.get(to_name)
        if to is None:
            return False, f"Keinen Account „{str(to_name)[:16]}“ auf diesem Server gefunden."
        if to is acc:
            return False, "Du kannst dir nicht selbst etwas schenken."
        if sid in to["owned"]:
            return False, f"{to['name']} hat diesen Skin schon."
        if not admin:
            acc["owned"].remove(sid)
            t, _ = K.parse(sid)
            if acc["equip"].get(t) == sid:
                acc["equip"].pop(t, None)
        to["owned"].append(sid)
        self.save()
        return True, f"{K.display_name(sid)} an {to['name']} verschenkt!"

    # ------------------------------------------------------------------ Glücksrad
    def wheel_ready(self, acc):
        return acc.get("wheel") != today()

    def spin(self, acc, admin=False, rng=None, rocket=True):
        """Gibt (ok, msg, segment, gewinn) zurück. gewinn: ("money", betrag) oder ("skin", id)."""
        if not self.wheel_ready(acc):
            return False, "Das Glücksrad kannst du morgen wieder drehen.", None, None
        rng = rng or random.Random()
        idx = rng.choices(range(len(K.WHEEL)), K.WHEEL_WEIGHTS)[0]
        kind, value, _ = K.WHEEL[idx]
        acc["wheel"] = today()
        if kind == "skin":
            pool = [s for s in K.all_ids() if K.rarity(s) == value and s not in acc["owned"]
                    and (rocket or K.parse(s)[0] != K.ROCKET)]
            if not pool or admin:                       # alles schon da: stattdessen Geld
                kind, value = "money", 10_000
                idx = 2
            else:
                sid = rng.choice(pool)
                acc["owned"].append(sid)
                self.save()
                return True, f"Glücksrad: Gratis-Skin {K.display_name(sid)}!", idx, ("skin", sid)
        self.save()
        return True, f"Glücksrad: +{value:,} € Geld-Boost!".replace(",", "."), idx, ("money", value)

    # ------------------------------------------------------------------ Netzwerk
    def profile(self, acc, admin=False):
        return {"name": acc["name"], "token": acc["token"], "points": acc["points"], "spent": acc["spent"],
                "avail": self.available_points(acc, admin), "owned": list(acc["owned"]), "equip": dict(acc["equip"]),
                "all": bool(admin), "wheel": self.wheel_ready(acc)}
