"""
Neuigkeiten je Version – wird nach einem Update im Spiel angezeigt und für die Update-Datei
(update.json) verwendet. Neueste Version oben.
"""

CHANGELOG = [
    ("2.15.3", [
        "Kleine Verbesserungen und Fehlerbehebungen",
    ]),
    ("2.15.2", [
        "Kleine Verbesserungen und Fehlerbehebungen",
    ]),
    ("2.15.2", [
        "Kleine Verbesserungen und Fehlerbehebungen",
    ]),
    ("2.15.1", [
        "Karte: Der weiße Rahmen ist weg – der orange Pfeil zeigt deine Position und Blickrichtung",
        "Neue Updates erscheinen im Spiel jetzt schon nach etwa einer Minute oben rechts (vorher konnte es bis zu 7 Minuten dauern)",
    ]),
    ("2.15.0", [
        "Neues Design: Alle Anzeigen im Glas-Look mit Leuchtkanten, Schatten und schöneren Symbolleisten",
        "Die Karte unten links ist komplett neu: schärfer, mit Erz-Feldern, Gebäuden, Förderband-Richtungen und deinem Sichtfeld",
        "Auf der Karte siehst du jetzt, wohin du schaust, und die Koordinaten unter der Maus – ein Klick fährt direkt dorthin",
    ]),
    ("2.14.0", [
        "Live-Updates: Neue Versionen werden jetzt auch mitten im Spiel gefunden – oben rechts erscheint „Update verfügbar“",
        "Ein Klick lädt das Update im Hintergrund, danach lädt das Spiel kurz neu und du bist sofort wieder in deiner Welt",
    ]),
    ("2.13.0", [
        "13 neue Erfolge: zum Beispiel „Deine erste große Fabrik“ für 10 Großfabriken – mit eigenem Erfolgs-Sound",
        "Einstellungen neu sortiert: Reiter für Anzeige, Leistung, Audio und Steuerung",
        "Tastenbelegung: Unter Optionen » Steuerung legst du jede Taste selbst fest",
        "Eigener Lautstärkeregler für den Erfolgs-Sound (mit Test-Knopf)",
    ]),
    ("2.12.0", [
        "Kleine Verbesserungen und Fehlerbehebungen",
    ]),
    ("2.11.0", [
        "Weitere Vorbereitungen für das große Update – nur noch wenige Tage bis zum Ende des Countdowns!",
        "Kleine Verbesserungen und Fehlerbehebungen",
    ]),
    ("2.10.0", [
        "Hinter den Kulissen: Alles ist bereit für das große Update – der Countdown läuft weiter …",
        "Kleine Verbesserungen und Fehlerbehebungen",
    ]),
    ("2.9.3", [
        "Sprachauswahl: Spiele auf Deutsch, Englisch, Französisch, Spanisch, Italienisch, Portugiesisch, Polnisch, Türkisch oder Russisch – unter Optionen » Sprache, wechselt sofort",
        "Lautstärke in 1-%-Schritten: Musik, Umgebung und Effekte lassen sich jetzt ganz fein einstellen, z. B. auf 2 % – auch mit dem Mausrad über dem Regler",
    ]),
    ("2.9.2", [
        "Hintergrundmusik: Zwei entspannte Musikstücke laufen im Wechsel – im Menü und im Spiel",
        "Vogelgezwitscher: Amseln, Meisen und Finken zwitschern mal links, mal rechts aus dem Wald",
        "Wind und Fabrikgeräusche: Leiser Wind in den Bäumen, je mehr Maschinen laufen, desto lauter brummt und klackert die Fabrik",
        "Neue Regler: Musik und Umgebung lassen sich unter Optionen getrennt einstellen",
    ]),
    ("2.9.1", [
        "Förderband-Kurven: Gehen Bänder um die Ecke, entsteht jetzt ein schöner Bogen – die Waren fahren die Kurve entlang",
        "Chat mit T: T drücken, Nachricht schreiben, Enter – mit Verlauf und Spielerfarben",
        "Realistischere Grafik: Neue Beleuchtung mit Himmelslicht, Glanzlichtern und kräftigeren Farben",
        "Geheime Baustelle: Vor der Nordwest-Ecke wird etwas gebaut – mit Countdown bis zum nächsten großen Update …",
    ]),
    ("2.9.0", [
        "Automatische Updates: Neue Versionen werden direkt im Spiel heruntergeladen – kein neuer Download nötig",
        "Nach jedem Update zeigt dieses Fenster, was neu ist",
    ]),
    ("2.8.1", [
        "Discord-Status: Discord zeigt „Spielt Factory Empire“ mit Logo, Spielmodus, Geld und Spielzeit",
        "Abschaltbar unter Optionen » „Status in Discord zeigen“",
    ]),
    ("2.8.0", [
        "Aufträge (O): Städte bestellen Waren, LKW liefern sie gegen hohe Belohnungen",
        "Neues Gebäude Frachtbahnhof mit LKW, Speditions-Ruf und Forschung „Autobahnanbindung“",
        "Dichter Wald bis zum Horizont, Dunst in der Ferne und eine Landstraße mit Verkehr",
        "Statistiken & 15 Erfolge im Hauptmenü",
    ]),
    ("2.7.1", [
        "Fehler behoben, durch den man nichts mehr anklicken konnte",
        "Weniger Zeichenaufrufe: Rauch, Funken und Warnschilder gebündelt – mehr FPS",
    ]),
    ("2.7.0", [
        "Rasen statt grauem Boden",
        "Materialien auf Bändern auch weit herausgezoomt sichtbar",
        "Eigener Mauszeiger im Vollbild (F11)",
        "Mehrspieler mit 5 Welten-Plätzen",
    ]),
]


def _key(v):
    return tuple(int(p) for p in v.split("."))


def notes_since(old, new=None):
    """Alle Einträge neuer als `old` (bis einschließlich `new`): [(version, [zeilen])]."""
    out = []
    for version, lines in CHANGELOG:
        if old and _key(version) <= _key(old):
            continue
        if new and _key(version) > _key(new):
            continue
        out.append((version, lines))
    return out
