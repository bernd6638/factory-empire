"""
Automatische Updates.

1. Beim Start lädt das Spiel im Hintergrund die kleine Datei update.json (UPDATE_URL).
2. Ist dort eine neuere Version eingetragen, erscheint im Hauptmenü ein Fenster mit den Neuigkeiten.
3. "Jetzt aktualisieren": das Spielpaket (nur Spielcode und Grafiken, wenige MB) wird geladen,
   per SHA-256 geprüft und nach <saves>/update/app entpackt. Danach startet das Spiel neu –
   bootstrap_update.py startet dann automatisch die neue Version.

Die mitgelieferte Laufzeit (Python, Panda3D ...) bleibt dabei unverändert. Braucht ein Update eine
neuere Laufzeit (RUNTIME_VERSION), zeigt das Fenster stattdessen einen Link zum vollständigen Download.

update.json:
    {"version": "2.9.1", "runtime": 1, "url": "https://.../factory_empire_app_2.9.1.zip",
     "sha256": "...", "size": 1234567, "download_page": "https://...",
     "notes": [["2.9.1", ["Neu: ...", "..."]], ...]}
"""

import hashlib
import json
import os
import shutil
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile

from . import config as C

TIMEOUT = 8


def version_key(v):
    try:
        return tuple(int(p) for p in str(v).split("."))
    except ValueError:
        return (0,)


def _ssl_context():
    """Zertifikate: certifi (mitgeliefert, nötig auf dem Mac), sonst die des Systems."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _open(url):
    req = urllib.request.Request(url, headers={"User-Agent": f"FactoryEmpire/{C.GAME_VERSION}",
                                               "Cache-Control": "no-cache"})
    return urllib.request.urlopen(req, timeout=TIMEOUT, context=_ssl_context())


def update_root():
    return os.path.join(C.DATA_DIR, "update")


class Updater:
    def __init__(self, url=None):
        env = os.environ.get("FACTORY_EMPIRE_UPDATE_URL")
        self.url = url if url is not None else (env or C.UPDATE_URL)
        self.api_url = C.UPDATE_API_URL if (url is None and not env) else None
        self._etag = None
        self._api_info = None
        self._api_off_until = 0.0
        self.state = "idle"          # idle | checking | available | none | downloading | ready | error
        self.info = None             # Inhalt von update.json
        self.progress = 0.0
        self.error = ""
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ Prüfen
    def check_async(self):
        if not self.url or self.state in ("checking", "downloading"):
            return
        self.state = "checking"
        threading.Thread(target=self._check, name="update-check", daemon=True).start()

    def _check(self):
        try:
            info = self._fetch_api() if self.api_url else None
            if info is None:
                with _open(self.url) as r:
                    info = json.loads(r.read(256 * 1024).decode("utf-8"))
            if not isinstance(info, dict) or "version" not in info:
                raise ValueError("update.json ohne Version")
            self.info = info
            newer = version_key(info["version"]) > version_key(C.GAME_VERSION)
            self.state = "available" if newer else "none"
        except Exception as exc:                       # kein Internet o. Ä.: einfach kein Update
            self.error = str(exc)
            self.state = "none"
            print(f"[Update] Prüfung nicht möglich: {exc}")

    def _fetch_api(self):
        """update.json direkt über die GitHub-API (sieht neue Versionen nach höchstens ~1 Minute).
        Gibt None zurück, wenn das gerade nicht geht – dann wird die normale Adresse benutzt."""
        if time.time() < self._api_off_until:
            return None
        headers = {"User-Agent": f"FactoryEmpire/{C.GAME_VERSION}", "Accept": "application/vnd.github.raw"}
        if self._etag and self._api_info:
            headers["If-None-Match"] = self._etag
        try:
            req = urllib.request.Request(self.api_url, headers=headers)
            with urllib.request.urlopen(req, timeout=TIMEOUT, context=_ssl_context()) as r:
                info = json.loads(r.read(256 * 1024).decode("utf-8"))
                self._etag = r.headers.get("ETag")
                self._api_info = info
                return info
        except urllib.error.HTTPError as exc:
            if exc.code == 304 and self._api_info:
                return self._api_info
            self._api_off_until = time.time() + 900       # z. B. Abruflimit erreicht: eine Weile pausieren
        except Exception:
            self._api_off_until = time.time() + 300
        return None

    @property
    def needs_full_download(self):
        return bool(self.info) and int(self.info.get("runtime", 1)) > C.RUNTIME_VERSION

    def notes(self):
        """Neuigkeiten aller Versionen zwischen der installierten und der neuen."""
        out = []
        for entry in (self.info or {}).get("notes", []):
            try:
                ver, lines = entry
            except (TypeError, ValueError):
                continue
            if version_key(ver) > version_key(C.GAME_VERSION):
                out.append((str(ver), [str(x) for x in lines][:12]))
        return out

    # ------------------------------------------------------------------ Laden & Installieren
    def download_async(self):
        if self.state != "available" or self.needs_full_download:
            return
        self.state = "downloading"
        self.progress = 0.0
        threading.Thread(target=self._download, name="update-download", daemon=True).start()

    def _download(self):
        root = update_root()
        tmp_zip = os.path.join(root, "download.zip")
        staging = os.path.join(root, "staging")
        try:
            os.makedirs(root, exist_ok=True)
            info = self.info
            size = int(info.get("size", 0)) or None
            h = hashlib.sha256()
            done = 0
            with _open(info["url"]) as r, open(tmp_zip, "wb") as f:
                while True:
                    chunk = r.read(64 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    h.update(chunk)
                    done += len(chunk)
                    if size:
                        self.progress = min(0.95, done / size * 0.95)
            if info.get("sha256") and h.hexdigest() != info["sha256"].lower():
                raise ValueError("Prüfsumme stimmt nicht – Download beschädigt.")
            shutil.rmtree(staging, ignore_errors=True)
            with zipfile.ZipFile(tmp_zip) as z:
                for name in z.namelist():           # nichts außerhalb des Zielordners entpacken
                    target = os.path.realpath(os.path.join(staging, name))
                    if not target.startswith(os.path.realpath(staging) + os.sep) and target != os.path.realpath(staging):
                        raise ValueError(f"Ungültiger Pfad im Update: {name}")
                z.extractall(staging)
            for need in ("main.py", "server.py", os.path.join("game", "config.py")):
                if not os.path.exists(os.path.join(staging, need)):
                    raise ValueError(f"Update unvollständig ({need} fehlt).")
            # Jede Version in einen eigenen Ordner (die laufende Version wird nie überschrieben)
            app = os.path.join(root, "app-" + str(info["version"]))
            shutil.rmtree(app, ignore_errors=True)
            os.replace(staging, app)
            os.remove(tmp_zip)
            self.progress = 1.0
            self.state = "ready"
        except Exception as exc:
            self.error = str(exc)
            self.state = "error"
            print(f"[Update] fehlgeschlagen: {exc}")
            shutil.rmtree(staging, ignore_errors=True)

    @staticmethod
    def cleanup():
        """Ältere heruntergeladene Versionen löschen (nicht die laufende)."""
        root = update_root()
        try:
            names = os.listdir(root)
        except OSError:
            return
        running = os.path.realpath(C.PROJECT_DIR)
        for name in names:
            path = os.path.join(root, name)
            if not name.startswith("app-") or os.path.realpath(path) == running:
                continue
            if version_key(name[4:]) <= version_key(C.GAME_VERSION):
                shutil.rmtree(path, ignore_errors=True)

    # ------------------------------------------------------------------ Neustart
    @staticmethod
    def restart():
        """Spiel neu starten – der Start-Code wählt dann automatisch die neue Version."""
        base = os.environ.get("FE_BASE_DIR") or C.PROJECT_DIR
        env = dict(os.environ)
        for k in ("FE_OVERLAY", "FE_BASE_DIR"):
            env.pop(k, None)
        args = [sys.executable, os.path.join(base, "main.py")] + sys.argv[1:]
        kwargs = {"cwd": base, "env": env}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "DETACHED_PROCESS", 0) | \
                getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen(args, **kwargs)
