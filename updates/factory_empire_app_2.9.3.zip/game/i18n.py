"""
Mehrsprachigkeit.

Der Quelltext bleibt deutsch – jeder angezeigte Text wird kurz vor der Anzeige
übersetzt. Die Übersetzungen liegen in game/lang/<code>.json als
{"deutscher Text": "Übersetzung"}. Texte mit Platzhaltern ({0}, {1} ...)
werden als Vorlagen erkannt, z. B. "{0} gebaut (-{1} €)." passt auf
"Förderband gebaut (-25 €).". Die eingesetzten Teile (hier "Förderband")
werden dabei selbst wieder übersetzt. So funktionieren auch Meldungen, die
vom (evtl. deutschen) Server kommen.

Der Hook sitzt an Ursinas Text: alles, was angezeigt wird, läuft hier durch.
Eingabefelder und Spielernamen/Chat werden nicht übersetzt.
"""

import json
import locale
import os
import re
import weakref

LANGUAGES = [
    ("de", "Deutsch"),
    ("en", "English"),
    ("fr", "Français"),
    ("es", "Español"),
    ("it", "Italiano"),
    ("pt", "Português"),
    ("pl", "Polski"),
    ("tr", "Türkçe"),
    ("ru", "Русский"),
]
CODES = [c for c, _ in LANGUAGES]
LANG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lang")

_lang = "de"
_table = {}
_templates = []         # (prefilter, regex, translation)
_suffixes = []          # Anhängsel wie " (du)" oder ", nächste Stufe in {0} Lieferungen)"
_EXTRA_SUFFIX = ("Esc-Menü: Adresse kopieren.",)
_cache = {}
_registry = weakref.WeakSet()
_listeners = []

_LETTER = "A-Za-zÀ-ÖØ-öø-ÿ"
_AFFIX = re.compile(r"^([^%s]*)(.*?)([^%s]*)$" % (_LETTER, _LETTER), re.S)
_SEP = re.compile(r"(\s+[·|»→]\s+|\s{2,}|\s[–-]\s)")
_TAG = re.compile(r"(<[^<>\n]{1,40}>)")
_PH = re.compile(r"\{(\d+)\}")


def detect():
    """Sprache des Betriebssystems, falls unterstützt – sonst Englisch."""
    cands = []
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        if os.environ.get(var):
            cands.append(os.environ[var])
    try:
        loc = locale.getlocale()[0]
        if loc:
            cands.append(loc)
    except Exception:
        pass
    try:  # Windows: Anzeigesprache
        import ctypes
        lcid = ctypes.windll.kernel32.GetUserDefaultUILanguage()
        cands.append(locale.windows_locale.get(lcid, ""))
    except Exception:
        pass
    try:  # macOS
        import subprocess
        out = subprocess.run(["defaults", "read", "-g", "AppleLanguages"], capture_output=True, text=True,
                             timeout=2).stdout
        m = re.search(r'"?([a-z]{2})[-_"]', out)
        if m:
            cands.insert(0, m.group(1))
    except Exception:
        pass
    names = {"german": "de", "english": "en", "french": "fr", "spanish": "es", "italian": "it",
             "portuguese": "pt", "polish": "pl", "turkish": "tr", "russian": "ru"}
    for c in cands:
        c = c.lower()
        if c[:2] in CODES:
            return c[:2]
        for n, code in names.items():
            if c.startswith(n):
                return code
    return "en"


def language():
    return _lang


def _compile(key, value):
    parts = _PH.split(key)
    lits = [p.replace("{{", "{").replace("}}", "}") for p in parts[0::2]]
    idx = [int(p) for p in parts[1::2]]
    if sum(len(re.findall("[%s]" % _LETTER, x)) for x in lits) < 2:
        return None
    pat = ""
    for i, lit in enumerate(lits):
        pat += re.escape(lit)
        if i < len(idx):
            q = "*" if (i > 0 and lits[i] == "") else "+"
            pat += ("(?P<a%d>.%s?)" % (idx[i], q)) if ("(?P<a%d>" % idx[i]) not in pat else ".+?"
    best = max(lits, key=len)
    return (len("".join(lits)), best, re.compile(pat, re.S), value)


def set_language(code):
    """Lädt eine Sprache und übersetzt alle sichtbaren Texte neu."""
    global _lang, _table, _templates, _suffixes
    code = code if code in CODES else "de"
    table = {}
    if code != "de":
        try:
            with open(os.path.join(LANG_DIR, code + ".json"), encoding="utf-8") as f:
                table = json.load(f)
        except Exception as e:  # fehlende/kaputte Datei -> deutsch weiter
            print(f"[i18n] Sprache {code} nicht ladbar: {e}")
            code = "de"
    _lang, _table = code, table
    tpls, sufs = [], []
    for k, v in list(table.items()):
        if k.endswith(":") and v.rstrip().endswith((":", "：")):
            # "Nicht möglich:" -> Vorlage "Nicht möglich: {n}"
            n = len(set(_PH.findall(k)))
            table.setdefault(f"{k} {{{n}}}", f"{v} {{{n}}}")
    for k, v in table.items():
        if "{" in k and _PH.search(k):
            t = _compile(k, v)
            if t:
                tpls.append(t)
        if k[:1] in "(–·,." or k in _EXTRA_SUFFIX:
            t = _compile(k, v) if _PH.search(k) else None
            rx = t[2].pattern if t else re.escape(k)
            sufs.append((len(k), re.compile(r"(?P<pre>.*\S)(?P<ws>\s*)" + rx, re.S), v))
    tpls.sort(key=lambda t: -t[0])
    _templates = [t[1:] for t in tpls]
    sufs.sort(key=lambda t: -t[0])
    _suffixes = [t[1:] for t in sufs]
    _cache.clear()
    retranslate_all()
    for fn in list(_listeners):
        try:
            fn(code)
        except Exception:
            pass


def on_change(fn):
    _listeners.append(fn)


# ---------------------------------------------------------------- Übersetzen
def _fill(value, m):
    def rep(mm):
        try:
            a = m.group("a" + mm.group(1))
        except IndexError:
            return mm.group(0)
        if not a:
            return a
        r = _piece(a)
        if r is not None:
            return r
        r = _block(a)
        if r == a and ", " in a:
            r = ", ".join(_block(x) for x in a.split(", "))
        return r
    return _PH.sub(rep, value)



def _lookup(core):
    v = _table.get(core)
    if v is not None:
        return v
    if "{" in core:
        return None
    for best, rx, value in _templates:
        if best and best not in core:
            continue
        m = rx.fullmatch(core)
        if m:
            return _fill(value, m)
    return None


def _piece(s):
    """Übersetzt ein Stück Text (Leerraum, Symbole und Zahlen am Rand bleiben stehen)."""
    core = s.strip()
    if not core or not re.search("[%s]" % _LETTER, core):
        return s
    lead = s[:len(s) - len(s.lstrip())]
    trail = s[len(s.rstrip()):]
    r = _lookup(core)
    if r is None:
        m = _AFFIX.match(core)
        if m and m.group(2) and (m.group(1) or m.group(3)):
            inner = _lookup(m.group(2))
            if inner is not None:
                r = m.group(1) + inner + m.group(3)
    return None if r is None else lead + r + trail


def _block(s):
    r = _piece(s)
    if r is not None:
        return r
    if "\n" in s:
        return "\n".join(_block(line) for line in s.split("\n"))
    for rx, value in _suffixes:
        m = rx.fullmatch(s)
        if m:
            return _block(m.group("pre")) + m.group("ws") + (_fill(value, m) if "{" in value else value)
    parts = _SEP.split(s)
    if len(parts) > 1:
        return "".join(p if i % 2 else _block(p) for i, p in enumerate(parts))
    return s


def tr(text):
    """Übersetzt einen anzuzeigenden Text in die eingestellte Sprache."""
    if _lang == "de" or not text or not isinstance(text, str):
        return text
    r = _cache.get(text)
    if r is not None:
        return r
    if "<" in text and ">" in text:
        r = "".join(p if i % 2 else _block(p) for i, p in enumerate(_TAG.split(text)))
    else:
        r = _block(text)
    if len(_cache) > 6000:
        _cache.clear()
    _cache[text] = r
    return r


# ---------------------------------------------------------------- Anbindung an Ursina
def _render(t, src):
    d = t.__dict__
    out = src if d.get("_raw") else tr(src)
    wrap = d.get("_fe_wrap")
    if wrap:
        out = wrap(out)
    d["_fe_out"] = out
    return out


def install():
    """Hängt die Übersetzung in Ursinas Text (und schützt Eingabefelder)."""
    from ursina import Text
    from ursina.prefabs.text_field import TextField
    if getattr(Text, "_fe_i18n", False):
        return
    prop = Text.text
    orig = prop.fset

    def fset(self, value):
        d = self.__dict__
        if d.get("_no_tr") or not isinstance(value, str) or ("_fe_src" in d and value == d.get("_fe_out")):
            return orig(self, value)
        d["_fe_src"] = value
        _registry.add(self)
        orig(self, _render(self, value))

    Text.text = property(prop.fget, fset, prop.fdel)
    Text._fe_orig_setter = staticmethod(orig)
    Text._fe_i18n = True

    tf_init = TextField.__init__

    def tf_patched(self, *a, **kw):
        tf_init(self, *a, **kw)
        for name in ("text_entity", "line_numbers"):
            te = getattr(self, name, None)
            if te is not None:
                te.__dict__["_no_tr"] = True
    TextField.__init__ = tf_patched


def set_raw(text_entity, raw=True):
    """Text wird nie übersetzt (Spielernamen, Chat, Weltnamen ...)."""
    text_entity.__dict__["_raw"] = raw


def retranslate_all():
    try:
        from ursina import Text
        orig = Text._fe_orig_setter
    except Exception:
        return
    for t in list(_registry):
        try:
            if t.is_empty() if hasattr(t, "is_empty") else False:
                continue
            src = t.__dict__.get("_fe_src")
            if src is None:
                continue
            orig(t, _render(t, src))
            fix = t.__dict__.get("_fe_after")
            if fix:
                fix()
        except Exception:
            pass
