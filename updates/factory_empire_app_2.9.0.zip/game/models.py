"""
Prozedurale 3D-Modelle.

Alle Modelle bestehen aus einfachen Grundkörpern (Quader, Zylinder, Kegel,
Keil), die hier direkt zu EINEM Mesh mit Vertexfarben, Normalen und
Texturkoordinaten zusammengefügt werden. Die Texturkoordinaten werden je
Fläche planar aus der Position berechnet, so bleibt die Texturdichte auf
großen und kleinen Teilen gleich. Ein Gebäude = ein Draw-Call für alle
unbeweglichen Teile; keine externen Modelldateien nötig.

Koordinaten je Gebäude: Kachel von -0.5 bis 0.5 (x, z), Boden bei y = 0,
Vorderseite (Ausgang) zeigt nach +z.
"""

import math

from ursina import Mesh, Vec2, Vec3

# ---------------------------------------------------------------- Farbpalette
FOUNDATION = (0.30, 0.32, 0.36)
DARK = (0.16, 0.17, 0.19)
STEEL = (0.62, 0.65, 0.70)
LIGHT_STEEL = (0.80, 0.83, 0.87)
YELLOW = (0.98, 0.74, 0.16)
BRICK = (0.66, 0.32, 0.22)
TEAL = (0.12, 0.60, 0.62)
WHITE = (0.94, 0.95, 0.97)
RED = (0.90, 0.26, 0.22)
GOLD = (1.00, 0.80, 0.25)
BLUEGRAY = (0.38, 0.50, 0.66)
WOOD = (0.66, 0.48, 0.28)
PURPLE = (0.45, 0.38, 0.82)
ORANGE = (0.98, 0.52, 0.12)
GREEN = (0.30, 0.78, 0.42)
CYAN = (0.30, 0.82, 0.95)
GLASS = (0.62, 0.85, 1.00)
BELT = (0.12, 0.12, 0.13)


# ---------------------------------------------------------------- Mathe
def _rotate(v, rx, ry, rz):
    x, y, z = v
    if rz:
        a = math.radians(rz)
        x, y = x * math.cos(a) + y * math.sin(a), -x * math.sin(a) + y * math.cos(a)
    if rx:
        a = math.radians(rx)
        y, z = y * math.cos(a) - z * math.sin(a), y * math.sin(a) + z * math.cos(a)
    if ry:
        a = math.radians(ry)
        x, z = x * math.cos(a) + z * math.sin(a), -x * math.sin(a) + z * math.cos(a)
    return x, y, z


# ---------------------------------------------------------------- Grundkörper
# Jeder Grundkörper liefert (vertices, triangles, normals) für Einheitsgröße.
def _box_geometry():
    faces = [
        ((0, 0, -1), [(-.5, -.5, -.5), (.5, -.5, -.5), (.5, .5, -.5), (-.5, .5, -.5)]),
        ((0, 0, 1), [(.5, -.5, .5), (-.5, -.5, .5), (-.5, .5, .5), (.5, .5, .5)]),
        ((0, 1, 0), [(-.5, .5, -.5), (.5, .5, -.5), (.5, .5, .5), (-.5, .5, .5)]),
        ((0, -1, 0), [(-.5, -.5, .5), (.5, -.5, .5), (.5, -.5, -.5), (-.5, -.5, -.5)]),
        ((1, 0, 0), [(.5, -.5, -.5), (.5, -.5, .5), (.5, .5, .5), (.5, .5, -.5)]),
        ((-1, 0, 0), [(-.5, -.5, .5), (-.5, -.5, -.5), (-.5, .5, -.5), (-.5, .5, .5)]),
    ]
    verts, tris, norms = [], [], []
    for normal, quad in faces:
        o = len(verts)
        verts += quad
        norms += [normal] * 4
        tris += [(o, o + 1, o + 2), (o, o + 2, o + 3)]
    return verts, tris, norms


def _cylinder_geometry(resolution=14, top_radius=0.5):
    verts, tris, norms = [], [], []
    ring = [(math.cos(2 * math.pi * i / resolution), math.sin(2 * math.pi * i / resolution))
            for i in range(resolution)]
    r0, r1 = 0.5, top_radius
    slope = (r0 - r1)
    for i in range(resolution):
        (c0, s0), (c1, s1) = ring[i], ring[(i + 1) % resolution]
        o = len(verts)
        verts += [(c0 * r0, -.5, s0 * r0), (c0 * r1, .5, s0 * r1), (c1 * r1, .5, s1 * r1), (c1 * r0, -.5, s1 * r0)]
        n0 = (c0, slope, s0)
        n1 = (c1, slope, s1)
        norms += [n0, n0, n1, n1]
        tris += [(o, o + 3, o + 2), (o, o + 2, o + 1)]
    for y, ny, r in ((.5, 1, r1), (-.5, -1, r0)):
        if r <= 0.001:
            continue
        c = len(verts)
        verts.append((0, y, 0))
        norms.append((0, ny, 0))
        for cx, sz in ring:
            verts.append((cx * r, y, sz * r))
            norms.append((0, ny, 0))
        for i in range(resolution):
            a, b = c + 1 + i, c + 1 + (i + 1) % resolution
            tris.append((c, a, b) if ny > 0 else (c, b, a))
    return verts, tris, norms


def _wedge_geometry():
    """Keil (Dachschräge): rechtwinkliges Prisma, Schräge zeigt nach +z/oben."""
    p = [(-.5, -.5, -.5), (.5, -.5, -.5), (.5, .5, -.5), (-.5, .5, -.5), (-.5, -.5, .5), (.5, -.5, .5)]
    s = 1 / math.sqrt(2)
    faces = [
        ((0, 0, -1), [p[0], p[1], p[2], p[3]]),
        ((0, -1, 0), [p[4], p[5], p[1], p[0]]),
        ((0, s, s), [p[3], p[2], p[5], p[4]]),
        ((1, 0, 0), [p[1], p[5], p[2]]),
        ((-1, 0, 0), [p[4], p[0], p[3]]),
    ]
    verts, tris, norms = [], [], []
    for normal, poly in faces:
        o = len(verts)
        verts += poly
        norms += [normal] * len(poly)
        tris += [(o, o + 1, o + 2)] if len(poly) == 3 else [(o, o + 1, o + 2), (o, o + 2, o + 3)]
    return verts, tris, norms


def _ico_geometry():
    """Grobe Kugel (Ikosaeder, flach schattiert) für Baumkronen, Büsche, Steine."""
    t = (1 + 5 ** 0.5) / 2
    pts = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t),
           (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    faces = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2),
             (10, 7, 6), (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5),
             (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]
    length = math.sqrt(1 + t * t)
    pts = [(x / length * .5, y / length * .5, z / length * .5) for x, y, z in pts]
    verts, tris, norms = [], [], []
    for a, b, c in faces:
        pa, pb, pc = pts[a], pts[b], pts[c]
        nx, ny, nz = [(pa[i] + pb[i] + pc[i]) / 3 for i in range(3)]
        ln = math.sqrt(nx * nx + ny * ny + nz * nz)
        o = len(verts)
        verts += [pa, pc, pb]
        norms += [(nx / ln, ny / ln, nz / ln)] * 3
        tris.append((o, o + 1, o + 2))
    return verts, tris, norms


def _pebble_geometry():
    """Sehr einfacher Stein (Doppelpyramide mit 6 Ecken, flach schattiert) – für tausende Erzbrocken."""
    pts = [(0, 0.5, 0), (0, -0.5, 0), (0.5, 0, 0.1), (-0.45, 0, -0.15), (0.1, 0, 0.5), (-0.15, 0, -0.45)]
    faces = [(0, 2, 4), (0, 4, 3), (0, 3, 5), (0, 5, 2), (1, 4, 2), (1, 3, 4), (1, 5, 3), (1, 2, 5)]
    verts, tris, norms = [], [], []
    for a, b, c in faces:
        pa, pb, pc = pts[a], pts[b], pts[c]
        ux, uy, uz = (pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2])
        vx, vy, vz = (pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2])
        nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        ln = math.sqrt(nx * nx + ny * ny + nz * nz) or 1
        if nx * (pa[0] + pb[0] + pc[0]) + ny * (pa[1] + pb[1] + pc[1]) + nz * (pa[2] + pb[2] + pc[2]) < 0:
            nx, ny, nz = -nx, -ny, -nz
            pb, pc = pc, pb
        o = len(verts)
        verts += [pa, pc, pb]
        norms += [(nx / ln, ny / ln, nz / ln)] * 3
        tris.append((o, o + 1, o + 2))
    return verts, tris, norms


SHAPES = {
    "box": _box_geometry(),
    "cyl": _cylinder_geometry(16),
    "cyl8": _cylinder_geometry(8),
    "cyl6": _cylinder_geometry(6),
    "cone": _cylinder_geometry(10, 0.0),
    "cone6": _cylinder_geometry(6, 0.0),
    "frustum": _cylinder_geometry(12, 0.32),
    "wedge": _wedge_geometry(),
    "ico": _ico_geometry(),
    "pebble": _pebble_geometry(),
}


class MeshBuilder:
    """Sammelt transformierte Grundkörper und erzeugt daraus ein Ursina-Mesh."""

    def __init__(self, uv_density=1.6):
        self.verts, self.tris, self.norms, self.cols, self.uvs = [], [], [], [], []
        self.uv_density = uv_density

    def add(self, shape, pos=(0, 0, 0), scale=(1, 1, 1), color=(1, 1, 1), rot=(0, 0, 0), alpha=1.0):
        sv, st, sn = SHAPES[shape]
        sx, sy, sz = scale
        rx, ry, rz = rot
        o = len(self.verts)
        d = self.uv_density
        local = []
        for (x, y, z) in sv:
            vx, vy, vz = _rotate((x * sx, y * sy, z * sz), rx, ry, rz)
            local.append((vx, vy, vz))
            self.verts.append((vx + pos[0], vy + pos[1], vz + pos[2]))
        for i, (nx, ny, nz) in enumerate(sn):
            # Normalen bei nicht-uniformer Skalierung korrekt transformieren
            nx, ny, nz = nx / sx, ny / sy, nz / sz
            length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1
            n = _rotate((nx / length, ny / length, nz / length), rx, ry, rz)
            self.norms.append(n)
            px, py, pz = self.verts[o + i]
            ax, ay, az = abs(n[0]), abs(n[1]), abs(n[2])
            if ay >= ax and ay >= az:
                self.uvs.append((px * d, pz * d))
            elif ax >= az:
                self.uvs.append((pz * d, py * d))
            else:
                self.uvs.append((px * d, py * d))
        self.tris += [(a + o, b + o, c + o) for a, b, c in st]
        rgba = (color[0], color[1], color[2], alpha)
        self.cols += [rgba] * len(sv)
        return self

    def build(self, ao=False):
        cols = self.cols
        if ao:
            cols = self._ambient_occlusion()
        return Mesh(vertices=[Vec3(*v) for v in self.verts], triangles=self.tris,
                    normals=[Vec3(*n) for n in self.norms], colors=cols,
                    uvs=[Vec2(*u) for u in self.uvs])

    def _ambient_occlusion(self):
        """Vorberechnete Verschattung: bodennahe Stellen und Unterseiten dunkler, Oberseiten etwas
        heller – wirkt viel plastischer und "geerdeter" als einfarbige Flächen."""
        out = []
        for (x, y, z), (nx, ny, nz), (r, g, b, a) in zip(self.verts, self.norms, self.cols):
            t = max(0.0, min(1.0, y / 0.55))
            k = 0.58 + 0.42 * (t * t * (3 - 2 * t))
            if ny < -0.5:
                k *= 0.7
            elif ny > 0.5:
                k *= 1.06
            # Kanten nach außen etwas heller (Kantenlicht), Innenecken dunkler
            edge = max(abs(x), abs(z))
            if edge > 0.42 and ny <= 0.5:
                k *= 1.04
            out.append((min(1.0, r * k), min(1.0, g * k), min(1.0, b * k), a))
        return out


def mesh_from_parts(parts, uv_density=1.6, ao=False):
    mb = MeshBuilder(uv_density)
    for part in parts:
        mb.add(*part)
    return mb.build(ao=ao)


def shade(color, f):
    return tuple(max(0.0, min(1.0, c * f)) for c in color)


# ---------------------------------------------------------------- Gebäudeteile
# Teile: (form, position, skalierung, farbe, rotation)
def _foundation(h=0.12):
    parts = [("box", (0, h / 2, 0), (0.96, h, 0.96), FOUNDATION),
             ("box", (0, h + 0.006, 0), (0.88, 0.012, 0.88), (0.36, 0.38, 0.42))]
    # Warnstreifen an der Vorderkante (Ausgangsseite)
    for i in range(6):
        parts.append(("box", (-0.4 + i * 0.16, h + 0.014, 0.455), (0.07, 0.008, 0.03), YELLOW if i % 2 else DARK))
    return parts


def _bolts(y, r=0.4, color=STEEL):
    return [("cyl6", (x, y, z), (0.04, 0.03, 0.04), color) for x in (-r, r) for z in (-r, r)]


def _pipe(start, end, radius, color):
    """Rohr zwischen zwei Punkten (nur achsenparallel)."""
    (x0, y0, z0), (x1, y1, z1) = start, end
    mid = ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2)
    length = math.dist(start, end)
    if abs(y1 - y0) > 1e-6:
        return ("cyl8", mid, (radius, length, radius), color)
    if abs(x1 - x0) > 1e-6:
        return ("cyl8", mid, (radius, length, radius), color, (0, 0, 90))
    return ("cyl8", mid, (radius, length, radius), color, (90, 0, 0))


def _belt_frame(length=1.0):
    return [
        ("box", (0, 0.05, 0), (0.92, 0.1, length), DARK),
        ("box", (-0.44, 0.12, 0), (0.06, 0.08, length), YELLOW),
        ("box", (0.44, 0.12, 0), (0.06, 0.08, length), YELLOW),
        ("box", (-0.44, 0.025, -0.35), (0.09, 0.05, 0.1), DARK),
        ("box", (0.44, 0.025, 0.35), (0.09, 0.05, 0.1), DARK),
        ("cyl8", (0, 0.07, -0.46), (0.07, 0.86, 0.07), STEEL, (0, 0, 90)),
        ("cyl8", (0, 0.07, 0.46), (0.07, 0.86, 0.07), STEEL, (0, 0, 90)),
    ]


def _router_parts(color, outputs):
    """Gemeinsame Basis für Splitter, T-Stück und Sortierer."""
    parts = [("box", (0, 0.05, 0), (0.94, 0.1, 0.94), DARK),
             ("box", (0, 0.105, 0), (0.86, 0.012, 0.86), BELT)]
    # Eingang hinten
    parts += [("box", (-0.44, 0.12, -0.3), (0.06, 0.08, 0.36), YELLOW),
              ("box", (0.44, 0.12, -0.3), (0.06, 0.08, 0.36), YELLOW)]
    # Gehäuse in der Mitte
    parts += [("cyl", (0, 0.2, 0), (0.42, 0.2, 0.42), color),
              ("cyl", (0, 0.31, 0), (0.46, 0.03, 0.46), DARK),
              ("cyl", (0, 0.36, 0), (0.16, 0.08, 0.16), STEEL)]
    # Ausgangsmarkierungen
    marks = {"F": (0, 0.42), "L": (-0.42, 0), "R": (0.42, 0)}
    for side in outputs:
        x, z = marks[side]
        parts.append(("box", (x, 0.112, z), (0.14 if side == "F" else 0.1, 0.01, 0.1 if side == "F" else 0.14), GREEN))
    return parts


STATIC_PARTS = {
    "miner": _foundation() + [
        ("box", (0, 0.38, -0.06), (0.76, 0.5, 0.68), YELLOW),
        ("box", (0, 0.65, -0.06), (0.8, 0.06, 0.72), DARK),
        ("box", (0, 0.2, -0.06), (0.8, 0.06, 0.72), DARK),
        ("box", (-0.39, 0.38, -0.06), (0.02, 0.5, 0.14), DARK),
        ("box", (0.39, 0.38, -0.06), (0.02, 0.5, 0.14), DARK),
        ("box", (0.12, 0.42, 0.285), (0.32, 0.18, 0.02), GLASS),        # Kontrollfenster
        # Bohrturm
        ("box", (-0.22, 0.98, -0.2), (0.07, 0.66, 0.07), STEEL),
        ("box", (0.22, 0.98, -0.2), (0.07, 0.66, 0.07), STEEL),
        ("box", (0, 1.33, -0.2), (0.58, 0.08, 0.16), YELLOW),
        ("box", (0, 0.86, -0.2), (0.44, 0.04, 0.05), STEEL, (0, 0, 35)),
        ("box", (0, 0.86, -0.2), (0.44, 0.04, 0.05), STEEL, (0, 0, -35)),
        ("box", (0, 0.3, 0.39), (0.36, 0.16, 0.22), DARK),               # Ausgabeschacht vorne
        ("box", (0, 0.39, 0.31), (0.42, 0.04, 0.08), YELLOW),
        ("cyl", (0.28, 0.76, 0.12), (0.14, 0.2, 0.14), DARK),             # Motor
        ("cyl", (0.28, 0.88, 0.12), (0.1, 0.04, 0.1), STEEL),
        _pipe((-0.3, 0.68, 0.12), (-0.3, 1.05, 0.12), 0.05, STEEL),       # Auspuff
        ("cyl8", (-0.3, 1.07, 0.12), (0.07, 0.04, 0.07), DARK),
    ] + _bolts(0.15),
    "smelter": _foundation() + [
        ("box", (0, 0.44, -0.02), (0.82, 0.64, 0.8), BRICK),
        ("box", (0, 0.78, -0.02), (0.86, 0.07, 0.84), DARK),
        ("box", (0, 0.16, -0.02), (0.86, 0.06, 0.84), DARK),
        ("box", (0, 0.31, 0.385), (0.46, 0.34, 0.04), DARK),             # Ofenöffnung (Rahmen)
        ("cyl", (0.22, 1.1, -0.22), (0.2, 0.66, 0.2), STEEL),             # Schornstein
        ("cyl", (0.22, 1.12, -0.22), (0.21, 0.05, 0.21), RED),
        ("cyl", (0.22, 1.44, -0.22), (0.26, 0.05, 0.26), DARK),
        ("frustum", (-0.2, 0.92, -0.25), (0.3, 0.2, 0.3), DARK),          # Einfülltrichter
        ("box", (-0.43, 0.44, -0.02), (0.02, 0.64, 0.06), DARK),
        ("box", (0.43, 0.44, -0.02), (0.02, 0.64, 0.06), DARK),
        _pipe((0.43, 0.6, 0.2), (0.43, 0.6, -0.3), 0.05, STEEL),
        ("box", (-0.3, 0.6, 0.39), (0.1, 0.1, 0.02), GREEN),              # Kontrollleuchte
    ] + [("box", (x, 0.44, 0.405), (0.02, 0.6, 0.01), shade(BRICK, 0.8)) for x in (-0.3, -0.15, 0.15, 0.3)],
    "conveyor": _belt_frame(),
    "seller": _foundation() + [
        ("box", (0, 0.42, -0.12), (0.82, 0.58, 0.58), TEAL),
        ("box", (0, 0.74, -0.12), (0.92, 0.08, 0.68), WHITE),
        ("box", (0, 0.6, 0.25), (0.82, 0.03, 0.22), RED, (14, 0, 0)),      # Markise
        ("box", (0, 0.24, 0.3), (0.58, 0.24, 0.24), DARK),                # Annahmetheke
        ("box", (0, 0.37, 0.3), (0.62, 0.03, 0.28), STEEL),
        ("box", (0, 0.92, -0.12), (0.04, 0.3, 0.04), STEEL),               # Mast
        ("box", (-0.22, 0.44, 0.175), (0.2, 0.2, 0.02), GLASS),            # Fenster
        ("box", (0.22, 0.44, 0.175), (0.2, 0.2, 0.02), GLASS),
        ("box", (0, 0.66, 0.175), (0.5, 0.08, 0.02), GOLD),                # Schild
    ],
    "storage": _foundation() + [
        ("box", (0, 0.44, -0.04), (0.88, 0.62, 0.82), BLUEGRAY),
        ("wedge", (0, 0.86, -0.245), (0.94, 0.22, 0.44), (0.26, 0.32, 0.42), (0, 180, 0)),
        ("wedge", (0, 0.86, 0.165), (0.94, 0.22, 0.44), (0.26, 0.32, 0.42)),
        ("box", (0, 0.33, 0.375), (0.44, 0.44, 0.02), DARK),              # Tor
    ] + [("box", (0, 0.15 + i * 0.07, 0.385), (0.42, 0.012, 0.01), shade(DARK, 1.6)) for i in range(6)] + [
        ("box", (0, 0.57, 0.385), (0.48, 0.04, 0.02), YELLOW),
        ("box", (-0.44, 0.44, -0.04), (0.02, 0.62, 0.84), (0.3, 0.38, 0.52)),
        ("box", (0.44, 0.44, -0.04), (0.02, 0.62, 0.84), (0.3, 0.38, 0.52)),
        ("box", (0.33, 0.62, 0.38), (0.1, 0.08, 0.02), WHITE),            # Lampe über dem Tor
    ],
    "assembler": _foundation() + [
        ("box", (0, 0.2, 0), (0.88, 0.1, 0.88), DARK),
        ("box", (0, 0.48, -0.17), (0.74, 0.46, 0.46), PURPLE),
        ("box", (0, 0.73, -0.17), (0.78, 0.05, 0.5), DARK),
        ("box", (0, 0.32, 0.38), (0.34, 0.12, 0.16), DARK),               # Ausgabe
        ("cyl", (0.22, 0.3, 0.17), (0.16, 0.12, 0.16), STEEL),            # Armsockel
        ("box", (-0.22, 0.48, 0.065), (0.18, 0.18, 0.02), CYAN),          # Anzeige
        ("box", (-0.22, 0.48, 0.07), (0.14, 0.02, 0.01), DARK),
        _pipe((-0.36, 0.3, -0.38), (-0.36, 0.72, -0.38), 0.05, STEEL),
        _pipe((0.36, 0.3, -0.38), (0.36, 0.72, -0.38), 0.05, STEEL),
        ("box", (-0.2, 0.25, 0.3), (0.3, 0.04, 0.3), shade(DARK, 1.4)),   # Arbeitsplatte
    ],
    "factory": _foundation() + [
        ("box", (0, 0.2, 0), (0.92, 0.1, 0.92), DARK),
        ("box", (0, 0.46, -0.06), (0.86, 0.44, 0.7), (0.86, 0.78, 0.55)),            # Halle
        ("box", (0, 0.46, -0.06), (0.88, 0.05, 0.72), YELLOW),                      # Zierband
        ("wedge", (-0.22, 0.76, -0.06), (0.42, 0.18, 0.7), BLUEGRAY, (0, 90, 0)),     # Sheddach
        ("wedge", (0.22, 0.76, -0.06), (0.42, 0.18, 0.7), BLUEGRAY, (0, 90, 0)),
        ("box", (-0.03, 0.78, -0.06), (0.02, 0.16, 0.66), GLASS),                    # Oberlicht
        ("box", (0.41, 0.78, -0.06), (0.02, 0.16, 0.66), GLASS),
        ("box", (0, 0.34, 0.3), (0.42, 0.3, 0.02), DARK),                            # Tor
        ("box", (0, 0.51, 0.31), (0.46, 0.04, 0.02), YELLOW),
        ("box", (-0.3, 0.46, 0.295), (0.16, 0.12, 0.01), GLASS),                     # Fenster
        ("box", (0.3, 0.46, 0.295), (0.16, 0.12, 0.01), GLASS),
        ("cyl8", (0.32, 0.95, -0.3), (0.12, 0.5, 0.12), BRICK),                      # Schornstein
        ("cyl8", (0.32, 1.2, -0.3), (0.14, 0.04, 0.14), DARK),
        ("box", (0, 0.24, 0.4), (0.3, 0.06, 0.12), DARK),                            # Ausgabe
    ],
    # ---- ab 2.6: Spezialfabriken
    "kiln": _foundation() + [                                                       # Baustoffwerk
        ("box", (0, 0.2, 0), (0.9, 0.1, 0.9), DARK),
        ("box", (-0.08, 0.38, 0.0), (0.66, 0.3, 0.8), (0.74, 0.46, 0.30)),            # Brennkammer
        ("cyl", (-0.08, 0.53, 0.0), (0.62, 0.8, 0.3), (0.66, 0.38, 0.25), (90, 0, 0)),  # Tonnengewölbe
        ("box", (-0.08, 0.31, 0.405), (0.34, 0.2, 0.02), DARK),                        # Ofentür
        ("cyl8", (-0.3, 0.95, -0.3), (0.1, 0.62, 0.1), BRICK),                         # Kamin
        ("cyl8", (-0.3, 1.27, -0.3), (0.12, 0.04, 0.12), DARK),
        ("cyl", (0.33, 0.72, -0.22), (0.22, 0.62, 0.22), LIGHT_STEEL),                 # Sandsilo
        ("cone", (0.33, 1.1, -0.22), (0.22, 0.14, 0.22), STEEL),
        ("frustum", (0.33, 0.33, -0.22), (0.2, 0.16, 0.2), STEEL, (180, 0, 0)),
        ("box", (0.33, 0.62, -0.1), (0.02, 0.5, 0.02), DARK),
        ("box", (0.3, 0.27, 0.3), (0.22, 0.1, 0.24), shade(TEAL, 0.8)),               # Mischer
    ],
    "blast_furnace": _foundation() + [                                              # Hochofen
        ("box", (0, 0.2, 0), (0.9, 0.1, 0.9), DARK),
        ("cyl", (0, 0.62, -0.05), (0.5, 0.86, 0.5), (0.30, 0.31, 0.34)),              # Schacht
        ("cyl", (0, 0.35, -0.05), (0.56, 0.08, 0.56), ORANGE),
        ("cyl", (0, 0.75, -0.05), (0.53, 0.05, 0.53), ORANGE),
        ("frustum", (0, 1.12, -0.05), (0.42, 0.18, 0.42), DARK),
        ("cyl8", (0, 1.3, -0.05), (0.12, 0.24, 0.12), STEEL),                         # Gichtgasleitung
        ("box", (0, 0.3, 0.33), (0.3, 0.2, 0.18), DARK),                              # Abstich
        ("box", (0.32, 0.72, -0.1), (0.06, 1.0, 0.06), STEEL, (0, 0, -22)),           # Schrägaufzug
        ("box", (0.36, 0.72, -0.24), (0.06, 1.0, 0.06), STEEL, (0, 0, -22)),
        _pipe((-0.32, 0.3, 0.25), (-0.32, 1.0, 0.25), 0.06, STEEL),
        ("box", (-0.32, 1.0, 0.0), (0.06, 0.06, 0.5), STEEL),
    ],
    "chemical": _foundation() + [                                                   # Chemiewerk
        ("box", (0, 0.2, 0), (0.9, 0.1, 0.9), DARK),
        ("cyl", (-0.22, 0.56, -0.2), (0.34, 0.62, 0.34), WHITE),                      # Tank 1
        ("cyl", (-0.22, 0.88, -0.2), (0.35, 0.04, 0.35), TEAL),
        ("cyl", (0.24, 0.48, -0.22), (0.28, 0.46, 0.28), (0.85, 0.88, 0.9)),          # Tank 2
        ("cyl", (0.24, 0.72, -0.22), (0.29, 0.04, 0.29), ORANGE),
        ("box", (0, 0.36, 0.22), (0.62, 0.26, 0.34), TEAL),                           # Reaktorhalle
        ("box", (0, 0.5, 0.22), (0.66, 0.03, 0.38), DARK),
        ("box", (-0.15, 0.38, 0.395), (0.18, 0.12, 0.01), GLASS),
        _pipe((-0.04, 0.7, -0.2), (0.12, 0.7, -0.2), 0.04, STEEL),
        _pipe((-0.22, 0.88, 0.04), (-0.22, 0.88, -0.05), 0.04, STEEL),
        _pipe((0.38, 0.25, 0.1), (0.38, 0.66, 0.1), 0.04, STEEL),
        ("box", (0, 0.24, 0.42), (0.24, 0.06, 0.1), DARK),
    ],
    "electronics": _foundation() + [                                                # Elektronikwerk
        ("box", (0, 0.2, 0), (0.9, 0.1, 0.9), DARK),
        ("box", (0, 0.46, -0.04), (0.84, 0.44, 0.74), (0.88, 0.9, 0.93)),             # Reinraumhalle
        ("box", (0, 0.69, -0.04), (0.88, 0.04, 0.78), (0.3, 0.34, 0.4)),
        ("box", (0, 0.47, 0.335), (0.74, 0.16, 0.01), (0.2, 0.45, 0.85)),             # Fensterband
        ("box", (0.42, 0.47, -0.04), (0.01, 0.16, 0.6), (0.2, 0.45, 0.85)),
        ("box", (-0.42, 0.47, -0.04), (0.01, 0.16, 0.6), (0.2, 0.45, 0.85)),
        ("box", (0, 0.3, 0.34), (0.2, 0.14, 0.02), DARK),                             # Tor
        ("box", (0.24, 0.78, -0.2), (0.24, 0.14, 0.24), STEEL),                       # Klimagerät
        ("cyl8", (-0.3, 0.92, -0.25), (0.02, 0.42, 0.02), STEEL),                     # Antenne
        ("box", (-0.3, 1.12, -0.25), (0.06, 0.03, 0.06), RED),
        ("box", (0, 0.24, 0.42), (0.24, 0.06, 0.1), DARK),
    ],
    "freight": [                                                                     # Frachtbahnhof
        ("box", (0, 0.04, 0), (0.98, 0.08, 0.98), (0.42, 0.43, 0.45)),               # Betonplatte
        ("box", (0, 0.081, 0.12), (0.5, 0.004, 0.66), (0.33, 0.34, 0.36)),            # Stellplatz
        ("box", (-0.26, 0.084, 0.14), (0.025, 0.004, 0.62), (0.95, 0.95, 0.92)),      # Markierung
        ("box", (0.26, 0.084, 0.14), (0.025, 0.004, 0.62), (0.95, 0.95, 0.92)),
        ("box", (0, 0.2, -0.33), (0.96, 0.24, 0.3), (0.5, 0.51, 0.53)),               # Laderampe
        ("box", (0, 0.5, -0.38), (0.94, 0.42, 0.22), (0.86, 0.87, 0.88)),             # Halle
        ("box", (0, 0.73, -0.38), (0.98, 0.05, 0.26), DARK),                          # Dach
        ("box", (0, 0.42, -0.266), (0.36, 0.3, 0.012), (0.55, 0.58, 0.62)),           # Rolltor
    ] + [("box", (0, 0.3 + i * 0.05, -0.259), (0.34, 0.008, 0.004), (0.42, 0.45, 0.5)) for i in range(5)] + [
        ("box", (-0.27, 0.32, -0.16), (0.08, 0.06, 0.06), DARK),                      # Rammpuffer
        ("box", (0.27, 0.32, -0.16), (0.08, 0.06, 0.06), DARK),
        ("box", (0, 0.62, -0.266), (0.4, 0.05, 0.016), YELLOW),                       # Schild über dem Tor
        ("box", (0, 0.9, -0.15), (0.98, 0.03, 0.42), (0.36, 0.38, 0.42), (-6, 0, 0)), # Vordach
        ("cyl8", (-0.44, 0.48, 0.02), (0.04, 0.84, 0.04), STEEL),
        ("cyl8", (0.44, 0.48, 0.02), (0.04, 0.84, 0.04), STEEL),
        ("box", (0.4, 0.11, 0.42), (0.1, 0.06, 0.1), (0.95, 0.5, 0.1)),               # Leitkegel-Sockel
        ("cone6", (0.4, 0.2, 0.42), (0.08, 0.14, 0.08), (0.98, 0.45, 0.1)),
        ("box", (-0.42, 0.15, 0.44), (0.08, 0.14, 0.08), WOOD),                       # Palette
        ("box", (-0.42, 0.25, 0.44), (0.08, 0.06, 0.08), (0.75, 0.62, 0.42)),
    ],
    "splitter": _router_parts((0.2, 0.62, 0.38), ["F", "L", "R"]),
    "tpiece": _router_parts((0.30, 0.50, 0.85), ["L", "R"]),
    "sorter": _router_parts((0.75, 0.35, 0.80), ["F", "L", "R"]) + [
        ("box", (0, 0.5, -0.05), (0.26, 0.2, 0.04), DARK),
        ("box", (0, 0.5, -0.025), (0.2, 0.14, 0.01), CYAN),
    ],
}

# Höhe (für Statuslampe und Warnsymbol)
HEIGHTS = {"miner": 1.4, "smelter": 1.48, "conveyor": 0.2, "seller": 1.1, "storage": 1.0, "assembler": 0.85, "factory": 1.25,
           "splitter": 0.45, "tpiece": 0.45, "sorter": 0.6, "kiln": 1.3, "blast_furnace": 1.45, "chemical": 0.95,
           "electronics": 1.15, "freight": 1.0}


def truck_parts(body=(0.92, 0.18, 0.16), flatbed=True):
    """LKW (Fahrerhaus vorne bei +z), ca. 0.62 lang. flatbed=True: Pritsche für sichtbare Ladung."""
    tire = (0.08, 0.08, 0.09)
    parts = [
        ("box", (0, 0.12, 0.0), (0.26, 0.05, 0.62), DARK),                          # Rahmen
        ("box", (0, 0.27, 0.22), (0.27, 0.22, 0.17), body),                         # Fahrerhaus
        ("box", (0, 0.31, 0.307), (0.23, 0.09, 0.005), (0.25, 0.35, 0.45)),         # Frontscheibe
        ("box", (0.136, 0.31, 0.23), (0.005, 0.08, 0.1), (0.25, 0.35, 0.45)),       # Seitenscheiben
        ("box", (-0.136, 0.31, 0.23), (0.005, 0.08, 0.1), (0.25, 0.35, 0.45)),
        ("box", (0, 0.39, 0.2), (0.26, 0.03, 0.15), shade(body, 0.85)),              # Dach
        ("box", (0, 0.18, 0.31), (0.25, 0.05, 0.02), STEEL),                         # Stoßstange
        ("box", (0.09, 0.2, 0.312), (0.04, 0.025, 0.005), (1.0, 0.95, 0.75)),        # Scheinwerfer
        ("box", (-0.09, 0.2, 0.312), (0.04, 0.025, 0.005), (1.0, 0.95, 0.75)),
    ]
    if flatbed:
        parts += [("box", (0, 0.165, -0.1), (0.27, 0.03, 0.4), (0.4, 0.3, 0.2)),       # Pritsche (Holz)
                  ("box", (0.13, 0.21, -0.1), (0.012, 0.06, 0.4), body),
                  ("box", (-0.13, 0.21, -0.1), (0.012, 0.06, 0.4), body),
                  ("box", (0, 0.21, -0.295), (0.27, 0.06, 0.012), body),
                  ("box", (0, 0.26, 0.12), (0.27, 0.16, 0.02), shade(body, 0.7))]     # Stirnwand
    else:
        parts += [("box", (0, 0.29, -0.1), (0.27, 0.27, 0.42), body),                 # Koffer
                  ("box", (0, 0.29, -0.311), (0.25, 0.25, 0.004), shade(body, 0.8))]
    for z in (0.2, -0.05, -0.2):
        for x in (0.12, -0.12):
            parts.append(("cyl", (x, 0.08, z), tire, (0.09, 0.09, 0.1), (0, 0, 90)))
    return parts


def static_mesh(btype):
    return mesh_from_parts(STATIC_PARTS[btype], ao=True)


def item_mesh(item, color):
    """Kleines Modell für transportierte Gegenstände."""
    if item.endswith("_ore"):
        parts = [("ico", (0, 0, 0), (0.22, 0.17, 0.2), color, (10, 25, 5)),
                 ("ico", (0.05, 0.04, 0.03), (0.13, 0.11, 0.11), shade(color, 0.8), (0, 40, 20))]
    elif item.endswith("_bar"):
        parts = [("box", (0, 0, 0), (0.26, 0.09, 0.14), color),
                 ("box", (0, 0.06, 0), (0.22, 0.04, 0.1), shade(color, 1.15))]
    elif item == "steel":
        parts = [("box", (0, 0, 0), (0.3, 0.06, 0.06), color), ("box", (0, 0.06, 0), (0.3, 0.06, 0.06), color),
                 ("box", (0, 0.03, 0), (0.3, 0.02, 0.16), shade(color, 1.2))]
    elif item == "gear":
        parts = [("cyl", (0, 0, 0), (0.24, 0.06, 0.24), color)] + [
            ("box", (0, 0, 0), (0.3, 0.05, 0.06), color, (0, a, 0)) for a in (0, 45, 90, 135)] + [
            ("cyl8", (0, 0.001, 0), (0.08, 0.065, 0.08), DARK)]
    elif item == "wire":
        parts = [("cyl", (0, 0, 0), (0.2, 0.12, 0.2), color), ("cyl", (0, 0, 0), (0.08, 0.14, 0.08), DARK)]
    elif item == "motor":
        parts = [("cyl", (0, 0.02, 0), (0.18, 0.24, 0.18), color, (0, 0, 90)),
                 ("box", (0, -0.06, 0), (0.22, 0.04, 0.16), DARK),
                 ("cyl8", (0.15, 0.02, 0), (0.04, 0.1, 0.04), STEEL, (0, 0, 90))]
    elif item == "coal":
        parts = [("ico", (0, 0, 0), (0.2, 0.15, 0.18), color, (20, 10, 0)),
                 ("ico", (0.07, 0.03, -0.04), (0.12, 0.1, 0.1), shade(color, 1.4), (0, 30, 10))]
    elif item == "stone":
        parts = [("ico", (0, 0, 0), (0.24, 0.16, 0.2), color, (5, 40, 0)),
                 ("ico", (-0.06, 0.05, 0.04), (0.12, 0.1, 0.1), shade(color, 0.85))]
    elif item == "sand":
        parts = [("cone", (0, -0.02, 0), (0.28, 0.14, 0.28), color),
                 ("cone", (0.06, -0.03, 0.05), (0.16, 0.09, 0.16), shade(color, 0.92))]
    elif item == "brick":
        parts = [("box", (0, 0, 0), (0.26, 0.08, 0.13), color), ("box", (0, 0.085, 0), (0.26, 0.08, 0.13), shade(color, 1.1))]
    elif item == "glass":
        parts = [("box", (0, 0, 0), (0.28, 0.03, 0.2), color), ("box", (0, 0.035, 0), (0.24, 0.03, 0.17), shade(color, 1.1))]
    elif item == "concrete":
        parts = [("box", (0, 0, 0), (0.24, 0.16, 0.18), color), ("box", (0, 0.085, 0), (0.2, 0.02, 0.14), shade(color, 0.85))]
    elif item == "steel_beam":
        parts = [("box", (0, 0.06, 0), (0.34, 0.025, 0.1), color), ("box", (0, -0.06, 0), (0.34, 0.025, 0.1), color),
                 ("box", (0, 0, 0), (0.34, 0.12, 0.03), shade(color, 1.15))]
    elif item == "battery":
        parts = [("cyl", (0, 0, 0), (0.14, 0.22, 0.14), color), ("cyl", (0, 0.12, 0), (0.06, 0.04, 0.06), STEEL),
                 ("cyl", (0, 0.06, 0), (0.145, 0.03, 0.145), DARK)]
    elif item == "computer":
        parts = [("box", (0, 0.04, 0), (0.26, 0.17, 0.03), color), ("box", (0, 0.04, 0.017), (0.22, 0.13, 0.005), CYAN),
                 ("box", (0, -0.06, 0.03), (0.06, 0.06, 0.03), DARK), ("box", (0, -0.09, 0.04), (0.16, 0.02, 0.1), DARK)]
    elif item == "solar_panel":
        parts = [("box", (0, 0, 0), (0.3, 0.025, 0.22), color, (15, 0, 0)),
                 ("box", (0, 0.015, 0), (0.31, 0.01, 0.01), STEEL, (15, 0, 0)),
                 ("box", (0, 0.015, 0), (0.01, 0.01, 0.22), STEEL, (15, 0, 0))]
    elif item == "house":
        parts = [("box", (0, -0.02, 0), (0.24, 0.16, 0.2), color),
                 ("wedge", (0, 0.1, 0), (0.28, 0.1, 0.24), BRICK),
                 ("box", (0, -0.05, 0.101), (0.06, 0.1, 0.005), WOOD)]
    elif item == "robot":
        parts = [("box", (0, -0.02, 0), (0.16, 0.14, 0.12), color), ("box", (0, 0.1, 0), (0.12, 0.09, 0.1), STEEL),
                 ("box", (0, 0.1, 0.051), (0.08, 0.025, 0.005), CYAN),
                 ("box", (0.11, -0.01, 0), (0.04, 0.12, 0.04), DARK), ("box", (-0.11, -0.01, 0), (0.04, 0.12, 0.04), DARK)]
    elif item == "ecar":
        parts = [("box", (0, -0.02, 0), (0.34, 0.08, 0.17), color), ("box", (-0.02, 0.05, 0), (0.18, 0.07, 0.15), GLASS),
                 ("cyl", (0.1, -0.06, 0.09), (0.08, 0.03, 0.08), DARK, (90, 0, 0)),
                 ("cyl", (-0.1, -0.06, 0.09), (0.08, 0.03, 0.08), DARK, (90, 0, 0)),
                 ("cyl", (0.1, -0.06, -0.09), (0.08, 0.03, 0.08), DARK, (90, 0, 0)),
                 ("cyl", (-0.1, -0.06, -0.09), (0.08, 0.03, 0.08), DARK, (90, 0, 0))]
    elif item == "plastic":
        parts = [("box", (0, 0, 0), (0.24, 0.05, 0.18), color), ("box", (0.02, 0.05, -0.01), (0.2, 0.05, 0.15), shade(color, 0.92)),
                 ("box", (0, 0.035, 0.091), (0.24, 0.02, 0.005), (0.3, 0.6, 0.9))]
    elif item == "processor":
        parts = [("box", (0, 0, 0), (0.18, 0.03, 0.18), (0.18, 0.5, 0.25)), ("box", (0, 0.03, 0), (0.12, 0.03, 0.12), STEEL),
                 ("box", (0, 0.05, 0), (0.08, 0.01, 0.08), shade(STEEL, 1.2))]
    else:  # circuit
        parts = [("box", (0, 0, 0), (0.24, 0.04, 0.2), color), ("box", (0, 0.03, 0), (0.1, 0.03, 0.08), DARK),
                 ("box", (0.07, 0.025, 0.05), (0.04, 0.02, 0.03), GOLD)]
    return mesh_from_parts(parts, uv_density=3.0)


# ---------------------------------------------------------------- Natur
def tree_parts(kind, x, z, s, rng):
    """Liefert (stamm_teile, kronen_teile) eines Baumes."""
    trunk, crown = [], []
    if kind == "pine":
        h = 1.0 * s
        trunk.append(("cyl6", (x, h * 0.25, z), (0.18 * s, h * 0.5, 0.18 * s), (0.40, 0.27, 0.17)))
        base_green = (0.12 + rng.uniform(-0.02, 0.03), 0.34 + rng.uniform(-0.05, 0.06), 0.20)
        for i, (y, w, hh) in enumerate(((0.55, 1.15, 0.9), (1.0, 0.9, 0.8), (1.4, 0.62, 0.7), (1.75, 0.36, 0.55))):
            crown.append(("cone6", (x, y * s, z), (w * s, hh * s, w * s), shade(base_green, 1 + i * 0.08),
                          (0, rng.uniform(0, 60), 0)))
    elif kind == "birch":
        h = 1.6 * s
        trunk.append(("cyl6", (x, h * 0.5, z), (0.1 * s, h, 0.1 * s), (0.88, 0.88, 0.84)))
        green = (0.42 + rng.uniform(-0.05, 0.05), 0.62 + rng.uniform(-0.05, 0.05), 0.26)
        for dx, dy, dz, r in ((0, 1.55, 0, 0.75), (0.2, 1.3, 0.1, 0.55), (-0.18, 1.35, -0.12, 0.5)):
            crown.append(("ico", (x + dx * s, dy * s, z + dz * s), (r * s, r * 1.15 * s, r * s), shade(green, rng.uniform(0.9, 1.1)),
                          (rng.uniform(0, 40), rng.uniform(0, 90), 0)))
    else:  # oak / Laubbaum
        h = 0.9 * s
        trunk.append(("cyl6", (x, h * 0.5, z), (0.22 * s, h, 0.22 * s), (0.42, 0.29, 0.18)))
        green = (0.20 + rng.uniform(-0.03, 0.05), 0.46 + rng.uniform(-0.06, 0.06), 0.20)
        for dx, dy, dz, r in ((0, 1.35, 0, 1.15), (0.35, 1.15, 0.2, 0.75), (-0.35, 1.2, -0.15, 0.8), (0.05, 1.7, -0.1, 0.7)):
            crown.append(("ico", (x + dx * s, dy * s, z + dz * s), (r * s, r * 0.9 * s, r * s), shade(green, rng.uniform(0.88, 1.12)),
                          (rng.uniform(0, 40), rng.uniform(0, 90), 0)))
    return trunk, crown


def bush_parts(x, z, s, rng):
    green = (0.22 + rng.uniform(-0.04, 0.04), 0.48 + rng.uniform(-0.06, 0.06), 0.20)
    parts = []
    for _ in range(3):
        parts.append(("ico", (x + rng.uniform(-0.2, 0.2) * s, 0.2 * s, z + rng.uniform(-0.2, 0.2) * s),
                      (0.5 * s, 0.38 * s, 0.5 * s), shade(green, rng.uniform(0.85, 1.15)),
                      (0, rng.uniform(0, 90), 0)))
    if rng.random() < 0.4:                                          # Beeren
        for _ in range(4):
            parts.append(("ico", (x + rng.uniform(-0.25, 0.25) * s, rng.uniform(0.25, 0.4) * s,
                                  z + rng.uniform(-0.25, 0.25) * s), (0.06, 0.06, 0.06), RED))
    return parts


FLOWER_COLORS = [(0.95, 0.85, 0.25), (0.95, 0.4, 0.6), (0.6, 0.45, 0.95), (0.98, 0.98, 0.98), (0.95, 0.35, 0.2)]


def flower_parts(x, z, rng):
    col = FLOWER_COLORS[rng.randrange(len(FLOWER_COLORS))]
    parts = []
    for _ in range(rng.randint(3, 6)):
        fx, fz = x + rng.uniform(-0.3, 0.3), z + rng.uniform(-0.3, 0.3)
        h = rng.uniform(0.12, 0.22)
        parts.append(("box", (fx, h / 2, fz), (0.015, h, 0.015), (0.25, 0.55, 0.2)))
        parts.append(("ico", (fx, h, fz), (0.07, 0.04, 0.07), col))
    return parts


def grass_tuft_parts(x, z, rng):
    green = (0.30 + rng.uniform(-0.05, 0.05), 0.58 + rng.uniform(-0.08, 0.06), 0.22)
    parts = []
    for _ in range(5):
        h = rng.uniform(0.15, 0.3)
        parts.append(("cone6", (x + rng.uniform(-0.12, 0.12), h / 2, z + rng.uniform(-0.12, 0.12)),
                      (0.05, h, 0.05), shade(green, rng.uniform(0.85, 1.15)),
                      (rng.uniform(-15, 15), 0, rng.uniform(-15, 15))))
    return parts


def rock_parts(x, z, s, rng, y=0.0):
    g = rng.uniform(0.48, 0.6)
    col = (g, g * 1.0, g * 1.02)
    parts = [("ico", (x, y + 0.18 * s, z), (1.0 * s, 0.55 * s, 0.8 * s), col,
              (rng.uniform(-10, 10), rng.uniform(0, 90), rng.uniform(-10, 10)))]
    if rng.random() < 0.6:
        parts.append(("ico", (x + 0.4 * s, y + 0.08 * s, z + 0.2 * s), (0.45 * s, 0.3 * s, 0.4 * s), shade(col, 0.9),
                      (0, rng.uniform(0, 90), 0)))
    return parts


# ---------------------------------------------------------------- Spielfigur
def avatar_parts(rgb):
    """Rumpf und Kopf eines Bauarbeiters (Arme und Beine werden separat animiert)."""
    skin = (0.96, 0.80, 0.66)
    return [
        ("box", (0, 0.92, 0), (0.42, 0.5, 0.24), rgb),                   # Oberkörper
        ("box", (0, 0.98, 0.125), (0.3, 0.2, 0.01), YELLOW),             # Warnweste
        ("box", (0, 0.68, 0), (0.4, 0.08, 0.22), DARK),                  # Gürtel
        ("box", (0, 1.3, 0), (0.28, 0.28, 0.26), skin),                  # Kopf
        ("box", (-0.07, 1.33, 0.131), (0.04, 0.04, 0.01), DARK),          # Augen
        ("box", (0.07, 1.33, 0.131), (0.04, 0.04, 0.01), DARK),
        ("cyl", (0, 1.47, 0), (0.36, 0.05, 0.36), YELLOW),               # Helmkrempe
        ("cyl", (0, 1.53, 0), (0.29, 0.12, 0.29), YELLOW),
    ]


def limb_mesh(color, length, width=0.13, hand=None):
    """Arm oder Bein, Drehpunkt oben (für Schwing-Animation)."""
    parts = [("box", (0, -length / 2, 0), (width, length, width), color)]
    if hand:
        parts.append(("box", (0, -length - 0.04, 0), (width * 0.9, 0.09, width * 0.9), hand))
    return mesh_from_parts(parts)
