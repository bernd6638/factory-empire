"""
Grafikqualität.

"hoch":    Ursinas lit_with_shadows_shader + Schattenwurf der Sonne
           (benötigt eine Grafikkarte mit OpenGL 3.2+, also praktisch jeder
           Windows-PC und Mac der letzten zehn Jahre).
"niedrig": klassische Panda3D-Beleuchtung ohne Schatten. Läuft auch auf
           sehr alten Grafikchips, Remote-Desktops und Software-Renderern.

Mit "auto" wird bei erkannten Software-Renderern automatisch "niedrig" gewählt.
"""

import sys

from ursina.shaders import unlit_shader

QUALITY = {"high": True}

SOFTWARE_RENDERERS = ("llvmpipe", "softpipe", "swrast", "gdi generic", "microsoft basic render", "software")


def configure(mode, renderer_name=""):
    mode = (mode or "auto").lower()
    if sys.platform == "darwin":
        # macOS hat nur das OpenGL-Core-Profile: ohne Shader (Modus "niedrig") bliebe die Szene schwarz
        mode = "high"
    if mode in ("low", "niedrig"):
        QUALITY["high"] = False
    elif mode in ("high", "hoch"):
        QUALITY["high"] = True
    else:
        name = (renderer_name or "").lower()
        QUALITY["high"] = not any(s in name for s in SOFTWARE_RENDERERS)
    if QUALITY["high"]:
        # weiche Schattenkanten mit 2x2 statt 4x4 Abtastungen: kaum sichtbar, aber viel schneller
        try:
            from ursina.shaders import lit_with_shadows_shader
            lit_with_shadows_shader.default_input["shadow_samples"] = 2
            lit_with_shadows_shader.default_input["shadow_blur"] = 0.004
        except Exception:
            pass
    if not QUALITY["high"]:
        # Container-Entities dürfen keinen eigenen Shader setzen, sonst würden
        # Kind-Objekte unbeleuchtet dargestellt. Ohne Shader greift die
        # klassische Panda3D-Beleuchtung.
        from ursina import Entity
        Entity.default_shader = None
    return QUALITY["high"]


def shadow_resolution(quality="medium"):
    """Größe der Schattenkarte je Qualitätsstufe. Macs (OpenGL läuft dort über eine
    Übersetzungsschicht) bekommen eine Stufe kleiner."""
    import os
    env = os.environ.get("FACTORY_EMPIRE_SHADOW", "")
    if env.isdigit() and int(env) >= 256:
        return int(env)
    res = {"high": 4096, "medium": 2048, "low": 1024}.get(quality, 2048)
    if sys.platform == "darwin":
        res = max(1024, res // 2)
    return res


def high():
    return QUALITY["high"]


_FAST_VERTEX = """#version 150
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelViewMatrix;
uniform mat3 p3d_NormalMatrix;
in vec4 vertex;
in vec3 normal;
in vec4 p3d_Color;
in vec2 p3d_MultiTexCoord0;
uniform vec2 texture_scale;
uniform vec2 texture_offset;
out vec2 texcoords;
out vec4 vertex_color;
out vec3 normal_vector;
out float view_dist;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * vertex;
    view_dist = length((p3d_ModelViewMatrix * vertex).xyz);
    normal_vector = normalize(p3d_NormalMatrix * normal);
    texcoords = (p3d_MultiTexCoord0 * texture_scale) + texture_offset;
    vertex_color = p3d_Color;
}
"""

_FAST_FRAGMENT = """#version 150
uniform struct {
    vec4 position;
    vec3 color;
} p3d_LightSource[1];
uniform sampler2D p3d_Texture0;
uniform vec4 p3d_ColorScale;
uniform vec4 fe_fog;          // rgb = Dunstfarbe, a = Stärke (0 = aus)
uniform vec2 fe_fog_range;    // Beginn, Ende (volle Stärke)
in vec2 texcoords;
in vec4 vertex_color;
in vec3 normal_vector;
in float view_dist;
out vec4 fragment_color;
void main() {
    vec4 color = texture(p3d_Texture0, texcoords) * p3d_ColorScale * vertex_color;
    vec3 L = normalize(p3d_LightSource[0].position.xyz);
    float NdotL = clamp(dot(normalize(normal_vector), L), 0.001, 1.0);
    vec3 light = p3d_LightSource[0].color;
    color.rgb = color.rgb * light + NdotL * light / 3.14159265;
    float f = clamp((view_dist - fe_fog_range.x) / (fe_fog_range.y - fe_fog_range.x), 0.0, 1.0);
    color.rgb = mix(color.rgb, fe_fog.rgb, f * f * fe_fog.a);
    fragment_color = color;
}
"""

_FAST = {}


def fast_lit_shader():
    """Schneller Licht-Shader ohne Schatten: gleiche Optik wie Ursinas Licht-Shader im
    beleuchteten Bereich, aber nur ein Bruchteil der Rechenarbeit pro Bildpunkt."""
    if "shader" not in _FAST:
        from ursina import Vec2
        from ursina.shader import Shader
        _FAST["shader"] = Shader(name="fe_fast_lit", language=Shader.GLSL, vertex=_FAST_VERTEX,
                                 fragment=_FAST_FRAGMENT,
                                 default_input={"texture_scale": Vec2(1, 1), "texture_offset": Vec2(0, 0)})
    return _FAST["shader"]


def set_fast(on):
    """Schatten aus -> schneller Shader für alle danach erzeugten Objekte (beim Start gesetzt)."""
    QUALITY["fast"] = bool(on)


def lit_shader():
    """Shader für beleuchtete 3D-Objekte (None = feste Panda3D-Beleuchtung)."""
    if QUALITY["high"]:
        if QUALITY.get("fast"):
            return fast_lit_shader()
        from ursina.shaders import lit_with_shadows_shader
        return lit_with_shadows_shader
    return None


def unlit():
    return unlit_shader


FOG = {"color": (0.74, 0.81, 0.88), "range": (55.0, 240.0)}


def setup_fog(render):
    """Luftperspektive: entfernte Landschaft verblasst im Dunst (wirkt deutlich echter).
    Schneller Shader: eigener Nebel; ohne Shader ("niedrig"): Panda3D-Nebel."""
    from panda3d.core import Fog, Vec2, Vec4
    r, g, b = FOG["color"]
    start, end = FOG["range"]
    render.setShaderInput("fe_fog", Vec4(r, g, b, 1.0))
    render.setShaderInput("fe_fog_range", Vec2(start, end))
    if not QUALITY["high"]:
        fog = Fog("dunst")
        fog.setColor(r, g, b)
        fog.setLinearRange(start, end * 1.15)
        render.setFog(fog)
