"""
Gemeinsame Spielregeln.

Diese Funktionen werden sowohl vom Server (verbindliche Prüfung) als auch vom
Client (Vorschau beim Platzieren und Anzeige) verwendet. Dadurch zeigt die
Vorschau exakt dieselben Fehlermeldungen und Werte, die der Server später
liefern würde. Das Modul hat keine Abhängigkeit zu Ursina oder zum Netzwerk.
"""

from . import config as C


def in_bounds(x, y):
    return 0 <= x < C.GRID_W and 0 <= y < C.GRID_H


def front_tile(x, y, rot):
    dx, dy = C.DIRS[rot % 4]
    return x + dx, y + dy


def back_tile(x, y, rot):
    dx, dy = C.DIRS[rot % 4]
    return x - dx, y - dy


def side_rot(rot, side):
    """Weltrichtung eines relativen Ausgangs: F = vorne, L = links, R = rechts."""
    return {"F": rot, "L": (rot + 3) % 4, "R": (rot + 1) % 4}[side] % 4


def side_tile(x, y, rot, side):
    return front_tile(x, y, side_rot(rot, side))


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def building_unlocked(btype, unlocked):
    req = C.BUILDINGS[btype]["requires"]
    return req is None or req in unlocked


def recipe_unlocked(recipe_id, unlocked):
    req = C.RECIPES[recipe_id]["requires"]
    return req is None or req in unlocked


def upgrade_cost(btype, level):
    """Kosten für das Upgrade von `level` auf `level + 1` (None = nicht möglich)."""
    spec = C.BUILDINGS[btype]
    if level >= spec["max_level"]:
        return None
    return int(round(spec["cost"] * C.UPGRADE_COST_FACTOR * level))


def demolish_refund(btype, level):
    spec = C.BUILDINGS[btype]
    total = spec["cost"]
    for lvl in range(1, level):
        total += upgrade_cost(btype, lvl) or 0
    return int(total * C.DEMOLISH_REFUND)


def _check_tile(btype, x, y, rot, occupied, deposit_at):
    if btype not in C.BUILDINGS:
        return False, "Unbekannter Gebäudetyp."
    if not (is_int(x) and is_int(y) and is_int(rot)):
        return False, "Ungültige Koordinaten."
    if rot not in (0, 1, 2, 3):
        return False, "Ungültige Ausrichtung."
    if not in_bounds(x, y):
        return False, "Außerhalb der Baufläche."
    if occupied(x, y):
        return False, "Feld ist bereits belegt."
    if btype == "miner" and deposit_at(x, y) is None:
        return False, "Miner nur auf Erzvorkommen platzierbar."
    return True, "OK"


def check_build(btype, x, y, rot, *, occupied, deposit_at, unlocked, money):
    """Prüft, ob ein Gebäude gebaut werden darf.

    occupied(x, y)   -> bool    ist die Kachel belegt?
    deposit_at(x, y) -> str|None  Erzvorkommen auf der Kachel
    Rückgabe: (ok: bool, grund: str)
    """
    if btype not in C.BUILDINGS:
        return False, "Unbekannter Gebäudetyp."
    spec = C.BUILDINGS[btype]
    if not building_unlocked(btype, unlocked):
        req = C.RESEARCH[spec["requires"]]["name"]
        return False, f"{spec['name']} benötigt Forschung: {req}."
    ok, msg = _check_tile(btype, x, y, rot, occupied, deposit_at)
    if not ok:
        return ok, msg
    if money < spec["cost"]:
        return False, f"Nicht genug Geld ({spec['cost']} € benötigt)."
    return True, "OK"


def check_move(btype, from_xy, x, y, rot, *, occupied, deposit_at):
    """Prüft das Verschieben eines Gebäudes. Das eigene Feld zählt als frei."""
    return _check_tile(btype, x, y, rot, lambda a, b: (a, b) != tuple(from_xy) and occupied(a, b), deposit_at)


# ----------------------------------------------------------------------------- Forschungseffekte
def _effect_product(unlocked, key):
    value = 1.0
    for tid in unlocked:
        tech = C.RESEARCH.get(tid)
        if tech and key in tech["effects"]:
            value *= tech["effects"][key]
    return value


def speed_multiplier(unlocked):
    return _effect_product(unlocked, "speed_mult")


def miner_multiplier(unlocked):
    return _effect_product(unlocked, "miner_mult")


def storage_multiplier(unlocked):
    return _effect_product(unlocked, "storage_mult")


def travel_multiplier(unlocked):
    return _effect_product(unlocked, "travel_mult")


def belt_multiplier(unlocked):
    return _effect_product(unlocked, "belt_mult")


def price_multiplier(unlocked):
    return _effect_product(unlocked, "price_mult")


def cost_multiplier(unlocked):
    return _effect_product(unlocked, "cost_mult")


def check_research(tech_id, unlocked, active, money):
    if tech_id not in C.RESEARCH:
        return False, "Unbekannte Technologie."
    tech = C.RESEARCH[tech_id]
    if tech_id in unlocked:
        return False, f"{tech['name']} ist bereits erforscht."
    if active:
        return False, "Es läuft bereits eine Forschung."
    missing = [C.RESEARCH[r]["name"] for r in tech["requires"] if r not in unlocked]
    if missing:
        return False, "Voraussetzung fehlt: " + ", ".join(missing)
    if money < tech["cost"]:
        return False, f"Nicht genug Geld ({tech['cost']} € benötigt)."
    return True, "OK"


# ----------------------------------------------------------------------------- Produktionsraten
def machine_speed(btype, level, speed_mult=1.0, miner_mult=1.0):
    speed = C.LEVEL_SPEED.get(level, 1.0) * speed_mult
    if btype == "miner":
        speed *= miner_mult
    return speed


def recipe_rate(recipe_id, speed):
    """Ausgaben pro Minute eines Rezepts bei gegebener Geschwindigkeit: {item: menge}."""
    r = C.RECIPES[recipe_id]
    runs = 60.0 / r["time"] * speed
    return {item: qty * runs for item, qty in r["outputs"].items()}


def recipe_energy_per_min(recipe_id, speed, cost_mult=1.0):
    r = C.RECIPES[recipe_id]
    return 60.0 / r["time"] * speed * r["cost"] * cost_mult


def theoretical_rates(btype, level, *, recipe=None, ore=None, speed_mult=1.0, miner_mult=1.0):
    """Höchstleistung pro Minute eines Gebäudes auf einer Stufe.

    Rückgabe: Liste von (beschriftung, wert_pro_minute).
    """
    speed = machine_speed(btype, level, speed_mult, miner_mult)
    spec = C.BUILDINGS[btype]
    if btype == "miner":
        name = C.ITEMS[ore]["name"] if ore in C.ITEMS else "Erz"
        return [(name, 60.0 / spec["time"] * speed)]
    if btype == "smelter":
        out = []
        for rid in ("smelt_iron", "smelt_copper"):
            for item, rate in recipe_rate(rid, speed).items():
                label = C.ITEMS[item]["name"]
                out.append((label, rate))
        return out
    if btype in C.MACHINE_RECIPES and recipe in C.RECIPES:
        return [(C.ITEMS[i]["name"], v) for i, v in recipe_rate(recipe, speed).items()]
    if btype == "seller":
        return [("Verkäufe", 60.0 / spec["time"] * speed)]
    return []


# ----------------------------------------------------------------------------- Verkäufer
def threshold_label(pct):
    if pct is None:
        return "Immer"
    return f"ab {pct:+d} %"


def price_ok(current_price, base_price, pct):
    """Darf der Verkäufer zum aktuellen Preis verkaufen?"""
    if pct is None:
        return True
    return current_price >= base_price * (1.0 + pct / 100.0) - 1e-9


def format_money(value):
    """Formatiert Geldbeträge im deutschen Stil: 12.345 €"""
    sign = "-" if value < 0 else ""
    return sign + f"{abs(int(value)):,}".replace(",", ".") + " €"


def format_rate(value):
    if value >= 100:
        return f"{value:.0f}"
    if value >= 10:
        return f"{value:.1f}".replace(".", ",")
    return f"{value:.2f}".replace(".", ",")


def format_duration(seconds):
    """12 s · 4:05 min · 1:02 h"""
    seconds = max(0, int(round(seconds)))
    if seconds < 60:
        return f"{seconds} s"
    if seconds < 3600:
        return f"{seconds // 60}:{seconds % 60:02d} min"
    return f"{seconds // 3600}:{seconds % 3600 // 60:02d} h"
