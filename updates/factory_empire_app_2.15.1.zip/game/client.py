"""
Spielclient: verbindet Netzwerk, Welt, Gebäudedarstellung, Kameras und UI.

Der Client schickt ausschließlich Aktionswünsche an den Server und zeigt den
Zustand an, den der Server zurückmeldet. Eine lokale Vorprüfung (gleiche
Regeln wie der Server) sorgt für sofortiges Feedback beim Platzieren.
"""

import atexit
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time

from panda3d.core import WindowProperties
from ursina import Entity, Text, Vec3, application, camera, color, held_keys, mouse, window
from ursina import time as utime

from . import anim
from . import textures
from . import batching
from . import buildings as buildings_mod
from . import config as C
from . import graphics
from . import effects
from . import rules
from .audio import Audio
from .buildings import BuildingView, Ghost, TileFrame
from .camera import RTSCamera
from .client_state import ClientState
from .networking import ConnectionFailed, NetworkClient
from .ui import (MainMenu, AdminPanel, BuyMenu, ChatInput, DisconnectOverlay, HelpWindow, HUD, InfoPanel,
                 MarketWindow, NewsWindow, OrdersWindow, ResearchWindow, SettingsMenu, StatsWindow)
from .mousecapture import MouseCapture, sync_ursina_window
from .tutorial import Tutorial
from .ui_base import BAD, GOOD, MUTED, TEXT, WARN, Anchors
from .world import PlayerCursor, World

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD_KEYS = {spec["hotkey"]: btype for btype, spec in C.BUILDINGS.items() if spec["hotkey"]}


def keep_in_entity_list(e):
    """Muss das Objekt in Ursinas Objektliste bleiben? WICHTIG: alles mit Collider – Ursina findet
    anklickbare Objekte (Knöpfe, Boden, Fenster) nur über diese Liste. Fehlte das (2.7.0), ließ sich
    im Spiel nichts mehr anklicken."""
    return bool(getattr(e, "collider", None) is not None or getattr(e, "hovered", False)
                or callable(getattr(e, "update", None)) or callable(getattr(e, "input", None))
                or getattr(e, "scripts", None) or getattr(e, "keep_in_entity_list", False)
                or getattr(e, "on_click", None) is not None)


class GameClient(Entity):
    def __init__(self, args, settings):
        super().__init__()
        self.args = args
        self.settings = settings
        self.net = None
        self.state = ClientState()
        self.anchors = Anchors()
        self.anchors.set_scale(settings["gui_scale"])
        self.world = World(shadow_quality=settings["shadows"])
        self.world.set_grid_visible(settings["show_grid"])
        self.world.set_scenery(settings["scenery"])
        self.cam = RTSCamera(target=self.world.center)
        self.cam.auto_orbit = True
        self.capture = MouseCapture()
        self.cam.sensitivity = settings["mouse_sensitivity"]
        self.particles = effects.get()
        self.particles.enabled = settings["particles"]
        self.audio = Audio(enabled=not args.no_sound)
        self.audio.volume = settings["volume"]
        self.audio.music_volume = settings["music_volume"]
        self.audio.ambient_volume = settings["ambient_volume"]
        self.audio.rocket_volume = settings["rocket_volume"]
        self.audio.achievement_volume = settings["achievement_volume"]
        self._busy = 0.0
        self._busy_t = 0.0
        self._key_actions = {}           # Taste -> Aktion (eigene Tastenbelegung)
        self.planet = "earth"            # Erde oder Mond (vom Server)
        self.moon_preview = False        # Test-Welt: Rakete schon vor Ablauf des Countdowns
        self.cinematic = None            # laufende Kinofahrt (Enthüllung, Raketenflug)
        self._moon_open = rules.moon_open(False)
        self.world.set_launch(self._moon_open)
        if self.world.launchpad is not None:
            self.world.launchpad.on_click = self.start_launch

        self.views = {}
        self.batcher = batching.Batcher()  # fasst unbewegliche Gebäudeteile zusammen (große Fabriken)
        buildings_mod.BATCHER["inst"] = self.batcher
        self._visible_views = []          # nur sichtbare Gebäude werden animiert
        self._cull_t = 0.0
        self._cull_dirty = True
        self._anim_phase = 0
        self._far_phase = 0
        self._far_belts = []
        self.avatars = {}               # Mitspieler-Mauszeiger
        self._cursor_point = None
        self._last_pos_msg = None
        self.my_id = None
        self.my_color = 0
        self.is_admin = False
        self.admin_login = False
        self.tool = "select"
        self.ghost_rot = 1
        self.selected = None
        self.hover_tile = None
        self.hover_tool = None
        self.drag = None
        self.move_bid = None
        self.pending = {}
        self.load_confirm_until = 0.0
        self.connect_params = None
        self.local_server = None
        self._connect_job = None
        self._user_disconnect = False
        self._first_static = True
        self._timers = {"pos": 0.0, "ui": 0.0, "ping": 0.0, "map": 0.0}
        self._blink = False
        self._fullscreen = False
        self._windowed = None

        self.ghost = Ghost()
        self.hover_frame = TileFrame(color.rgba(1, 1, 1, 0.7), enabled=False)
        self.select_frame = TileFrame(color.rgba(0.98, 0.62, 0.16, 1), thickness=0.07, height=0.06, enabled=False)

        # ---------------- Benutzeroberfläche
        self.hud = HUD(self.anchors, {"tool": self.set_tool, "hover_tool": self._on_hover_tool,
                                      "minimap": self._minimap_click, "orders": self.toggle_orders,
                                      "update_now": self._update_now, "update_later": self._update_later})
        self.info = InfoPanel(self.anchors, {
            "upgrade": self.upgrade_selected, "rotate": self.rotate_selected, "demolish": self.demolish_selected,
            "recipe": self.set_recipe, "toggle": self.toggle_selected, "move": self.start_move,
            "filter": self.set_filter, "threshold": self.set_threshold})
        self.buy_menu = BuyMenu(self.anchors, self._buy_pick, lambda: self.buy_menu.hide())
        self.research_win = ResearchWindow(self.anchors, self.start_research, lambda: self.research_win.hide())
        self.market_win = MarketWindow(self.anchors, self.sell, lambda: self.market_win.hide())
        self.orders_win = OrdersWindow(self.anchors, {
            "accept": lambda oid: self._send("order_accept", oid=oid),
            "cancel": lambda cid: self._send("order_cancel", cid=cid),
            "load": lambda cid: self._send("order_load", cid=cid)}, lambda: self.orders_win.hide())
        from .stats import Stats
        self.stats = Stats()
        self.stats_win = StatsWindow(self.anchors, self.stats, lambda: self.stats_win.hide())
        self._last_money = None
        self._last_produced = None
        self._last_unlocked = None
        self._last_rovers = None
        buildings_mod.TRUCK_EVENTS["cb"] = self._on_truck
        from . import discord_rpc
        self.discord = discord_rpc.get()
        self.discord.start(settings["discord"])
        self._discord_t = 10.0
        self._session_start = None
        # ---------------- Updates und Neuigkeiten
        from .updater import Updater
        self.updater = Updater()
        try:
            self.updater.cleanup()
        except Exception as exc:
            print("[Update] Aufräumen fehlgeschlagen:", exc)
        self.updater.check_async()
        self.news_win = NewsWindow(self.anchors, {"primary": self._news_primary, "later": self._news_later})
        self._update_offered = False
        self._news_pending = False
        self._restart_at = None
        self._upd_check_t = 0.0          # alle paar Minuten erneut nach Updates suchen (auch im Spiel)
        self._upd_dismissed = None       # "Später" für diese Version (Hinweis kommt nach 10 Min. wieder)
        self._upd_badge = None
        if settings["seen_version"] != C.GAME_VERSION:
            from . import changelog
            notes = changelog.notes_since(settings["seen_version"] or None, C.GAME_VERSION)
            if not settings["seen_version"]:
                notes = notes[:1]                   # neue Spieler: nur die aktuelle Version
            settings["seen_version"] = C.GAME_VERSION
            settings.save()
            if notes:
                from ursina import invoke
                self._news_pending = True

                def show_news():
                    self._news_pending = False
                    self.news_win.show_news(C.GAME_VERSION, notes)
                invoke(show_news, delay=1.2)
        self.help_win = HelpWindow(self.anchors, lambda: self.help_win.hide(), self.start_tutorial)
        self.settings_menu = SettingsMenu(self.anchors, settings, {
            "resume": lambda: self.settings_menu.hide(), "save": self.save_game, "load": self.request_load,
            "help": self.toggle_help, "admin": self.toggle_admin, "disconnect": self.disconnect_to_menu,
            "quit": self.quit_game, "setting": self.change_setting,
            "copy": lambda: self.copy_host_address()})
        self.apply_keys()
        self._update_secret_flag()
        self.admin_panel = AdminPanel(self.anchors, {
            "close": lambda: self.admin_panel.hide(), "give": self.admin_give, "kick": self.admin_kick,
            "ban": self.admin_ban, "unban": self.admin_unban, "bans": self.admin_bans, "login": self.admin_login_send,
            "all_enabled": self.set_all_enabled, "set_admin": self.admin_set_admin})
        self.windows = [self.buy_menu, self.research_win, self.market_win, self.orders_win, self.help_win,
                        self.admin_panel, self.settings_menu, self.stats_win]
        self.windows.append(self.news_win)
        self.info.fit(settings["gui_scale"])
        self.session = None            # {"mode": "single"|"host"|"join", ...} der laufenden Partie
        try:                           # Welten aus 2.5/2.6 auf die Mehrspieler-Plätze übernehmen
            from . import worlds as W
            for old, slot in W.migrate_worlds():
                print(f"[Welten] \"{old}\" liegt jetzt auf Mehrspieler-Platz {slot}")
        except Exception as exc:
            print("[Welten] Übernahme fehlgeschlagen:", exc)
        self.online_info = None
        self.menu = MainMenu(self.anchors, {
            "single": self.start_singleplayer, "host": self.start_hosting, "join": self.join_game,
            "test_info": self._test_world_info, "test_world": self.start_test_world,
            "options": self.open_options, "quit": self.quit_game, "slots_info": self._singleplayer_slots_info,
            "stats": lambda: self.stats_win.show(),
            "last_slot": lambda: self.settings["sp_slot"],
            "mp_slots_info": self._multiplayer_slots_info,
            "last_mp_slot": lambda: self.settings["mp_slot"]}, {
            "name": args.name, "host": "" if args.host in (None, "", "127.0.0.1") else args.host,
            "port": args.port, "password": args.password or "", "host_port": settings["host_port"],
            "relay": settings["relay"]})
        self.showcase = []
        self._build_showcase()
        self.disconnect_overlay = DisconnectOverlay(self.anchors, self.reconnect, self.disconnect_to_menu)
        self.chat = ChatInput(self.anchors, self.send_chat)
        self.tutorial = Tutorial(self, self.anchors)
        self._tutorial_checked = False
        self.fps_label = Text(parent=self.anchors["br"], text="", origin=(0.5, -0.5), position=(-0.012, 0.04),
                              scale=0.8, color=color.rgba(1, 1, 1, 0.7))
        atexit.register(self._shutdown)
        self._vsync_at_start = bool(settings["vsync"])
        self.apply_fps_limit()

        if settings["fullscreen"] or args.fullscreen:
            self.set_fullscreen(True)
        resume = self._take_resume()
        if resume is not None:                         # gerade aktualisiert: zurück in dieselbe Welt
            self._resume_after_update(resume)
        elif args.local:
            self.start_singleplayer(False)
        elif args.connect:
            self.join_game(args.name, args.host, str(args.port), args.password or "")
        else:
            self._show_menu()

    # ================================================================== Hilfen
    def _any_window(self):
        return any(w.visible for w in self.windows)

    def _close_windows(self):
        for w in self.windows:
            w.hide()

    def _in_game(self):
        return self.net is not None and self.state.has_state

    def _typing(self):
        if self.chat.active:
            return True
        if self.menu.visible and self.menu.typing():
            return True
        if self.admin_panel.visible and self.admin_panel.content:
            for f in (getattr(self.admin_panel, "amount", None), getattr(self.admin_panel, "pw", None)):
                if f is not None and f.enabled and f.active:
                    return True
        return False

    def _mouse_over_ui(self):
        he = mouse.hovered_entity
        return he is not None and he.has_ancestor(camera.ui)

    # ================================================================== Einstellungen
    def change_setting(self, key, value):
        if key == "keys":
            self.settings["keys"] = value
            self.settings.save()
            self.apply_keys()
            return
        if key == "achievement_test":                    # Knopf "Test" neben dem Erfolge-Regler
            self.audio.play("achievement")
            return
        self.settings[key] = value
        if key == "achievement_volume":
            self.audio.achievement_volume = float(value)
        elif key == "gui_scale":
            self.apply_gui_scale(self.settings["gui_scale"])
        elif key == "fullscreen":
            self.set_fullscreen(bool(value))
        elif key == "show_grid":
            self.world.set_grid_visible(bool(value))
        elif key == "particles":
            self.particles.enabled = bool(value)
            if not value:
                self.particles.clear()
        elif key == "show_fps":
            if not value:
                self.fps_label.text = ""
        elif key == "mouse_sensitivity":
            self.cam.sensitivity = float(value)
        elif key == "volume":
            self.audio.volume = float(value)
            self.audio.play("click")
        elif key == "music_volume":
            self.audio.music_volume = float(value)
        elif key == "ambient_volume":
            self.audio.ambient_volume = float(value)
        elif key == "rocket_volume":
            self.audio.rocket_volume = float(value)
        elif key == "discord":
            self.discord.set_enabled(bool(value))
        elif key == "language":
            from . import i18n
            i18n.set_language(value)
            ch = getattr(getattr(self, "settings_menu", None), "lang_choice", None)
            if ch is not None and ch.value != value:
                ch.set(value)
        elif key == "scenery":
            self.world.set_scenery(bool(value))
        elif key == "cursor_scale":
            for cur in self.avatars.values():
                cur.set_scale(float(value))
        elif key == "fps_limit":
            self.apply_fps_limit()
        elif key == "shadows":
            if graphics.QUALITY.get("fast"):
                # Spiel läuft mit dem schnellen Shader (ohne Schatten) – Schatten erst nach Neustart
                self.settings_menu.set_vsync_hint("" if value == "off" else "Schatten: nach Neustart")
            else:
                self.world.set_shadow_quality(value)
                if value == "off":
                    self.settings_menu.set_vsync_hint("Neustart = noch mehr FPS")
        elif key == "vsync":
            self.settings_menu.set_vsync_hint("" if bool(value) == self._vsync_at_start else "nach Neustart")
        elif key == "msaa":
            self.settings_menu.set_vsync_hint("nach Neustart")
        self.settings.save()

    def _update_secret_flag(self):
        from . import ui
        ui.SHOW_SECRET["on"] = rules.check_test_code(self.settings["test_code"] or "")

    def apply_keys(self):
        km = rules.keymap(self.settings["keys"])
        self._key_actions = {k: a for a, k in km.items()}

    def apply_fps_limit(self):
        """FPS-Begrenzer (wirkt sofort). 0 = unbegrenzt."""
        from panda3d.core import ClockObject
        clock = ClockObject.getGlobalClock()
        limit = int(self.settings["fps_limit"] or 0)
        if limit > 0:
            clock.setMode(ClockObject.MLimited)
            clock.setFrameRate(limit)
        else:
            clock.setMode(ClockObject.MNormal)

    def apply_gui_scale(self, value):
        self.anchors.set_scale(value)
        if getattr(self, "menu", None) is not None:
            self.menu.fit(value)
        self.hud.fit()
        self.info.fit(value)
        for w in self.windows:
            if w.visible:
                w.fit()

    def set_fullscreen(self, on):
        """Randloser Vollbildmodus auf dem Monitor, auf dem das Fenster gerade ist.
        Der Mauszeiger bleibt sichtbar (außer in der Ego-Perspektive)."""
        if not application.base or not application.base.win:
            return
        on = bool(on)
        win = application.base.win
        props = win.getProperties()
        wp = WindowProperties()
        if on:
            if not self._fullscreen:
                self._windowed = (props.getXSize(), props.getYSize(), props.getXOrigin(), props.getYOrigin())
            mon = self._current_monitor(props)
            size = origin = None
            if mon is not None:
                origin, size = (mon.x, mon.y), (mon.width, mon.height)
        else:
            if self._windowed:
                w, h, x, y = self._windowed
            else:
                w, h, x, y = 1280, 720, 80, 80
            size, origin = (w, h), (max(0, x), max(30, y))
        wp.setUndecorated(on)
        if size:
            wp.setSize(int(size[0]), int(size[1]))
            wp.setOrigin(int(origin[0]), int(origin[1]))
        # Im Vollbild zeichnet das Spiel seinen eigenen Mauszeiger: Der Systemzeiger verschwand dort
        # auf manchen Rechnern (Windows/macOS) – der eigene Zeiger ist immer sichtbar.
        self.capture.soft = on
        wp.setCursorHidden(self.capture.captured or on)
        win.requestProperties(wp)
        # Ursinas eigenes Fensterobjekt mitziehen, sonst setzt Ursina das Fenster später zurück
        sync_ursina_window(undecorated=on, size=size, origin=origin, cursor_hidden=self.capture.captured or on)
        self._fullscreen = on
        self.settings["fullscreen"] = on
        # Nach dem Größenwechsel Mauszeiger/Mausmodus noch einmal sicher setzen
        from ursina import invoke
        for delay in (0.3, 1.0):
            invoke(self.capture.apply, delay=delay)
        if self.settings_menu.visible:
            self.settings_menu.toggles["fullscreen"].set(on)

    def _current_monitor(self, props):
        monitors = getattr(window, "monitors", None) or []
        cx = props.getXOrigin() + props.getXSize() // 2
        cy = props.getYOrigin() + props.getYSize() // 2
        for m in monitors:
            if m.x <= cx < m.x + m.width and m.y <= cy < m.y + m.height:
                return m
        main = getattr(window, "main_monitor", None)
        if main is not None:
            return main
        # Ohne Monitorliste (z. B. macOS ohne pyobjc): Bildschirmgröße direkt von Panda3D
        try:
            pipe = application.base.pipe
            w, h = pipe.getDisplayWidth(), pipe.getDisplayHeight()
            if w > 0 and h > 0:
                from types import SimpleNamespace
                return SimpleNamespace(x=0, y=0, width=w, height=h)
        except Exception:
            pass
        return None

    def _update_mouse_lock(self):
        self.capture.set_captured(False)
        self.capture.update()
        self._update_soft_cursor()

    def _update_badges(self):
        """Alle Warn-/Aus-Schilder in je einem Modell (ein Zeichenaufruf statt einem pro Schild)."""
        batches = getattr(self, "_badge_batches", None)
        if batches is None:
            from . import sprites
            batches = self._badge_batches = (sprites.SpriteBatch(textures.texture("badge_warn"), "warn", 5),
                                             sprites.SpriteBatch(textures.texture("badge_off"), "off", 5))
        warn, off = buildings_mod.badge_sprites(time.time())
        for batch, sp in zip(batches, (warn, off)):
            if sp or batch.count:
                batch.write(sp)

    def _update_soft_cursor(self):
        cur = getattr(self, "_soft_cursor", None)
        if not self.capture.soft:
            if cur is not None and not cur.isHidden():
                cur.hide()
            return
        if cur is None:
            s = 0.04                                   # etwa so groß wie der Systemzeiger
            cur = self._soft_cursor = Entity(parent=camera.ui, add_to_scene_entities=False)
            arrow = Entity(parent=cur, model="quad", texture=textures.texture("cursor"), origin=(-0.5, 0.5),
                           position=(-6 / 64 * s, 4 / 64 * s), scale=s, add_to_scene_entities=False)
            arrow.setBin("gui-popup", 10000)
            arrow.setDepthTest(False)
            arrow.setDepthWrite(False)
        mw = application.base.mouseWatcherNode
        if mw is None or not mw.hasMouse():
            cur.hide()
            return
        cur.show()
        cur.setPos(mouse.x, mouse.y, -0.99)

    # ================================================================== Verbindung
    def connect(self, name, host, port, password="", start_local=False):
        if self._connect_job:
            return
        self.connect_params = (name, host, port, password)
        self.menu.set_status(f"Verbinde mit {host}:{port} …" if not start_local else "Starte Spiel …", MUTED)
        job = {"done": False, "error": None, "net": None}

        def worker():
            net = NetworkClient()
            attempts = 16 if start_local else 1
            for attempt in range(attempts):
                try:
                    net.connect(host, port, name, password=password)
                    job["net"] = net
                    break
                except ConnectionFailed as exc:
                    job["error"] = str(exc)
                    if self.local_server and self.local_server.poll() is not None:
                        job["error"] = self._local_server_error()
                        break
                    if attempt < attempts - 1:
                        time.sleep(0.5)
            job["done"] = True

        self._connect_job = job
        threading.Thread(target=worker, daemon=True).start()

    # ------------------------------------------------------------------ Partie starten
    def _player_name(self):
        return (self.settings["name"] or self.menu.player_name() or "Spieler")[:16]

    def _singleplayer_slots_info(self):
        """Kurzinfo zu allen Einzelspieler-Plätzen (None = leer)."""
        from . import worlds as W
        return W.slots_info(C.singleplayer_slot_file, C.SINGLEPLAYER_SLOTS)

    def _multiplayer_slots_info(self):
        """Kurzinfo zu allen Mehrspieler-Plätzen (None = leer)."""
        from . import worlds as W
        return W.slots_info(C.multiplayer_slot_file, C.MULTIPLAYER_SLOTS)

    @staticmethod
    def _free_port():
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return sock.getsockname()[1]

    def _spawn_server(self, port, extra):
        """Startet den Spielserver als eigenen Prozess (Ausgabe nach server.log)."""
        self._stop_local_server(save=False)
        os.makedirs(C.DATA_DIR, exist_ok=True)
        self._server_log_path = os.path.join(C.DATA_DIR, "server.log")
        log = open(self._server_log_path, "w", encoding="utf-8")
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            self.local_server = subprocess.Popen(
                [sys.executable, os.path.join(PROJECT_DIR, "server.py"), "--port", str(port), "--no-console"] + extra,
                cwd=PROJECT_DIR, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **kwargs)
        except OSError as exc:
            self.menu.set_status(f"Server konnte nicht gestartet werden: {exc}", BAD)
            return False
        return True

    def _local_server_error(self):
        text = ""
        try:
            with open(self._server_log_path, encoding="utf-8", errors="replace") as f:
                text = f.read()[-3000:]
        except (OSError, AttributeError):
            pass
        if "bereits belegt" in text or "in use" in text.lower() or "10048" in text:
            return ("Der Port ist schon belegt (läuft der Server schon in einem anderen Fenster?). "
                    "Bitte einen anderen Port wählen, z. B. 5601.")
        return "Der Spielserver wurde unerwartet beendet. Details: server.log im Spielstand-Ordner."

    def start_singleplayer(self, new_game=False, slot=None):
        if self._connect_job:
            return
        from . import worlds as W
        slot = slot or self.settings["sp_slot"]
        self.settings["sp_slot"] = slot
        self.settings.save()
        port = self._free_port()
        extra = ["--host", "127.0.0.1", "--save", C.singleplayer_slot_file(slot)]
        if new_game:
            extra += ["--new", "--seed", str(W.new_seed())]     # jede neue Welt mit eigener Karte
        self.session = {"mode": "single", "port": port, "extra": extra, "new": "--new" in extra}
        if self._spawn_server(port, extra):
            self.connect(self._player_name(), "127.0.0.1", str(port), "", start_local=True)

    # ------------------------------------------------------------------ geheime Test-Welt
    TEST_WORLD_FILE = os.path.join(C.DATA_DIR, "test_world.json")

    def _test_world_info(self):
        """(freigeschaltet, Kurzinfo oder None) für die Zeile im Einzelspieler-Menü."""
        code = self.settings["test_code"]
        if not code or not rules.check_test_code(code):
            return False, None
        from . import worlds as W
        info = W._describe(self.TEST_WORLD_FILE) if os.path.exists(self.TEST_WORLD_FILE) else None
        return True, (W.describe_line(info) if info else None)

    def start_test_world(self, new_game=False):
        """Test-World: eigene Welt, in der die Rakete schon vor Ablauf des Countdowns startklar ist."""
        code = self.settings["test_code"]
        if self._connect_job or not code or not rules.check_test_code(code):
            return
        from . import worlds as W
        port = self._free_port()
        extra = ["--host", "127.0.0.1", "--save", self.TEST_WORLD_FILE, "--test-code", code]
        if new_game or not os.path.exists(self.TEST_WORLD_FILE):
            extra += ["--new", "--seed", str(W.new_seed())]
        self.session = {"mode": "single", "port": port, "extra": extra, "new": "--new" in extra}
        if self._spawn_server(port, extra):
            self.connect(self._player_name(), "127.0.0.1", str(port), "", start_local=True)

    def unlock_test_world(self, code):
        code = "".join(code.split()).upper()
        self.settings["test_code"] = code
        self.settings.save()
        self._update_secret_flag()
        self.hud.toast_show("Test-World freigeschaltet! Hauptmenü » Einzelspieler » Test-World.", "success", 6)
        self.hud.add_message("Geheimcode erkannt: Die Test-World mit Mond-Vorschau steht jetzt im "
                             "Einzelspieler-Menü (nur auf diesem Rechner).", "success")
        self.audio.play("research")

    def start_hosting(self, name, port, password, relay_mode, slot=None, new_game=False):
        if self._connect_job:
            return
        try:
            port_num = int(port)
            if not 1024 <= port_num <= 65535:
                raise ValueError
        except ValueError:
            self.menu.set_status("Bitte einen Port zwischen 1024 und 65535 eingeben (z. B. 5600).", BAD)
            return
        # Welt: einer der 5 Mehrspieler-Plätze (leerer Platz oder "Neu" = neue Welt mit eigener Karte)
        from . import worlds as W
        slot = slot or self.settings["mp_slot"]
        save_path = C.multiplayer_slot_file(slot)
        new_args = []
        if new_game or not os.path.exists(save_path):
            new_args = ["--new", "--seed", str(W.new_seed())]
        self.settings["name"] = name
        self.settings["host_port"] = port_num
        self.settings["relay"] = bool(relay_mode)
        self.settings["mp_slot"] = slot
        self.settings.save()
        # Raum-Code: Vermittlungsserver (klappt er nicht, versucht der Server automatisch die Router-Freigabe)
        extra = ["--save", save_path, "--online"] + new_args + (["--relay"] if relay_mode else [])
        if password:
            extra += ["--password", password]
        self.session = {"mode": "host", "port": port_num, "extra": extra, "new": bool(new_args)}
        if self._spawn_server(port_num, extra):
            self.connect(name, "127.0.0.1", str(port_num), password, start_local=True)

    def join_game(self, name, host, port, password):
        if self._connect_job:
            return
        if not host:
            self.menu.set_status("Bitte den Raum-Code (z. B. FE-41234) oder die IP-Adresse des Hosts eingeben.", BAD)
            return
        from . import relay
        code = relay.parse_room_code(host)
        self._stop_local_server(save=True)
        self.settings["name"] = name
        self.session = {"mode": "join", "entered": host}
        if code is not None:
            self.connect(name, relay.relay_host(), str(code), password)
        else:
            self.connect(name, host, port or str(C.DEFAULT_PORT), password)

    def _stop_local_server(self, save=True):
        server = self.local_server
        self.local_server = None
        if server is None or server.poll() is not None:
            return
        try:
            if os.name == "nt":
                server.terminate()
            else:
                server.send_signal(signal.SIGINT)        # Server speichert beim Beenden
            server.wait(timeout=6)
        except Exception:
            try:
                server.kill()
            except Exception:
                pass

    def open_options(self):
        self.settings_menu.set_menu_mode(True)
        self.settings_menu.sync()
        self.settings_menu.show()

    def copy_host_address(self):
        text = self._host_address_text()
        if not text:
            return
        try:
            import pyperclip
            pyperclip.copy(text if (self.online_info or {}).get("relay") else text.replace(" ", ""))
            self.hud.toast_show("Kopiert - schick es deinen Freunden.", "success", 2.5)
        except Exception:
            self.hud.toast_show(f"Adresse: {text}", "info", 4)

    def _host_address_text(self):
        info = self.online_info or {}
        if info.get("relay"):
            return info.get("code")
        ip = info.get("public") or info.get("lan")
        return f"{ip} : {info.get('port')}" if ip else None

    def _apply_online_info(self, info):
        if not self.session or self.session.get("mode") != "host" or not info:
            self.online_info = None
            self.settings_menu.set_host_info(None)
            return
        first = self.online_info is None
        self.online_info = info
        text = self._host_address_text()
        if info.get("relay"):
            self.settings_menu.set_host_info(f"Raum-Code {text}" + ("\n(mit Passwort)" if info.get("password") else "")
                                             + ("\n(Verbindung wird neu aufgebaut ...)" if info.get("relay_lost") else ""))
            if info.get("relay_lost"):
                self.hud.add_message("Verbindung zum Vermittlungsserver unterbrochen - wird automatisch neu aufgebaut.",
                                     "warn")
            else:
                self.hud.add_message(f"Online! Raum-Code für deine Freunde: {text}"
                                     + (" (plus dein Passwort)" if info.get("password") else "")
                                     + ". Esc-Menü: Code kopieren.", "success")
                if first:
                    self.hud.toast_show(f"Raum-Code: {text}", "success", 6)
            return
        if text:
            text += "\n(mit Passwort)" if info.get("password") else ""
            text += "" if info.get("public") else "\n(nur im selben WLAN)"
        self.settings_menu.set_host_info(text)
        port = info.get("port")
        if info.get("relay_error"):
            self.hud.add_message("Raum-Code nicht verfügbar (Vermittlungsserver nicht erreichbar). "
                                 "Freunde können stattdessen über IP und Port beitreten.", "warn")
        if info.get("public"):
            self.hud.add_message(f"Online-Server läuft. Freunde treten bei mit IP {info['public']} und Port {port}"
                                 + (" (und deinem Passwort)." if info.get("password") else ".")
                                 + " Esc-Menü: Adresse kopieren.", "success")
        if info.get("cgnat"):
            self.hud.add_message("Achtung: Dein Internetanschluss hat keine eigene öffentliche IPv4-Adresse "
                                 "(DS-Lite). Freunde von außerhalb können so nicht beitreten - siehe README.", "warn")
        elif not info.get("upnp_ok"):
            self.hud.add_message(f"Router-Freigabe nicht automatisch möglich. Bitte im Router TCP-Port {port} an "
                                 f"diesen PC ({info.get('lan') or 'lokale IP'}) weiterleiten (FritzBox: Internet > "
                                 "Freigaben).", "warn")
        if info.get("lan"):
            self.hud.add_message(f"Im selben WLAN: IP {info['lan']}, Port {port}.", "info")

    def _show_menu(self):
        self.menu.show()
        self.menu.fit(self.settings["gui_scale"])
        self.menu.refresh_single()
        for v in self.showcase:
            v.root.enabled = True
        anim.cancel("cam_intro")
        self.cam.auto_orbit = True
        self.cam.focus(*self._showcase_center)
        self.cam.target_distance = 17
        self.cam.pitch = 30

    def _build_showcase(self):
        """Kleine Beispielfabrik, die im Hauptmenü hinter dem Titel arbeitet."""
        cx, cz = C.GRID_W // 2, C.GRID_H // 2
        self._showcase_center = (cx + 0.5, cz)
        layout = [("miner", -6, 0, 1, None), ("conveyor", -5, 0, 1, None), ("conveyor", -4, 0, 1, None),
                  ("conveyor", -3, 0, 1, None), ("smelter", -2, 0, 1, "smelt_iron"), ("conveyor", -1, 0, 1, None),
                  ("conveyor", 0, 0, 1, None), ("assembler", 1, 0, 1, "gear"), ("conveyor", 2, 0, 1, None),
                  ("conveyor", 3, 0, 1, None), ("seller", 4, 0, 1, None),
                  ("miner", -6, 3, 1, None), ("conveyor", -5, 3, 1, None), ("conveyor", -4, 3, 1, None),
                  ("smelter", -3, 3, 1, "smelt_copper"), ("conveyor", -2, 3, 1, None), ("splitter", -1, 3, 1, None),
                  ("conveyor", 0, 3, 1, None), ("assembler", 1, 3, 1, "wire"), ("conveyor", 2, 3, 1, None),
                  ("storage", 3, 3, 1, None),
                  ("miner", -6, -3, 1, None), ("conveyor", -5, -3, 1, None), ("smelter", -4, -3, 1, "smelt_iron"),
                  ("conveyor", -3, -3, 1, None), ("conveyor", -2, -3, 1, None), ("seller", -1, -3, 1, None),
                  ("electronics", 4, -3, 1, "computer"), ("blast_furnace", 2, -3, 1, "steel_coal"),
                  ("miner", -6, 6, 1, None), ("conveyor", -5, 6, 1, None), ("kiln", -4, 6, 1, "glass"),
                  ("conveyor", -3, 6, 1, None), ("factory", -2, 6, 1, "solar_panel"), ("chemical", 1, 6, 1, "plastic"),
                  ("freight", 4, 3, 1, None)]
        deposits = []
        for i, (btype, dx, dz, rot, recipe) in enumerate(layout):
            x, z = cx + dx, cz + dz
            try:
                view = BuildingView([-(i + 1), btype, x, z, rot, 1 + (i % 3), recipe, 0, True, {}])
            except Exception as exc:             # Deko darf das Spiel nie verhindern
                print(f"[Menü] Beispielgebäude {btype} nicht darstellbar: {exc}")
                continue
            view.status = "working"
            self.showcase.append(view)
            if btype == "miner":
                deposits.append([x, z, {3: "copper_ore", 6: "sand"}.get(dz, "iron_ore")])
        self._showcase_deposits = deposits
        self.world.set_deposits(deposits)

    def _hide_showcase(self):
        for v in self.showcase:
            v.root.enabled = False

    def _finish_connect(self, job):
        self._connect_job = None
        if job["net"] is None:
            self.menu.set_status(job["error"] or "Verbindung fehlgeschlagen.", BAD)
            self.audio.play("error")
            if not self.menu.visible:
                self.disconnect_overlay.show(job["error"] or "Verbindung fehlgeschlagen.")
            if self.session and self.session.get("mode") in ("single", "host"):
                self._stop_local_server(save=False)
            return
        self.net = job["net"]
        welcome = self.net.welcome
        self._upd_check_t = self.UPDATE_CHECK_EVERY - 3.0   # kurz nach dem Betreten einer Welt nach Updates sehen
        self.my_id = welcome["id"]
        self.my_color = welcome.get("color", 0)
        self._last_pos_msg = None
        self.is_admin = bool(welcome.get("admin"))
        self.admin_login = bool(welcome.get("admin_login"))
        self._reset_world_views()
        self.state = ClientState()
        self.moon_preview = bool(welcome.get("moon_preview"))
        self._apply_planet(welcome.get("planet", "earth"))
        self.state.planet = self.planet
        self.state.rocket_unlocked = bool(welcome.get("rocket_unlocked"))
        self._rocket_sign = None
        self.state.set_deposits(welcome["deposits"])
        self.world.set_deposits(welcome["deposits"])
        self.menu.hide()
        self._hide_showcase()
        self.disconnect_overlay.hide()
        self.hud.show()
        self.hud.play_intro()
        self.cam.auto_orbit = False
        self.cam.focus(C.GRID_W / 2 - 0.5, C.GRID_H / 2 - 0.5)
        # Kamera-Einflug: von hoch oben schräg herunter in die Fabrik
        cam = self.cam
        cam.distance, cam.target_distance = 62.0, 22.0
        yaw0 = cam.yaw - 50

        def fly(v):
            cam.pitch = 74 - 22 * v
            cam.yaw = yaw0 + 50 * v
        anim.tween(fly, 2.2, ease=anim.in_out_cubic, key="cam_intro")
        self.set_tool("select", quiet=True)
        self._user_disconnect = False
        self._tutorial_checked = False
        self._first_static = True
        self._last_money = self._last_produced = self._last_unlocked = None
        self._last_rovers = None
        if self.session is not None and not self.session.get("counted"):
            self.session["counted"] = True
            self._achievements(self.stats.start_session(new_world=bool(self.session.get("new")),
                                                        multiplayer=self.session.get("mode") != "single"))
        name, host, port, _pw = self.connect_params
        self.settings["name"] = name
        if self.session and self.session.get("mode") == "join":
            entered = self.session.get("entered", host)
            self.settings["host"] = entered            # Raum-Code oder IP, wie eingegeben
            from . import relay
            if relay.parse_room_code(entered) is None:
                try:
                    self.settings["port"] = int(port)
                except ValueError:
                    pass
        self.settings.save()
        self._apply_online_info(welcome.get("online"))
        self.hud.add_message(f"Verbunden als {welcome['name']} (Server {welcome['server_version']}). "
                             f"Q öffnet das Kaufmenü, F1 die Hilfe.", "success")
        if self.is_admin:
            self.hud.add_message("Du bist Admin auf diesem Server (Admin-Panel: F2).", "info")
        self.audio.play("message")
        cam = getattr(self, "_resume_cam", None)
        if cam:                                            # nach einem Update: Kamera wie vorher
            self._resume_cam = None
            anim.cancel("cam_intro")
            try:
                self.cam.focus(float(cam[0]), float(cam[1]))
                self.cam.distance = self.cam.target_distance = float(cam[2])
                self.cam.yaw, self.cam.pitch = float(cam[3]), float(cam[4])
            except (TypeError, ValueError, IndexError):
                pass
            self.hud.toast_show(f"Update auf Version {C.GAME_VERSION} installiert – weiter geht's!", "success", 4)
        self._maybe_reveal()

    # ================================================================== Mond & Rakete
    def _apply_planet(self, planet):
        """Umgebung, Währung und Geräusche auf Erde oder Mond umstellen."""
        from . import i18n
        self.planet = "moon" if planet == "moon" else "earth"
        rules.apply_planet_texts(self.planet)             # Mond: andere Gebäudenamen, eigene Forschung
        from . import models
        models.PLANET["cur"] = self.planet                # Mond: Gebäude im Mond-Look
        self._moon_open = rules.moon_open(self.moon_preview)
        self._last_money = self._last_produced = self._last_unlocked = None
        self.world.set_planet(self.planet)
        self.world.set_launch(self._moon_open or self.planet == "moon")
        pad = self.world.launchpad
        if pad is not None:
            pad.on_click = self.start_launch
            pad.set_planet(self.planet)
        i18n.set_currency(rules.currency(self.planet))
        self.audio.air = 0.0 if self.planet == "moon" else 1.0
        self.cam.min_pitch = 6 if self.planet == "moon" else 15
        self.research_win.set_planet(self.planet)
        self.buy_menu.planet = None                      # Karten neu aufbauen
        self.hud.set_planet(self.planet) if hasattr(self.hud, "set_planet") else None

    def _reveal_key(self):
        return "test" if self.moon_preview else "release"

    def _maybe_reveal(self):
        """Nach Ablauf des Countdowns (bzw. in der Test-Welt) einmalig die Enthüllung zeigen."""
        if self.planet != "earth" or not self._moon_open or self.cinematic is not None:
            return
        seen = list(self.settings["reveal_seen"] or [])
        if self._reveal_key() in seen or self.world.launchpad is None:
            return
        seen.append(self._reveal_key())
        self.settings["reveal_seen"] = seen
        self.settings.save()
        from .rocket import RevealSequence
        anim.cancel("cam_intro")
        self.cinematic = RevealSequence(self, self.world.launchpad, self.world.teaser)

    def start_launch(self):
        """Klick auf die Rakete (oder Taste L): Startsequenz zum Mond bzw. zurück zur Erde."""
        pad = self.world.launchpad
        if pad is None or pad.busy or self.cinematic is not None or not self._in_game():
            return
        if self.planet == "earth" and not self._moon_open:
            self.hud.toast_show("Die Rakete ist noch nicht startklar.", "warn")
            return
        if self.planet == "earth" and not self.state.rocket_unlocked:
            price = rules.format_money(C.ROCKET_PRICE)
            if self.state.available < C.ROCKET_PRICE:
                self.hud.toast_show(f"Die Rakete kostet {price} – dir fehlen noch "
                                    f"{rules.format_money(C.ROCKET_PRICE - self.state.available)}.", "warn", 4)
                self.audio.play("error")
                return
            if time.time() > getattr(self, "_rocket_confirm", 0):
                self._rocket_confirm = time.time() + 5
                self.hud.toast_show(f"Rakete für {price} freischalten? Zum Bestätigen nochmal klicken.", "info", 5)
                self.audio.play("click")
                return
            self._rocket_confirm = 0
            self._send("unlock_rocket")
            return
        from .rocket import LaunchSequence
        dest = "earth" if self.planet == "moon" else "moon"
        self.cinematic = LaunchSequence(self, pad, dest)
        self._stat("launches")

    def request_travel(self, dest):
        self._send("travel", to=dest)

    def _on_travel_result(self, msg):
        seq = self.cinematic
        if not msg.get("ok") and seq is not None and hasattr(seq, "on_failed"):
            seq.on_failed(msg.get("msg", "Flug nicht möglich."))

    def reconnect(self):
        self.disconnect_overlay.hide()
        if not self.connect_params:
            return
        name, host, port, password = self.connect_params
        mode = (self.session or {}).get("mode")
        if mode in ("single", "host") and (self.local_server is None or self.local_server.poll() is not None):
            if self._spawn_server(self.session["port"], self.session["extra"]):
                self.connect(name, "127.0.0.1", str(self.session["port"]), password, start_local=True)
        else:
            self.connect(name, host, port, password, start_local=mode in ("single", "host"))

    def disconnect_to_menu(self):
        self._user_disconnect = True
        if self.net:
            if self.local_server is not None:
                try:
                    self.net.action("save")
                    time.sleep(0.3)
                except Exception:
                    pass
            self.net.close()
            self.net = None
        self._stop_local_server(save=True)
        self.session = None
        self._apply_online_info(None)
        self.tutorial.close()
        self._close_windows()
        self.disconnect_overlay.hide()
        self.hud.hide()
        self.info.hide()
        self._reset_world_views()
        self.ghost.enabled = False
        self.hover_frame.enabled = False
        if self.cinematic is not None:
            self.cinematic.finish()
            self.cinematic = None
        self.moon_preview = False
        self._apply_planet("earth")
        if self.world.launchpad is not None:
            self.world.launchpad.reset()
        self.world.set_deposits(self._showcase_deposits)
        self._show_menu()
        self.menu.set_status("")

    def _reset_world_views(self):
        for v in self.views.values():
            v.destroy()
        self.views = {}
        self.batcher.clear()
        self._visible_views = []
        self._far_belts = []
        self._on_screen = set()
        self._cull_dirty = True
        for a in self.avatars.values():
            a.destroy()
        self.avatars = {}
        self.selected = None
        self.move_bid = None
        self.select_frame.enabled = False
        self.particles.clear()

    def _shutdown(self):
        try:
            self.settings.save()
            self.stats.flush()
            self.discord.stop()
        except Exception:
            pass
        try:
            if self.net and self.net.connected and self.local_server is not None:
                self.net.action("save")
                time.sleep(0.4)
            if self.net:
                self.net.close()
        except Exception:
            pass
        if self.local_server is not None and self.local_server.poll() is None:
            try:
                if os.name == "nt":
                    self.local_server.terminate()
                else:
                    self.local_server.send_signal(signal.SIGINT)   # Server speichert beim Beenden
                self.local_server.wait(timeout=5)
            except Exception:
                self.local_server.kill()
        self.audio.shutdown()

    def quit_game(self):
        self._shutdown()
        self.local_server = None
        application.quit()

    # ================================================================== Netzwerknachrichten
    def _process_network(self):
        if not self.net:
            return
        # Mehrere Zustände in einem Frame (z. B. nach kurzem Hänger) zusammenfassen: Daten übernehmen
        # ist billig, die Darstellung wird danach nur EINMAL aktualisiert.
        pending = None
        for msg in self.net.poll():
            t = msg["t"]
            if t == "state":
                pending = self._apply_state(msg, pending)
                continue
            if pending is not None:
                self._on_state_applied(pending)
                pending = None
            if t == "result":
                self._on_result(msg)
            elif t == "result":
                self._on_result(msg)
            elif t == "event":
                text = msg.get("text", "")
                kind = msg.get("kind", "info")
                self.hud.add_message(text, kind)
                if text.startswith("Lieferung angekommen"):
                    m = re.search(r"\(\+([\d.]+) €\)", text)
                    self._stat("deliveries")
                    if m:
                        self._stat("delivery_money", int(m.group(1).replace(".", "")))
                    self.audio.play("sell")
                    self.hud.toast_show(text, "success", 4)
                elif "Forschung abgeschlossen" in text:
                    self.audio.play("research")
                    self.hud.toast_show(text, "success", 4)
                else:
                    self.audio.play("message")
            elif t == "chat":
                self.hud.add_message(f"{msg.get('name')}: {msg.get('text')}", "chat")
                from .ui import player_color
                col = msg.get("color")
                self.chat.add(str(msg.get("name", "?")), str(msg.get("text", "")),
                              player_color(col) if isinstance(col, int) else TEXT)
                self.audio.play("message")
            elif t == "you":
                was = self.is_admin
                self.is_admin = bool(msg.get("admin"))
                if self.is_admin and not was:
                    self.hud.toast_show("Du bist jetzt Admin (F2).", "success")
                elif was and not self.is_admin:
                    self.hud.toast_show("Deine Admin-Rechte wurden entzogen.", "warn")
                    self.admin_panel.hide()
            elif t == "bans":
                self.admin_panel.set_bans(msg.get("list", []))
            elif t == "world":
                planet = msg.get("planet", self.planet)
                changed = planet != self.planet
                self._reset_world_views()
                if changed:
                    self._apply_planet(planet)
                unlocked = self.state.rocket_unlocked
                self.state = ClientState()
                self.state.planet = self.planet
                self.state.rocket_unlocked = unlocked
                self._rocket_sign = None
                self.state.set_deposits(msg["deposits"])
                self.world.set_deposits(msg["deposits"])
                self._first_static = True
                if changed:
                    self._close_windows()
                    if self.planet == "moon":
                        self._achievements(self.stats.add("moon_landings", 1) or [])
                    seq = self.cinematic
                    if seq is not None and hasattr(seq, "on_world"):
                        seq.on_world(self.planet)
            elif t == "online":
                self._apply_online_info(msg.get("info"))
            elif t == "kicked":
                self._kicked_reason = msg.get("msg", "Du wurdest vom Server entfernt.")
            elif t == "error":
                self.hud.add_message(msg.get("msg", "Serverfehler"), "error")
            elif t == "_disconnected":
                self.net = None
                if not self._user_disconnect:
                    self._close_windows()
                    self.hud.hide()
                    self.info.hide()
                    reason = getattr(self, "_kicked_reason", None)
                    if reason:
                        self.disconnect_overlay.show(reason, "Vom Server entfernt")
                        self._kicked_reason = None
                    else:
                        self.disconnect_overlay.show(msg.get("reason", "Verbindung verloren."))
                    self.audio.play("error")
        if pending is not None:
            self._on_state_applied(pending)

    def start_tutorial(self):
        if not self._in_game():
            return
        self._close_windows()
        self.tutorial.start()

    def _apply_state(self, msg, pending):
        """Übernimmt einen Zustand ins Datenmodell und merkt sich, was sich geändert hat."""
        static_changed = self.state.apply(msg)
        if pending is None:
            pending = {"static": False, "rows": set(), "full": False}
        pending["static"] |= static_changed
        if msg.get("dpart"):
            pending["rows"].update(row[0] for row in msg.get("dyn", []))
        else:
            pending["full"] = True
        return pending

    def _on_state(self, msg):
        self._on_state_applied(self._apply_state(msg, None))

    def _on_state_applied(self, pending):
        static_changed = pending["static"]
        if not self._tutorial_checked:
            self._tutorial_checked = True
            if self.settings["tutorial"] and Tutorial.is_fresh_world(self.state):
                self.tutorial.start()
        if static_changed:
            self._sync_views()
            self._update_curves()
        self._track_state()
        fill = self.state.storage_fill()
        dyn = self.state.dynamic
        rows = dyn.keys() if (pending["full"] or static_changed) else pending["rows"]
        for bid in rows:
            view = self.views.get(bid)
            d = dyn.get(bid)
            if view and d:
                view.update_dynamic(d[0], d[1], d[2], fill)
        if abs(fill - getattr(self, "_last_fill", -1)) > 0.004:      # Lager-Füllstand betrifft alle Lager
            self._last_fill = fill
            for view in self.views.values():
                if view.type == "storage":
                    view.set_storage_fill(fill)
        self._sync_avatars()
        if self.selected is not None:
            if self.selected in self.state.static:
                row = self.state.static[self.selected]
                self.select_frame.position = Vec3(row[2], 0.02, row[3])
                self.info.show(row, self.state.dynamic.get(self.selected), self.state)
            else:
                self.deselect()
        if self.move_bid is not None and self.move_bid not in self.state.static:
            self.cancel_move()

    def _update_curves(self):
        """Förderbänder, die um die Ecke gehen, als Kurve darstellen."""
        static, grid = self.state.static, self.state.grid

        def get(x, y):
            row = static.get(grid.get((x, y)))
            return (row[1], row[4]) if row else None
        for v in self.views.values():
            if v.type == "conveyor":
                v.set_curve(rules.curve_side(v.x, v.y, v.rot, get))

    def _sync_views(self):
        static = self.state.static
        spawn = not self._first_static
        for bid in list(self.views):
            if bid not in static or static[bid][1] != self.views[bid].type:
                gone = self.views.pop(bid)
                if gone in self._visible_views:
                    self._visible_views.remove(gone)
                self.batcher.remove(gone)
                gone.destroy(effect=spawn)
        for bid, row in static.items():
            view = self.views.get(bid)
            if view is None:
                view = self.views[bid] = BuildingView(row, animate_spawn=spawn)
                self.batcher.add(view)
                self._cull_dirty = True
            else:
                view.update_static(row)
        self._first_static = False

    @staticmethod
    def _prune_entity_list():
        """Ursina geht JEDEN Frame alle Objekte seiner Liste durch (auch reine Deko wie Panels, Texte,
        Icons). Objekte ohne update()/input() brauchen das nicht – sie werden ausgetragen. Gezeichnet
        werden sie weiterhin ganz normal. Spart bei vielen Fenstern einige Millisekunden pro Bild."""
        from ursina import scene
        keep = [e for e in scene.entities if keep_in_entity_list(e)]
        if len(keep) != len(scene.entities):
            scene.entities = keep

    def _update_visibility(self):
        """Welche Gebäude werden animiert? Nur nahe UND sichtbare (plus gerade entstehende).
        Der Schattenbereich folgt der Kamera."""
        self._cull_dirty = False
        test = batching.visible_test()
        visible = [v for v in self.batcher.near_views() if test(v.x, v.y)]
        # Bänder in fernen Abschnitten: nur ihre Waren weiterschieben (die Waren sind gebündelt
        # und auch aus der Ferne sichtbar)
        self._far_belts = [v for v in self.batcher.far_belt_views() if test(v.x, v.y)]
        seen = set(visible)
        visible += [v for v in self.views.values() if v.spawn_t < 1.0 and v not in seen]
        self._visible_views = visible
        # "im Bild"-Markierung: Waren auf Bändern außerhalb des Bildes müssen nicht platziert werden
        on = set(visible)
        on.update(self._far_belts)
        for v in getattr(self, "_on_screen", ()):
            if v not in on:
                v.on_screen = False
        for v in on:
            if not v.on_screen:
                v.on_screen = True
                if v.items:
                    v._place_items(orient=True)        # Waren an die aktuelle Stelle setzen
        self._on_screen = on
        self.world.update_shadow_focus(self.cam.x, self.cam.z, self.cam.distance * 1.6 + 10)

    def _detail_radius(self):
        """Umkreis um den Blickpunkt, in dem Gebäude voll animiert werden – je weiter herausgezoomt,
        desto kleiner (dann sind die Teile ohnehin winzig)."""
        base = 24.0 if graphics.high() else 18.0
        r = base - self.cam.distance * 0.5
        # weit herausgezoomt: alles kommt aus den Bündeln (Einzelteile wären ohnehin winzig)
        return r if r > 2.0 else -100.0

    def _sync_avatars(self):
        """Mitspieler als Mauszeiger darstellen (keine Figuren)."""
        seen = set()
        for p in self.state.players:
            pid, name, col, x, z = p[0], p[1], p[2], p[3], p[4]
            tool = p[5] if len(p) > 5 else ""
            admin = p[9] if len(p) > 9 else False
            visible = p[10] if len(p) > 10 else True
            if pid == self.my_id:
                if admin != self.is_admin:
                    self.is_admin = bool(admin)
                continue
            seen.add(pid)
            cur = self.avatars.get(pid)
            if cur is None or cur.name != name:
                if cur:
                    cur.destroy()
                cur = PlayerCursor(pid, name, col, admin, self.settings["cursor_scale"])
                self.avatars[pid] = cur
            cur.set_target(x, z, visible, tool)
        for pid in list(self.avatars):
            if pid not in seen:
                self.avatars.pop(pid).destroy()
        self.hud.refresh_players(self.state.players, self.my_id)

    def _on_result(self, msg):
        action, fields = self.pending.pop(msg.get("rid"), (msg.get("a"), {}))
        if action == "travel":
            self._on_travel_result(msg)
            return
        if action == "unlock_rocket" and msg.get("ok"):
            self.state.rocket_unlocked = True
            self._stat("rockets_bought")
            self.hud.toast_show(msg.get("msg", ""), "success", 5)
            self.audio.play("research")
            return
        if action == "build" and not msg.get("ok"):
            key = (fields.get("x"), fields.get("y"))
            if self.state.grid.get(key) == -1:
                del self.state.grid[key]
        if msg.get("ok"):
            key = {"build": "built", "upgrade": "upgrades", "demolish": "demolished",
                   "order_accept": "orders"}.get(action)
            if key:
                self._stat(key)
            if action == "build" and fields.get("btype") in ("factory", "conveyor"):
                self._stat("factories" if fields["btype"] == "factory" else "belts")
            sound = {"build": "build", "demolish": "demolish", "upgrade": "upgrade", "sell": "sell",
                     "research": "research", "move": "build"}.get(action, "click")
            self.audio.play(sound)
            if action not in ("build", "demolish", "rotate", "move", "set_filter", "set_enabled"):
                self.hud.add_message(msg.get("msg", ""), "success")
            if action == "admin" and fields.get("cmd") in ("kick", "ban", "unban", "login"):
                self.hud.toast_show(msg.get("msg", ""), "success")
                if fields.get("cmd") == "unban":
                    self.admin_bans()
        else:
            self.audio.play("error")
            self.hud.add_message(msg.get("msg", "Aktion fehlgeschlagen."), "error")
            self.hud.toast_show(msg.get("msg", "Aktion fehlgeschlagen."), "error", 2.5)

    # ================================================================== Aktionen
    def _send(self, action, **fields):
        if not self.net or not self.net.connected:
            self.hud.add_message("Keine Verbindung zum Server.", "error")
            return
        rid = self.net.action(action, **fields)
        self.pending[rid] = (action, fields)

    def _send_admin(self, cmd, **fields):
        if not self.net or not self.net.connected:
            return
        self.net._rid += 1
        rid = self.net._rid
        self.net.send({"t": "admin", "cmd": cmd, "rid": rid, **fields})
        self.pending[rid] = ("admin", {"cmd": cmd, **fields})

    def set_tool(self, tool, quiet=False):
        if tool == "menu":
            self.toggle_buy_menu()
            return
        if tool in C.BUILDINGS and not rules.building_on_planet(tool, self.planet):
            self.hud.toast_show(f"{C.BUILDINGS[tool]['name']} gibt es auf dem Mond nicht.", "warn")
            self.audio.play("error")
            return
        if tool in C.BUILDINGS and not rules.building_unlocked(tool, self.state.unlocked, self.planet):
            req = C.RESEARCH[C.BUILDINGS[tool]["requires"]]["name"]
            self.hud.toast_show(f"{C.BUILDINGS[tool]['name']} benötigt die Forschung „{req}“ (R).", "warn")
            self.audio.play("error")
            return
        self.cancel_move()
        self.tool = tool
        self.drag = None
        self.ghost.set_type(tool if tool in C.BUILDINGS else None)
        if tool != "select":
            self.deselect()
        if not quiet:
            self.audio.play("click")

    def _buy_pick(self, btype):
        self.buy_menu.hide()
        self.set_tool(btype)

    def _on_hover_tool(self, tool):
        self.hover_tool = tool

    def _minimap_click(self, x, z):
        self.cam.focus(max(0, min(C.GRID_W - 1, x)), max(0, min(C.GRID_H - 1, z)), smooth=True)

    def build_at(self, btype, x, y, rot, quiet=False):
        ok, reason = self.state.check_build(btype, x, y, rot)
        if not ok:
            if not quiet:
                self.hud.toast_show(reason, "error", 2.0)
                self.audio.play("error")
            return False
        self._send("build", btype=btype, x=x, y=y, rot=rot)
        self.state.grid.setdefault((x, y), -1)      # vorläufig belegt (gegen Doppelklicks beim Ziehen)
        return True

    def demolish_at(self, x, y):
        bid = self.state.grid.get((x, y))
        if bid is None or bid < 0:
            return
        self._send("demolish", id=bid)
        if bid == self.selected:
            self.deselect()

    def select_at(self, x, y):
        bid = self.state.grid.get((x, y))
        if bid is None or bid < 0:
            self.deselect()
            return
        self.selected = bid
        row = self.state.static[bid]
        self.select_frame.enabled = True
        self.select_frame.position = Vec3(row[2], 0.02, row[3])
        self.info.show(row, self.state.dynamic.get(bid), self.state)
        self.audio.play("click")

    def deselect(self):
        self.selected = None
        self.select_frame.enabled = False
        self.info.hide()

    def _selected_row(self):
        return self.state.static.get(self.selected) if self.selected is not None else None

    def upgrade_selected(self):
        if self.selected is not None:
            self._send("upgrade", id=self.selected)

    def rotate_selected(self):
        if self.selected is not None:
            self._send("rotate", id=self.selected)

    def toggle_selected(self):
        row = self._selected_row()
        if row is not None:
            enabled = row[8] if len(row) > 8 else True
            self._send("set_enabled", id=self.selected, enabled=not enabled)

    def set_all_enabled(self, enabled):
        self._send("set_all_enabled", enabled=bool(enabled))

    def demolish_selected(self):
        if self.selected is not None:
            self._send("demolish", id=self.selected)
            self.deselect()

    def set_recipe(self, recipe):
        if self.selected is not None:
            self._send("set_recipe", id=self.selected, recipe=recipe)

    def set_filter(self, item, side):
        if self.selected is not None:
            self._send("set_filter", id=self.selected, item=item, side=side)

    def set_threshold(self, pct):
        if self.selected is not None:
            self._send("set_threshold", id=self.selected, pct=pct)

    def start_move(self):
        row = self._selected_row()
        if row is None:
            return
        self.move_bid = row[0]
        self.tool = "select"
        self.ghost.set_type(row[1])
        self.ghost_rot = row[4]
        self.hud.toast_show(f"{C.BUILDINGS[row[1]]['name']} versetzen: Zielfeld anklicken · E drehen · Esc abbrechen",
                            "info", 3.5)
        self.audio.play("click")

    def cancel_move(self):
        if self.move_bid is not None:
            self.move_bid = None
            self.ghost.set_type(self.tool if self.tool in C.BUILDINGS else None)

    def start_research(self, tech_id):
        ok, reason = rules.check_research(tech_id, self.state.unlocked, self.state.research_active,
                                          self.state.available, self.planet)
        if not ok:
            self.hud.toast_show(reason, "error")
            self.audio.play("error")
            return
        self._send("research", tech=tech_id)

    def sell(self, item, amount):
        self._send("sell", item=item, amount=amount)

    def save_game(self):
        self.settings_menu.hide()
        self._send("save")

    def request_load(self):
        now = time.time()
        if now < self.load_confirm_until:
            self.load_confirm_until = 0
            self.settings_menu.hide()
            self._send("load")
        else:
            self.load_confirm_until = now + 4
            self.hud.toast_show("Laden setzt die Fabrik für ALLE auf den letzten Speicherstand zurück – "
                                "zum Bestätigen innerhalb von 4 s erneut F9 / Laden drücken.", "warn", 4)
            self.audio.play("message")

    def send_chat(self, text):
        token = text.strip().split()[-1] if text.strip() else ""
        if token and rules.check_test_code(token):          # Geheimcode: nicht an andere senden
            self.unlock_test_world(token)
            return
        if self.net:
            self.net.send({"t": "chat", "text": text})

    # ------------------------------------------------------------------ Admin
    def admin_give(self, amount):
        self._send_admin("give_money", amount=amount)

    def admin_kick(self, pid):
        self._send_admin("kick", pid=pid, reason="")

    def admin_ban(self, pid):
        self._send_admin("ban", pid=pid, reason="")

    def admin_set_admin(self, pid, admin):
        self._send_admin("set_admin", pid=pid, admin=bool(admin))

    def admin_unban(self, key):
        self._send_admin("unban", key=key)

    def admin_bans(self):
        self._send_admin("bans")

    def admin_login_send(self, password):
        if password:
            self._send_admin("login", password=password)

    # ------------------------------------------------------------------ Fenster
    def _toggle_window(self, win):
        was = win.visible
        for w in self.windows:
            if w is not win:
                w.hide()
        if was:
            win.hide()
        else:
            win.show()
        return win.visible

    def toggle_orders(self):
        if self._toggle_window(self.orders_win):
            self.orders_win.refresh(self.state)

    def _on_truck(self, view, away):
        """LKW eines Frachtbahnhofs fährt los: auf der Landstraße mitfahren lassen."""
        if away and self._in_game() and view in self.views.values():
            self.world.traffic.dispatch(view.x)

    # ------------------------------------------------------------------ Updates
    def _news_primary(self):
        mode = getattr(self.news_win, "mode", "news")
        if mode == "news":
            self.news_win.hide()
        elif mode == "full":
            import webbrowser
            page = (self.updater.info or {}).get("download_page") or (self.updater.info or {}).get("url", "")
            if page:
                webbrowser.open(page)
            self.news_win.hide()
        else:
            self.news_win.set_busy(True)
            self.news_win.set_progress(0, "Lade Update …")
            self.updater.download_async()

    # ------------------------------------------------------------------ Live-Updates im Spiel
    RESUME_FILE = os.path.join(C.DATA_DIR, "resume.json")
    UPDATE_CHECK_EVERY = 60.0

    def _update_now(self):
        u = self.updater
        if u.needs_full_download:
            import webbrowser
            page = (u.info or {}).get("download_page") or ""
            if page:
                webbrowser.open(page)
            return
        if u.state in ("available", "error"):
            u.state = "available"
            u.download_async()

    def _update_later(self):
        if self.updater.info:
            self._upd_dismissed = (self.updater.info.get("version"), time.time())
        self._set_badge(None)

    def _set_badge(self, mode, **kw):
        key = (mode, kw.get("version"), round(kw.get("progress", 0), 2), kw.get("text"))
        if key != self._upd_badge:
            self._upd_badge = key
            self.hud.update_badge(mode, **kw)

    def _write_resume(self):
        """Vor dem Neustart nach einem Update: wohin es danach automatisch zurückgeht."""
        if not self._in_game() or not self.session or not self.connect_params:
            return
        try:
            name, host, port, pw = self.connect_params
            data = {"t": time.time(), "session": {k: v for k, v in self.session.items()
                                                    if k in ("mode", "port", "extra", "entered")},
                    "connect": [name, host, str(port), pw],
                    "cam": [self.cam.x, self.cam.z, self.cam.distance, self.cam.yaw, self.cam.pitch]}
            with open(self.RESUME_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except Exception as exc:
            print("[Update] Fortsetzen nicht vorbereitet:", exc)

    def _take_resume(self):
        try:
            with open(self.RESUME_FILE, encoding="utf-8") as f:
                data = json.load(f)
            os.remove(self.RESUME_FILE)
        except (OSError, ValueError):
            return None
        if not isinstance(data, dict) or time.time() - float(data.get("t", 0)) > 300:
            return None
        return data

    def _resume_after_update(self, data):
        sess = data.get("session") or {}
        name, host, port, pw = (list(data.get("connect") or []) + ["", "", "", ""])[:4]
        self._resume_cam = data.get("cam")
        mode = sess.get("mode")
        if mode in ("single", "host"):
            extra = [str(a) for a in sess.get("extra", [])]
            clean, skip = [], False
            for a in extra:                            # Welt fortsetzen, nicht neu anlegen
                if skip:
                    skip = False
                    continue
                if a == "--new":
                    continue
                if a == "--seed":
                    skip = True
                    continue
                clean.append(a)
            port_num = int(sess.get("port") or self._free_port())
            if mode == "single":
                port_num = self._free_port()
            self.session = {"mode": mode, "port": port_num, "extra": clean, "new": False, "counted": True}
            if self._spawn_server(port_num, clean):
                self.connect(name or self._player_name(), "127.0.0.1", str(port_num), pw, start_local=True)
            else:
                self._show_menu()
        elif mode == "join":
            self.join_game(name, sess.get("entered") or host, port, pw)
        else:
            self._show_menu()

    def _news_later(self):
        if self.updater.state != "downloading":
            self.news_win.hide()

    def _poll_updater(self):
        u = self.updater
        # regelmäßig erneut nachsehen – auch mitten im Spiel
        self._upd_check_t += min(utime.dt, 0.5)
        if self._upd_check_t >= self.UPDATE_CHECK_EVERY:
            self._upd_check_t = 0.0
            if u.state in ("none", "idle"):
                u.check_async()
        # Hinweis oben rechts im Spiel
        if self._in_game():
            ver = (u.info or {}).get("version", "")
            dis = self._upd_dismissed
            hidden = dis is not None and dis[0] == ver and time.time() - dis[1] < 600
            if u.state == "available" and not hidden:
                txt = ("Großes Update – bitte einmal neu herunterladen." if u.needs_full_download else "")
                self._set_badge("available", version=ver, text=txt)
            elif u.state == "downloading":
                self._set_badge("downloading", version=ver, progress=u.progress)
            elif u.state == "error" and not hidden:
                self._set_badge("error", version=ver, text=u.error)
            elif u.state == "ready":
                left = max(0, int((self._restart_at or time.time() + 4) - time.time()) + 1)
                self._set_badge("ready", version=ver,
                                text=f"Das Spiel speichert und lädt in {left} s kurz neu – danach geht es genau hier weiter.")
            elif u.state in ("none", "idle", "checking") or hidden:
                self._set_badge(None)
        if u.state == "available" and not self._update_offered and self.menu.visible \
                and not self.news_win.visible and not self._news_pending:
            self._update_offered = True
            self.news_win.show_update(u.info["version"], u.notes(), full_download=u.needs_full_download)
        elif u.state == "downloading" and self.news_win.visible:
            self.news_win.set_progress(u.progress, f"Lade Update … {u.progress * 100:.0f} %")
        elif u.state == "error" and self.news_win.visible and getattr(self.news_win, "mode", "") == "update":
            u.state = "available"
            self.news_win.set_busy(False)
            self.news_win.set_progress(0, f"Update fehlgeschlagen: {u.error[:120]} – nochmal versuchen?", BAD)
        elif u.state == "ready" and self._restart_at is None:
            self.news_win.set_progress(1.0, "Update installiert – das Spiel startet neu …", GOOD)
            self._restart_at = time.time() + (4.0 if self._in_game() else 1.5)
        if self._restart_at is not None and time.time() >= self._restart_at:
            self._restart_at = float("inf")
            try:
                self._write_resume()
                self._shutdown()
                u.restart()
            finally:
                application.quit()

    def _update_discord(self):
        """Was Discord bei deinem Profil anzeigt (wird im Hintergrund alle 15 s übertragen)."""
        if not self.discord.enabled:
            return
        if not self._in_game() or self.session is None:
            self._session_start = None
            self.discord.set_info("Im Hauptmenü")
            return
        if self._session_start is None:
            self._session_start = time.time()
        st = self.state
        mode = self.session.get("mode")
        machines = sum(1 for row in st.static.values() if row[1] not in C.BELT_LIKE)
        from .ui import short_money
        state = f"{short_money(st.money)} · {machines} Maschinen"
        if mode == "single":
            details = f"Einzelspieler · Welt {self.settings['sp_slot']}"
            party = None
        else:
            details = "Mehrspieler · " + ("hostet eine Fabrik" if mode == "host" else "baut mit Freunden")
            party = (max(1, len(st.players)), C.MAX_PLAYERS)
        if self.planet == "moon":
            state = state.replace("€", "MC")
            details = "Auf dem Mond · " + details
        if self.moon_preview and not rules.moon_open(False):
            # geheime Test-Welt: in Discord nichts verraten
            details, state = "Einzelspieler", f"{machines} Maschinen"
        self.discord.set_info(details, state, start=self._session_start, party=party)

    def _stat(self, key, amount=1):
        self._achievements(self.stats.add(key, amount))

    def _achievements(self, new):
        for name, desc in new:
            self.hud.toast_show(f"Erfolg freigeschaltet: {name} – {desc}", "success", 4.5)
            self.hud.add_message(f"Erfolg: {name} ({desc})", "success")
            self.audio.play("achievement")

    def _track_state(self):
        """Statistik aus dem Serverzustand: verdientes Geld, hergestellte Waren, Forschung."""
        st = self.state
        if st.planet == "moon":            # Mooncoins zählen nicht als Euro
            self._last_money = None
            self._achievements(self.stats.peak("max_mooncoins", st.money))
            rov = (st.produced or {}).get("rover", 0)
            if self._last_rovers is not None and rov > self._last_rovers:
                self._stat("rovers", rov - self._last_rovers)
            self._last_rovers = rov
            n = sum(st.produced.values()) if st.produced else 0
            if self._last_produced is not None and n > self._last_produced:
                self._stat("produced", n - self._last_produced)
            self._last_produced = n
            return
        if self._last_money is not None and st.money > self._last_money:
            self._stat("earned", st.money - self._last_money)
        self._last_money = st.money
        self._achievements(self.stats.peak("max_money", st.money))
        total = sum(st.produced.values()) if st.produced else 0
        if self._last_produced is not None and total > self._last_produced:
            self._stat("produced", total - self._last_produced)
        self._last_produced = total
        n = len(st.unlocked)
        if self._last_unlocked is not None and n > self._last_unlocked:
            self._stat("research", n - self._last_unlocked)
        self._last_unlocked = n

    def toggle_help(self):
        self._toggle_window(self.help_win)

    def toggle_admin(self):
        if self._toggle_window(self.admin_panel):
            self.admin_panel.refresh(self.state, self.my_id, self.is_admin, self.admin_login)
            if self.is_admin:
                self.admin_bans()

    def toggle_buy_menu(self):
        if self._toggle_window(self.buy_menu):
            self.buy_menu.refresh(self.state, self.tool)

    # ================================================================== Eingabe
    def input(self, key):
        try:
            self._input(key)
        except Exception:
            self._report_error()

    def update(self):
        try:
            self._update()
        except Exception:
            self._report_error()

    def _report_error(self):
        """Ein Fehler im Spiel soll nie zum Absturz führen: Fehler ins Log schreiben, kurz anzeigen, weiterspielen."""
        import traceback
        text = traceback.format_exc()
        print(text, file=sys.stderr, flush=True)
        now = time.time()
        if now - getattr(self, "_last_error_shown", 0) > 10:
            self._last_error_shown = now
            last = text.strip().splitlines()[-1][:120]
            try:
                self.hud.add_message(f"Interner Fehler (Spiel läuft weiter): {last} - Details in client.log", "error")
            except Exception:
                pass

    def _input(self, key):
        if key == "f11":
            self.set_fullscreen(not self._fullscreen)
            self.settings.save()
            return
        if self.settings_menu.capturing:               # Optionen » Steuerung: neue Taste wird gedrückt
            self.settings_menu.capture(key)
            return
        if self.cinematic is not None:                 # Kinofahrt: nur Esc (überspringen, falls möglich)
            if key == "escape":
                self.cinematic.skip()
            return
        if self.chat.active:
            if key == "enter":
                self.chat.submit()
            elif key == "escape":
                self.chat.close()
            return
        if self.menu.visible:
            if self.settings_menu.visible or self.help_win.visible or self.stats_win.visible \
                    or self.news_win.visible:
                if key == "escape":
                    if self.news_win.visible:
                        self._news_later()
                    elif self.stats_win.visible:
                        self.stats_win.hide()
                    elif self.help_win.visible:
                        self.help_win.hide()
                    else:
                        self.settings_menu.hide()
                return
            if key == "enter":
                self.menu.submit()
            elif key == "escape":
                self.menu.close_page()
            return
        if not self._in_game() or self._typing():
            return

        if key == "escape":
            if self._any_window():
                self._close_windows()
            elif self.move_bid is not None:
                self.cancel_move()
            elif self.tool != "select" or self.selected is not None:
                self.set_tool("select", quiet=True)
                self.deselect()
            else:
                self.settings_menu.set_menu_mode(False)
                self.settings_menu.sync()
                self._toggle_window(self.settings_menu)
            return
        action = self._key_actions.get(key)
        if key == "enter" or action == "chat":
            self.chat.open()
            return
        if action == "buy_menu":
            self.toggle_buy_menu()
        elif action == "rocket":
            self.start_launch()
        elif action == "orders":
            if self.planet == "moon":
                self.hud.toast_show("Aufträge gibt es nur auf der Erde – auf dem Mond gibt es keine Städte.", "warn")
                return
            self.toggle_orders()
        elif action == "research":
            if self._toggle_window(self.research_win):
                self.research_win.refresh(self.state)
        elif action == "market":
            if self._toggle_window(self.market_win):
                self.market_win.refresh(self.state)
        elif action == "help":
            self.toggle_help()
        elif action == "admin":
            self.toggle_admin()
        elif action == "save":
            self.save_game()
        elif action == "load":
            self.request_load()
        elif self._any_window():
            return                                      # restliche Tasten nur ohne offenes Fenster
        elif key in BUILD_KEYS:
            self.set_tool(BUILD_KEYS[key])
        elif action == "demolish":
            self.set_tool("demolish")
        elif action == "select":
            self.set_tool("select")
        elif action == "rotate":
            if self.tool in C.BUILDINGS or self.move_bid is not None:
                self.ghost_rot = (self.ghost_rot + (-1 if held_keys["shift"] else 1)) % 4
                self.audio.play("click")
            else:
                self.rotate_selected()
        elif action == "toggle":
            self.toggle_selected()
        elif action == "move":
            self.start_move()
        elif action == "upgrade":
            self.upgrade_selected()
        elif key in ("delete", "backspace"):
            self.demolish_selected()
        elif key == "left mouse down":
            self._on_click()
        elif key == "left mouse up":
            self._finish_drag()

    def _on_click(self):
        if self._mouse_over_ui() or self.hover_tile is None:
            return
        x, y = self.hover_tile
        if self.move_bid is not None:
            ok, reason = self.state.check_move(self.move_bid, x, y, self.ghost_rot)
            if ok:
                self._send("move", id=self.move_bid, x=x, y=y, rot=self.ghost_rot)
                self.move_bid = None
                self.ghost.set_type(None)
            else:
                self.hud.toast_show(reason, "error", 2)
                self.audio.play("error")
            return
        if self.tool == "conveyor":
            self.drag = {"cur": (x, y), "rot": self.ghost_rot, "built": set()}
        elif self.tool in C.BUILDINGS:
            self.build_at(self.tool, x, y, self.ghost_rot)
        elif self.tool == "demolish":
            self.demolish_at(x, y)
            self.drag = {"cur": (x, y)}
        else:
            self.select_at(x, y)

    def _update_drag(self):
        if not self.drag or not mouse.left or self.hover_tile is None:
            return
        tile = self.hover_tile
        if self.tool == "demolish":
            if tile != self.drag["cur"]:
                self.drag["cur"] = tile
                self.demolish_at(*tile)
            return
        if self.tool != "conveyor":
            return
        cx, cy = self.drag["cur"]
        tx, ty = tile
        steps = 0
        while (cx, cy) != (tx, ty) and steps < 64:
            steps += 1
            if cx != tx:
                nx, ny = cx + (1 if tx > cx else -1), cy
            else:
                nx, ny = cx, cy + (1 if ty > cy else -1)
            rot = C.DIRS.index((nx - cx, ny - cy))
            self.build_at("conveyor", cx, cy, rot, quiet=True)
            self.drag["built"].add((cx, cy))
            cx, cy = nx, ny
            self.drag["rot"] = rot
            self.ghost_rot = rot
        self.drag["cur"] = (cx, cy)

    def _finish_drag(self):
        if self.drag and self.tool == "conveyor":
            cur = self.drag["cur"]
            if cur not in self.drag["built"]:
                self.build_at("conveyor", cur[0], cur[1], self.drag["rot"], quiet=bool(self.drag["built"]))
        self.drag = None

    # ================================================================== Frame-Update
    def _update(self):
        job = self._connect_job
        if job and job["done"]:
            self._finish_connect(job)
        self._process_network()
        dt = min(utime.dt, 0.1)
        anim.update(dt)
        self._prune_t = getattr(self, "_prune_t", 0.0) + dt
        if self._prune_t > 2.0:
            self._prune_t = 0.0
            self._prune_entity_list()
        self.world.update(dt)
        self.particles.update(dt)
        self._update_badges()
        self._achievements(self.stats.tick(dt, self._in_game()))
        self._poll_updater()
        self._busy_t += dt
        if self._busy_t >= 0.5:
            self._busy_t = 0.0
            if self._in_game():
                counts = self.state.status_counts()
                working = counts.get("ok", 0)
                self._busy = min(1.0, working / 25.0)
            else:
                self._busy = 0.0
        self.audio.update(dt, self._in_game(), self.cam.distance, self._busy)
        if self.cinematic is not None:
            try:
                self.cinematic.update(dt)
            except Exception:
                self._report_error()
                try:
                    self.cinematic.finish()
                except Exception:
                    pass
                self.cinematic.done = True
            if self.cinematic.done:
                self.cinematic = None
        elif self._in_game() and self.world.launchpad is not None:
            sign = (self.planet, self.state.rocket_unlocked)
            if sign != getattr(self, "_rocket_sign", None) and not self.world.launchpad.busy:
                self._rocket_sign = sign
                self.world.launchpad.set_planet(self.planet, locked=not self.state.rocket_unlocked)
        if self.cinematic is None and not self._moon_open and rules.moon_open(self.moon_preview):
            # Countdown gerade abgelaufen: Baustelle wird zur Startrampe (mit Enthüllung, wenn im Spiel)
            self._moon_open = True
            self.world.set_launch(True)
            if self.world.launchpad is not None:
                self.world.launchpad.on_click = self.start_launch
            if self._in_game():
                self._maybe_reveal()
        self._discord_t += dt
        if self._discord_t >= 5.0:
            self._discord_t = 0.0
            self._update_discord()
        typing = self._typing()
        blocked = typing or self._any_window()
        self.cam.input_blocked = blocked
        self._update_mouse_lock()
        if self.settings["show_fps"] and utime.dt > 0:
            self.fps_label.text = f"{1 / max(utime.dt, 1e-3):.0f} FPS"

        if not self._in_game():
            if self.menu.visible:
                for view in self.showcase:
                    view.animate(dt, C.BELT_SPEED)
                if abs(window.aspect_ratio - getattr(self, "_menu_aspect", 0)) > 1e-3:
                    self._menu_aspect = window.aspect_ratio
                    self.anchors.refresh_positions()
                    self.menu.fit(self.settings["gui_scale"])
            return

        if self.cinematic is None:
            self._update_hover(dt)
            self._update_drag()
            self.tutorial.update(dt)

        belt_speed = C.BELT_SPEED * self.state.mods.get("belt", 1.0)
        self.batcher.update(dt, (self.cam.x, self.cam.z), self._detail_radius(), belt_speed)
        self.particles.distant = self.cam.distance > 42
        self._cull_t += dt
        if self._cull_t >= 0.15 or self._cull_dirty:
            self._cull_t = 0.0
            self._update_visibility()
        # Viele Gebäude im Bild: abwechselnd jede zweite Hälfte animieren (mit doppeltem Zeitschritt).
        # Das halbiert die Rechenzeit, sieht aber bei 60 FPS praktisch gleich flüssig aus.
        far = self._far_belts
        if far:
            # ferne Bänder: jeweils ein Drittel pro Bild (mit dreifachem Zeitschritt)
            self._far_phase = (self._far_phase + 1) % 3
            for v in far[self._far_phase::3]:
                v.move_items(dt * 3, belt_speed)
        views = self._visible_views
        if len(views) > 60:
            self._anim_phase ^= 1
            for view in views[self._anim_phase::2]:
                view.animate(dt * 2, belt_speed)
        else:
            for view in views:
                view.animate(dt, belt_speed)
        for cur in self.avatars.values():
            cur.update(dt)
        self.hud.minimap.update_view(self.cam.x, self.cam.z, self.cam.yaw, self.cam.distance, dt)
        self.hud.update()

        t = self._timers
        for k in t:
            t[k] += dt
        if t["pos"] >= 0.1:
            t["pos"] = 0
            # Mitspieler sehen nur unseren Mauszeiger: Punkt auf dem Boden, auf den die Maus zeigt
            p = self._cursor_point
            msg = {"t": "pos", "x": round(p[0], 2) if p else round(self.cam.x, 2),
                   "z": round(p[1], 2) if p else round(self.cam.z, 2), "cur": p is not None, "tool": self.tool}
            if msg != self._last_pos_msg:
                self._last_pos_msg = msg
                self.net.send(msg)
        if t["ping"] >= 2.0:
            t["ping"] = 0
            self.net.ping()
        if t["ui"] >= 0.2:
            t["ui"] = 0
            self.hud.refresh(self.state, self.net.ping_ms if self.net else None, self.tool, False)
            if self.research_win.visible:
                self.research_win.refresh(self.state)
            if self.market_win.visible:
                self.market_win.refresh(self.state)
            if self.orders_win.visible:
                self.orders_win.refresh(self.state)
            if self.buy_menu.visible:
                self.buy_menu.refresh(self.state, self.tool)
            if self.admin_panel.visible:
                self.admin_panel.refresh(self.state, self.my_id, self.is_admin, self.admin_login)
        if t["map"] >= 0.5:
            t["map"] = 0
            if abs(window.aspect_ratio - getattr(self, "_last_aspect", 0)) > 1e-3:
                self._last_aspect = window.aspect_ratio      # Fenstergröße geändert: Layout neu einpassen
                self.apply_gui_scale(self.settings["gui_scale"])
            self._blink = not self._blink
            self.hud.minimap.update(self.state, self.cam.x, self.cam.z, self.state.players, self.my_id, self._blink)

    def _update_hover(self, dt):
        tile = None
        over_ui = self._mouse_over_ui()
        if not over_ui and mouse.hovered_entity == self.world.ground and mouse.world_point is not None:
            p = mouse.world_point
        else:
            p = None
        self._cursor_point = (p.x, p.z) if p is not None else None
        if p is not None:
            tx, ty = int(round(p.x)), int(round(p.z))
            if rules.in_bounds(tx, ty):
                tile = (tx, ty)
        self.hover_tile = tile

        if self.hover_tool and self.hover_tool in C.BUILDINGS and over_ui:
            spec = C.BUILDINGS[self.hover_tool]
            locked = not rules.building_unlocked(self.hover_tool, self.state.unlocked, self.planet)
            sub = spec["desc"]
            if locked:
                sub = f"Gesperrt – benötigt Forschung: {C.RESEARCH[spec['requires']]['name']}"
            if not rules.building_on_planet(self.hover_tool, self.planet):
                locked, sub = True, "Gibt es auf dem Mond nicht."
            key = f"[{spec['hotkey']}] " if spec["hotkey"] else ""
            self.hud.set_hint(f"{key}{spec['name']} – {rules.format_money(spec['cost'])}", sub,
                              TEXT, BAD if locked else MUTED)
            self.ghost.enabled = False
            self.hover_frame.enabled = False
            return

        if tile is None:
            self.ghost.enabled = False
            self.hover_frame.enabled = False
            self._default_hint()
            return

        x, y = tile
        if self.move_bid is not None:
            self.hover_frame.enabled = False
            ok, reason = self.state.check_move(self.move_bid, x, y, self.ghost_rot)
            self.ghost.show(x, y, self.ghost_rot, ok, dt)
            row = self.state.static.get(self.move_bid)
            name = C.BUILDINGS[row[1]]["name"] if row else "Gebäude"
            self.hud.set_hint(f"{name} versetzen – Ausrichtung {C.DIR_NAMES[self.ghost_rot]} (E drehen, Esc abbrechen)",
                              "Linksklick setzt das Gebäude hier ab" if ok else "Nicht möglich: " + reason,
                              TEXT, MUTED if ok else BAD)
        elif self.tool in C.BUILDINGS:
            self.hover_frame.enabled = False
            ok, reason = self.state.check_build(self.tool, x, y, self.ghost_rot)
            self.ghost.show(x, y, self.ghost_rot, ok, dt)
            spec = C.BUILDINGS[self.tool]
            title = f"{spec['name']} bauen – {rules.format_money(spec['cost'])} – Richtung {C.DIR_NAMES[self.ghost_rot]} (E drehen)"
            if self.tool == "conveyor":
                title += " – gedrückt halten und ziehen"
            if ok:
                self.hud.set_hint(title, spec["desc"], TEXT)
            else:
                self.hud.set_hint(title, "Nicht möglich: " + reason, TEXT, BAD)
        else:
            self.ghost.enabled = False
            self.hover_frame.enabled = True
            self.hover_frame.position = Vec3(x, 0.02, y)
            row = self.state.building_at(x, y)
            if self.tool == "demolish":
                self.hover_frame.set_color(color.rgba(1, 0.3, 0.25, 1))
                if row:
                    refund = rules.demolish_refund(row[1], row[5])
                    self.hud.set_hint(f"{C.BUILDINGS[row[1]]['name']} abreißen (+{rules.format_money(refund)})",
                                      "Linksklick (ziehen für mehrere)", WARN)
                else:
                    self.hud.set_hint("Abrisswerkzeug", "Gebäude anklicken · Esc oder Leertaste beendet", WARN)
            else:
                self.hover_frame.set_color(color.rgba(1, 1, 1, 0.7))
                if row:
                    dyn = self.state.dynamic.get(row[0])
                    st = C.STATUS.get(dyn[0], {"text": "?"})["text"] if dyn else "?"
                    self.hud.set_hint(f"{C.BUILDINGS[row[1]]['name']} – {st}", "Linksklick für Details", TEXT)
                else:
                    ore = self.state.deposits.get((x, y))
                    sub = f"Erzvorkommen: {C.ITEMS[ore]['name']} – hier kann ein Miner stehen" if ore else ""
                    self._default_hint(sub)

    def _default_hint(self, sub=""):
        if self.move_bid is not None:
            self.hud.set_hint("Gebäude versetzen", "Zielfeld auf der Baufläche anklicken · Esc bricht ab", MUTED)
        elif self.tool == "select":
            k = rules.keymap(self.settings["keys"])["buy_menu"]
            main = ("Q: Kaufmenü · 1–9: Gebäude wählen · Gebäude anklicken für Details" if k == "q" else
                    f"{rules.key_label(k)}: Kaufmenü · 1–9: Gebäude wählen · Gebäude anklicken für Details")
            self.hud.set_hint(main,
                              sub or "Rechte Maustaste: drehen · Mausrad: Zoom · WASD: bewegen · Karte anklicken: hinfahren",
                              MUTED)
        elif self.tool == "demolish":
            self.hud.set_hint("Abrisswerkzeug", "Gebäude anklicken · Esc oder Leertaste beendet", WARN)
        else:
            self.hud.set_hint(f"{C.BUILDINGS[self.tool]['name']} bauen", sub or "Zeige auf die Baufläche", MUTED)
