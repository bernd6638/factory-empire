"""
Landschaft rund um die Fabrik: dichter Wald, der zum Horizont hin dünner wird und im Dunst
verschwindet, eine Landstraße mit Verkehr (auch die eigenen Liefer-LKW fahren dort los).

Der Wald besteht aus tausenden Bäumen. Damit das schnell geht, werden sie nicht über Ursinas
Mesh-Klasse, sondern direkt als Panda3D-Vertexdaten (array-Puffer) erzeugt: wenige große Modelle,
je Himmelsrichtung eines (damit die Grafikkarte Unsichtbares überspringen kann).
"""

import math
import random
from array import array

from panda3d.core import (Geom, GeomNode, GeomTriangles, GeomVertexArrayFormat, GeomVertexData,
                          GeomVertexFormat, NodePath)
from ursina import Entity

from . import config as C
from . import graphics
from . import models
from . import textures

HAZE = (0.74, 0.81, 0.88)              # Dunstfarbe am Horizont (passt zum Himmel)
ROAD_Z = C.GRID_H + 2.3                 # Landstraße hinter dem Südzaun
ROAD_W = 2.3
SECTORS = 8

_FMT = None


def _format():
    global _FMT
    if _FMT is None:
        a = GeomVertexArrayFormat()
        a.addColumn("vertex", 3, Geom.NT_float32, Geom.C_point)
        a.addColumn("normal", 3, Geom.NT_float32, Geom.C_normal)
        a.addColumn("color", 4, Geom.NT_float32, Geom.C_color)
        a.addColumn("texcoord", 2, Geom.NT_float32, Geom.C_texcoord)
        _FMT = GeomVertexFormat.registerFormat(GeomVertexFormat(a))
    return _FMT


def _cone(n, slope=0.55):
    """Kegel ohne Boden (glatte Normalen): Spitze + n Randpunkte."""
    verts = [((0.0, 1.0, 0.0), (0.0, 1.0, 0.0))]
    for i in range(n):
        a = 2 * math.pi * i / n
        nx, nz = math.cos(a), math.sin(a)
        ln = math.sqrt(1 + slope * slope)
        verts.append(((nx * 0.5, 0.0, nz * 0.5), (nx / ln, slope / ln, nz / ln)))
    tris = [(0, 1 + (i + 1) % n, 1 + i) for i in range(n)]
    return verts, tris


def _blob():
    """Runde Laubkrone (gestauchtes Oktaeder mit 8 Seiten)."""
    pts = [(0, 1, 0), (0, -1, 0)] + [(math.cos(2 * math.pi * i / 6), 0.15, math.sin(2 * math.pi * i / 6))
                                    for i in range(6)]
    verts = []
    for p in pts:
        ln = math.sqrt(sum(c * c for c in p)) or 1
        verts.append(((p[0] * 0.5, p[1] * 0.5, p[2] * 0.5), (p[0] / ln, p[1] / ln, p[2] / ln)))
    tris = []
    for i in range(6):
        a, b = 2 + i, 2 + (i + 1) % 6
        tris += [(0, b, a), (1, a, b)]
    return verts, tris


def _trunk():
    """Stamm (4 Seiten, für nahe Bäume)."""
    verts, tris = [], []
    for i in range(4):
        a = math.pi / 4 + i * math.pi / 2
        nx, nz = math.cos(a), math.sin(a)
        verts += [((nx * 0.5, 0.0, nz * 0.5), (nx, 0, nz)), ((nx * 0.5, 1.0, nz * 0.5), (nx, 0, nz))]
    for i in range(4):
        a0, a1 = 2 * i, 2 * ((i + 1) % 4)
        tris += [(a0, a1, a1 + 1), (a0, a1 + 1, a0 + 1)]
    return verts, tris


CONE6 = _cone(7)
BLOB = _blob()
TRUNK = _trunk()


class _Batch:
    def __init__(self):
        self.data = array("f")
        self.idx = array("I")
        self.n = 0

    def add(self, shape, x, y, z, sx, sy, sz, col):
        verts, tris = shape
        o = self.n
        d = self.data
        r, g, b = col
        for (px, py, pz), (nx, ny, nz) in verts:
            wx, wy, wz = x + px * sx, y + py * sy, z + pz * sz
            d.extend((wx, wy, wz, nx, ny, nz, r, g, b, 1.0, wx * 0.35, (wy + wz) * 0.35))
        self.n += len(verts)
        self.idx.extend(i + o for t in tris for i in t)

    def node(self, name):
        if not self.n:
            return None
        vd = GeomVertexData(name, _format(), Geom.UH_static)
        vd.setNumRows(self.n)
        vd.modifyArray(0).modifyHandle().copyDataFrom(self.data)
        prim = GeomTriangles(Geom.UH_static)
        prim.setIndexType(Geom.NT_uint32)
        prim.modifyVertices().modifyHandle().copyDataFrom(self.idx)
        geom = Geom(vd)
        geom.addPrimitive(prim)
        gn = GeomNode(name)
        gn.addGeom(geom)
        return NodePath(gn)


def _mix(c, k):
    return (c[0] + (HAZE[0] - c[0]) * k, c[1] + (HAZE[1] - c[1]) * k, c[2] + (HAZE[2] - c[2]) * k)


def build_forest(center, height_fn, factory_distance, skip_fn, seed=9090, spacing=2.7, reach=165.0):
    """Erzeugt den Waldgürtel. Gibt ein Entity zurück, das alle Abschnitts-Modelle enthält."""
    rng = random.Random(seed)
    crowns = [_Batch() for _ in range(SECTORS)]
    trunks = [_Batch() for _ in range(SECTORS)]
    cx, cz = center.x, center.z
    steps = int(reach * 2 / spacing)
    for i in range(steps):
        for j in range(steps):
            x = cx - reach + (i + rng.random()) * spacing
            z = cz - reach + (j + rng.random()) * spacing
            d = factory_distance(x, z)
            if d < 8.0 or skip_fn(x, z):
                continue
            dense = min(1.0, (d - 8.0) / 12.0)                      # am Fabrikrand lichter Waldsaum
            thin = 1.0 - max(0.0, min(1.0, (d - 95.0) / 70.0)) * 0.75   # zum Horizont hin dünner
            if rng.random() > dense * thin * 0.9:
                continue
            y = height_fn(x, z) - 0.1
            haze = max(0.0, min(0.8, (d - 30.0) / 130.0))
            sector = int((math.atan2(z - cz, x - cx) + math.pi) / (2 * math.pi) * SECTORS) % SECTORS
            s = rng.uniform(0.85, 1.6) * (1.0 + min(0.4, d / 250.0))
            if rng.random() < 0.68:                                  # Nadelbaum
                g = (0.13 + rng.uniform(-0.03, 0.03), 0.30 + rng.uniform(-0.05, 0.05), 0.15)
                h = 2.6 * s
                w = 1.25 * s
                if d < 45.0:                                        # weiter weg sieht man den Stamm nicht
                    trunks[sector].add(TRUNK, x, y, z, 0.16 * s, 0.6 * s, 0.16 * s, _mix((0.32, 0.22, 0.14), haze))
                crowns[sector].add(CONE6, x, y + 0.45 * s, z, w, h * 0.62, w, _mix(g, haze))
                crowns[sector].add(CONE6, x, y + 1.25 * s, z, w * 0.72, h * 0.5, w * 0.72,
                                   _mix((g[0] * 1.15, g[1] * 1.12, g[2] * 1.1), haze))
            else:                                                    # Laubbaum
                g = (0.24 + rng.uniform(-0.05, 0.05), 0.44 + rng.uniform(-0.07, 0.06), 0.17)
                trunks[sector].add(TRUNK, x, y, z, 0.18 * s, 1.1 * s, 0.18 * s, _mix((0.36, 0.26, 0.17), haze))
                crowns[sector].add(BLOB, x, y + 1.6 * s, z, 1.9 * s, 1.6 * s, 1.9 * s, _mix(g, haze))
    lit = graphics.lit_shader()
    root = Entity(add_to_scene_entities=False)
    crown_holder = Entity(parent=root, shader=lit, add_to_scene_entities=False)
    trunk_holder = Entity(parent=root, shader=lit, add_to_scene_entities=False)
    for holder, tex in ((crown_holder, "leaves"), (trunk_holder, "bark")):
        t = textures.texture(tex)
        if t is not None:
            holder.setTexture(t._texture, 1)
    for k in range(SECTORS):
        for batch, holder, name in ((crowns[k], crown_holder, "crowns"), (trunks[k], trunk_holder, "trunks")):
            np = batch.node(f"forest_{name}_{k}")
            if np is not None:
                np.reparentTo(holder)
    return root


# ----------------------------------------------------------------------------- Straße
def build_road(center, reach=170.0):
    """Landstraße entlang der Südseite: Asphalt, Randlinien, Mittelstreifen, Leitpfosten."""
    mb = models.MeshBuilder(0.5)
    x0, x1 = center.x - reach, center.x + reach
    length = x1 - x0
    mid = (x0 + x1) / 2
    mb.add("box", (mid, -0.01, ROAD_Z), (length, 0.06, ROAD_W + 0.6), (0.42, 0.40, 0.36))     # Bankett
    mb.add("box", (mid, 0.01, ROAD_Z), (length, 0.06, ROAD_W), (0.22, 0.23, 0.25))           # Asphalt
    for side in (-1, 1):
        mb.add("box", (mid, 0.045, ROAD_Z + side * (ROAD_W / 2 - 0.12)), (length, 0.005, 0.07), (0.92, 0.92, 0.9))
    x = x0
    while x < x1:
        mb.add("box", (x + 0.6, 0.045, ROAD_Z), (1.2, 0.005, 0.07), (0.95, 0.85, 0.35))
        x += 3.0
    x = x0
    while x < x1:
        for side in (-1, 1):
            mb.add("box", (x, 0.3, ROAD_Z + side * (ROAD_W / 2 + 0.25)), (0.07, 0.6, 0.07), (0.92, 0.92, 0.9))
            mb.add("box", (x, 0.5, ROAD_Z + side * (ROAD_W / 2 + 0.25)), (0.075, 0.08, 0.075), (0.15, 0.15, 0.15))
        x += 6.0
    e = Entity(model=mb.build(), shader=graphics.lit_shader(), add_to_scene_entities=False)
    t = textures.texture("rock")
    if t is not None:
        e.setTexture(t._texture, 1)
    return e


VEHICLE_COLORS = [(0.85, 0.2, 0.18), (0.92, 0.92, 0.94), (0.2, 0.42, 0.75), (0.95, 0.72, 0.15),
                  (0.25, 0.55, 0.3), (0.55, 0.57, 0.6), (0.12, 0.13, 0.15)]


def car_parts(body):
    tire = (0.07, 0.07, 0.08)
    parts = [("box", (0, 0.13, 0), (0.22, 0.09, 0.42), body),
             ("box", (0, 0.21, -0.02), (0.2, 0.08, 0.22), (0.3, 0.38, 0.48)),
             ("box", (0, 0.255, -0.02), (0.19, 0.012, 0.2), body)]
    for zz in (0.13, -0.13):
        for xx in (0.1, -0.1):
            parts.append(("cyl", (xx, 0.07, zz), tire, (0.08, 0.08, 0.09), (0, 0, 90)))
    return parts


class Traffic:
    """Fahrzeuge auf der Landstraße (Endlosschleife) plus abfahrende Liefer-LKW."""

    def __init__(self, center, reach=160.0, count=9):
        self.center = center
        self.reach = reach
        self.vehicles = []
        self.meshes = {}
        rng = random.Random(31)
        for i in range(count):
            direction = 1 if i % 2 == 0 else -1
            kind = "truck" if rng.random() < 0.45 else "car"
            col = rng.choice(VEHICLE_COLORS)
            x = center.x + rng.uniform(-reach, reach)
            self._spawn(kind, col, x, direction, rng.uniform(5.0, 8.5) if kind == "car" else rng.uniform(4.0, 6.0))

    def _mesh(self, kind, col):
        key = (kind, col)
        if key not in self.meshes:
            parts = models.truck_parts(col, flatbed=False) if kind == "truck" else car_parts(col)
            self.meshes[key] = models.mesh_from_parts(parts)
        return self.meshes[key]

    def _spawn(self, kind, col, x, direction, speed, temporary=False):
        lane = ROAD_Z + (0.55 if direction > 0 else -0.55)
        e = Entity(model=self._mesh(kind, col), shader=graphics.lit_shader(), position=(x, 0.03, lane),
                   rotation_y=90 if direction > 0 else -90, scale=1.9, add_to_scene_entities=False)
        t = textures.texture("metal")
        if t is not None:
            e.setTexture(t._texture, 1)
        self.vehicles.append({"e": e, "dir": direction, "speed": speed, "temp": temporary})
        return e

    def dispatch(self, x):
        """Eigener Liefer-LKW biegt bei x auf die Straße ab und fährt davon."""
        self._spawn("truck", (0.85, 0.2, 0.18), x, 1, 5.5, temporary=True)

    def update(self, dt):
        lo, hi = self.center.x - self.reach, self.center.x + self.reach
        keep = []
        for v in self.vehicles:
            e = v["e"]
            e.setX(e.getX() + v["dir"] * v["speed"] * dt)
            x = e.getX()
            if x > hi or x < lo:
                if v["temp"]:
                    e.removeNode()
                    continue
                e.setX(lo if x > hi else hi)
            keep.append(v)
        self.vehicles = keep

    def set_visible(self, on):
        for v in self.vehicles:
            v["e"].show() if on else v["e"].hide()
