"""
Benutzeroberfläche von Factory Empire.

HUD           Geld/Energie (oben links), Rohstoffe (oben Mitte), Forschung und
              Spieler (oben rechts), Hotbar (unten Mitte), Minimap (unten links),
              Nachrichten, Hinweiszeile, Einblendungen
InfoPanel     Details zum ausgewählten Gebäude inkl. Leistung pro Stufe, An/Aus,
              Rezept, Sortierer-Filter, Verkäufer-Mindestpreis
Fenster       Kaufmenü (Q), Forschung (R), Markt (M), Aufträge (O), Menü & Einstellungen (Esc),
              Admin-Panel (F2), Hilfe (F1)
Bildschirme   Verbindungsmenü, "Verbindung verloren", Chat

Die UI ruft für alle Aktionen Callbacks des Spielclients auf und verändert
selbst niemals Spielzustand.
"""

import math
import time

from panda3d.core import SamplerState
from panda3d.core import Texture as PandaTexture
from ursina import Button, Entity, InputField, Quad, Texture, color, mouse, window

from ursina import time as utime

from . import anim
from . import textures
from .i18n import tr
from . import config as C
from . import rules
from .ui_base import (ACCENT, ACCENT_DIM, ACCENT_SOFT, BAD, BLUE, BUTTON, BUTTON_ACCENT, BUTTON_DANGER,
                      BUTTON_GOOD, BUTTON_LOCKED, CARD, CARD_HOVER, FAINT, GOLD, GOOD, KIND_COLORS, LEVEL_COLORS,
                      MUTED, PANEL, PANEL_LIGHT, PANEL_SOLID, TEXT, WARN, AnimButton, Btn, Label, ProgressBar, Slider, Toggle,
                      Window, Choice, glow_quad, hud_panel, icon, panel, rect, rgb)


def item_color(item):
    return rgb(C.ITEMS[item]["color"])


def player_color(index):
    return rgb(C.PLAYER_COLORS[index % len(C.PLAYER_COLORS)])


def short_money(value):
    v = abs(value)
    sign = "-" if value < 0 else ""
    if v >= 1_000_000:
        return f"{sign}{v / 1_000_000:.2f}".replace(".", ",") + " Mio. €"
    return rules.format_money(value)


MAP_COLORS = {
    "miner": (0.98, 0.75, 0.2), "smelter": (0.75, 0.35, 0.25), "conveyor": (0.55, 0.56, 0.6),
    "seller": (0.15, 0.75, 0.75), "storage": (0.45, 0.6, 0.85), "assembler": (0.6, 0.45, 0.95), "factory": (0.95, 0.75, 0.2),
    "splitter": (0.3, 0.8, 0.45), "tpiece": (0.4, 0.6, 0.95), "sorter": (0.85, 0.4, 0.9),
    "kiln": (0.85, 0.55, 0.4), "blast_furnace": (0.55, 0.6, 0.7), "chemical": (0.45, 0.85, 0.75),
    "electronics": (0.35, 0.85, 0.45), "freight": (0.9, 0.35, 0.3),
}


# =============================================================================
class Minimap:
    """Karte unten links: gestochen scharf (3 Pixel je Feld), mit Gelände, Erzfeldern, Gebäuden mit Kante,
    Förderbändern mit Laufrichtung, Sichtfeld der Kamera, Mitspielern und Koordinaten unter der Maus."""

    SIZE = 0.25
    P = 3                                            # Pixel je Feld

    def __init__(self, parent, x, y, on_click):
        s = self.SIZE
        self.root = Entity(parent=parent, position=(x, y))
        hud_panel(self.root, 0, 0, s + 0.02, s + 0.078)
        Entity(parent=self.root, model="quad", texture=textures.texture("ui_arrow"), position=(0.024, -0.023, -0.02),
               scale=0.022, rotation_z=45, color=color.rgba(1, 0.72, 0.25, 1))
        Label(self.root, "KARTE", 0.04, -0.012, size=0.72, col=TEXT)
        self.planet_tag_bg = Entity(parent=self.root, model=Quad(radius=0.5, aspect=3.2), origin=(0.5, 0.5),
                                    position=(s + 0.01, -0.01, -0.01), scale=(0.072, 0.022),
                                    color=color.rgba(0.3, 0.7, 0.35, 0.35))
        self.planet_tag = Label(self.root, "ERDE", s + 0.01 - 0.036, -0.0125, size=0.56, col=TEXT, origin=(0, 0.5))
        self.W, self.H = C.GRID_W * self.P, C.GRID_H * self.P
        self.ptex = PandaTexture("minimap")
        self.ptex.setup2dTexture(self.W, self.H, PandaTexture.T_unsigned_byte, PandaTexture.F_rgb8)
        self.ptex.setMagfilter(SamplerState.FT_linear)
        self.ptex.setMinfilter(SamplerState.FT_linear)
        self.ptex.setWrapU(SamplerState.WM_clamp)
        self.ptex.setWrapV(SamplerState.WM_clamp)
        self.map = Button(parent=self.root, model="quad", texture=Texture(self.ptex), origin=(-0.5, 0.5),
                          position=(0.01, -0.04, -0.01), scale=(s, s), color=color.white,
                          highlight_color=color.white, pressed_color=color.white)
        self.map.on_click = self._clicked
        vig = textures.texture("ui_vignette")
        if vig is not None:
            Entity(parent=self.root, model="quad", texture=vig, origin=(-0.5, 0.5), position=(0.01, -0.04, -0.015),
                   scale=(s, s), color=color.white)
        # dünner Rahmen um die Karte
        for (fx, fy, fw, fh) in ((0.01, -0.04, s, 0.0015), (0.01, -0.04 - s + 0.0015, s, 0.0015),
                                 (0.01, -0.04, 0.0015, s), (0.01 + s - 0.0015, -0.04, 0.0015, s)):
            rect(self.root, fx, fy, fw, fh, color.rgba(1, 1, 1, 0.16), z=-0.016)
        self.on_click = on_click
        # Position und Blickrichtung der Kamera (Pfeil)
        self.arrow_bg = Entity(parent=self.root, model="quad", texture=textures.texture("ui_arrow"), scale=0.03,
                               color=color.rgba(0, 0, 0, 0.8), position=(0, 0, -0.028))
        self.arrow = Entity(parent=self.root, model="quad", texture=textures.texture("ui_arrow"), scale=0.022,
                            color=color.rgba(1, 0.72, 0.25, 1), position=(0, 0, -0.03))
        self.arrow_glow = glow_quad(self.root, 0, 0, 0.04, color.rgba(1, 0.6, 0.15, 0.5), z=-0.025)
        self.coords = Label(self.root, "Klick auf die Karte: hinfahren", 0.012, -0.04 - s - 0.008, size=0.56,
                            col=FAINT)
        self.dots = []
        self._bg = None
        self._bg_key = None
        self._sprites = {}
        self._t = 0.0

    # ---------------------------------------------------------------- Bedienung
    def _clicked(self):
        p = mouse.point
        if p is None:
            return
        # p ist lokal zum Kartenquad (Ursprung oben links): x 0..1, y 0..-1
        gx = p.x * C.GRID_W - 0.5
        gz = (1 + p.y) * C.GRID_H - 0.5
        self.on_click(gx, gz)

    def _to_map(self, x, z):
        s = self.SIZE
        return 0.01 + (x + 0.5) / C.GRID_W * s, -0.04 - s + (z + 0.5) / C.GRID_H * s

    def update_hover(self):
        """Koordinaten unter der Maus (jedes Bild)."""
        if mouse.hovered_entity is self.map and mouse.point is not None:
            p = mouse.point
            gx, gz = int(p.x * C.GRID_W), int((1 + p.y) * C.GRID_H)
            txt = f"Feld {gx}, {gz}  ·  Klick: hinfahren"
        else:
            txt = "Klick auf die Karte: hinfahren"
        if txt != getattr(self, "_coords_txt", None):
            self._coords_txt = txt
            self.coords.set(txt, MUTED if "Feld" in txt else FAINT)

    def update_view(self, cam_x, cam_z, yaw, distance, dt=0.016):
        """Blickpfeil (jedes Bild – billig, nur Position/Drehung)."""
        s = self.SIZE
        ax, ay = self._to_map(cam_x, cam_z)
        self.arrow.position = (ax, ay, -0.03)
        self.arrow.rotation_z = yaw
        self.arrow_bg.position = (ax, ay, -0.028)
        self.arrow_bg.rotation_z = yaw
        self._t += dt
        self.arrow_glow.position = (ax, ay, -0.025)
        self.arrow_glow.scale = 0.034 + 0.008 * math.sin(self._t * 4)
        inside = (0.01 <= ax <= 0.01 + s) and (-0.04 - s <= ay <= -0.04)
        for e in (self.arrow, self.arrow_bg, self.arrow_glow):
            e.enabled = inside

    # ---------------------------------------------------------------- Zeichnen
    @staticmethod
    def _px(c):
        return bytes((max(0, min(255, int(c[0] * 255))), max(0, min(255, int(c[1] * 255))),
                      max(0, min(255, int(c[2] * 255)))))

    def _background(self, deposits, planet):
        """Gelände und Erzfelder – nur neu, wenn sich Planet oder Vorkommen ändern."""
        from .world import fbm
        P, Wt, Ht = self.P, C.GRID_W, C.GRID_H
        moon = planet == "moon"
        base = (0.40, 0.40, 0.42) if moon else (0.24, 0.38, 0.20)
        occ = {}
        for (x, y), item in deposits.items():
            occ[(x, y)] = item
        rows = [bytearray() for _ in range(Ht * P)]
        for ty in range(Ht):
            for tx in range(Wt):
                item = occ.get((tx, ty))
                n = fbm(tx * 0.09, ty * 0.09, seed=301 if not moon else 71, octaves=3)
                k = 0.82 + (n - 0.5) * 0.45
                if (tx // 8 + ty // 8) % 2 == 0:
                    k *= 1.035                              # ganz leichtes Schachbrett (Orientierung)
                col = (base[0] * k, base[1] * k, base[2] * k)
                if item is not None and item in C.ITEMS:
                    oc = C.ITEMS[item]["color"]
                    col = (oc[0] * 0.9 + 0.04, oc[1] * 0.9 + 0.04, oc[2] * 0.9 + 0.04)
                light = self._px(col)
                for py in range(P):
                    row = rows[ty * P + py]
                    for px in range(P):
                        c = light
                        if item is not None:                # dunkler Rand, wo das Vorkommen endet
                            edge = ((px == 0 and occ.get((tx - 1, ty)) != item) or
                                    (px == P - 1 and occ.get((tx + 1, ty)) != item) or
                                    (py == 0 and occ.get((tx, ty - 1)) != item) or
                                    (py == P - 1 and occ.get((tx, ty + 1)) != item))
                            if edge:
                                oc = C.ITEMS[item]["color"]
                                c = self._px((oc[0] * 0.55, oc[1] * 0.55, oc[2] * 0.55))
                        row += c
        # Rand der Baufläche
        edge_col = self._px((0.75, 0.62, 0.25) if not moon else (0.4, 0.8, 0.9))
        for r in (0, len(rows) - 1):
            rows[r][:] = edge_col * (Wt * P)
        for row in rows:
            row[0:3] = edge_col
            row[-3:] = edge_col
        return bytes(b"".join(rows))

    def _sprite(self, kind, col, rot=0):
        """3×3-Pixel-Bild eines Gebäudes (Zeile 0 = unten): mit heller und dunkler Kante wie ein Knopf."""
        key = (kind, col, rot)
        sp = self._sprites.get(key)
        if sp is not None:
            return sp
        hi = self._px((min(1, col[0] * 1.3 + 0.08), min(1, col[1] * 1.3 + 0.08), min(1, col[2] * 1.3 + 0.08)))
        mid = self._px(col)
        lo = self._px((col[0] * 0.5, col[1] * 0.5, col[2] * 0.5))
        if kind == "belt":                                  # dunkles Band mit heller Laufrichtung
            dark = self._px((0.2, 0.21, 0.24))
            g = [[dark] * 3 for _ in range(3)]
            dx, dy = C.DIRS[rot % 4]
            g[1][1] = mid
            g[1 + dy][1 + dx] = hi
            sp = [b"".join(r) for r in g]
        else:
            g = [[mid] * 3 for _ in range(3)]
            for i in range(3):
                g[2][i] = hi                                # oben hell
                g[i][0] = hi
                g[0][i] = lo                                # unten dunkel
                g[i][2] = lo
            g[2][2] = mid
            g[0][0] = mid
            sp = [b"".join(r) for r in g]
        self._sprites[key] = sp
        return sp

    def update(self, state, cam_x, cam_z, players, my_id, blink):
        planet = getattr(state, "planet", "earth")
        key = (planet, id(state.deposits), len(state.deposits))     # billig: Vorkommen ändern sich nur bei neuer Welt
        if key != self._bg_key:
            self._bg_key = key
            self._bg = self._background(state.deposits, planet)
            moon = planet == "moon"
            self.planet_tag.set("MOND" if moon else "ERDE", TEXT)
            self.planet_tag_bg.color = color.rgba(0.5, 0.8, 1.0, 0.3) if moon else color.rgba(0.3, 0.7, 0.35, 0.35)
        buf = bytearray(self._bg)
        P, stride = self.P, self.W * 3
        for bid, row in state.static.items():
            btype, x, y, rot = row[1], row[2], row[3], row[4]
            if not (0 <= x < C.GRID_W and 0 <= y < C.GRID_H):
                continue
            dyn = state.dynamic.get(bid)
            lvl = C.STATUS.get(dyn[0], {}).get("level") if dyn else "warn"
            col = MAP_COLORS.get(btype, (0.8, 0.8, 0.8))
            if lvl == "error":
                col = (1.0, 0.18, 0.18) if blink else (0.55, 0.12, 0.12)
            elif lvl == "off":
                col = (0.18, 0.18, 0.21)
            sp = self._sprite("belt" if btype == "conveyor" else "box", col, rot if btype == "conveyor" else 0)
            o = (y * P) * stride + x * P * 3
            for r in range(P):
                buf[o + r * stride:o + r * stride + P * 3] = sp[r]
        self.ptex.setRamImageAs(bytes(buf), "RGB")
        while len(self.dots) < len(players):
            d = Entity(parent=self.root, model="circle", scale=0.013, z=-0.03)
            d.ring = Entity(parent=self.root, model=Quad(mode="line", radius=0.5, segments=12), scale=0.022, z=-0.03)
            self.dots.append(d)
        for i, dot in enumerate(self.dots):
            if i < len(players):
                p = players[i]
                show = p[0] != my_id
                dot.enabled = dot.ring.enabled = show
                c = player_color(p[2])
                dot.color = c
                dot.ring.color = color.rgba(c[0], c[1], c[2], 0.7)
                dot.x, dot.y = self._to_map(p[3], p[4])
                dot.ring.x, dot.ring.y = dot.x, dot.y
            else:
                dot.enabled = dot.ring.enabled = False


# =============================================================================
class HUD:
    def __init__(self, anchors, callbacks):
        self.a = anchors
        self.cb = callbacks
        self.roots = []

        # ---------------- oben links: Geld, Einnahmen, Energie, Maschinen
        tl = self._root("tl")
        hud_panel(tl, 0.012, -0.012, 0.46, 0.15)
        self.coin_glow = glow_quad(tl, 0.051, -0.051, 0.11, color.rgba(1, 0.8, 0.3, 0.32), z=-0.004)
        self.coin = icon(tl, "ui_coin", 0.026, -0.026, 0.05)
        self.money_shadow = Label(tl, "", 0.0872, -0.0236, size=1.9, col=color.rgba(0, 0, 0, 0.4), raw=True,
                                  z=-0.012)
        self.money = Label(tl, "", 0.086, -0.022, size=1.9, col=GOLD)
        rect(tl, 0.026, -0.086, 0.43, 0.0015, color.rgba(1, 1, 1, 0.07))
        self.tl_root = tl
        self._money_shown = None
        self._money_target = 0.0
        self._money_delta = 0.0
        self._money_delta_t = 0.0
        self._last_tool = None
        self._locked = {}
        self.income = Label(tl, "", 0.088, -0.068, size=0.8, col=GOOD)
        icon(tl, "ui_energy", 0.028, -0.094, 0.026)
        self.energy = Label(tl, "", 0.06, -0.096, size=0.74, col=MUTED)
        self.machines = Label(tl, "", 0.028, -0.125, size=0.72, col=MUTED, max_w=0.43)
        # Aufträge (erst nach der Forschung "Spedition")
        self.orders_btn = Btn(tl, "", 0.012 + 0.23, -0.172 - 0.031, 0.46, 0.062,
                              lambda: self.cb["orders"]() if "orders" in self.cb else None, col=PANEL, size=0.6)
        self.orders_icon = icon(tl, "ui_truck", 0.026, -0.178, 0.05, z=-0.05)
        self.orders_l1 = Label(tl, "", 0.084, -0.18, size=0.78, col=TEXT, z=-0.05)
        self.orders_l2 = Label(tl, "", 0.084, -0.205, size=0.66, col=MUTED, z=-0.05)
        self.orders_btn.add_follower(self.orders_icon)
        self._orders_parts = (self.orders_btn, self.orders_icon, self.orders_l1, self.orders_l2)
        for e in self._orders_parts:
            e.enabled = False

        # ---------------- oben Mitte: Rohstoffe
        t = self._root("t")
        self.res_root = Entity(parent=t)
        # Es gibt viele Warenarten: angezeigt werden nur die, die gerade im Lager sind
        # (bei leerem Lager die Rohstoffe). Platz für MAX_CHIPS Einträge.
        n = self.MAX_CHIPS
        self.chip_w = 0.088
        total = n * self.chip_w + 0.15
        self.res_width = total + 0.02
        x0 = -total / 2
        hud_panel(self.res_root, x0 - 0.01, -0.012, total + 0.02, 0.07, corners=False)
        self.chips = []
        for i in range(n):
            cx = x0 + i * self.chip_w
            Entity(parent=self.res_root, model=Quad(radius=0.5, aspect=(self.chip_w - 0.006) / 0.044),
                          origin=(-0.5, 0.5), position=(cx, -0.019, -0.003), scale=(self.chip_w - 0.006, 0.044),
                          color=color.rgba(1, 1, 1, 0.045))
            ic = icon(self.res_root, "iron_ore", cx + 0.004, -0.02, 0.034)
            lbl = Label(self.res_root, "0", cx + 0.04, -0.03, size=0.82)
            self.chips.append({"icon": ic, "label": lbl, "item": "-"})
        self.more_label = Label(self.res_root, "", x0 + (n - 1) * self.chip_w + 0.004, -0.03, size=0.72, col=MUTED)
        sx = x0 + n * self.chip_w + 0.005
        icon(self.res_root, "ui_storage", sx, -0.02, 0.032)
        self.storage = Label(self.res_root, "", sx + 0.038, -0.022, size=0.72)
        self.storage_bar = ProgressBar(self.res_root, sx + 0.038, -0.05, 0.1, 0.008, col=GOOD)

        # ---------------- oben rechts: Forschung und Spieler
        tr = self._root("tr")
        hud_panel(tr, -0.382, -0.012, 0.37, 0.1, accent=BLUE)
        icon(tr, "ui_research", -0.372, -0.022, 0.04)
        self.research_label = Label(tr, "", -0.322, -0.024, size=0.76, col=BLUE)
        self.research_bar = ProgressBar(tr, -0.322, -0.056, 0.296, 0.01, col=BLUE)
        icon(tr, "ui_players", -0.372, -0.072, 0.026)
        self.players_label = Label(tr, "", -0.34, -0.074, size=0.74)
        self.ping_label = Label(tr, "", -0.026, -0.074, size=0.68, col=MUTED, origin=(0.5, 0.5))
        self.player_root = Entity(parent=tr)
        self.player_entries = []
        self.player_key = None
        # Update-Hinweis oben rechts (auch mitten im Spiel)
        self.upd = Entity(parent=tr, enabled=False)
        self.upd_bg = hud_panel(self.upd, -0.382, -0.122, 0.37, 0.112, corners=False)
        rect(self.upd, -0.382, -0.122, 0.006, 0.112, ACCENT)
        icon(self.upd, "ui_research", -0.366, -0.134, 0.034)
        self.upd_title = Label(self.upd, "", -0.322, -0.132, size=0.82, col=ACCENT)
        self.upd_sub = Label(self.upd, "", -0.322, -0.164, size=0.62, col=MUTED, wordwrap=46)
        self.upd_bar = ProgressBar(self.upd, -0.322, -0.196, 0.296, 0.008, col=ACCENT)
        self.upd_btn = Btn(self.upd, "Jetzt aktualisieren", -0.2, -0.21, 0.24, 0.036,
                           lambda: self.cb["update_now"](), col=BUTTON_ACCENT, size=0.66)
        self.upd_close = Btn(self.upd, "x", -0.04, -0.138, 0.034, 0.03, lambda: self.cb["update_later"](), size=0.8)

        # ---------------- unten Mitte: Hotbar und Hinweiszeile
        b = self._root("b")
        self.bottom_root = b
        tools = list(C.BUILDING_ORDER) + ["demolish", "menu"]
        gap = 0.007
        # Hotbar darf die Minimap unten links nicht überdecken: bei vielen Gebäuden kleinere Felder
        self.slot = min(0.078, (1.2 + gap) / len(tools) - gap)
        ks = self.slot / 0.078
        width = len(tools) * (self.slot + gap) - gap
        self.hotbar_half = width / 2 + 0.02
        hud_panel(b, -width / 2 - 0.012, 0.118, width + 0.024, self.slot + 0.04)
        self.slot_glow = glow_quad(b, 0, 0, self.slot * 1.9, color.rgba(1, 0.6, 0.15, 0.55), z=-0.01)
        self.slot_glow.enabled = False
        self.slots = {}
        for i, tool in enumerate(tools):
            x = -width / 2 + i * (self.slot + gap) + self.slot / 2
            y = 0.118 - 0.012 - self.slot / 2
            btn = AnimButton(parent=b, position=(x, y, -0.02), scale=self.slot, color=PANEL_LIGHT, radius=0.16)
            btn.HOVER_SCALE = 1.08
            btn.lift = 0.007
            btn.on_click = (lambda t=tool: self.cb["tool"](t))
            btn.on_mouse_enter = (lambda t=tool: self.cb["hover_tool"](t))
            btn.on_mouse_exit = (lambda: self.cb["hover_tool"](None))
            if tool in C.BUILDINGS:
                ic = icon(b, tool, x, y + 0.004, self.slot * 0.78, z=-0.03, origin=(0, 0))
                key = C.BUILDINGS[tool]["hotkey"]
                price = Label(b, rules.format_money(C.BUILDINGS[tool]["cost"]), x, y - self.slot / 2 + 0.012 * ks,
                              size=0.55 * max(0.82, ks), col=GOLD, origin=(0, 0), z=-0.04)
            else:
                if tool == "demolish":
                    ic = Label(b, "X", x, y + 0.008, size=1.9, col=BAD, origin=(0, 0), z=-0.03)
                else:
                    ic = icon(b, "ui_coin", x, y + 0.006, self.slot * 0.5, z=-0.03, origin=(0, 0))
                key = "X" if tool == "demolish" else "Q"
                price = Label(b, "Abriss" if tool == "demolish" else "Kaufen", x, y - self.slot / 2 + 0.012 * ks,
                              size=0.55 * max(0.82, ks), col=MUTED, origin=(0, 0), z=-0.04)
            keylbl = Label(b, key, x - self.slot / 2 + 0.008, y + self.slot / 2 - 0.004, size=0.7 * max(0.85, ks),
                           col=ACCENT, z=-0.04)
            lock = Entity(parent=b, model=Quad(radius=0.16), position=(x, y, -0.05), scale=self.slot,
                          color=color.rgba(0, 0, 0, 0.45), enabled=False)
            btn.add_follower(ic)
            self.slots[tool] = {"btn": btn, "icon": ic, "price": price, "key": keylbl, "lock": lock}
        self.hint_bg = hud_panel(b, -0.38, 0.205, 0.76, 0.062, accent=None, corners=False, collider=False)
        self.hint = Label(b, "", 0, 0.193, size=0.9, origin=(0, 0.5))
        self.hint2 = Label(b, "", 0, 0.165, size=0.74, origin=(0, 0.5), col=MUTED)

        # ---------------- unten links: Minimap und Nachrichten
        bl = self._root("bl")
        self.minimap = Minimap(bl, 0.012, 0.345, self.cb["minimap"])
        self.msg_root = Entity(parent=bl)
        self.messages = []

        # ---------------- unten rechts: Tastenhilfe
        br = self._root("br")
        Label(br, "F1 Hilfe · Esc Menü", -0.012, 0.012, size=0.62, origin=(0.5, -0.5), col=FAINT)

        # ---------------- Mitte: Einblendungen und Fadenkreuz
        c = self._root("c")
        self.toast_bg = Entity(parent=c, model=Quad(radius=0.3), position=(0, 0.32, 0), scale=(0.6, 0.06),
                               color=color.rgba(0.05, 0.06, 0.08, 0.85), enabled=False)
        self.toast = Label(c, "", 0, 0.32, size=1.1, origin=(0, 0), z=-0.01)
        self.toast.enabled = False
        self._toast_ts = self.toast.scale_x
        self.toast_until = 0.0
        self.fit()

    MAX_CHIPS = 10

    def _refresh_chips(self, state):
        from . import textures
        planet = getattr(state, "planet", "earth")
        have = [i for i in rules.item_order(planet) if state.inventory.get(i, 0) > 0]
        shown = have if have else rules.deposit_items(planet)
        overflow = len(shown) > self.MAX_CHIPS
        if overflow:
            shown = shown[:self.MAX_CHIPS - 1]
        for i, chip in enumerate(self.chips):
            item = shown[i] if i < len(shown) else None
            if item != chip["item"]:
                chip["item"] = item
                chip["icon"].enabled = item is not None
                chip["label"].enabled = item is not None
                if item is not None:
                    tex = textures.icon(item)
                    if tex:
                        chip["icon"].texture = tex
            if item is not None:
                n = state.inventory.get(item, 0)
                chip["label"].set(f"{n}" if n < 10000 else f"{n / 1000:.0f}k", TEXT if n else FAINT)
        self.more_label.set(f"+{len(have) - (self.MAX_CHIPS - 1)} weitere (M)" if overflow else " ")

    def _root(self, anchor):
        r = Entity(parent=self.a[anchor], enabled=False)
        r.anchor_name = anchor
        self.roots.append(r)
        return r

    def play_intro(self):
        """HUD gleitet beim Spielstart von den Bildschirmrändern herein."""
        offsets = {"tl": (-0.25, 0.1), "t": (0, 0.15), "tr": (0.25, 0.1), "b": (0, -0.3), "bl": (-0.3, 0),
                   "br": (0.2, -0.1), "c": (0, 0)}
        for i, r in enumerate(self.roots):
            ox, oy = offsets.get(r.anchor_name, (0, 0))

            def f(v, r=r, ox=ox, oy=oy):
                r.x = ox * (1 - v)
                r.y = oy * (1 - v)
                anim.set_alpha(r, v)
            anim.tween(f, 0.7, delay=0.5 + 0.07 * i, ease=anim.out_back, key=("hud_in", i))

    def fit(self):
        """Rohstoffleiste und Hotbar verkleinern, falls sie mit Eckpanels/Minimap kollidieren würden."""
        s = self.a.scale
        half = window.aspect_ratio / 2
        free = window.aspect_ratio - 2 * (0.42 * s + 0.01)
        self.res_root.scale = max(0.5, min(1.0, free / (self.res_width * s)))
        self.bottom_root.scale = max(0.45, min(1.0, (half - 0.29 * s) / (self.hotbar_half * s)))

    def show(self):
        for r in self.roots:
            r.enabled = True

    def hide(self):
        for r in self.roots:
            r.enabled = False

    # ------------------------------------------------------------------
    def refresh(self, state, ping, active_tool, fp=False):
        if self._money_shown is None:
            self._money_shown = float(state.money)
            self._set_money(short_money(state.money), self._money_col() if state.money >= 0 else BAD)
        elif state.money != self._money_target:
            self._money_delta += state.money - self._money_target
        self._money_target = float(state.money)
        m = state.market or {}
        self.income.set(f"+{rules.format_money(m.get('per_min', 0))} / Min. Einnahmen")
        self.energy.set(f"Energie {rules.format_money(state.energy_min)}/Min · Abrechnung in "
                        f"{state.energy_next:.0f} s")
        counts = state.status_counts()
        belts, belts_bad = state.belt_counts()
        txt = f"Maschinen: {counts['ok']} aktiv · {counts['warn']} wartend · {counts['error']} gestört"
        if counts["off"]:
            txt += f" · {counts['off']} aus"
        if belts_bad:
            txt += f" · {belts_bad} Bänder"
        self.machines.set(txt, BAD if counts["error"] or belts_bad else MUTED)
        self._refresh_orders(state)

        self._refresh_chips(state)
        total, cap = state.inventory_total(), state.capacity
        fill = total / cap if cap else 1
        self.storage.set(f"{total}/{cap}", BAD if fill >= 1 else (WARN if fill > 0.8 else TEXT))
        self.storage_bar.set(fill if cap else 0, BAD if fill >= 1 else (WARN if fill > 0.8 else GOOD))

        active = state.research_active
        if active:
            name = C.RESEARCH[active["id"]]["name"]
            ratio = active["progress"] / max(0.01, active["time"])
            rem = max(0, active["time"] - active["progress"])
            self.research_label.set(f"{name} · {int(ratio * 100)} % · {rem:.0f} s", BLUE)
            self.research_bar.set(ratio, BLUE)
        else:
            total = len(rules.research_ids(state.planet))
            self.research_label.set(f"Keine Forschung aktiv ({len(state.unlocked)}/{total})  [R]", MUTED)
            self.research_bar.set(len(state.unlocked) / max(1, total), color.rgba(0.3, 0.5, 0.8, 0.6))
        self.players_label.set(f"{len(state.players)} Spieler online")
        self.ping_label.set(f"{ping} ms" if ping is not None else "–")

        self.slot_glow.enabled = False
        for tool, s in self.slots.items():
            locked = tool in C.BUILDINGS and (not rules.building_unlocked(tool, state.unlocked, state.planet)
                                              or not rules.building_on_planet(tool, state.planet))
            col = ACCENT_DIM if tool == active_tool else (BUTTON_LOCKED if locked else PANEL_LIGHT)
            if tool == active_tool and tool not in ("menu",):
                self.slot_glow.enabled = True
                self.slot_glow.x, self.slot_glow.y = s["btn"].x, s["btn"].y
            if s["btn"].color != col:
                s["btn"].color = col
                s["btn"].highlight_color = col.tint(0.15)
            s["lock"].enabled = locked
            if self._locked.get(tool) and not locked:          # gerade freigeschaltet
                anim.pop(s["btn"], self.slot, 0.28, 0.6)
            self._locked[tool] = locked
            if tool in C.BUILDINGS:
                cost = C.BUILDINGS[tool]["cost"]
                s["price"].color = FAINT if locked else (BAD if state.available < cost else GOLD)
        if active_tool != self._last_tool:
            self._last_tool = active_tool
            if active_tool in self.slots:
                anim.pop(self.slots[active_tool]["btn"], self.slot, 0.14, 0.28)

    def set_hint(self, text, sub="", col=TEXT, sub_col=MUTED):
        self.hint.set(text, col)
        self.hint2.set(sub, sub_col)

    def refresh_players(self, players, my_id):
        key = [(p[0], p[1], p[2], p[9] if len(p) > 9 else False) for p in players]
        if key == self.player_key:
            return
        self.player_key = key
        for e in self.player_entries:
            e.parent = None
            e.enabled = False
        self.player_entries = []
        y = -0.124
        for pid, name, col, admin in key:
            txt = "• " + name + (" (du)" if pid == my_id else "") + (" · Admin" if admin else "")
            lbl = Label(self.player_root, txt, -0.02, y, size=0.76, origin=(0.5, 0.5), col=player_color(col))
            self.player_entries.append(lbl)
            y -= 0.027

    def _refresh_orders(self, state):
        fr = state.freight or {}
        show = "freight" in state.unlocked and getattr(state, "planet", "earth") == "earth"
        if show != self.orders_btn.enabled:
            for e in self._orders_parts:
                e.enabled = show
        if not show:
            return
        contracts = fr.get("contracts", [])
        board = fr.get("board", [])
        self.orders_l1.set(f"Aufträge (O):  {len(contracts)}/{fr.get('max', 6)} aktiv  ·  {len(board)} Angebote")
        enroute = sorted((c for c in contracts if c["status"] == "enroute"), key=lambda c: c["eta"])
        loading = [c for c in contracts if c["status"] == "loading"]
        waiting = [c for c in contracts if c["status"] == "wait"]
        if enroute:
            c = enroute[0]
            line, col = f"LKW nach {c['city']}: Ankunft in {rules.format_duration(c['eta'])}", GOOD
        elif loading:
            c = loading[0]
            line, col = f"Wird beladen: {c['loaded']}/{c['qty']} {C.ITEMS[c['item']]['name']} » {c['city']}", ACCENT
        elif waiting:
            line, col = "Kein freier LKW – Frachtbahnhof bauen (Q)", WARN
        elif board:
            line, col = "Neue Angebote in der Auftragsbörse", MUTED
        else:
            line, col = "Gerade keine Angebote – bald kommen neue", FAINT
        self.orders_l2.set(line, col)

    def add_message(self, text, kind="info"):
        lbl = Label(self.msg_root, text, 0.016, 0, size=0.78, col=KIND_COLORS.get(kind, TEXT), wordwrap=72)
        lbl._fresh = True
        self.messages.append([lbl, time.time()])
        while len(self.messages) > 7:
            old = self.messages.pop(0)[0]
            old.enabled = False
            old.parent = None
        self._layout_messages()

    def _layout_messages(self):
        y = 0.36
        for lbl, _ in reversed(self.messages):
            lines = lbl.text.count("\n") + 1
            y += 0.026 * lines + 0.004
            if getattr(lbl, "_fresh", False):
                lbl._fresh = False
                lbl.y = y
                anim.tween(lambda v, l=lbl: (setattr(l, "x", 0.016 - 0.06 * (1 - v)), anim.set_alpha(l, v)),
                           0.35, key=("msg", id(lbl)))
            else:
                y0, y1 = lbl.y, y
                anim.tween(lambda v, l=lbl, a=y0, b=y1: setattr(l, "y", a + (b - a) * v), 0.25,
                           key=("msgy", id(lbl)))

    def _set_money(self, text, col):
        self.money.set(text, col)
        self.money_shadow.set(self.money.text, color.rgba(0, 0, 0, 0.4))

    def _money_col(self):
        return color.rgba(0.7, 0.86, 1.0, 1) if getattr(self, "_moon", False) else GOLD

    # ---------------------------------------------------------------- Update-Hinweis
    def update_badge(self, mode, version="", progress=0.0, text=""):
        """mode: None (aus) | available | downloading | ready | error"""
        if mode is None:
            self.upd.enabled = False
            self.player_root.y = 0
            return
        self.upd.enabled = True
        self.player_root.y = -0.12                         # Spielerliste rutscht unter den Hinweis
        if mode == "available":
            self.upd_title.set(f"Update {version} verfügbar", ACCENT)
            self.upd_sub.set(text or "Wird im Hintergrund geladen – du spielst einfach weiter.", MUTED)
            self.upd_bar.enabled = False
            self.upd_btn.enabled = True
            self.upd_btn.set_text("Jetzt aktualisieren")
            self.upd_close.enabled = True
        elif mode == "downloading":
            self.upd_title.set(f"Update {version} wird geladen …", ACCENT)
            self.upd_sub.set(f"{progress * 100:.0f} % – du kannst weiterspielen.", MUTED)
            self.upd_bar.enabled = True
            self.upd_bar.set(progress, ACCENT)
            self.upd_btn.enabled = False
            self.upd_close.enabled = False
        elif mode == "ready":
            self.upd_title.set(f"Update {version} ist bereit", GOOD)
            self.upd_sub.set(text, MUTED)
            self.upd_bar.enabled = True
            self.upd_bar.set(1.0, GOOD)
            self.upd_btn.enabled = False
            self.upd_close.enabled = False
        elif mode == "error":
            self.upd_title.set("Update fehlgeschlagen", BAD)
            self.upd_sub.set(text[:110], MUTED)
            self.upd_bar.enabled = False
            self.upd_btn.enabled = True
            self.upd_btn.set_text("Nochmal versuchen")
            self.upd_close.enabled = True

    def set_planet(self, planet):
        """Mond: silbrig-blaue Mooncoin statt goldener Euro-Münze, Gebäude-Icons im Mond-Look."""
        moon = self._moon = planet == "moon"
        from . import textures
        from .ui_base import icon_name
        for tool, slot in self.slots.items():
            if tool in C.BUILDINGS:
                tex = textures.icon(icon_name(tool))
                if tex is not None:
                    slot["icon"].texture = tex
        self.coin.color = color.rgba(0.62, 0.8, 1.0, 1) if moon else color.white
        self.money.color = color.rgba(0.7, 0.86, 1.0, 1) if moon else GOLD

    def toast_show(self, text, kind="info", seconds=3.0):
        self.toast.set(text, KIND_COLORS.get(kind, TEXT))
        self.toast.enabled = True
        self.toast_bg.enabled = True
        w = max(0.4, self.toast.width * self.toast.scale_x + 0.08)
        self.toast_until = time.time() + seconds
        anim.cancel("toast_out")
        bg, tx = self.toast_bg, self.toast
        ts = self._toast_ts

        def f(v):
            bg.scale = (w * (0.75 + 0.25 * v), 0.06 * (0.6 + 0.4 * v))
            tx.scale = ts * (0.85 + 0.15 * v)
            bg.y = tx.y = 0.32 + 0.03 * (1 - v)
            anim.set_alpha(bg, v)
            anim.set_alpha(tx, v)
        anim.tween(f, 0.38, ease=anim.out_back, key="toast")

    def update(self):
        self.minimap.update_hover()
        now = time.time()
        changed = False
        for entry in list(self.messages):
            lbl, t = entry
            age = now - t
            if age > 16:
                lbl.enabled = False
                lbl.parent = None
                self.messages.remove(entry)
                changed = True
            elif age > 12:
                c = lbl.color
                lbl.color = color.rgba(c[0], c[1], c[2], max(0, 1 - (age - 12) / 4))
        if changed:
            self._layout_messages()
        if self.toast.enabled and now > self.toast_until and not anim.running("toast_out"):
            bg, tx = self.toast_bg, self.toast

            def f(v):
                anim.set_alpha(bg, 1 - v)
                anim.set_alpha(tx, 1 - v)
                bg.y = tx.y = 0.32 + 0.02 * v

            def done():
                if time.time() > self.toast_until:
                    bg.enabled = tx.enabled = False
                bg.y = tx.y = 0.32
                anim.set_alpha(bg, 1)
                anim.set_alpha(tx, 1)
            anim.tween(f, 0.3, ease=anim.in_cubic, key="toast_out", done=done)

        # Kontostand zählt weich hoch/runter, Änderungen fliegen als "+123 €" heraus
        dt = min(utime.dt, 0.1)
        if self._money_shown is not None:
            tgt = self._money_target
            cur = anim.approach(self._money_shown, tgt, dt, 7)
            if abs(cur - tgt) < 0.5:
                cur = tgt
            if cur != self._money_shown or not self.money.text:
                self._money_shown = cur
                self._set_money(short_money(round(cur)), self._money_col() if tgt >= 0 else BAD)
            self._money_delta_t += dt
            if self._money_delta_t > 1.2 and abs(self._money_delta) >= 1:
                self._float_money(self._money_delta)
                self._money_delta = 0.0
                self._money_delta_t = 0.0
            elif self._money_delta_t > 1.2:
                self._money_delta_t = 0.0

    def _float_money(self, delta):
        txt = ("+" if delta > 0 else "−") + rules.format_money(abs(round(delta)))
        x0 = 0.086 + self.money.width * self.money.scale_x + 0.02
        y0 = -0.03
        if x0 > 0.3:                       # sehr großer Kontostand: Anzeige unter dem Feld statt daneben
            x0, y0 = 0.02, -0.25
        old = getattr(self, "_money_float", None)
        if old is not None:                 # nur eine Anzeige gleichzeitig (sonst überlagern sie sich)
            anim.cancel("money_float")
            old.enabled = False
            old.parent = None
        lbl = self._money_float = Label(self.tl_root, txt, x0, y0, size=0.95, col=GOOD if delta > 0 else BAD,
                                        z=-0.05)

        def f(v):
            lbl.x = x0 + 0.04 * v
            anim.set_alpha(lbl, 1 - max(0.0, (v - 0.5) * 2))

        def done():
            lbl.enabled = False
            lbl.parent = None
        anim.tween(f, 1.6, ease=anim.out_cubic, done=done, key="money_float")


# =============================================================================
HELP_FOR_STATUS = {
    "no_output": "Vor dem Ausgang steht nichts. Setze ein Förderband, Lager oder eine passende Maschine "
                 "in Pfeilrichtung.",
    "bad_output": "Das Ziel kann diese Ware nicht annehmen (falsche Maschine, falsches Rezept, Band zeigt "
                  "zurück oder Verteiler von der falschen Seite angeschlossen).",
    "blocked": "Das Ziel ist voll. Mehr Abnehmer bauen (Verkäufer, Lager) oder die Kette entzerren.",
    "no_money": "Zu wenig Geld für die Energiekosten. Waren verkaufen (M).",
    "no_deposit": "Der Miner steht nicht auf einem Erzvorkommen.",
    "full": "Firmenlager voll. Waren im Markt (M) verkaufen oder weitere Lager bauen.",
}


class InfoPanel:
    """Details zum ausgewählten Gebäude (rechte Bildschirmseite)."""

    W = 0.47
    H = 0.77

    def __init__(self, anchors, callbacks):
        self.cb = callbacks
        self.root = Entity(parent=anchors["r"], enabled=False, z=-0.05)
        self.x = -self.W - 0.012
        self.y = 0.4
        self.bg = panel(self.root, self.x, self.y, self.W, self.H, PANEL)
        rect(self.root, self.x + 0.012, self.y, self.W - 0.024, 0.005, ACCENT)
        self.content = None
        self.key = None

    _closing = False

    def hide(self):
        if not self.root.enabled or self._closing:
            return
        self._closing = True
        root = self.root

        def f(v):
            root.x = 0.12 * v
            anim.set_alpha(root, 1 - v)

        def done():
            if self._closing:
                self._closing = False
                root.enabled = False
                root.x = 0
                anim.set_alpha(root, 1)
        anim.tween(f, 0.14, ease=anim.in_cubic, key=("info", id(self)), done=done)

    def fit(self, s):
        """Panel so verkleinern, dass es zwischen Forschungsanzeige (oben) und Hotbar (unten) passt."""
        top, bottom = self.y, self.H - self.y
        k = min(1.0, (0.5 - 0.115 * s) / (top * s), (0.5 - 0.14 * s) / (bottom * s))
        self.root.scale = max(0.45, k)

    # ------------------------------------------------------------------ Aufbau je Gebäudetyp
    def _build(self, bid, btype, planet="earth"):
        if self.content:
            self.content.enabled = False
            self.content.parent = None
        c = self.content = Entity(parent=self.root)
        self.key = (bid, btype, planet)
        x, y, w = self.x + 0.02, self.y, self.W - 0.04
        icon(c, btype, x, y - 0.02, 0.085)
        Label(c, C.BUILDINGS[btype]["name"], x + 0.1, y - 0.022, size=1.35)
        self.level = Label(c, "", x + 0.1, y - 0.062, size=0.72, col=MUTED)
        self.pill_bg = Entity(parent=c, model=Quad(radius=0.5), origin=(-0.5, 0.5), position=(x, y - 0.118, -0.01),
                              scale=(0.2, 0.034), color=color.rgba(1, 1, 1, 0.08))
        self.status = Label(c, "", x + 0.012, y - 0.124, size=0.8)
        self.bar = ProgressBar(c, x + 0.24, y - 0.128, w - 0.24, 0.014)
        cy = y - 0.168
        self.lines = Label(c, "", x, cy, size=0.74, col=TEXT)
        cy -= 0.115
        self.rate_rows = []
        if btype in ("miner", "smelter", "seller") or btype in C.MACHINE_RECIPES:
            Label(c, "Leistung pro Minute je Ausbaustufe", x, cy, size=0.74, col=ACCENT)
            cy -= 0.032
            for lvl in range(1, C.BUILDINGS[btype]["max_level"] + 1):
                bg = Entity(parent=c, model=Quad(radius=0.3), origin=(-0.5, 0.5), position=(x - 0.006, cy + 0.004, -0.005),
                            scale=(w + 0.012, 0.03), color=color.rgba(1, 1, 1, 0))
                lab = Label(c, f"Stufe {lvl}", x + 0.006, cy, size=0.72, col=MUTED)
                val = Label(c, "", x + 0.1, cy, size=0.72)
                self.rate_rows.append((bg, lab, val))
                cy -= 0.032
            self.measured = Label(c, "", x, cy - 0.004, size=0.72, col=GOOD)
            cy -= 0.048
        if btype in C.MACHINE_RECIPES:
            Label(c, "Rezept", x, cy, size=0.74, col=ACCENT)
            cy -= 0.038
            per_row = 4
            bw = (w - 0.03) / per_row
            self.recipe_btns = {}
            recipes = rules.machine_recipes(btype, planet)
            for i, rid in enumerate(recipes):
                col_i, row_i = i % per_row, i // per_row
                out = next(iter(C.RECIPES[rid]["outputs"]))
                bx, by = x + col_i * (bw + 0.01), cy - 0.026 - row_i * 0.06
                b = Btn(c, "", bx + bw / 2, by, bw, 0.054, (lambda r=rid: self.cb["recipe"](r)), size=0.6)
                icon(c, out, bx + bw / 2, by, 0.044, z=-0.05, origin=(0, 0))
                self.recipe_btns[rid] = b
            cy -= 0.062 + 0.06 * ((len(recipes) - 1) // per_row)
            self.recipe_info = Label(c, "", x, cy, size=0.64, col=MUTED, wordwrap=62)
            self.recipe_info.enabled = cy > self.y - self.H + 0.16
            cy -= 0.055
        if btype == "sorter":
            Label(c, "Richtung je Ware (nicht eingestellt = vorne)", x, cy, size=0.72, col=ACCENT)
            cy -= 0.036
            self.filter_btns = {}
            half = (w + 0.01) / 2
            sort_items = rules.item_order(planet)
            for i, item in enumerate(sort_items):
                cx_ = x + (i % 2) * half
                ry = cy - (i // 2) * 0.027
                icon(c, item, cx_, ry + 0.004, 0.024)
                Label(c, C.ITEMS[item]["name"], cx_ + 0.028, ry - 0.002, size=0.56)
                row = {}
                for j, side in enumerate(("L", "F", "R")):
                    b = Btn(c, {"L": "L", "F": "V", "R": "R"}[side], cx_ + half - 0.1 + j * 0.031, ry - 0.009,
                            0.029, 0.024, (lambda it=item, sd=side: self.cb["filter"](it, sd)), size=0.5)
                    row[side] = b
                self.filter_btns[item] = row
            cy -= ((len(sort_items) + 1) // 2) * 0.027 + 0.008
            Label(c, "L = links, V = vorne, R = rechts", x, cy, size=0.56, col=FAINT)
            cy -= 0.03
        if btype == "seller":
            Label(c, "Mindestpreis: erst verkaufen ab … über Grundpreis", x, cy, size=0.72, col=ACCENT)
            cy -= 0.04
            self.thr_btns = {}
            bw = (w - 0.03) / 4
            for i, pct in enumerate(C.SELLER_THRESHOLDS):
                label = "Immer" if pct is None else ("±0 %" if pct == 0 else f"{pct:+d} %")
                b = Btn(c, label, x + bw / 2 + (i % 4) * (bw + 0.01), cy - 0.02 - (i // 4) * 0.05, bw, 0.042,
                        (lambda p=pct: self.cb["threshold"](p)), size=0.66)
                self.thr_btns[pct] = b
            cy -= 0.11
            self.price_info = Label(c, "", x, cy, size=0.66, col=MUTED, wordwrap=60)
            cy -= 0.04
        self.desc = Label(c, "", x, cy, size=0.66, col=MUTED, wordwrap=62)
        self.desc.enabled = cy > self.y - self.H + 0.2      # nur anzeigen, wenn Platz über den Knöpfen ist

        # Knöpfe unten
        by = self.y - self.H + 0.1
        bw = (w - 0.02) / 3
        self.btn_power = Btn(c, "Aus (P)", x + bw / 2, by, bw, 0.046, self.cb["toggle"], size=0.64)
        self.btn_rotate = Btn(c, "Drehen (E)", x + bw * 1.5 + 0.01, by, bw, 0.046, self.cb["rotate"], size=0.64)
        self.btn_move = Btn(c, "Versetzen (G)", x + bw * 2.5 + 0.02, by, bw, 0.046, self.cb["move"], size=0.64)
        by -= 0.056
        bw2 = (w - 0.01) / 2
        self.btn_upgrade = Btn(c, "Ausbau", x + bw2 / 2, by, bw2, 0.046, self.cb["upgrade"], size=0.62,
                               col=BUTTON_ACCENT)
        self.btn_demolish = Btn(c, "Abriss", x + bw2 * 1.5 + 0.01, by, bw2, 0.046, self.cb["demolish"], size=0.62,
                                col=BUTTON_DANGER)

    # ------------------------------------------------------------------ Werte aktualisieren
    def show(self, row, dyn, state):
        bid, btype, x, y, rot, level, recipe, owner = row[:8]
        planet = getattr(state, "planet", "earth")
        appearing = not self.root.enabled or self._closing
        switching = self.key is not None and self.key != (bid, btype, planet) and not appearing
        self._closing = False
        self.root.enabled = True
        root = self.root
        if appearing:
            def f(v):
                root.x = 0.14 * (1 - v)
                anim.set_alpha(root, min(1.0, v * 1.6))
            anim.tween(f, 0.3, ease=anim.out_cubic, key=("info", id(self)))
        elif switching:
            def f(v):
                root.x = 0.03 * (1 - v)
                anim.set_alpha(root, 0.35 + 0.65 * v)
            anim.tween(f, 0.2, ease=anim.out_cubic, key=("info", id(self)))
        enabled = row[8] if len(row) > 8 else True
        cfg = row[9] if len(row) > 9 and isinstance(row[9], dict) else {}
        if self.key != (bid, btype, planet):
            self._build(bid, btype, planet)
        spec = C.BUILDINGS[btype]
        status, progress, extra = dyn if dyn else ("idle", 0, {})
        st = C.STATUS.get(status, {"text": status, "level": "warn"})
        lvl_col = LEVEL_COLORS.get(st["level"], WARN)
        max_level = spec["max_level"]
        lvl_txt = f"Stufe {level}/{max_level}" if max_level > 1 else "Nicht ausbaubar"
        if btype in ("miner", "smelter", "conveyor") or btype in C.MACHINE_RECIPES:
            out_txt = f"Ausgang {C.DIR_NAMES[rot]}"
        elif btype in C.ROUTER_TYPES:
            out_txt = f"Eingang von {C.DIR_NAMES[(rot + 2) % 4]}"
        else:
            out_txt = "nimmt von allen Seiten an"
        self.level.set(f"{lvl_txt} · Feld {x},{y}\n{out_txt} · von {owner}")
        self.status.set(st["text"], lvl_col)
        self.pill_bg.color = color.rgba(lvl_col[0], lvl_col[1], lvl_col[2], 0.16)
        self.pill_bg.scale_x = max(0.12, self.status.width * self.status.scale_x + 0.03)
        show_bar = btype in ("miner", "smelter", "seller") or btype in C.MACHINE_RECIPES
        self.bar.enabled = show_bar
        if show_bar:
            self.bar.set(progress, lvl_col)

        lines = []
        if isinstance(extra, dict):
            if "in" in extra:
                inp = ", ".join(f"{C.ITEMS[i]['name']} {n}" for i, n in extra["in"].items()) or "leer"
                out = ", ".join(f"{C.ITEMS[i]['name']} {n}" for i, n in extra["out"].items()) or "leer"
                if btype != "miner":
                    lines.append(f"Eingang: {inp}")
                lines.append(f"Ausgang: {out}")
                if extra.get("ar"):
                    lines.append(f"Fertigt gerade: {C.RECIPES[extra['ar']]['name']}")
                lines.append(f"Hergestellt insgesamt: {extra.get('made', 0)}")
            if "q" in extra:
                lines.append(f"Warteschlange: {len(extra['q'])}/{C.BUILDINGS['seller']['in_cap']}")
                lines.append(f"Erlös dieses Verkäufers: {rules.format_money(extra.get('earned', 0))}")
            if "trucks" in extra:
                names = {"free": "frei", "loading": "lädt", "away": "unterwegs"}
                for i, t in enumerate(extra["trucks"][:3], start=1):
                    st, item, loaded, qty, city, back = (list(t) + [""] * 6)[:6]
                    if st == "loading" and item in C.ITEMS:
                        lines.append(f"LKW {i}: lädt {loaded}/{qty} {C.ITEMS[item]['name']} für {city}")
                    elif st == "away":
                        lines.append(f"LKW {i}: unterwegs, zurück in {rules.format_duration(back or 0)}")
                    else:
                        lines.append(f"LKW {i}: {names.get(st, st)} – wartet auf Auftrag (O)")
                store = extra.get("store") or {}
                total = sum(store.values())
                top = sorted(store.items(), key=lambda kv: -kv[1])[:3]
                what = ", ".join(f"{n}× {C.ITEMS[k]['name']}" for k, n in top if k in C.ITEMS)
                lines.append(f"Bahnhof-Lager: {total}/{extra.get('cap', 60)}" + (f" ({what})" if what else ""))
                caps = C.FREIGHT_STORE
                lines.append(f"Je Stufe: {caps[1]} / {caps[2]} / {caps[3]} Lagerplatz, 1 / 2 / 3 LKW  ·  Aufträge mit O")
            if "stored" in extra:
                lines.append(f"Hierüber eingelagert: {extra['stored']}")
                lines.append(f"Firmenlager: {state.inventory_total()}/{state.capacity}")
                caps = [int(C.BUILDINGS['storage']['capacity'] * C.LEVEL_CAPACITY[k] * state.mods.get('storage', 1))
                        for k in (1, 2, 3)]
                lines.append(f"Kapazität je Stufe: {caps[0]} / {caps[1]} / {caps[2]}")
        elif isinstance(extra, list):
            lines.append(f"Gegenstände: {len(extra)}/{spec['capacity']}")
            if btype == "conveyor":
                speed = C.BELT_SPEED * state.mods.get("belt", 1) * 60
                lines.append(f"Tempo: {speed:.0f} Felder/Min · max. ca. {speed / C.BELT_SPACING:.0f} Stück/Min")
            if btype in ("splitter", "tpiece"):
                lines.append("Verteilt abwechselnd: " + ", ".join(C.SIDE_NAMES[s] for s in spec["outputs"]))
        if btype == "miner":
            ore = state.deposits.get((x, y))
            lines.append(f"Vorkommen: {C.ITEMS[ore]['name'] if ore else 'keines'}")
        if btype in C.MACHINE_RECIPES and recipe in C.RECIPES:
            ins = " + ".join(f"{q} {C.ITEMS[i]['name']}" for i, q in C.RECIPES[recipe]["inputs"].items())
            import textwrap
            lines[0:0] = textwrap.wrap(tr(f"Braucht: {ins}"), 46)
        self.lines.set("\n".join(lines[:4]))

        if self.rate_rows:
            ore = state.deposits.get((x, y))
            for lvl, (bg, lab, val) in enumerate(self.rate_rows, start=1):
                rates = rules.theoretical_rates(btype, lvl, recipe=recipe, ore=ore,
                                                speed_mult=state.mods.get("speed", 1),
                                                miner_mult=state.mods.get("miner", 1), planet=planet)
                if btype == "smelter":
                    locked = {C.ITEMS[o]["name"] for rid, r in C.RECIPES.items() if r["machine"] == "smelter"
                              and not rules.recipe_unlocked(rid, state.unlocked) for o in r["outputs"]}
                    rates = [r for r in rates if r[0] not in locked]
                txt = "   ".join(f"{rules.format_rate(v)} {name}" for name, v in rates)
                if (btype == "smelter" and len(rates) <= 2) or btype in C.MACHINE_RECIPES:
                    rid = recipe if btype in C.MACHINE_RECIPES else rules.smelter_recipes(planet)[0]
                    if rid in C.RECIPES:
                        speed = rules.machine_speed(btype, lvl, state.mods.get("speed", 1))
                        e = rules.recipe_energy_per_min(rid, speed, state.mods.get("cost", 1))
                        txt += f"   Energie {e:.0f} €"
                val.set(txt, TEXT if lvl == level else FAINT)
                lab.set(f"Stufe {lvl}" + (" •" if lvl == level else ""), ACCENT if lvl == level else FAINT)
                bg.color = ACCENT_SOFT if lvl == level else color.rgba(1, 1, 1, 0)
            rpm = extra.get("rpm", 0) if isinstance(extra, dict) else 0
            unit = "Verkäufe" if btype == "seller" else "Stück"
            self.measured.set(f"Gemessen (letzte Minute): {rules.format_rate(rpm)} {unit}/Min")

        if btype in C.MACHINE_RECIPES:
            for rid, b in self.recipe_btns.items():
                unlocked = rules.recipe_unlocked(rid, state.unlocked)
                b.set_color(BUTTON_ACCENT if rid == recipe else (BUTTON if unlocked else BUTTON_LOCKED))
            r = C.RECIPES.get(recipe)
            if r:
                ins = " + ".join(f"{q} {C.ITEMS[i]['name']}" for i, q in r["inputs"].items())
                outs = " + ".join(f"{q} {C.ITEMS[i]['name']}" for i, q in r["outputs"].items())
                lock = ""
                if not rules.recipe_unlocked(recipe, state.unlocked):
                    lock = f" – benötigt {C.RESEARCH[r['requires']]['name']}"
                self.recipe_info.set(f"{r['name']}: {ins} » {outs} ({r['time']:.0f} s){lock}")
        if btype == "sorter":
            filters = cfg.get("filters", {})
            for item, row_btns in self.filter_btns.items():
                cur = filters.get(item, "F")
                for side, b in row_btns.items():
                    b.set_color(BUTTON_ACCENT if side == cur else BUTTON)
        if btype == "seller":
            cur = cfg.get("min_pct")
            for pct, b in self.thr_btns.items():
                b.set_color(BUTTON_ACCENT if pct == cur else BUTTON)
            queue = extra.get("q", []) if isinstance(extra, dict) else []
            if queue:
                item = queue[0]
                price = state.market.get("prices", {}).get(item, 0)
                base = C.ITEMS[item]["price"] * state.mods.get("price", 1)
                pct = (price / base - 1) * 100 if base else 0
                self.price_info.set(f"Nächste Ware: {C.ITEMS[item]['name']} · Preis {price:.2f} € ({pct:+.0f} %)")
            else:
                self.price_info.set("Keine Ware in der Warteschlange.")

        hint = spec["desc"]
        if st["level"] == "error":
            hint = HELP_FOR_STATUS.get(status, hint)
        self.desc.set(hint, BAD if st["level"] == "error" else MUTED)

        self.btn_power.set_text("Ausschalten (P)" if enabled else "Einschalten (P)")
        self.btn_power.set_color(BUTTON if enabled else BUTTON_GOOD)
        cost = rules.upgrade_cost(btype, level)
        self.btn_upgrade.enabled = cost is not None
        if cost is not None:
            self.btn_upgrade.set_text(f"Ausbau Stufe {level + 1}: {rules.format_money(cost)} (U)")
            self.btn_upgrade.set_color(BUTTON_ACCENT if state.available >= cost else BUTTON_LOCKED)
        self.btn_demolish.set_text(f"Abriss +{rules.format_money(rules.demolish_refund(btype, level))} (Entf)")


# =============================================================================
class BuyMenu(Window):
    """Kaufmenü (Q): alle Gebäude als Karten, gruppiert nach Kategorie."""

    COLS = 4
    CW = 0.37

    def __init__(self, anchors, on_pick, on_close):
        rows = (len(C.BUILDING_ORDER) + self.COLS - 1) // self.COLS
        super().__init__(anchors, "Kaufmenü", self.COLS * (self.CW + 0.015) + 0.045, 0.23 + rows * 0.2, on_close,
                         icon_name="ui_coin")
        self.on_pick = on_pick
        self.category = "all"
        self.tabs = {}
        x = -self.w / 2 + 0.03
        for key, name in [("all", "Alle")] + C.CATEGORIES:
            b = Btn(self.root, name, x + 0.085, self.h / 2 - 0.1, 0.17, 0.048, (lambda k=key: self.set_category(k)),
                    size=0.8)
            self.tabs[key] = b
            x += 0.18
        Label(self.root, "Karte anklicken, dann auf der Baufläche platzieren (E dreht). Q schließt das Menü.",
              -self.w / 2 + 0.03, -self.h / 2 + 0.035, size=0.7, col=MUTED)
        self.cards = {}
        self.cards_root = None
        self.state = None
        self.tool = None
        self.set_category("all")

    def set_category(self, key):
        self.category = key
        for k, b in self.tabs.items():
            b.set_color(BUTTON_ACCENT if k == key else BUTTON)
        self._build_cards()
        if self.state:
            self.refresh(self.state, self.tool)

    def _build_cards(self):
        if self.cards_root:
            self.cards_root.enabled = False
            self.cards_root.parent = None
        self.cards_root = Entity(parent=self.root)
        self.cards = {}
        planet = getattr(self, "planet", "earth")
        types = [b for b in rules.building_order(planet)
                 if self.category == "all" or C.BUILDINGS[b]["category"] == self.category]
        cw, ch, gap = self.CW, 0.185, 0.015
        x0 = -self.w / 2 + 0.03
        y0 = self.h / 2 - 0.15
        for i, btype in enumerate(types):
            col_i, row_i = i % self.COLS, i // self.COLS
            x = x0 + col_i * (cw + gap)
            y = y0 - row_i * (ch + gap)
            spec = C.BUILDINGS[btype]
            card = Button(parent=self.cards_root, position=(x + cw / 2, y - ch / 2, -0.01), scale=(cw, ch),
                          color=CARD, radius=0.06)
            card.highlight_color = CARD_HOVER
            card.on_click = (lambda b=btype: self.on_pick(b))
            ic = icon(self.cards_root, btype, x + 0.01, y - 0.012, 0.13, z=-0.02)
            Label(self.cards_root, spec["name"], x + 0.15, y - 0.018, size=0.95, z=-0.02)
            key_lbl = Label(self.cards_root, f"Taste {spec['hotkey']}" if spec["hotkey"] else " ",
                            x + cw - 0.012, y - ch + 0.03, size=0.62, col=FAINT, origin=(0.5, 0.5), z=-0.02)
            price = Label(self.cards_root, rules.format_money(spec["cost"]), x + 0.15, y - 0.054, size=0.9, col=GOLD,
                          z=-0.02)
            Label(self.cards_root, spec["desc"], x + 0.15, y - 0.086, size=0.56, col=MUTED, wordwrap=30, z=-0.02)
            lock = Label(self.cards_root, "", x + 0.012, y - ch + 0.03, size=0.64, col=BAD, z=-0.02)
            self.cards[btype] = {"card": card, "icon": ic, "price": price, "lock": lock, "key": key_lbl}

    def refresh(self, state, tool):
        self.state, self.tool = state, tool
        if getattr(self, "planet", "earth") != state.planet:
            self.planet = state.planet            # Mond: nur Gebäude, die es dort gibt
            self._build_cards()
        for btype, c in self.cards.items():
            req = C.BUILDINGS[btype]["requires"]
            locked = not rules.building_unlocked(btype, state.unlocked, state.planet)
            cost = C.BUILDINGS[btype]["cost"]
            if locked:
                c["lock"].set(f"Gesperrt – Forschung: {C.RESEARCH[req]['name']}", BAD)
            elif state.available < cost:
                c["lock"].set("Nicht genug Geld", WARN)
            else:
                c["lock"].set(" ")
            # Bei langem Hinweis die Tasten-Angabe ausblenden, damit sich nichts überlappt
            if c["key"].enabled == locked:
                c["key"].enabled = not locked
            c["icon"].color = color.rgba(1, 1, 1, 0.35 if locked else 1)
            c["price"].color = BAD if state.available < cost else GOLD
            col = ACCENT_DIM if btype == tool else (BUTTON_LOCKED if locked else CARD)
            if c["card"].color != col:
                c["card"].color = col
                c["card"].highlight_color = col.tint(0.1)


# =============================================================================
class ResearchWindow(Window):
    NODE_W, NODE_H = 0.235, 0.112
    STEP_X, STEP_Y = 0.272, 0.126

    def __init__(self, anchors, on_research, on_close):
        cols = max(t["pos"][0] for t in C.RESEARCH.values()) + 1
        rows = max(t["pos"][1] for t in C.RESEARCH.values()) + 1
        w = cols * self.STEP_X + 0.05
        h = rows * self.STEP_Y + 0.25
        super().__init__(anchors, "Forschungsbaum", w, h, on_close, icon_name="ui_research")
        self.on_research = on_research
        self.state = None
        self.hover = None
        # Reiter: Gebäude & Produkte / Verbesserungen
        self.tab_btns = {}
        self.planet = "earth"
        slot = {}
        for key, name in C.RESEARCH_TABS:            # Erde: a/b, Mond: m/n – jeweils auf denselben Plätzen
            pl = C.RESEARCH_TAB_PLANET.get(key, "earth")
            i = slot[pl] = slot.get(pl, -1) + 1
            bw = 0.26 if pl == "earth" else 0.33
            bx = -w / 2 + 0.03 + i * (bw + 0.015)
            self.tab_btns[key] = Btn(self.root, name, bx + bw / 2, h / 2 - 0.1, bw, 0.048,
                                     (lambda k=key: self.set_tab(k)), size=0.82)
            self.tab_btns[key].enabled = pl == "earth"
        x = -w / 2 + 0.03 + 2 * (0.33 + 0.015)
        self.tab_counts = Label(self.root, "", x + 0.01, h / 2 - 0.088, size=0.7, col=FAINT)
        self.status = Label(self.root, "", -w / 2 + 0.03, h / 2 - 0.14, size=0.85, col=MUTED)
        self.active_bar = ProgressBar(self.root, -w / 2 + 0.03, h / 2 - 0.172, w - 0.06, 0.01, col=BLUE)
        self.origin_x, self.origin_y = -w / 2 + 0.035, h / 2 - 0.195
        self.nodes = {}
        self.lines = []
        self.pages = {key: Entity(parent=self.root) for key, _ in C.RESEARCH_TABS}
        for tid, tech in C.RESEARCH.items():
            page = self.pages[tech["tab"]]
            for req in tech["requires"]:
                if C.RESEARCH[req]["tab"] != tech["tab"]:
                    continue                      # Voraussetzung im anderen Reiter: steht im Hinweis
                x0, y0 = self._anchor(C.RESEARCH[req]["pos"], right=True)
                x1, y1 = self._anchor(tech["pos"], right=False)
                dx, dy = x1 - x0, y1 - y0
                line = Entity(parent=page, model="quad", position=((x0 + x1) / 2, (y0 + y1) / 2, -0.005),
                              scale=(math.hypot(dx, dy), 0.004), rotation_z=-math.degrees(math.atan2(dy, dx)),
                              color=color.rgba(1, 1, 1, 0.12))
                self.lines.append((line, req, tid))
        for tid, tech in C.RESEARCH.items():
            page = self.pages[tech["tab"]]
            x, y = self._corner(tech["pos"])
            btn = AnimButton(parent=page, position=(x + self.NODE_W / 2, y - self.NODE_H / 2, -0.02),
                             scale=(self.NODE_W, self.NODE_H), color=BUTTON, radius=0.1)
            btn.HOVER_SCALE = 1.03
            btn.on_click = (lambda t=tid: self.on_research(t))
            btn.on_mouse_enter = (lambda t=tid: self._hover(t))
            btn.on_mouse_exit = (lambda t=tid: self._hover(None, t))
            name = Label(page, tech["name"], x + 0.01, y - 0.009, size=0.78, z=-0.03)
            Label(page, f"{short_money(tech['cost'])} · {tech['time']} s", x + 0.01, y - 0.044,
                  size=0.64, col=GOLD, z=-0.03)
            Label(page, tech["desc"], x + 0.01, y - 0.068, size=0.54, col=MUTED, z=-0.03, wordwrap=37)
            state = Label(page, "", x + self.NODE_W - 0.01, y - 0.044, size=0.58, col=MUTED,
                          origin=(0.5, 0.5), z=-0.03)
            bar = ProgressBar(page, x + 0.004, y - self.NODE_H + 0.007, self.NODE_W - 0.008, 0.005, col=BLUE,
                              z=-0.03)
            self.nodes[tid] = {"btn": btn, "name": name, "state": state, "bar": bar}
        Label(self.root, "Klick auf eine verfügbare Technologie startet die Forschung. Maus darüber zeigt, was noch "
                         "fehlt. Es läuft immer eine Forschung gleichzeitig.",
              -w / 2 + 0.03, -h / 2 + 0.035, size=0.66, col=MUTED)
        self.tab = None
        self.set_tab(C.RESEARCH_TABS[0][0])

    def set_planet(self, planet):
        """Erde und Mond haben getrennte Forschungsbäume."""
        self.planet = planet
        for k, b in self.tab_btns.items():
            b.enabled = C.RESEARCH_TAB_PLANET.get(k, "earth") == planet
        if C.RESEARCH_TAB_PLANET.get(self.tab, "earth") != planet:
            self.set_tab(rules.research_tabs(planet)[0][0])

    def set_tab(self, key):
        self.tab = key
        for k, page in self.pages.items():
            page.enabled = k == key
        for k, b in self.tab_btns.items():
            b.set_color(BUTTON_ACCENT if k == key else BUTTON)
        if self.state:
            self.refresh(self.state)

    def _hover(self, tid, leaving=None):
        if tid is None and self.hover != leaving:
            return
        self.hover = tid
        if self.state:
            self.refresh(self.state)

    def _corner(self, pos):
        col_i, row_i = pos
        return self.origin_x + col_i * self.STEP_X, self.origin_y - row_i * self.STEP_Y

    def _anchor(self, pos, right):
        x, y = self._corner(pos)
        return x + (self.NODE_W if right else 0), y - self.NODE_H / 2

    def refresh(self, state):
        self.state = state
        active = state.research_active
        counts = []
        for key, name in rules.research_tabs(self.planet):
            ids = [t for t, v in C.RESEARCH.items() if v["tab"] == key]
            counts.append(f"{name}: {sum(1 for t in ids if t in state.unlocked)}/{len(ids)}")
        self.tab_counts.set("   ·   ".join(counts))
        if self.hover and self.hover not in state.unlocked:
            tech = C.RESEARCH[self.hover]
            missing = [C.RESEARCH[r]["name"] for r in tech["requires"] if r not in state.unlocked]
            if missing:
                self.status.set(f"{tech['name']} benötigt noch: " + ", ".join(missing), WARN)
            else:
                self.status.set(f"{tech['name']}: {tech['desc']} Kosten {short_money(tech['cost'])}.", ACCENT)
        elif active:
            tech = C.RESEARCH[active["id"]]
            ratio = active["progress"] / max(0.01, active["time"])
            remaining = max(0, active["time"] - active["progress"])
            self.status.set(f"Aktive Forschung: {tech['name']} – {int(ratio * 100)} % (noch {remaining:.0f} s)", BLUE)
            self.active_bar.set(ratio, BLUE)
        else:
            total = len(rules.research_ids(self.planet))
            self.status.set(f"Keine aktive Forschung · {len(state.unlocked)}/{total} Technologien erforscht",
                            MUTED)
            self.active_bar.set(len(state.unlocked) / max(1, total), color.rgba(0.3, 0.5, 0.8, 0.5))
        for tid, node in self.nodes.items():
            tech = C.RESEARCH[tid]
            if tech["tab"] != self.tab:
                continue
            if tid in state.unlocked:
                col, txt, tcol = color.rgba(0.12, 0.30, 0.17, 1), "ERFORSCHT", GOOD
                node["bar"].set(1, GOOD)
            elif active and active["id"] == tid:
                col, txt, tcol = color.rgba(0.12, 0.22, 0.38, 1), "LÄUFT", BLUE
                node["bar"].set(active["progress"] / max(0.01, active["time"]), BLUE)
            elif all(r in state.unlocked for r in tech["requires"]):
                affordable = state.available >= tech["cost"]
                col = color.rgba(0.30, 0.20, 0.07, 1) if affordable else BUTTON
                txt = "VERFÜGBAR" if affordable else "ZU TEUER"
                tcol = ACCENT if affordable else WARN
                node["bar"].set(0)
            else:
                col, txt, tcol = BUTTON_LOCKED, "GESPERRT", FAINT
                node["bar"].set(0)
            if node["btn"].color != col:
                node["btn"].color = col
                node["btn"].highlight_color = col.tint(0.12)
            node["state"].set(txt, tcol)
            node["name"].color = MUTED if txt == "GESPERRT" else TEXT
        for line, req, tid in self.lines:
            line.color = color.rgba(0.38, 0.93, 0.5, 0.6) if req in state.unlocked else color.rgba(1, 1, 1, 0.1)


# =============================================================================
class MarketWindow(Window):
    def __init__(self, anchors, on_sell, on_close):
        super().__init__(anchors, "Markt", 1.5, 0.94, on_close, icon_name="ui_market")
        self.on_sell = on_sell
        w, h = self.w, self.h
        self.summary = Label(self.root, "", -w / 2 + 0.03, h / 2 - 0.085, size=0.9, col=MUTED)
        y0 = h / 2 - 0.135
        col_w = (w - 0.06) / 2
        self.rows = {}
        for c_i in range(2):
            bx = -w / 2 + 0.03 + c_i * (col_w + 0.0)
            for title, dx in [("Ware", 0.01), ("Preis", 0.235), ("Trend", 0.345), ("Lager", 0.42), ("Verkauft", 0.5)]:
                Label(self.root, title, bx + dx, y0, size=0.68, col=MUTED)
        rect(self.root, -w / 2 + 0.03, y0 - 0.03, w - 0.06, 0.002, color.rgba(1, 1, 1, 0.12))
        # je Himmelskörper eine eigene Warenliste (Erde: Euro-Waren, Mond: Mond-Waren)
        self.boxes = {}
        self.planet = None
        for planet in ("earth", "moon"):
            box = self.boxes[planet] = Entity(parent=self.root)
            items = rules.item_order(planet)
            per_col = (len(C.ITEM_ORDER) + 1) // 2
            for i, item in enumerate(items):
                c_i, r_i = i // per_col, i % per_col
                bx = -w / 2 + 0.03 + c_i * col_w
                y = y0 - 0.05 - r_i * 0.058
                if r_i % 2 == 0:
                    rect(box, bx - 0.005, y + 0.012, col_w - 0.01, 0.056, color.rgba(1, 1, 1, 0.025), z=-0.005)
                icon(box, item, bx + 0.005, y + 0.006, 0.038)
                Label(box, C.ITEMS[item]["name"], bx + 0.05, y - 0.006, size=0.74)
                self.rows[item] = {
                    "price": Label(box, "", bx + 0.235, y - 0.006, size=0.76, col=GOLD),
                    "trend": Label(box, "", bx + 0.345, y - 0.006, size=0.7),
                    "stock": Label(box, "", bx + 0.42, y - 0.006, size=0.76),
                    "sold": Label(box, "", bx + 0.5, y - 0.006, size=0.72, col=MUTED),
                    "sell10": Btn(box, "10", bx + col_w - 0.125, y - 0.016, 0.06, 0.04,
                                  (lambda it=item: self.on_sell(it, 10)), size=0.62),
                    "sellall": Btn(box, "Alle", bx + col_w - 0.055, y - 0.016, 0.07, 0.04,
                                   (lambda it=item: self.on_sell(it, "all")), size=0.62, col=BUTTON_ACCENT),
                    "planet": planet,
                }
            box.enabled = planet == "earth"
        Label(self.root, "Preise sinken bei großen Verkaufsmengen und erholen sich mit der Zeit. Verkäufer-Gebäude "
                         "verkaufen automatisch - im Infofenster lässt sich ein Mindestpreis einstellen.",
              -w / 2 + 0.03, -h / 2 + 0.05, size=0.62, col=MUTED, wordwrap=150)

    def refresh(self, state):
        m = state.market
        if not m:
            return
        self.summary.set(f"Gesamterlös: {rules.format_money(m.get('total', 0))}   ·   Einnahmen letzte Minute: "
                         f"{rules.format_money(m.get('per_min', 0))}   ·   Lager: {state.inventory_total()}/{state.capacity}")
        prices = m.get("prices", {})
        planet = getattr(state, "planet", "earth")
        if planet != self.planet:
            self.planet = planet
            for p, box in self.boxes.items():
                box.enabled = p == planet
        for item, row in self.rows.items():
            if row["planet"] != planet:
                continue
            price = prices.get(item, 0)
            base = C.ITEMS[item]["price"] * state.mods.get("price", 1.0)
            row["price"].set(f"{price:.2f} €" if price < 1000 else f"{price:.0f} €")
            pct = (price / base - 1) * 100 if base else 0
            row["trend"].set(f"{pct:+.0f} %", GOOD if pct > 1 else (BAD if pct < -1 else MUTED))
            stock = state.inventory.get(item, 0)
            row["stock"].set(str(stock), TEXT if stock else FAINT)
            row["sold"].set(str(m.get("sold", {}).get(item, 0)))


# =============================================================================
class OrdersWindow(Window):
    """Auftragsbörse (links) und eigene Aufträge mit LKW-Status (rechts)."""

    ROWS = 6

    def __init__(self, anchors, cb, on_close):
        super().__init__(anchors, "Aufträge & Spedition", 1.56, 0.92, on_close, icon_name="ui_truck")
        self.cb = cb
        w, h = self.w, self.h
        self.summary = Label(self.root, "", -w / 2 + 0.03, h / 2 - 0.085, size=0.82, col=MUTED)
        col_w = (w - 0.08) / 2
        lx, rx = -w / 2 + 0.03, -w / 2 + 0.05 + col_w
        top = h / 2 - 0.13
        for x, title in ((lx, "Auftragsbörse"), (rx, "Deine Aufträge")):
            panel(self.root, x, top, col_w, h - 0.22, PANEL_LIGHT, radius=0.014, collider=False, edge=False)
            Label(self.root, title, x + 0.02, top - 0.018, size=1.1, col=ACCENT)
        self.empty_l = Label(self.root, "", lx + 0.02, top - 0.075, size=0.74, col=FAINT, wordwrap=58)
        self.empty_r = Label(self.root, "", rx + 0.02, top - 0.075, size=0.74, col=FAINT, wordwrap=58)
        rh = 0.098
        self.offers = []
        self.mine = []
        for i in range(self.ROWS):
            y = top - 0.065 - i * rh
            # Angebot
            r = {"bg": rect(self.root, lx + 0.012, y, col_w - 0.024, rh - 0.01, CARD, z=-0.005)}
            r["icon"] = icon(self.root, "iron_ore", lx + 0.024, y - 0.012, 0.06)
            r["title"] = Label(self.root, "", lx + 0.095, y - 0.012, size=0.84)
            r["info"] = Label(self.root, "", lx + 0.095, y - 0.045, size=0.64, col=MUTED)
            r["reward"] = Label(self.root, "", lx + col_w - 0.185, y - 0.014, size=0.86, col=GOLD, origin=(0.5, 0.5))
            r["btn"] = Btn(self.root, "Annehmen", lx + col_w - 0.085, y - 0.045, 0.13, 0.042,
                           (lambda k=i: self._accept(k)), col=BUTTON_ACCENT, size=0.62)
            r["id"] = None
            self.offers.append(r)
            # eigener Auftrag
            m = {"bg": rect(self.root, rx + 0.012, y, col_w - 0.024, rh - 0.01, CARD, z=-0.005)}
            m["icon"] = icon(self.root, "iron_ore", rx + 0.024, y - 0.012, 0.06)
            m["title"] = Label(self.root, "", rx + 0.095, y - 0.012, size=0.84)
            m["info"] = Label(self.root, "", rx + 0.095, y - 0.045, size=0.64, col=MUTED)
            m["bar"] = ProgressBar(self.root, rx + 0.095, y - 0.072, col_w - 0.43, 0.01, col=ACCENT)
            m["reward"] = Label(self.root, "", rx + col_w - 0.03, y - 0.014, size=0.82, col=GOLD, origin=(0.5, 0.5))
            m["load"] = Btn(self.root, "Aus Lager", rx + col_w - 0.19, y - 0.06, 0.12, 0.038,
                            (lambda k=i: self._mine_action(k, "load")), size=0.58)
            m["cancel"] = Btn(self.root, "Stornieren", rx + col_w - 0.07, y - 0.06, 0.11, 0.038,
                              (lambda k=i: self._mine_action(k, "cancel")), col=BUTTON_DANGER, size=0.56)
            m["id"] = None
            self.mine.append(m)
        Label(self.root, "So geht's: Auftrag annehmen  »  Frachtbahnhof bauen (Q, Lager & Handel)  »  passende Waren "
                         "per Förderband anliefern oder „Aus Lager“ klicken  »  ist der LKW voll, fährt er los und "
                         "bringt nach der Fahrzeit die Belohnung. Jede Ausbaustufe des Bahnhofs = ein LKW mehr.",
              -w / 2 + 0.03, -h / 2 + 0.065, size=0.62, col=MUTED, wordwrap=160)

    def _accept(self, k):
        oid = self.offers[k]["id"]
        if oid is not None:
            self.cb["accept"](oid)

    def _mine_action(self, k, what):
        cid = self.mine[k]["id"]
        if cid is not None:
            self.cb[what](cid)

    @staticmethod
    def _set_row(row, on):
        for key, e in row.items():
            if key == "id":
                continue
            e.enabled = on

    def refresh(self, state):
        from . import freight as F
        from . import textures
        fr = state.freight or {}
        unlocked = "freight" in state.unlocked
        rep = fr.get("rep", 1)
        nxt = F.REP_STEP - fr.get("deliveries", 0) % F.REP_STEP
        rep_txt = (f"Speditions-Ruf: Stufe {rep}/{F.REP_MAX} (+{(rep - 1) * 4} % Belohnung"
                   + (f", nächste Stufe in {nxt} Lieferungen)" if rep < F.REP_MAX else ")"))
        self.summary.set(f"{rep_txt}   ·   Lieferungen: {fr.get('deliveries', 0)}   ·   Einnahmen aus Aufträgen: "
                         f"{rules.format_money(fr.get('income', 0))}")
        board = fr.get("board", []) if unlocked else []
        contracts = fr.get("contracts", [])
        stations = sum(1 for row in state.static.values() if row[1] == "freight")
        if not unlocked:
            self.empty_l.set("Erforsche „Spedition“ (R), um Aufträge annehmen zu können. Städte zahlen für "
                             "Lieferungen per LKW deutlich mehr als der Markt.")
        elif not board:
            self.empty_l.set("Gerade keine Angebote. Neue Aufträge kommen etwa alle halbe Minute.")
        else:
            self.empty_l.set(" ")
        self.empty_r.set(" " if contracts else ("Noch keine Aufträge angenommen." if unlocked else " "))
        for i, r in enumerate(self.offers):
            o = board[i] if i < len(board) else None
            self._set_row(r, o is not None)
            r["id"] = o["id"] if o else None
            if not o:
                continue
            r["icon"].texture = textures.icon(o["item"])
            r["title"].set(f"{o['qty']}× {C.ITEMS[o['item']]['name']}  »  {o['city']}")
            stock = state.inventory.get(o["item"], 0)
            r["info"].set(f"Fahrzeit {rules.format_duration(o['min'] * 60)}  ·  Angebot noch "
                          f"{rules.format_duration(max(0, o['exp']))}  ·  im Lager: {stock}")
            r["reward"].set(rules.format_money(o["reward"]))
            full = len(contracts) >= fr.get("max", 6)
            r["btn"].set_color(BUTTON_LOCKED if full else BUTTON_ACCENT)
        for i, m in enumerate(self.mine):
            c = contracts[i] if i < len(contracts) else None
            self._set_row(m, c is not None)
            m["id"] = c["id"] if c else None
            if not c:
                continue
            m["icon"].texture = textures.icon(c["item"])
            m["title"].set(f"{c['qty']}× {C.ITEMS[c['item']]['name']}  »  {c['city']}")
            m["reward"].set(rules.format_money(c["reward"]))
            st = c["status"]
            if st == "enroute":
                done = 1 - c["eta"] / c["total"] if c["total"] else 1
                m["info"].set(f"LKW unterwegs  ·  Ankunft in {rules.format_duration(c['eta'])}", GOOD)
                m["bar"].set(done, GOOD)
            elif st == "loading":
                m["info"].set(f"Wird beladen: {c['loaded']}/{c['qty']}  ·  Fahrzeit "
                              f"{rules.format_duration(c['total'])}", ACCENT)
                m["bar"].set(c["loaded"] / max(1, c["qty"]), ACCENT)
            else:
                m["info"].set("Wartet auf einen freien LKW" if stations else
                              "Kein Frachtbahnhof – baue einen (Q, Lager & Handel)", WARN)
                m["bar"].set(c["loaded"] / max(1, c["qty"]), WARN)
            m["load"].enabled = st == "loading"
            m["cancel"].enabled = st != "enroute"


# =============================================================================
class NewsWindow(Window):
    """Neuigkeiten nach einem Update – und das Update-Angebot selbst (mit Fortschrittsbalken)."""

    def __init__(self, anchors, cb):
        super().__init__(anchors, "Neuigkeiten", 1.1, 0.62, lambda: cb["later"](), z=-0.7, icon_name="ui_stats")
        self.cb = cb
        w, h = self.w, self.h
        self.head = Label(self.root, "", -w / 2 + 0.04, h / 2 - 0.095, size=1.05, col=ACCENT)
        self.body = Label(self.root, "", -w / 2 + 0.04, h / 2 - 0.15, size=0.82, col=TEXT)
        self.status = Label(self.root, "", -w / 2 + 0.04, -h / 2 + 0.135, size=0.74, col=MUTED, wordwrap=90)
        self.bar = ProgressBar(self.root, -w / 2 + 0.04, -h / 2 + 0.1, w - 0.08, 0.012, col=GOOD)
        self.primary = Btn(self.root, "", w / 2 - 0.2, -h / 2 + 0.05, 0.34, 0.058, lambda: self.cb["primary"](),
                           col=BUTTON_ACCENT, size=0.9)
        self.secondary = Btn(self.root, "Später", w / 2 - 0.45, -h / 2 + 0.05, 0.14, 0.058,
                             lambda: self.cb["later"](), size=0.85)

    @staticmethod
    def _notes_text(notes, limit=16):
        lines = []
        for version, items in notes:
            if len(notes) > 1:
                lines.append(f"Version {version}")
            import textwrap
            for x in items:
                wrapped = textwrap.wrap(tr(x), 74) or [""]
                lines.append(f"  •  {wrapped[0]}")
                lines += [f"      {w}" for w in wrapped[1:]]
            lines.append("")
        if len(lines) > limit:
            lines = lines[:limit - 1] + ["  … und mehr"]
        return "\n".join(lines).rstrip()

    def show_news(self, version, notes):
        self.mode = "news"
        self.title.set("Neuigkeiten")
        self.head.set(f"Neu in Version {version}")
        self.body.set(self._notes_text(notes))
        self.status.set(" ")
        self.bar.enabled = False
        self.primary.set_text("Los geht's!")
        self.secondary.enabled = False
        self.show()

    def show_update(self, version, notes, full_download=False):
        self.mode = "full" if full_download else "update"
        self.title.set("Update verfügbar")
        self.head.set(f"Version {version} ist da!")
        self.body.set(self._notes_text(notes) or "Verbesserungen und Fehlerbehebungen.")
        if full_download:
            self.status.set("Diese Version braucht einen neuen Download (größere technische Änderungen). "
                            "Spielstände bleiben erhalten, wenn du den Ordner „saves“ mitnimmst.", WARN)
            self.primary.set_text("Download-Seite öffnen")
        else:
            self.status.set("Das Update wird direkt im Spiel installiert (wenige MB), danach startet das Spiel "
                            "neu. Deine Spielstände bleiben erhalten.", MUTED)
            self.primary.set_text("Jetzt aktualisieren")
        self.bar.enabled = False
        self.secondary.enabled = True
        self.primary.enabled = True
        self.show()

    def set_progress(self, ratio, text, col=MUTED):
        self.bar.enabled = True
        self.bar.set(ratio)
        self.status.set(text, col)

    def set_busy(self, busy):
        self.primary.enabled = not busy
        self.secondary.enabled = not busy


# =============================================================================
SHOW_SECRET = {"on": False}      # Test-World freigeschaltet: Mond-Erfolge schon vor dem Countdown zeigen


class StatsWindow(Window):
    """Statistiken (über alle Welten) und Erfolge – im Hauptmenü."""

    PER_PAGE = 16

    def __init__(self, anchors, stats, on_close):
        from . import stats as S
        super().__init__(anchors, "Statistiken & Erfolge", 1.4, 1.0, on_close, z=-0.5, icon_name="ui_stats")
        self.stats = stats
        w, h = self.w, self.h
        lx, rx = -w / 2 + 0.03, 0.02
        top = h / 2 - 0.09
        cw = w / 2 - 0.05
        panel(self.root, lx, top, cw, h - 0.13, PANEL_LIGHT, radius=0.014, collider=False, edge=False)
        panel(self.root, rx, top, cw, h - 0.13, PANEL_LIGHT, radius=0.014, collider=False, edge=False)
        Label(self.root, "Statistiken", lx + 0.02, top - 0.018, size=1.1, col=ACCENT)
        self.first = Label(self.root, "", lx + cw - 0.02, top - 0.026, size=0.62, col=FAINT, origin=(0.5, 0.5))
        self.rows = {}
        y = top - 0.07
        for i, key in enumerate(S.ORDER):
            if i % 2 == 0:
                rect(self.root, lx + 0.01, y + 0.008, cw - 0.02, 0.044, color.rgba(1, 1, 1, 0.03), z=-0.005)
            name_lbl = Label(self.root, S.COUNTERS[key][0], lx + 0.025, y - 0.006, size=0.76, col=MUTED)
            self.rows[key] = Label(self.root, "", lx + cw - 0.025, y - 0.006, size=0.82, col=TEXT, origin=(0.5, 0.5))
            self.rows[key].name_lbl = name_lbl
            y -= 0.046
        Label(self.root, "Erfolge", rx + 0.02, top - 0.018, size=1.1, col=ACCENT)
        self.ach_count = Label(self.root, "", rx + cw - 0.02, top - 0.026, size=0.7, col=GOLD, origin=(0.5, 0.5))
        # Erfolge seitenweise (es sind mehr, als in eine Spalte passen)
        self.slots = []
        y = top - 0.07
        for i in range(self.PER_PAGE):
            star = icon(self.root, "ui_admin", rx + 0.02, y + 0.004, 0.034)
            t = Label(self.root, " ", rx + 0.065, y - 0.001, size=0.76)
            d = Label(self.root, " ", rx + 0.34, y - 0.004, size=0.62, col=MUTED)
            self.slots.append((star, t, d))
            y -= 0.046
        self.page = 0
        by = -h / 2 + 0.07
        self.prev_btn = Btn(self.root, "«", rx + cw - 0.2, by, 0.05, 0.04, lambda: self._flip(-1), size=0.9)
        self.next_btn = Btn(self.root, "»", rx + cw - 0.04, by, 0.05, 0.04, lambda: self._flip(1), size=0.9)
        self.page_lbl = Label(self.root, "", rx + cw - 0.12, by + 0.012, size=0.66, col=FAINT, origin=(0, 0.5))

    def refresh(self):
        from . import stats as S
        data = self.stats.data
        reveal = rules.moon_open(False) or SHOW_SECRET["on"]   # Mond-Einträge erst nach dem Countdown
        for key, lbl in self.rows.items():
            lbl.set(S.fmt(key, data.get(key, 0)))
            show = key not in S.SECRET or reveal or data.get(key, 0) > 0
            lbl.enabled = lbl.name_lbl.enabled = show
        self.first.set(f"seit {data['first']}" if data.get("first") else "noch nicht gespielt")
        visible = [a for a in S.ACHIEVEMENTS if a[0] not in S.SECRET or reveal or a[0] in self.stats.unlocked]
        # freigeschaltete zuerst, sonst in der festen Reihenfolge
        visible.sort(key=lambda a: a[0] not in self.stats.unlocked)
        n = sum(1 for a in visible if a[0] in self.stats.unlocked)
        pages = max(1, (len(visible) + self.PER_PAGE - 1) // self.PER_PAGE)
        self.page = max(0, min(self.page, pages - 1))
        chunk = visible[self.page * self.PER_PAGE:(self.page + 1) * self.PER_PAGE]
        for i, (star, t, d) in enumerate(self.slots):
            if i >= len(chunk):
                star.enabled = False
                t.set(" ")
                d.set(" ")
                continue
            aid, name, desc, _ = chunk[i]
            got = aid in self.stats.unlocked
            star.enabled = True
            star.color = color.white if got else color.rgba(1, 1, 1, 0.15)
            t.set(name, TEXT if got else FAINT)
            d.set(desc, MUTED if got else color.rgba(1, 1, 1, 0.25))
        self.page_lbl.set(f"Seite {self.page + 1}/{pages}")
        self.prev_btn.enabled = self.page > 0
        self.next_btn.enabled = self.page < pages - 1
        self.ach_count.set(f"{n}/{len(visible)} freigeschaltet")

    def _flip(self, d):
        self.page += d
        self.refresh()

    def show(self):
        self.refresh()
        super().show()


# =============================================================================
class SettingsMenu(Window):
    """Menü (Esc) mit Einstellungen: GUI-Größe, Vollbild, Maus, Lautstärke ..."""

    def __init__(self, anchors, settings, cb):
        super().__init__(anchors, "Menü & Einstellungen", 1.62, 0.92, cb["resume"], z=-0.5, icon_name="ui_settings")
        self.cb = cb
        self.settings = settings
        w, h = self.w, self.h
        nav_x = -w / 2 + 0.03
        panel(self.root, nav_x - 0.01, h / 2 - 0.08, 0.34, h - 0.11, PANEL_LIGHT, collider=False, edge=False)
        entries = [("Weiterspielen", cb["resume"], BUTTON_ACCENT), ("Speichern (F5)", cb["save"], BUTTON),
                   ("Laden (F9)", cb["load"], BUTTON), ("Steuerung & Hilfe (F1)", cb["help"], BUTTON),
                   ("Admin-Panel (F2)", cb["admin"], BUTTON), ("Verbindung trennen", cb["disconnect"], BUTTON),
                   ("Spiel beenden", cb["quit"], BUTTON_DANGER)]
        y = h / 2 - 0.13
        self.nav = []
        for text, fn, col in entries:
            self.nav.append(Btn(self.root, text, nav_x + 0.16, y, 0.3, 0.058, fn, col=col, size=0.85))
            y -= 0.072
        # Im Hauptmenü: nur "Zurück" und Hilfe (Speichern, Laden, Admin ... gibt es dort nicht)
        self.back_btn = Btn(self.root, "Zurück", nav_x + 0.16, h / 2 - 0.13, 0.3, 0.058, cb["resume"],
                            col=BUTTON_ACCENT, size=0.85)
        self.back_btn.enabled = False
        # Adresse für Freunde, wenn man selbst hostet
        self.host_title = Label(self.root, "", nav_x, y - 0.005, size=0.72, col=ACCENT, wordwrap=34)
        self.host_info = Label(self.root, "", nav_x, y - 0.04, size=0.78, col=TEXT, wordwrap=34)
        self.copy_btn = Btn(self.root, "Kopieren", nav_x + 0.16, y - 0.125, 0.3, 0.046,
                            lambda: cb["copy"](), size=0.75)
        self.copy_btn.enabled = False
        self.in_menu = False

        from .settings import FPS_CHOICES
        from .i18n import LANGUAGES
        sx = nav_x + 0.38
        right = w / 2 - 0.03
        # ---- Reiter: Anzeige · Leistung · Audio · Steuerung
        self.pages = {}
        self.tab_btns = {}
        tabs = [("display", "Anzeige"), ("performance", "Leistung"), ("audio", "Audio"), ("controls", "Steuerung")]
        tw = (right - sx - 0.03) / len(tabs)
        for i, (key, name) in enumerate(tabs):
            self.tab_btns[key] = Btn(self.root, name, sx + i * (tw + 0.01) + tw / 2, h / 2 - 0.105, tw, 0.052,
                                     (lambda k=key: self.set_page(k)), size=0.9)
            self.pages[key] = Entity(parent=self.root)
        rect(self.root, sx, h / 2 - 0.145, right - sx, 0.003, color.rgba(1, 1, 1, 0.1))
        top = h / 2 - 0.2
        lw = 0.36                     # Breite der Beschriftung
        step = 0.066

        def row_label(page, text, y):
            return Label(page, text, sx + 0.01, y + 0.012, size=0.9, max_w=lw - 0.02)

        def head(page, text, y):
            Label(page, text, sx + 0.01, y + 0.01, size=0.95, col=ACCENT)

        def vol_slider(page, y, key):
            return Slider(page, sx + lw, y, 0.3, 0.0, 1.0, settings[key], lambda v, k=key: cb["setting"](k, v),
                          fmt=lambda v: f"{v * 100:.0f} %", step=0.01)

        # -- Anzeige
        pg = self.pages["display"]
        y = top
        row_label(pg, "GUI-Größe", y)
        self.gui_slider = Slider(pg, sx + lw, y, 0.3, 0.6, 1.6, settings["gui_scale"],
                                 None, fmt=lambda v: f"{v * 100:.0f} %", step=0.05,
                                 on_release=lambda v: cb["setting"]("gui_scale", v))
        Btn(pg, "100 %", sx + lw + 0.44, y, 0.08, 0.036, lambda: self._set_gui(1.0), size=0.62)
        y -= step
        row_label(pg, "Sprache", y)
        self.lang_choice = Choice(pg, sx + lw, y, 0.3, LANGUAGES, settings["language"],
                                  lambda v: cb["setting"]("language", v), raw=True)
        y -= step
        self.toggles = {}
        for key, label in (("fullscreen", "Vollbild (F11)"), ("show_grid", "Bau-Raster anzeigen"),
                           ("particles", "Partikeleffekte"), ("show_fps", "FPS anzeigen"), ("signs", "Schilder über Maschinen"),
                           ("tutorial", "Tutorial bei neuem Spiel"), ("discord", "Status in Discord zeigen")):
            row_label(pg, label, y)
            self.toggles[key] = Toggle(pg, sx + lw, y, settings[key], (lambda v, k=key: cb["setting"](k, v)))
            y -= step

        # -- Leistung
        pg = self.pages["performance"]
        y = top
        row_label(pg, "V-Sync", y)
        self.toggles["vsync"] = Toggle(pg, sx + lw, y, settings["vsync"], lambda v: cb["setting"]("vsync", v))
        self.vsync_hint = Label(pg, "", sx + lw + 0.1, y + 0.01, size=0.66, col=FAINT)
        y -= step
        row_label(pg, "FPS-Begrenzer", y)
        self.fps_choice = Choice(pg, sx + lw, y, 0.3,
                                 [(v, "Unbegrenzt" if v == 0 else f"{v} FPS") for v in FPS_CHOICES],
                                 settings["fps_limit"], lambda v: cb["setting"]("fps_limit", v))
        y -= step
        row_label(pg, "Schatten", y)
        self.shadow_choice = Choice(pg, sx + lw, y, 0.3,
                                    [("high", "Hoch"), ("medium", "Mittel"), ("low", "Niedrig"), ("off", "Aus")],
                                    settings["shadows"], lambda v: cb["setting"]("shadows", v))
        y -= step
        row_label(pg, "Kantenglättung", y)
        self.msaa_choice = Choice(pg, sx + lw, y, 0.3,
                                  [(-1, "Automatisch"), (0, "Aus"), (2, "2-fach"), (4, "4-fach"), (8, "8-fach")],
                                  settings["msaa"], lambda v: cb["setting"]("msaa", v))
        y -= step
        row_label(pg, "Landschafts-Details", y)
        self.toggles["scenery"] = Toggle(pg, sx + lw, y, settings["scenery"],
                                         lambda v: cb["setting"]("scenery", v))
        y -= step + 0.01
        Label(pg, "Tipp bei Rucklern: Schatten auf Niedrig/Aus, Landschafts-Details aus. V-Sync und "
                  "Kantenglättung wirken nach einem Neustart.", sx + 0.01, y + 0.02, size=0.7, col=FAINT, wordwrap=80)

        # -- Audio: Musik, Umgebung und Ton
        pg = self.pages["audio"]
        y = top
        head(pg, "Musik & Umgebung", y)
        y -= step * 0.85
        row_label(pg, "Musik", y)
        self.music_slider = vol_slider(pg, y, "music_volume")
        y -= step
        row_label(pg, "Vögel, Wind & Fabrik", y)
        self.ambient_slider = vol_slider(pg, y, "ambient_volume")
        y -= step * 1.1
        head(pg, "Ton", y)
        y -= step * 0.85
        row_label(pg, "Effekte-Lautstärke", y)
        self.vol_slider = vol_slider(pg, y, "volume")
        y -= step
        row_label(pg, "Erfolge", y)
        self.ach_slider = vol_slider(pg, y, "achievement_volume")
        Btn(pg, "Test", sx + lw + 0.44, y, 0.08, 0.036, lambda: cb["setting"]("achievement_test", True), size=0.62)
        y -= step
        self.rocket_label = row_label(pg, "Raketen-Lautstärke", y)
        self.rocket_slider = vol_slider(pg, y, "rocket_volume")
        y -= step
        Label(pg, "Mausrad über dem Regler: in 1-%-Schritten einstellen", sx + 0.01, y + 0.02, size=0.68, col=FAINT)

        # -- Steuerung
        pg = self.pages["controls"]
        y = top
        row_label(pg, "Maus-Empfindlichkeit", y)
        self.sens_slider = Slider(pg, sx + lw, y, 0.3, 0.2, 3.0, settings["mouse_sensitivity"],
                                  lambda v: cb["setting"]("mouse_sensitivity", v), fmt=lambda v: f"{v:.1f}x", step=0.1)
        y -= step
        row_label(pg, "Mitspieler-Zeiger", y)
        self.cursor_slider = Slider(pg, sx + lw, y, 0.3, 0.3, 2.0, settings["cursor_scale"],
                                    lambda v: cb["setting"]("cursor_scale", v), fmt=lambda v: f"{v * 100:.0f} %",
                                    step=0.05)
        y -= step * 1.1
        head(pg, "Tastenbelegung", y)
        Btn(pg, "Standard", right - 0.08, y + 0.008, 0.14, 0.038, self._reset_keys, size=0.66)
        y -= step * 0.7
        Label(pg, "Auf eine Taste klicken und dann die neue Taste drücken (Esc bricht ab).", sx + 0.01, y + 0.02,
              size=0.64, col=FAINT)
        y -= 0.035
        self.key_btns = {}
        self.key_rows = {}
        col_w = (right - sx) / 2
        per_col = (len(C.KEY_ACTIONS) + 1) // 2
        for i, (action, label, _) in enumerate(C.KEY_ACTIONS):
            cx = sx + 0.01 + (i // per_col) * col_w
            cy = y - (i % per_col) * 0.046
            lbl = Label(pg, label, cx, cy + 0.008, size=0.74, col=TEXT, max_w=col_w - 0.2)
            b = Btn(pg, "", cx + col_w - 0.1, cy, 0.15, 0.038, (lambda a=action: self._start_capture(a)), size=0.7)
            self.key_btns[action] = b
            self.key_rows[action] = (lbl, b)
        y -= per_col * 0.046 + 0.01
        self.key_msg = Label(pg, " ", sx + 0.01, y + 0.02, size=0.66, col=WARN)
        Label(pg, "Fest belegt: WASD/Pfeiltasten Kamera · 1–9, 0 Gebäude · Enter Chat · Esc Menü · F11 Vollbild",
              sx + 0.01, y - 0.012, size=0.62, col=FAINT)
        self.capturing = None
        Label(self.root, "Einstellungen werden automatisch gespeichert.",
              sx, -h / 2 + 0.045, size=0.66, col=FAINT, wordwrap=70)
        self.page = None
        self.set_page("display")

    # ---------------------------------------------------------------- Tastenbelegung
    def _refresh_keys(self):
        km = rules.keymap(self.settings["keys"])
        for action, b in self.key_btns.items():
            if action == self.capturing:
                b.set_text("Taste …")
                b.set_color(BUTTON_ACCENT)
            else:
                b.set_text(rules.key_label(km[action]))
                b.set_color(BUTTON if km[action] == C.DEFAULT_KEYS[action] else ACCENT_DIM)
        show_rocket = rules.moon_open(False) or rules.check_test_code(self.settings["test_code"] or "")
        for e in self.key_rows["rocket"]:
            e.enabled = show_rocket and self.page == "controls"

    def _start_capture(self, action):
        self.capturing = action
        self.key_msg.set(" ")
        self._refresh_keys()

    def capture(self, key):
        """Wird vom Client mit der nächsten gedrückten Taste aufgerufen."""
        if key.endswith(" up") or "mouse" in key or key.startswith("scroll") or key.endswith(" hold"):
            return
        action = self.capturing
        self.capturing = None
        if key != "escape":
            if key in C.RESERVED_KEYS:
                self.key_msg.set(f"„{rules.key_label(key)}“ ist fest belegt – bitte eine andere Taste wählen.")
            else:
                old = rules.keymap(self.settings["keys"])
                new = rules.rebind(self.settings["keys"], action, key)
                swapped = [a for a, k in rules.keymap(new).items() if a != action and k != old[a]]
                self.cb["setting"]("keys", new)
                if swapped:
                    other = next(lbl for a, lbl, _ in C.KEY_ACTIONS if a == swapped[0])
                    self.key_msg.set(f"Getauscht: {other} liegt jetzt auf {rules.key_label(old[action])}.", )
                else:
                    self.key_msg.set(" ")
        self._refresh_keys()

    def _reset_keys(self):
        self.capturing = None
        self.cb["setting"]("keys", {})
        self.key_msg.set(" ")
        self._refresh_keys()

    def set_page(self, key):
        self.page = key
        self.capturing = None
        for k, pg in self.pages.items():
            pg.enabled = k == key
        for k, b in self.tab_btns.items():
            b.set_color(BUTTON_ACCENT if k == key else BUTTON)
        if key == "audio":
            self._rocket_visibility()
        self._refresh_keys()

    def set_menu_mode(self, in_menu):
        """Im Hauptmenü zeigt das Fenster nur die Einstellungen (ohne Spiel-Knöpfe)."""
        self.in_menu = in_menu
        self.title.set("Optionen" if in_menu else "Menü & Einstellungen")
        for i, b in enumerate(self.nav):
            b.enabled = (not in_menu) or i == 3          # Hilfe bleibt verfügbar
        self.nav[3].y = (self.back_btn.y - 0.072) if in_menu else (self.nav[2].y - 0.072)
        self.back_btn.enabled = in_menu
        self._render_host()

    def set_host_info(self, text):
        """text: z. B. "84.1.2.3 : 5600" oder None (nicht selbst gehostet)."""
        self._host_text = text
        self._render_host()

    def _render_host(self):
        text = None if self.in_menu else getattr(self, "_host_text", None)
        show = bool(text)
        self.host_title.set("Freunde treten bei mit:" if show else " ")
        self.host_info.set(text if show else " ")
        self.copy_btn.enabled = show

    def _set_gui(self, v):
        self.gui_slider.set_value(v)
        self.cb["setting"]("gui_scale", v)

    def sync(self):
        s = self.settings
        self.gui_slider.set_value(s["gui_scale"])
        self.sens_slider.set_value(s["mouse_sensitivity"])
        self.vol_slider.set_value(s["volume"])
        self.music_slider.set_value(s["music_volume"])
        self.ambient_slider.set_value(s["ambient_volume"])
        self.rocket_slider.set_value(s["rocket_volume"])
        self.ach_slider.set_value(s["achievement_volume"])
        self._rocket_visibility()
        self._refresh_keys()
        self.cursor_slider.set_value(s["cursor_scale"])
        for key, t in self.toggles.items():
            t.set(s[key])
        self.fps_choice.set(s["fps_limit"])
        self.shadow_choice.set(s["shadows"])
        self.msaa_choice.set(s["msaa"])

    def _rocket_visibility(self):
        """Regler für die Rakete erst nach dem Countdown (oder mit freigeschalteter Test-World) zeigen."""
        show = rules.moon_open(False) or rules.check_test_code(self.settings["test_code"] or "")
        sl = self.rocket_slider
        for e in (self.rocket_label, sl.track, sl.fill, sl.knob, sl.label):
            e.enabled = show and self.page == "audio"

    def set_vsync_hint(self, text):
        self.vsync_hint.set(text or " ")


# =============================================================================
class AdminPanel(Window):
    def __init__(self, anchors, cb):
        super().__init__(anchors, "Admin-Panel", 1.2, 0.84, cb["close"], z=-0.45, icon_name="ui_admin")
        self.cb = cb
        self.content = None
        self.mode = None
        self.player_key = None
        self.bans = []
        self.bans_changed = False
        self.money_label = None

    def set_bans(self, bans):
        self.bans = list(bans)
        self.bans_changed = True

    def refresh(self, state, my_id, is_admin, login_possible):
        mode = "admin" if is_admin else "login"
        key = [(p[0], p[1], p[9] if len(p) > 9 else False) for p in state.players]
        if mode != self.mode or (mode == "admin" and (key != self.player_key or self.bans_changed)):
            self._build(mode, state, my_id, login_possible)
            self.player_key = key
        if mode == "admin" and self.money_label:
            self.money_label.set(f"Firmenkonto: {rules.format_money(state.money)}")

    def _build(self, mode, state, my_id, login_possible):
        self.bans_changed = False
        self.mode = mode
        if self.content:
            self.content.enabled = False
            self.content.parent = None
        c = self.content = Entity(parent=self.root)
        w, h = self.w, self.h
        x0 = -w / 2 + 0.03
        y = h / 2 - 0.1
        self.money_label = None
        if mode == "login":
            Label(c, "Du hast auf diesem Server keine Admin-Rechte.", x0, y, size=1.0)
            y -= 0.06
            Label(c, "• Wer auf dem Server-PC spielt (Verbindung über 127.0.0.1), ist automatisch Admin.\n"
                     "• Ein Admin kann dich im Admin-Panel (F2) mit „Zum Admin machen“ befördern.\n"
                     "• Hat der Server ein Admin-Passwort (--admin-password), kannst du dich hier anmelden.",
                  x0, y, size=0.78, col=MUTED)
            y -= 0.16
            if login_possible:
                Label(c, "Admin-Passwort", x0, y, size=0.85, col=MUTED)
                self.pw = InputField(parent=c, position=(x0 + 0.42, y - 0.012, -0.02), scale=(0.4, 0.05),
                                     character_limit=32)
                self.pw.hide_content = True
                Btn(c, "Anmelden", x0 + 0.72, y - 0.012, 0.18, 0.05, lambda: self.cb["login"](self.pw.text),
                    col=BUTTON_ACCENT)
            else:
                Label(c, "Dieser Server hat kein Admin-Passwort eingerichtet.", x0, y, size=0.8, col=FAINT)
            return

        # ---------------- Geld
        Label(c, "Geld", x0, y, size=1.05, col=ACCENT)
        self.money_label = Label(c, "", w / 2 - 0.03, y, size=0.85, col=GOLD, origin=(0.5, 0.5))
        y -= 0.06
        for i, amount in enumerate((1_000, 10_000, 100_000, 1_000_000)):
            Btn(c, "+" + short_money(amount), x0 + 0.1 + i * 0.21, y, 0.2, 0.05,
                (lambda a=amount: self.cb["give"](a)), col=BUTTON_GOOD, size=0.8)
        y -= 0.065
        Label(c, "Eigener Betrag", x0, y + 0.012, size=0.8, col=MUTED)
        self.amount = InputField(parent=c, position=(x0 + 0.42, y, -0.02), scale=(0.3, 0.046), character_limit=12)
        self.amount.limit_content_to = "0123456789"
        Btn(c, "Geben", x0 + 0.65, y, 0.13, 0.046, self._give_custom, col=BUTTON_ACCENT, size=0.8)
        Btn(c, "Abziehen", x0 + 0.8, y, 0.15, 0.046, lambda: self._give_custom(sign=-1), col=BUTTON_DANGER, size=0.8)
        y -= 0.08

        # ---------------- Spieler
        Label(c, "Spieler online", x0, y, size=1.05, col=ACCENT)
        y -= 0.055
        for p in state.players[:6]:
            pid, name, col = p[0], p[1], p[2]
            admin = p[9] if len(p) > 9 else False
            Label(c, "• " + name + (" (du)" if pid == my_id else "") + (" · Admin" if admin else ""), x0, y + 0.012,
                  size=0.85, col=player_color(col))
            if pid != my_id:
                if admin:
                    Btn(c, "Admin entziehen", x0 + 0.42, y, 0.19, 0.042,
                        (lambda i=pid: self.cb["set_admin"](i, False)), size=0.7)
                else:
                    Btn(c, "Zum Admin machen", x0 + 0.42, y, 0.19, 0.042,
                        (lambda i=pid: self.cb["set_admin"](i, True)), col=BUTTON_GOOD, size=0.7)
                Btn(c, "Kicken", x0 + 0.62, y, 0.14, 0.042, (lambda i=pid: self.cb["kick"](i)), size=0.75)
                Btn(c, "Bannen", x0 + 0.78, y, 0.14, 0.042, (lambda i=pid: self.cb["ban"](i)), col=BUTTON_DANGER,
                    size=0.75)
            y -= 0.05
        y -= 0.02

        # ---------------- Bannliste und Fabrik
        Label(c, "Bannliste", x0, y, size=1.05, col=ACCENT)
        Btn(c, "Aktualisieren", x0 + 0.33, y - 0.012, 0.18, 0.04, self.cb["bans"], size=0.72)
        Btn(c, "Alle Gebäude an", w / 2 - 0.36, y - 0.012, 0.2, 0.04, lambda: self.cb["all_enabled"](True),
            col=BUTTON_GOOD, size=0.72)
        Btn(c, "Alle aus", w / 2 - 0.13, y - 0.012, 0.18, 0.04, lambda: self.cb["all_enabled"](False), size=0.72)
        y -= 0.055
        if not self.bans:
            Label(c, "Keine gebannten Spieler (oder „Aktualisieren“ klicken).", x0, y + 0.01, size=0.78, col=FAINT)
        for b in self.bans[-4:]:
            key = b.get("name") or b.get("ip", "")
            Label(c, f"{b.get('name', '?')} · {b.get('time', '')} · {b.get('reason') or 'ohne Grund'}", x0, y + 0.012,
                  size=0.78, col=MUTED)
            Btn(c, "Entbannen", x0 + 0.78, y, 0.14, 0.04, (lambda k=key: self.cb["unban"](k)), size=0.72)
            y -= 0.048

    def _give_custom(self, sign=1):
        try:
            amount = int(self.amount.text.strip() or "0")
        except ValueError:
            return
        if amount:
            self.cb["give"](amount * sign)


# =============================================================================
HELP_SECTIONS = [
    ("Kamera", [
        ("WASD / Pfeil hoch, runter", "bewegen (Shift = schneller)"),
        ("Rechte Maustaste halten", "drehen und neigen,  Pfeil links / rechts: drehen"),
        ("Mausrad / mittlere Maustaste", "zoomen / verschieben,  Klick auf die Karte: hinfliegen"),
        ("Minimap-Klick", "Kamera fährt weich zu dieser Stelle"),
    ]),
    ("Bauen", [
        ("Q", "Kaufmenü öffnen,  1 – 9 Gebäude direkt wählen"),
        ("Linksklick", "platzieren (Förderbänder: gedrückt halten und ziehen)"),
        ("E / Shift+E", "vor dem Bau drehen (Pfeile = Ausgänge)"),
        ("X  /  Leertaste", "Abrisswerkzeug  /  Auswahlwerkzeug"),
        ("Gebäude anklicken", "Infofenster: P an/aus, E drehen, G versetzen, U Ausbau, Entf Abriss"),
    ]),
    ("Menüs", [
        ("R  /  M  /  O", "Forschungsbaum  /  Markt  /  Aufträge (LKW-Lieferungen)"),
        ("Esc", "Menü & Einstellungen (GUI-Größe, Vollbild, Maus, Ton)"),
        ("F2", "Admin-Panel (Geld, Admin-Rechte vergeben, Kick, Bann)"),
        ("F5  /  F9", "Speichern  /  Laden (zum Bestätigen zweimal drücken)"),
        ("T (oder Enter) / F11 / F1", "Chat  /  Vollbild an-aus  /  diese Hilfe"),
    ]),
    ("Produktion", [
        ("Kette", "Miner (auf Erz) » Band » Schmelze » Band » Verkäufer oder Lager"),
        ("Verteiler", "Splitter (3 Richtungen), T-Stück (links/rechts), Sortierer (je Ware einstellbar)"),
        ("Statuslampe", "grün arbeitet · gelb wartet · rot + „!“ Problem · grau ausgeschaltet"),
        ("Energie", "Schmelzen und Montageanlagen kosten Energie, abgerechnet alle 5 Sekunden"),
    ]),
]


class HelpWindow(Window):
    def __init__(self, anchors, on_close, on_tutorial=None):
        super().__init__(anchors, "Steuerung & Hilfe", 1.36, 0.92, on_close, z=-0.6)
        if on_tutorial:
            Btn(self.root, "Tutorial starten", self.w / 2 - 0.2, self.h / 2 - 0.042, 0.22, 0.046, on_tutorial,
                col=BUTTON_ACCENT, size=0.75)
        y = self.h / 2 - 0.09
        x0 = -self.w / 2 + 0.04
        for title, rows in HELP_SECTIONS:
            Label(self.root, title, x0, y, size=1.0, col=ACCENT)
            y -= 0.036
            for key, desc in rows:
                Label(self.root, key, x0 + 0.02, y, size=0.8, col=GOLD)
                Label(self.root, desc, x0 + 0.38, y, size=0.8)
                y -= 0.03
            y -= 0.014


# =============================================================================
class MainMenu:
    """Hauptmenü: Spielname groß über der animierten Fabrik, unten Einzelspieler, Mehrspieler,
    Optionen und Beenden. Einzel- und Mehrspieler öffnen jeweils eine Seite in der Bildmitte."""

    def __init__(self, anchors, cb, defaults):
        from ursina import camera
        from . import textures
        self.cb = cb
        self.anchors = anchors
        # Abdunklung oben/unten über die volle Bildschirmbreite (unabhängig von der GUI-Größe)
        self.shade = Entity(parent=camera.ui, model="quad", texture=textures.texture("menu_shade"),
                            scale=(window.aspect_ratio * 1.02, 1.02), z=-0.35, color=color.white)
        self.root = Entity(parent=anchors["c"], z=-0.4)

        # ---- Titel
        title = "FACTORY EMPIRE"
        self.title_group = Entity(parent=self.root)
        self.title_glow = Label(self.title_group, title, 0, 0.38, size=4.68, origin=(0, 0.5),
                                col=color.rgba(1.0, 0.55, 0.1, 0.13))
        Label(self.title_group, title, 0.005, 0.372, size=4.6, origin=(0, 0.5), col=color.rgba(0, 0, 0, 0.55))
        Label(self.title_group, title, 0, 0.378, size=4.6, origin=(0, 0.5), col=ACCENT)
        self.underline = Entity(parent=self.root, model="quad", origin=(0, 0.5), position=(0, 0.255, -0.01),
                                scale=(0.52, 0.004), color=color.rgba(0.98, 0.62, 0.16, 0.7))
        self.subtitle = Label(self.root, "Baue dein Industrie-Imperium  -  allein oder mit Freunden", 0, 0.235,
                              size=1.0, origin=(0, 0.5), col=TEXT)
        self._t = 0.0
        self._intro_played = False
        self.title_glow_base = self.title_glow.scale_x
        self.root.update = self._idle
        self.version = Label(self.root, f"Version {C.GAME_VERSION}", 0, -0.47, size=0.7, origin=(0, 0.5),
                             col=color.rgba(1, 1, 1, 0.45))

        # ---- Hauptknöpfe unten
        bw, bh, gap = 0.226, 0.082, 0.018
        items = [("Einzelspieler", "miner", self.open_single, BUTTON_ACCENT),
                 ("Mehrspieler", "ui_players", self.open_multi, BUTTON_ACCENT),
                 ("Statistiken", "ui_stats", cb.get("stats", lambda: None), BUTTON),
                 ("Optionen", "ui_settings", cb["options"], BUTTON),
                 ("Beenden", None, cb["quit"], BUTTON_DANGER)]
        x0 = -(len(items) * bw + (len(items) - 1) * gap) / 2 + bw / 2
        self.main_buttons = []
        for i, (text, ic, fn, col) in enumerate(items):
            b = Btn(self.root, text, x0 + i * (bw + gap), -0.385, bw, bh, fn, col=col, size=1.0, icon_name=ic)
            self.main_buttons.append(b)

        self.status = Label(self.root, "", 0, -0.306, size=0.8, origin=(0, 0.5), col=MUTED, wordwrap=110)

        # ---- Seite: Einzelspieler (5 Spielstand-Plätze)
        self.single = Entity(parent=self.root, enabled=False)
        w, h = 0.86, 0.5
        top = 0.21
        self.single_bg = panel(self.single, -w / 2, top, w, h, color.rgba(0.07, 0.08, 0.10, 0.94), radius=0.02)
        self.single_bg_tall = panel(self.single, -w / 2, top, w, h + 0.08, color.rgba(0.07, 0.08, 0.10, 0.94),
                                    radius=0.02)
        rect(self.single, -w / 2 + 0.015, top, w - 0.03, 0.005, ACCENT)
        Label(self.single, "Einzelspieler", -w / 2 + 0.03, top - 0.03, size=1.5)
        Label(self.single, "5 Spielstände - jeder Platz ist eine eigene Welt. Es wird automatisch gespeichert.",
              -w / 2 + 0.03, top - 0.088, size=0.7, col=MUTED)
        self.slot_rows = []
        y = top - 0.13
        rh = 0.068
        for n in range(1, C.SINGLEPLAYER_SLOTS + 1):
            bg = panel(self.single, -w / 2 + 0.02, y, w - 0.04, rh - 0.008, PANEL_LIGHT, radius=0.012,
                       collider=False, edge=False)
            Label(self.single, f"{n}", -w / 2 + 0.045, y - 0.012, size=1.5, col=ACCENT)
            title = Label(self.single, "", -w / 2 + 0.1, y - 0.01, size=0.9, col=TEXT)
            info = Label(self.single, "", -w / 2 + 0.1, y - 0.036, size=0.66, col=FAINT)
            play = Btn(self.single, "Spielen", w / 2 - 0.235, y - (rh - 0.008) / 2, 0.15, 0.044,
                       (lambda k=n: self._single(k, False)), col=BUTTON_ACCENT, size=0.8)
            new = Btn(self.single, "Neu", w / 2 - 0.085, y - (rh - 0.008) / 2, 0.12, 0.044,
                      (lambda k=n: self._single(k, True)), size=0.8)
            self.slot_rows.append({"bg": bg, "title": title, "info": info, "play": play, "new": new, "used": False})
            y -= rh
        # geheime Test-Welt (Mond-Vorschau) – nur sichtbar, wenn der Code eingegeben wurde
        self.test_row = Entity(parent=self.single)
        panel(self.test_row, -w / 2 + 0.02, y, w - 0.04, rh - 0.008, color.rgba(0.16, 0.2, 0.32, 1), radius=0.012,
              collider=False, edge=False)
        icon(self.test_row, "ui_research", -w / 2 + 0.048, y - 0.03, 0.04, origin=(0, 0))
        Label(self.test_row, "Test-World  ·  Mond-Vorschau", -w / 2 + 0.1, y - 0.01, size=0.9, col=TEXT)
        self.test_info = Label(self.test_row, "", -w / 2 + 0.1, y - 0.036, size=0.66, col=MUTED)
        self.test_play = Btn(self.test_row, "Spielen", w / 2 - 0.235, y - (rh - 0.008) / 2, 0.15, 0.044,
                             lambda: self.cb["test_world"](False), col=BUTTON_ACCENT, size=0.8)
        self.test_new = Btn(self.test_row, "Neu", w / 2 - 0.085, y - (rh - 0.008) / 2, 0.12, 0.044,
                            lambda: self._test_new(), size=0.8)
        self.test_row.enabled = False
        self.single_info = Label(self.single, " ", -w / 2 + 0.03, top - h + 0.03, size=0.62, col=FAINT)
        self._single_info_y = (top - h + 0.03, top - h - 0.05)
        self._confirm_new = (0, 0.0)
        self.last_slot = 1

        # ---- Seite: Mehrspieler
        self.multi = Entity(parent=self.root, enabled=False)
        w, h = 1.12, 0.5
        top = 0.2
        panel(self.multi, -w / 2, top, w, h, color.rgba(0.07, 0.08, 0.10, 0.94), radius=0.02)
        rect(self.multi, -w / 2 + 0.015, top, w - 0.03, 0.005, ACCENT)
        Label(self.multi, "Mehrspieler", -w / 2 + 0.03, top - 0.03, size=1.5)
        Label(self.multi, "Dein Name", 0.06, top - 0.04, size=0.8, col=MUTED)
        self.name = InputField(default_value=defaults["name"], parent=self.multi, position=(0.36, top - 0.052, -0.02),
                               scale=(0.34, 0.048), character_limit=16)

        col_w = 0.52
        lx, rx = -w / 2 + 0.03, 0.02
        ctop = top - 0.1
        for x, title_text, sub in ((lx, "Spiel hosten", "Freunde treten mit deinem Raum-Code bei."),
                                   (rx, "Spiel beitreten", "Raum-Code von deinem Freund eingeben - fertig.")):
            panel(self.multi, x, ctop, col_w, 0.39, PANEL_LIGHT, radius=0.014, collider=False, edge=False)
            Label(self.multi, title_text, x + 0.02, ctop - 0.018, size=1.15, col=ACCENT)
            Label(self.multi, sub, x + 0.02, ctop - 0.056, size=0.62, col=MUTED, wordwrap=60)

        # Hosten: 5 Spielstand-Plätze wie im Einzelspieler
        tw, tg = 0.088, 0.01
        self.mp_tiles = []
        for n in range(1, C.MULTIPLAYER_SLOTS + 1):
            b = Btn(self.multi, f"Platz {n}", lx + 0.02 + tw / 2 + (n - 1) * (tw + tg), ctop - 0.112, tw, 0.05,
                    (lambda k=n: self._select_mp(k)), size=0.66)
            self.mp_tiles.append(b)
        self.mp_info = Label(self.multi, " ", lx + 0.02, ctop - 0.146, size=0.62, col=FAINT)
        self.mp_slot = 1
        self.mp_used = [False] * C.MULTIPLAYER_SLOTS
        y = ctop - 0.185
        Label(self.multi, "Port", lx + 0.02, y, size=0.74, col=MUTED)
        Label(self.multi, "Passwort (empfohlen)", lx + 0.16, y, size=0.74, col=MUTED)
        self.host_port = InputField(default_value=str(defaults["host_port"]), parent=self.multi,
                                    position=(lx + 0.075, y - 0.045, -0.02), scale=(0.11, 0.044), character_limit=5)
        self.host_port.limit_content_to = "0123456789"
        self.host_pw = InputField(default_value="", parent=self.multi, position=(lx + 0.335, y - 0.045, -0.02),
                                  scale=(0.33, 0.044), character_limit=32)
        self.host_pw.hide_content = True
        Label(self.multi, "Online mit Raum-Code", lx + 0.02, ctop - 0.268, size=0.74, col=TEXT)
        self.relay = Toggle(self.multi, lx + 0.235, ctop - 0.28, defaults["relay"], None)
        self.relay_hint = Label(self.multi, "Empfohlen: keine Router-Einstellungen nötig.",
                                lx + 0.325, ctop - 0.266, size=0.55, col=FAINT, wordwrap=30)
        bw_new = 0.12
        self.host_btn = Btn(self.multi, "Server starten & spielen", lx + 0.02 + (col_w - 0.05 - bw_new) / 2,
                            ctop - 0.345, col_w - 0.05 - bw_new, 0.058, lambda: self._host(False),
                            col=BUTTON_ACCENT, size=0.95)
        self.host_new_btn = Btn(self.multi, "Neu", lx + col_w - 0.02 - bw_new / 2, ctop - 0.345, bw_new, 0.058,
                                lambda: self._host(True), size=0.9)

        # Beitreten
        y = ctop - 0.09
        Label(self.multi, "Raum-Code (oder IP-Adresse)", rx + 0.02, y, size=0.78, col=MUTED)
        Label(self.multi, "Port (nur IP)", rx + 0.36, y, size=0.7, col=MUTED)
        self.join_host = InputField(default_value=defaults["host"], parent=self.multi,
                                    position=(rx + 0.19, y - 0.05, -0.02), scale=(0.34, 0.046), character_limit=40)
        self.join_port = InputField(default_value=str(defaults["port"]), parent=self.multi,
                                    position=(rx + 0.445, y - 0.05, -0.02), scale=(0.11, 0.046), character_limit=5)
        self.join_port.limit_content_to = "0123456789"
        Label(self.multi, "Passwort (falls nötig)", rx + 0.02, y - 0.095, size=0.78, col=MUTED)
        self.join_pw = InputField(default_value=defaults.get("password", ""), parent=self.multi,
                                  position=(rx + 0.19, y - 0.145, -0.02), scale=(0.34, 0.046), character_limit=32)
        self.join_pw.hide_content = True
        Label(self.multi, "Die Welt wählt der Host.", rx + 0.02, y - 0.2, size=0.62, col=FAINT)
        Btn(self.multi, "Beitreten", rx + col_w / 2, ctop - 0.345, col_w - 0.04, 0.058, self._join,
            col=BUTTON_ACCENT, size=1.0)

        self.name.next_field = self.join_host
        self.join_host.next_field = self.join_port
        self.join_port.next_field = self.join_pw
        self.host_port.next_field = self.host_pw
        self._fields = (self.name, self.host_port, self.host_pw, self.join_host, self.join_port, self.join_pw)
        self.has_save = False

    # ---------------------------------------------------------------- Seiten
    def open_single(self):
        self.multi.enabled = False
        self.single.enabled = not self.single.enabled
        self._confirm_new = (0, 0.0)
        self.set_status("")
        if self.single.enabled:
            self.refresh_single()
            self._page_in(self.single)

    def open_multi(self):
        self.single.enabled = False
        self.multi.enabled = not self.multi.enabled
        self.set_status("")
        self._confirm_new = (0, 0.0)
        if self.multi.enabled:
            self.refresh_multi()
            self._page_in(self.multi)

    def close_page(self):
        """Esc: offene Seite schließen. Gibt True zurück, wenn etwas geschlossen wurde."""
        if self.single.enabled or self.multi.enabled:
            self.single.enabled = self.multi.enabled = False
            self._deactivate_fields()
            return True
        return False

    def refresh_single(self):
        infos = self.cb["slots_info"]()
        self.last_slot = self.cb["last_slot"]() if "last_slot" in self.cb else 1
        self.has_save = any(infos)
        for n, (row, info) in enumerate(zip(self.slot_rows, infos), start=1):
            row["used"] = info is not None
            mark = "  ·  zuletzt gespielt" if n == self.last_slot and info else ""
            if info:
                row["title"].set(f"Welt {n}{mark}", TEXT)
                row["info"].set(info, MUTED)
                row["play"].enabled = True
                row["new"].set_text("Neu")
                row["new"].set_color(BUTTON)
                row["new"].x = row["play"].x + 0.15
            else:
                row["title"].set("Leerer Platz", FAINT)
                row["info"].set("Noch keine Welt - hier eine neue Fabrik starten.", FAINT)
                row["play"].enabled = False
                row["new"].set_text("Neue Welt")
                row["new"].set_color(BUTTON_ACCENT)
                row["new"].x = row["play"].x + 0.15
            row["bg"].color = ACCENT_SOFT if n == self.last_slot and info else PANEL_LIGHT
        self.single_info.set("Tipp: „Neu“ ersetzt die Welt auf diesem Platz (eine Sicherung bleibt erhalten).")
        unlocked, info = self.cb["test_info"]() if "test_info" in self.cb else (False, None)
        self.test_row.enabled = unlocked
        self.single_bg.enabled = not unlocked
        self.single_bg_tall.enabled = unlocked
        self.single_info.y = self._single_info_y[1 if unlocked else 0]
        if unlocked:
            self.test_used = info is not None
            self.test_info.set(info or "Nur für dich: Rakete und Mond schon vor dem Countdown testen.", MUTED)
            self.test_play.enabled = info is not None
            self.test_new.set_text("Neu" if info else "Erstellen")
            self.test_new.set_color(BUTTON if info else BUTTON_ACCENT)

    def _test_new(self):
        last_slot, last_t = self._confirm_new
        if getattr(self, "test_used", False) and not (last_slot == "test" and time.time() - last_t < 4):
            self._confirm_new = ("test", time.time())
            self.set_status("Die Test-World wird neu erstellt (eine Sicherung bleibt erhalten). "
                            "Zum Bestätigen nochmal auf \"Neu\" klicken.", WARN)
            return
        self._confirm_new = (0, 0.0)
        self.cb["test_world"](True)

    def _single(self, slot, new_game):
        used = self.slot_rows[slot - 1]["used"]
        last_slot, last_t = self._confirm_new
        if new_game and used and not (last_slot == slot and time.time() - last_t < 4):
            self._confirm_new = (slot, time.time())
            self.set_status(f"Die Welt auf Platz {slot} wird ersetzt (eine Sicherung bleibt erhalten). "
                            f"Zum Bestätigen nochmal auf \"Neu\" klicken.", WARN)
            return
        self._confirm_new = (0, 0.0)
        self.cb["single"](new_game or not used, slot)

    def refresh_multi(self):
        """Mehrspieler-Plätze neu einlesen. Vorauswahl: zuletzt gehosteter Platz."""
        self.mp_infos = self.cb["mp_slots_info"]() if "mp_slots_info" in self.cb else [None] * C.MULTIPLAYER_SLOTS
        self.mp_used = [i is not None for i in self.mp_infos]
        last = self.cb["last_mp_slot"]() if "last_mp_slot" in self.cb else 1
        self._select_mp(last if 1 <= last <= C.MULTIPLAYER_SLOTS else 1)

    def _select_mp(self, slot):
        self.mp_slot = slot
        self._confirm_new = (0, 0.0)
        for n, b in enumerate(self.mp_tiles, start=1):
            if n == slot:
                b.set_color(BUTTON_ACCENT)
            else:
                b.set_color(BUTTON if self.mp_used[n - 1] else color.rgba(0.16, 0.17, 0.2, 1))
            b.set_text(f"Platz {n}" if self.mp_used[n - 1] else f"{n} · leer")
        info = self.mp_infos[slot - 1] if hasattr(self, "mp_infos") else None
        if info:
            self.mp_info.set(f"Welt {slot}: {info}", MUTED)
            self.host_btn.set_text("Server starten & spielen")
            self.host_new_btn.enabled = True
        else:
            self.mp_info.set(f"Platz {slot} ist leer - hier startet eine neue Welt.", FAINT)
            self.host_btn.set_text("Neue Welt starten")
            self.host_new_btn.enabled = False

    def _host(self, new_game):
        slot = self.mp_slot
        used = self.mp_used[slot - 1]
        last_slot, last_t = self._confirm_new
        if new_game and used and not (last_slot == -slot and time.time() - last_t < 4):
            self._confirm_new = (-slot, time.time())
            self.set_status(f"Die Welt auf Mehrspieler-Platz {slot} wird ersetzt (eine Sicherung bleibt "
                            f"erhalten). Zum Bestätigen nochmal auf \"Neu\" klicken.", WARN)
            return
        self._confirm_new = (0, 0.0)
        self.cb["host"](self.player_name(), self.host_port.text.strip(), self.host_pw.text, self.relay.value,
                        slot, new_game or not used)

    def _join(self):
        self.cb["join"](self.player_name(), self.join_host.text.strip(), self.join_port.text.strip(), self.join_pw.text)

    def submit(self):
        """Enter: Hauptaktion der offenen Seite."""
        if self.multi.enabled:
            if self.host_port.active or self.host_pw.active:
                self._host(False)
            else:
                self._join()
        elif self.single.enabled:
            self._single(self.last_slot, False)

    # ---------------------------------------------------------------- Hilfen
    def player_name(self):
        return self.name.text.strip() or "Spieler"

    def set_status(self, text, col=MUTED):
        self.status.set(text, col)

    def typing(self):
        return any(f.active and f.enabled for f in self._fields if f.parent.enabled)

    def _deactivate_fields(self):
        for f in self._fields:
            f.active = False

    def fit(self, scale):
        a = window.aspect_ratio
        self.shade.scale = (a * 1.02, 1.02)
        # Alles muss bei jeder GUI-Größe in die Bildschirmbreite passen
        k = min(1.0, (a * 0.96) / (1.2 * scale), 0.98 / scale)
        self.root.scale = k

    @property
    def visible(self):
        return self.root.enabled

    def show(self):
        was = self.root.enabled
        self.root.enabled = True
        self.shade.enabled = True
        if not was or not self._intro_played:
            self._intro_played = True
            self.play_intro()

    def _page_in(self, page):
        def f(v):
            page.scale = 0.93 + 0.07 * v
            page.y = -0.02 * (1 - v)
            anim.set_alpha(page, v)
        anim.tween(f, 0.3, ease=anim.out_back, key=("page", id(page)))

    def play_intro(self):
        """Einzug: Titel fällt weich herein, Linie wächst, Knöpfe gleiten nacheinander hoch."""
        tg, ul, sub = self.title_group, self.underline, self.subtitle

        def title(v):
            tg.y = 0.06 * (1 - v)
            tg.scale = 1.12 - 0.12 * v
            anim.set_alpha(tg, min(1.0, v * 1.5))
        anim.tween(title, 0.9, ease=anim.out_back, key="intro_title")
        anim.tween(lambda v: setattr(ul, "scale_x", 0.52 * v), 0.6, delay=0.35, key="intro_line")
        anim.tween(lambda v: anim.set_alpha(sub, v), 0.6, delay=0.5, key="intro_sub")
        anim.set_alpha(sub, 0)
        for i, b in enumerate(self.main_buttons):
            y0 = -0.385

            def f(v, b=b, y0=y0):
                b.y = y0 - 0.12 * (1 - v)
                anim.set_alpha(b, min(1.0, v * 1.4))
            anim.tween(f, 0.55, delay=0.45 + i * 0.09, ease=anim.out_back, key=("intro_btn", i))
        anim.set_alpha(self.version, 0)
        anim.tween(lambda v: anim.set_alpha(self.version, v), 0.8, delay=1.0, key="intro_ver")

    def _idle(self):
        """Ruhige Dauer-Animation: Titel glimmt leicht."""
        self._t += min(utime.dt, 0.1)
        k = 0.5 + 0.5 * math.sin(self._t * 1.6)
        self.title_glow.scale = self.title_glow_base * (1.0 + 0.012 * k)
        anim.set_alpha(self.title_glow, 0.35 + 0.65 * k)

    def hide(self):
        self.root.enabled = False
        self.shade.enabled = False
        self.single.enabled = self.multi.enabled = False
        self._deactivate_fields()


class DisconnectOverlay:
    def __init__(self, anchors, on_reconnect, on_menu):
        self.root = Entity(parent=anchors["c"], z=-0.7, enabled=False)
        a = window.aspect_ratio
        Entity(parent=self.root, model="quad", scale=(a * 3, 3), color=color.rgba(0, 0, 0, 0.55), z=0.02)
        panel(self.root, -0.42, 0.18, 0.84, 0.36, PANEL_SOLID, radius=0.025)
        rect(self.root, -0.4, 0.18, 0.8, 0.008, BAD)
        self.title = Label(self.root, "Verbindung verloren", 0, 0.14, size=1.6, origin=(0, 0.5), col=BAD)
        self.reason = Label(self.root, "", 0, 0.07, size=0.85, origin=(0, 0.5), wordwrap=62)
        Btn(self.root, "Erneut verbinden", -0.18, -0.1, 0.32, 0.06, on_reconnect, col=BUTTON_ACCENT)
        Btn(self.root, "Hauptmenü", 0.18, -0.1, 0.32, 0.06, on_menu)

    def show(self, reason, title="Verbindung verloren"):
        self.title.set(title)
        self.reason.set(reason + "\nDie Fabrik läuft auf dem Server weiter, der Spielstand wird dort gespeichert.")
        if not self.root.enabled:
            self.root.enabled = True
            root = self.root

            def f(v):
                anim.set_alpha(root, v)
                root.scale = 0.92 + 0.08 * v
            anim.tween(f, 0.35, ease=anim.out_back, key="disconnect")

    def hide(self):
        self.root.enabled = False


class ChatInput:
    """Chat (T oder Enter): Fenster mit den letzten Nachrichten und Eingabezeile."""

    LINES = 9

    def __init__(self, anchors, on_send):
        self.on_send = on_send
        bl = anchors["bl"]
        self.root = Entity(parent=bl, enabled=False, z=-0.55)
        x, top, w, h = 0.012, 0.79, 0.66, 0.4
        panel(self.root, x, top, w, h, color.rgba(0.06, 0.07, 0.09, 0.9), radius=0.014, collider=False)
        rect(self.root, x + 0.01, top, w - 0.02, 0.004, ACCENT)
        Label(self.root, "Chat", x + 0.02, top - 0.018, size=0.95, col=ACCENT)
        Label(self.root, "Enter = senden  ·  Esc = schließen", x + w - 0.02, top - 0.024, size=0.6, col=FAINT,
              origin=(0.5, 0.5))
        self.names, self.texts = [], []
        for i in range(self.LINES):
            y = top - 0.07 - i * 0.031
            self.names.append(Label(self.root, "", x + 0.02, y, size=0.74, col=TEXT, raw=True))
            self.texts.append(Label(self.root, "", x + 0.12, y, size=0.74, col=TEXT, raw=True))
        self.empty = Label(self.root, "Noch keine Nachrichten. Schreib etwas!", x + 0.02, top - 0.07, size=0.72,
                           col=FAINT)
        self.field = InputField(parent=bl, position=(x + w / 2, top - h + 0.04, -0.6), scale=(w - 0.04, 0.045),
                                character_limit=120, enabled=False)
        self.history = []

    @property
    def active(self):
        return self.field.enabled

    def add(self, name, text, col=TEXT):
        self.history.append((name, text, col))
        self.history = self.history[-40:]
        if self.root.enabled:
            self._refresh()

    def _refresh(self):
        import textwrap
        rows = []
        for name, text, col in self.history:
            parts = textwrap.wrap(text, 52) or [""]
            rows.append((name + ":", parts[0], col))
            rows += [("", p, col) for p in parts[1:]]
        rows = rows[-self.LINES:]
        self.empty.enabled = not rows
        for i in range(self.LINES):
            if i < len(rows):
                name, text, col = rows[i]
                self.names[i].set(name or " ", col)
                w = self.names[i].width * self.names[i].scale_x if name else 0.0
                self.texts[i].x = self.names[i].x + w + 0.01
                self.texts[i].set(text or " ", TEXT)
            else:
                self.names[i].set(" ")
                self.texts[i].set(" ")

    def open(self):
        self.root.enabled = True
        self._refresh()
        self.field.enabled = True
        self.field.text = ""
        self.field.active = True
        from ursina import invoke

        def clear_hotkey():                  # das "t" zum Öffnen nicht mit eintippen
            if self.field.text.lower() == "t":
                self.field.text = ""
        invoke(clear_hotkey, delay=0.02)
        invoke(clear_hotkey, delay=0.08)

    def close(self):
        self.field.active = False
        self.field.enabled = False
        self.root.enabled = False

    def submit(self):
        text = self.field.text.strip()
        self.close()
        if text:
            self.on_send(text)
