"""
Shop-Fenster (K): Skins für alle Gebäude und die Rakete, das tägliche Glücksrad und das Konto
(Account anlegen, einloggen, Skins verschenken).
"""

import math

from ursina import Entity, InputField, Mesh, Quad, Vec3, color

from . import anim
from . import skins as K
from .ui_base import (ACCENT, BUTTON, BUTTON_ACCENT, BUTTON_GOOD, BUTTON_LOCKED, FAINT, GOLD, MUTED, PANEL_LIGHT,
                      TEXT, Btn, Label, Window, panel, rect)

PER_PAGE = 11


def _rc(rarity, a=1.0):
    r, g, b = K.RARITY[rarity]["color"]
    return color.rgba(r, g, b, a)


def swatch_color(tint):
    base = (0.55, 0.55, 0.57)
    return color.rgba(min(1, base[0] * tint[0]), min(1, base[1] * tint[1]), min(1, base[2] * tint[2]), 1)


class ShopWindow(Window):
    def __init__(self, anchors, cb):
        super().__init__(anchors, "Shop", 1.36, 0.86, cb["close"], z=-0.5, icon_name="ui_market")
        self.cb = cb
        self.tab = "shop"
        self.target = "miner"
        self.page = 0
        self.gift_idx = 0
        self.account = None
        self.planet = "earth"
        self.content = None
        self.user = self.pw = self.gift_to = None
        self.wheel = None
        self.spinning = False
        self.rocket_ok = False             # Raketen-Skins erst, wenn der Mond offen ist (kein Spoiler)
        w, h = self.w, self.h
        self.tab_btns = {}
        for i, (key, label) in enumerate((("shop", "Skins"), ("wheel", "Glücksrad"), ("account", "Konto"))):
            self.tab_btns[key] = Btn(self.root, label, -w / 2 + 0.11 + i * 0.2, h / 2 - 0.1, 0.19, 0.046,
                                     (lambda k=key: self.set_tab(k)), size=0.8)
        self.points_l = Label(self.root, "", w / 2 - 0.03, h / 2 - 0.1, size=0.82, col=GOLD, origin=(0.5, 0))

    # ------------------------------------------------------------------ allgemein
    def typing(self):
        return any(f is not None and f.enabled and f.active for f in (self.user, self.pw, self.gift_to))

    def set_tab(self, tab):
        self._finish_spin()
        self.tab = tab
        self.refresh(self.account, self.planet)

    def _finish_spin(self):
        """Rad dreht noch: sofort anhalten und das Ergebnis zeigen (z. B. beim Reiterwechsel)."""
        if self.spinning:
            anim.cancel("wheel")
            self.spinning = False
            text, self._spin_text = getattr(self, "_spin_text", ""), ""
            if text:
                self.cb["toast"](text)
                self.cb["won"]()

    def hide(self):
        self._finish_spin()
        super().hide()

    def show_tab(self, tab):
        self.tab = tab
        self.show()

    def refresh(self, account, planet="earth"):
        self.account = account
        self.planet = planet
        for key, b in self.tab_btns.items():
            b.set_color(BUTTON_ACCENT if key == self.tab else BUTTON)
        if account:
            if account.get("all"):
                self.points_l.set("Entwickler: alle Skins freigeschaltet")
            else:
                self.points_l.set(f"Erfolgspunkte: {account.get('avail', 0)}")
        else:
            self.points_l.set("Nicht eingeloggt")
        if self.spinning:
            return
        if self.content is not None:
            self.content.enabled = False
            self.content.parent = None
        self.user = self.pw = self.gift_to = None
        self.wheel = None
        self.content = Entity(parent=self.root)
        if self.tab == "shop":
            self._build_shop()
        elif self.tab == "wheel":
            self._build_wheel()
        else:
            self._build_account()

    def _need_login(self, c, y):
        Label(c, "Für Shop und Glücksrad brauchst du einen Account auf diesem Server.", -self.w / 2 + 0.04, y,
              size=0.9, col=MUTED)
        Btn(c, "Zum Konto: Account anlegen oder einloggen", 0, y - 0.09, 0.56, 0.054, lambda: self.set_tab("account"),
            col=BUTTON_ACCENT, size=0.82)

    def _targets(self):
        return [t for t in K.targets() if t != K.ROCKET or self.rocket_ok]

    def _owned(self, sid):
        a = self.account or {}
        return bool(a.get("all")) or sid in a.get("owned", [])

    # ------------------------------------------------------------------ Skins
    def _build_shop(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.03, h / 2 - 0.16
        Label(c, "1 Erfolg = 1 Punkt  ·  Selten 7  ·  Superselten 15  ·  Episch 23  ·  Legendär 50", x0, top,
              size=0.68, col=FAINT)
        if not self.account:
            self._need_login(c, top - 0.08)
            return
        targets = self._targets()
        if self.target not in targets:
            self.target = targets[0]
        pages = max(1, math.ceil(len(targets) / PER_PAGE))
        self.page = min(self.page, pages - 1)
        lw = 0.3
        y = top - 0.07
        equip = self.account.get("equip", {})
        for t in targets[self.page * PER_PAGE:(self.page + 1) * PER_PAGE]:
            name = K.target_name(t, self.planet)
            mark = " •" if t in equip else ""
            Btn(c, name + mark, x0 + lw / 2, y, lw, 0.046, (lambda tt=t: self._pick(tt)), size=0.72,
                col=BUTTON_ACCENT if t == self.target else BUTTON)
            y -= 0.054
        Btn(c, "«", x0 + 0.03, y, 0.06, 0.04, lambda: self._page(-1), size=0.8)
        Label(c, f"{self.page + 1}/{pages}", x0 + lw / 2, y, size=0.7, col=MUTED, origin=(0, 0))
        Btn(c, "»", x0 + lw - 0.03, y, 0.06, 0.04, lambda: self._page(1), size=0.8)

        gx = x0 + lw + 0.04
        gw = w / 2 - 0.03 - gx
        Label(c, K.target_name(self.target, self.planet), gx, top - 0.05, size=1.05, col=ACCENT, raw=True)
        cur = equip.get(self.target)
        Btn(c, "Standard-Look", gx + gw - 0.09, top - 0.065, 0.18, 0.042, lambda: self.cb["equip"](self.target, None),
            size=0.7, col=BUTTON_GOOD if cur is None else BUTTON)
        cols, cw, ch = 4, (gw - 0.03) / 4, 0.16
        for i, (style, sname, rarity, tint) in enumerate(K.STYLES):
            sid = K.skin_id(self.target, style)
            cx = gx + (i % cols) * (cw + 0.01)
            cy = top - 0.11 - (i // cols) * (ch + 0.012)
            panel(c, cx, cy, cw, ch, PANEL_LIGHT, radius=0.01, z=-0.01)
            rect(c, cx + 0.006, cy - 0.004, cw - 0.012, 0.005, _rc(rarity), z=-0.015)
            Entity(parent=c, model=Quad(radius=0.5), position=(cx + 0.04, cy - 0.05, -0.02), scale=0.05,
                   color=swatch_color(tint))
            Label(c, sname, cx + 0.075, cy - 0.032, size=0.74, col=TEXT)
            Label(c, K.RARITY[rarity]["name"], cx + 0.075, cy - 0.062, size=0.6, col=_rc(rarity))
            if sid == cur:
                Btn(c, "Angelegt", cx + cw / 2, cy - ch + 0.032, cw - 0.02, 0.04, lambda: None, col=BUTTON_GOOD,
                    size=0.68)
            elif self._owned(sid):
                Btn(c, "Anlegen", cx + cw / 2, cy - ch + 0.032, cw - 0.02, 0.04,
                    (lambda s=sid: self.cb["equip"](self.target, s)), col=BUTTON_ACCENT, size=0.68)
            else:
                price = K.RARITY[rarity]["price"]
                ok = self.account.get("avail", 0) >= price
                Btn(c, f"Kaufen · {price} P", cx + cw / 2, cy - ch + 0.032, cw - 0.02, 0.04,
                    (lambda s=sid: self.cb["buy"](s)), col=BUTTON_ACCENT if ok else BUTTON_LOCKED, size=0.68)

    def _pick(self, target):
        self.target = target
        self.refresh(self.account, self.planet)

    def _page(self, d):
        pages = max(1, math.ceil(len(self._targets()) / PER_PAGE))
        self.page = (self.page + d) % pages
        self.refresh(self.account, self.planet)

    # ------------------------------------------------------------------ Glücksrad
    def _wheel_mesh(self):
        n = len(K.WHEEL)
        verts, tris, cols = [Vec3(0, 0, 0)], [], [color.rgba(0.1, 0.1, 0.12, 1)]
        palette = [(0.95, 0.55, 0.15), (0.3, 0.55, 0.95), (0.95, 0.75, 0.2), (0.6, 0.4, 0.95),
                   (0.9, 0.45, 0.2), (0.3, 0.7, 0.9), (1.0, 0.82, 0.25), (0.9, 0.35, 0.8)]
        seg = 8
        for i in range(n):
            base = len(verts)
            r, g, b = palette[i % len(palette)]
            for k in range(seg + 1):
                a = math.radians(90 - (i + k / seg) * 360 / n)
                verts.append(Vec3(math.cos(a) * 0.5, math.sin(a) * 0.5, 0))
                cols.append(color.rgba(r, g, b, 1))
            for k in range(seg):
                tris.append((0, base + k, base + k + 1))
        return Mesh(vertices=verts, triangles=tris, colors=cols)

    def _build_wheel(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.03, h / 2 - 0.16
        if not self.account:
            self._need_login(c, top - 0.04)
            return
        Label(c, "Einmal am Tag drehen: Gratis-Skin oder Geld-Boost für die Firma!", x0, top, size=0.85, col=MUTED)
        cx, cy, size = -0.18, -0.1, 0.52
        Entity(parent=c, model=Quad(radius=0.5), position=(cx, cy, -0.005), scale=size + 0.03,
               color=color.rgba(1, 0.75, 0.3, 1))
        self.wheel = Entity(parent=c, position=(cx, cy, -0.01), scale=size)
        Entity(parent=self.wheel, model=self._wheel_mesh(), double_sided=True)
        n = len(K.WHEEL)
        for i, (kind, value, label) in enumerate(K.WHEEL):
            a = math.radians(90 - (i + 0.5) * 360 / n)
            txt = label + (" €" if kind == "money" else "")
            Label(self.wheel, txt, math.cos(a) * 0.33, math.sin(a) * 0.33, size=1.5 / size * 0.5, col=TEXT,
                  origin=(0, 0), z=-0.01, raw=True)
        Entity(parent=c, model=Quad(radius=0.5), position=(cx, cy, -0.03), scale=0.07, color=color.rgba(0.1, 0.1, 0.12, 1))
        # Zeiger oben
        Entity(parent=c, model=Mesh(vertices=[Vec3(-0.025, 0.03, 0), Vec3(0.025, 0.03, 0), Vec3(0, -0.03, 0)],
                                    triangles=[(0, 1, 2)]), position=(cx, cy + size / 2 + 0.01, -0.04),
               color=color.rgba(1, 1, 1, 1), double_sided=True)
        rx = 0.2
        ready = bool(self.account.get("wheel"))
        Label(c, "Gewinne", rx, top - 0.08, size=1.0, col=ACCENT)
        lines = ["Gratis-Skin (selten bis episch)", "2.500 € bis 25.000 € für die Firma",
                 "Neuer Versuch: jeden Tag ab Mitternacht"]
        for i, t in enumerate(lines):                     # Punkt getrennt – sonst greift die Übersetzung nicht
            Label(c, "•", rx, top - 0.14 - i * 0.045, size=0.75, col=MUTED, raw=True)
            Label(c, t, rx + 0.022, top - 0.14 - i * 0.045, size=0.75, col=MUTED)
        Btn(c, "Drehen!" if ready else "Heute schon gedreht", rx + 0.22, top - 0.36, 0.42, 0.07,
            self._spin if ready else (lambda: None), col=BUTTON_ACCENT if ready else BUTTON_LOCKED, size=1.1)
        self.result_l = Label(c, "", rx, top - 0.45, size=0.8, col=GOLD, wordwrap=40)

    def _spin(self):
        if self.spinning:
            return
        self.cb["spin"]()

    def spin_to(self, seg, text):
        """Antwort vom Server: Rad dreht sich und bleibt beim gewonnenen Feld stehen."""
        if self.wheel is None or seg is None:
            if text:
                self.cb["toast"](text)
            return
        n = len(K.WHEEL)
        start = self.wheel.rotation_z % 360
        target = 360 * 5 + (seg + 0.5) * 360 / n
        wheel = self.wheel
        self.spinning = True
        self._spin_text = text

        def f(v):
            wheel.rotation_z = start + (target - start) * v

        def done():
            self.spinning = False
            self._spin_text = ""
            self.cb["toast"](text)
            self.cb["won"]()
            if self.visible and self.tab == "wheel":
                self.refresh(self.account, self.planet)
                if getattr(self, "result_l", None):
                    self.result_l.set(text)
        anim.tween(f, 4.0, ease=anim.out_cubic, done=done, key="wheel")

    # ------------------------------------------------------------------ Konto
    def _build_account(self):
        c = self.content
        w, h = self.w, self.h
        x0, top = -w / 2 + 0.04, h / 2 - 0.17
        a = self.account
        if not a:
            Label(c, "Account anlegen oder einloggen", x0, top, size=1.1, col=ACCENT)
            Label(c, "Dein Account gilt auf diesem Server. Damit kaufst du Skins mit Erfolgspunkten, drehst das "
                     "Glücksrad und kannst anderen Spielern Skins schenken.", x0, top - 0.06, size=0.78, col=MUTED,
                  wordwrap=90)
            y = top - 0.19
            Label(c, "Benutzername", x0, y, size=0.85, col=MUTED)
            self.user = InputField(parent=c, position=(x0 + 0.45, y - 0.012, -0.02), scale=(0.4, 0.05),
                                   character_limit=16)
            y -= 0.08
            Label(c, "Passwort", x0, y, size=0.85, col=MUTED)
            self.pw = InputField(parent=c, position=(x0 + 0.45, y - 0.012, -0.02), scale=(0.4, 0.05),
                                 character_limit=64)
            self.pw.hide_content = True
            y -= 0.1
            Btn(c, "Einloggen", x0 + 0.35, y, 0.2, 0.054, lambda: self.cb["login"](self.user.text, self.pw.text),
                col=BUTTON_ACCENT)
            Btn(c, "Registrieren", x0 + 0.57, y, 0.2, 0.054,
                lambda: self.cb["register"](self.user.text, self.pw.text), col=BUTTON_GOOD)
            Label(c, "Passwörter werden nur verschlüsselt (als Hash) auf dem Server gespeichert. "
                     "Nimm kein Passwort, das du woanders benutzt.", x0, y - 0.07, size=0.68, col=FAINT, wordwrap=100)
            return
        Label(c, f"Eingeloggt als {a['name']}", x0, top, size=1.1, col=ACCENT)
        owned = sorted(s for s in (K.all_ids() if a.get("all") else a.get("owned", []))
                       if K.parse(s)[0] in self._targets())
        Label(c, f"Erfolgspunkte: {a.get('points', 0)} gesammelt, {a.get('spent', 0)} ausgegeben  ·  "
                 f"Skins: {len(owned)}", x0, top - 0.06, size=0.8, col=MUTED)
        Btn(c, "Ausloggen", w / 2 - 0.14, top - 0.01, 0.2, 0.046, self.cb["logout"], size=0.8)
        y = top - 0.16
        Label(c, "Skin verschenken", x0, y, size=1.0, col=ACCENT)
        y -= 0.07
        if not owned:
            Label(c, "Du hast noch keine Skins – kaufe welche oder dreh das Glücksrad.", x0, y, size=0.8, col=FAINT)
            return
        self.gift_idx %= len(owned)
        sid = owned[self.gift_idx]
        Btn(c, "«", x0 + 0.03, y, 0.06, 0.046, lambda: self._gift_step(-1), size=0.9)
        panel(c, x0 + 0.07, y + 0.023, 0.5, 0.046, PANEL_LIGHT, radius=0.008, collider=False)
        Label(c, K.display_name(sid, self.planet), x0 + 0.32, y, size=0.8, col=_rc(K.rarity(sid)), origin=(0, 0),
              raw=True, max_w=0.48)
        Btn(c, "»", x0 + 0.6, y, 0.06, 0.046, lambda: self._gift_step(1), size=0.9)
        y -= 0.08
        Label(c, "An (Benutzername)", x0, y, size=0.85, col=MUTED)
        self.gift_to = InputField(parent=c, position=(x0 + 0.45, y - 0.012, -0.02), scale=(0.4, 0.05),
                                  character_limit=16)
        Btn(c, "Verschenken", x0 + 0.78, y - 0.012, 0.22, 0.05, lambda: self.cb["gift"](sid, self.gift_to.text),
            col=BUTTON_ACCENT)
        if a.get("all"):
            Label(c, "Als Entwickler verschenkst du Kopien – du behältst alle Skins.", x0, y - 0.07, size=0.7, col=FAINT)

    def _gift_step(self, d):
        self.gift_idx += d
        self.refresh(self.account, self.planet)
