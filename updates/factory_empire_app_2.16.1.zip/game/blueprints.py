"""
Blueprints: die eigene Fabrik als Bauplan speichern und in einer anderen Welt als grauen Schatten
einblenden. Was dort schon passend steht, verschwindet aus dem Schatten; ein Klick auf ein
Schattenfeld wählt das richtige Gebäude mit der richtigen Drehung aus.

Gespeichert wird lokal beim Spieler (saves/blueprints.json) – so nimmt man Baupläne in jede Welt mit.
"""

import json
import os
import time

from panda3d.core import NodePath, TransparencyAttrib
from ursina import Entity

from . import config as C
from . import graphics
from . import models
from .ui_base import (ACCENT, BUTTON, BUTTON_ACCENT, BUTTON_DANGER, BUTTON_GOOD, FAINT, MUTED, PANEL_LIGHT, TEXT,
                      Btn, Label, Window, panel)

PATH = os.path.join(C.DATA_DIR, "blueprints.json")
MAX_BLUEPRINTS = 12


def load():
    try:
        with open(PATH, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return []
    out = []
    for bp in data if isinstance(data, list) else []:
        try:
            items = [[str(t), int(x), int(y), int(r) % 4, r2 if isinstance(r2, str) else None]
                     for t, x, y, r, r2 in bp["items"] if t in C.BUILDINGS]
            out.append({"name": str(bp.get("name", "Blueprint"))[:40], "date": str(bp.get("date", ""))[:20],
                        "planet": bp.get("planet", "earth"), "items": items})
        except (KeyError, TypeError, ValueError):
            continue
    return out[:MAX_BLUEPRINTS]


def save(blueprints):
    try:
        os.makedirs(os.path.dirname(PATH), exist_ok=True)
        tmp = PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(blueprints[:MAX_BLUEPRINTS], f, ensure_ascii=False)
        os.replace(tmp, PATH)
        return True
    except OSError:
        return False


def from_state(static, planet, name):
    items = [[row[1], row[2], row[3], row[4], row[6] if len(row) > 6 else None] for row in static.values()
             if row[1] in C.BUILDINGS]
    items.sort(key=lambda it: (it[2], it[1]))
    return {"name": name, "date": time.strftime("%d.%m.%Y %H:%M"), "planet": planet, "items": items}


class GhostLayer:
    """Graue, halb durchsichtige Schatten aller noch fehlenden Gebäude eines Blueprints."""

    def __init__(self):
        self.bp = None
        self.node = None
        self.missing = {}                # (x, y) -> (typ, drehung, rezept)
        self._key = None

    def set_blueprint(self, bp):
        self.bp = bp
        self._key = None

    def clear(self):
        self.bp = None
        self.missing = {}
        self._key = None
        if self.node is not None:
            self.node.removeNode()
            self.node = None

    def at(self, x, y):
        return self.missing.get((x, y))

    def update(self, static, grid):
        """Nach Änderungen der Gebäude: fehlende Teile neu bestimmen und den Schatten neu bauen."""
        if self.bp is None:
            return
        have = {(row[2], row[3]): row[1] for row in static.values()}
        missing = {}
        for t, x, y, rot, recipe in self.bp["items"]:
            if have.get((x, y)) != t:
                missing[(x, y)] = (t, rot, recipe)
        key = tuple(sorted(missing))
        if key == self._key:
            return
        self._key = key
        self.missing = missing
        from .buildings import _mesh
        root = NodePath("blueprint")
        for (x, y), (t, rot, _) in missing.items():
            src = _mesh(("static", t), lambda tt=t: models.static_mesh(tt))
            np = src.copyTo(root)
            np.setPos(x, 0.02, y)
            np.setH(-rot * 90)
        root.flattenStrong()
        if self.node is not None:
            self.node.removeNode()
        holder = Entity(add_to_scene_entities=False, shader=graphics.unlit())
        root.reparentTo(holder)
        holder.setTransparency(TransparencyAttrib.M_alpha)
        holder.setColorScale(1.3, 1.4, 1.65, 0.5)
        holder.setTextureOff(1)
        holder.setLightOff(1)
        holder.setDepthWrite(False)
        holder.setBin("transparent", 5)
        self.node = holder


class BlueprintWindow(Window):
    def __init__(self, anchors, cb):
        super().__init__(anchors, "Blueprints", 1.0, 0.74, cb["close"], z=-0.5, icon_name="ui_stats")
        self.cb = cb
        self.content = None

    def refresh(self, blueprints, active_name, missing, buildings_now):
        if self.content is not None:
            self.content.enabled = False
            self.content.parent = None
        c = self.content = Entity(parent=self.root)
        w, h = self.w, self.h
        x0, y = -w / 2 + 0.035, h / 2 - 0.11
        Label(c, "Speichere deine Fabrik als Bauplan und blende sie in einer anderen Welt als grauen "
                 "Schatten ein. Klick auf ein Schattenfeld wählt das passende Gebäude samt Drehung.", x0, y,
              size=0.74, col=MUTED, wordwrap=80)
        y -= 0.11
        Btn(c, f"Aktuelle Fabrik speichern ({buildings_now} Teile)", x0 + 0.3, y, 0.6, 0.054, self.cb["save"],
            col=BUTTON_GOOD, size=0.82)
        if active_name:
            Btn(c, "Schatten ausblenden", w / 2 - 0.16, y, 0.26, 0.054, self.cb["hide"], col=BUTTON, size=0.78)
        y -= 0.075
        if not blueprints:
            Label(c, "Noch keine Blueprints gespeichert.", x0, y - 0.02, size=0.82, col=FAINT)
            return
        for i, bp in enumerate(blueprints[:8]):
            active = bp["name"] == active_name
            panel(c, x0, y + 0.026, w - 0.07, 0.052, PANEL_LIGHT, radius=0.008, collider=False)
            Label(c, bp["name"], x0 + 0.015, y + 0.008, size=0.8, col=ACCENT if active else TEXT, raw=True, max_w=0.36)
            info = f"{len(bp['items'])} Teile · {bp['date']}" + (" · Mond" if bp.get("planet") == "moon" else "")
            if active:
                info += f" · noch {missing} zu bauen"
            Label(c, info, x0 + 0.015, y - 0.016, size=0.66, col=MUTED)
            Btn(c, "Angezeigt" if active else "Anzeigen", w / 2 - 0.27, y, 0.18, 0.042,
                (lambda b=bp: self.cb["show"](b)), col=BUTTON_GOOD if active else BUTTON_ACCENT, size=0.72)
            Btn(c, "Löschen", w / 2 - 0.1, y, 0.12, 0.042, (lambda k=i: self.cb["delete"](k)), col=BUTTON_DANGER,
                size=0.7)
            y -= 0.062
