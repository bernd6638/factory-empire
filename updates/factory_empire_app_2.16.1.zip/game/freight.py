"""
Aufträge und Frachtbahnhof (läuft auf dem Server).

Auftragsbörse: Städte bestellen Waren ("10× Batterie nach Berlin"). Ein angenommener Auftrag wird
einem freien LKW an einem Frachtbahnhof zugeteilt. Der LKW wird über Förderbänder (oder per Knopf
aus dem Firmenlager) beladen; ist er voll, fährt er los. Nach der Fahrzeit kommt die Ware an und
die Belohnung wird gutgeschrieben – deutlich mehr als beim normalen Verkauf. Danach fährt der LKW
leer zurück und steht für den nächsten Auftrag bereit.
"""

import math
import random

from . import config as C
from . import rules

# Stadt, Fahrzeit in Minuten (eine Richtung)
CITIES = [
    ("Leipzig", 2.0), ("Dresden", 2.5), ("Hannover", 3.0), ("Berlin", 4.0), ("Prag", 4.5),
    ("Hamburg", 5.0), ("Köln", 5.5), ("Frankfurt", 6.0), ("Nürnberg", 6.0), ("Amsterdam", 7.0),
    ("Stuttgart", 7.0), ("München", 8.0), ("Kopenhagen", 8.0), ("Wien", 9.0), ("Zürich", 9.0),
    ("Warschau", 10.0), ("Paris", 10.0), ("Mailand", 11.0),
]
CITY_MINUTES = dict(CITIES)

BOARD_SIZE = 6                  # Angebote auf der Auftragsbörse
MAX_CONTRACTS = 6               # gleichzeitig angenommene Aufträge
OFFER_INTERVAL = (25.0, 50.0)   # Sekunden bis zum nächsten neuen Angebot
OFFER_LIFETIME = (420.0, 720.0) # so lange bleibt ein Angebot auf der Börse
RETURN_FACTOR = 0.4             # Rückfahrt (leer) im Verhältnis zur Hinfahrt
REP_STEP = 5                    # Lieferungen pro Ruf-Stufe
REP_MAX = 10


def rep_level(deliveries):
    return min(REP_MAX, 1 + deliveries // REP_STEP)


def rep_bonus(deliveries):
    """Belohnungs-Aufschlag durch den Speditions-Ruf (+4 % je Stufe)."""
    return 1.0 + 0.04 * (rep_level(deliveries) - 1)


def store_capacity(b):
    return C.FREIGHT_STORE.get(b.level, C.FREIGHT_STORE[1])


def producible_items(unlocked):
    """Waren, die der Spieler mit seiner Forschung herstellen kann."""
    items = set(C.DEPOSIT_ITEMS)
    for rid, r in C.RECIPES.items():
        if rules.recipe_unlocked(rid, unlocked) and rules.building_unlocked(r["machine"], unlocked):
            items.update(r["outputs"])
    return [i for i in C.ITEM_ORDER if i in items]


def quantity_for(price, rng):
    if price < 10:
        return rng.randint(6, 16) * 5
    if price < 50:
        return rng.randint(4, 10) * 5
    if price < 200:
        return rng.randint(6, 20)
    if price < 600:
        return rng.randint(4, 12)
    return rng.randint(2, 6)


class Freight:
    def __init__(self):
        self.board = []             # Angebote
        self.contracts = []         # angenommene Aufträge
        self.next_id = 1
        self.offer_timer = 3.0
        self.deliveries = 0
        self.income = 0.0

    # ------------------------------------------------------------------ Angebote
    def make_offer(self, state, rng):
        items = producible_items(state.research.unlocked)
        if not items:
            return None
        # höherwertige Waren etwas häufiger (sobald man sie herstellen kann)
        weights = [1.0 + math.log10(1 + C.ITEMS[i]["price"]) for i in items]
        item = rng.choices(items, weights)[0]
        city, minutes = rng.choice(CITIES)
        price = C.ITEMS[item]["price"]
        qty = quantity_for(price, rng)
        bonus = 3.0 + minutes * 0.3 + rng.uniform(0.0, 0.6)
        reward = round(qty * price * bonus * rep_bonus(self.deliveries) / 10) * 10
        offer = {"id": self.next_id, "city": city, "item": item, "qty": qty, "reward": float(reward),
                 "min": minutes, "expires": state.time + rng.uniform(*OFFER_LIFETIME)}
        self.next_id += 1
        return offer

    def travel_seconds(self, state, minutes):
        return minutes * 60.0 * state.travel_mult

    # ------------------------------------------------------------------ Aktionen
    def accept(self, state, oid):
        offer = next((o for o in self.board if o["id"] == oid), None)
        if offer is None:
            return False, "Dieses Angebot gibt es nicht mehr."
        if not rules.building_unlocked("freight", state.research.unlocked):
            return False, "Für Aufträge brauchst du die Forschung „Spedition“ (Frachtbahnhof)."
        if len(self.contracts) >= MAX_CONTRACTS:
            return False, f"Höchstens {MAX_CONTRACTS} Aufträge gleichzeitig."
        self.board.remove(offer)
        c = {"id": offer["id"], "city": offer["city"], "item": offer["item"], "qty": offer["qty"],
             "reward": offer["reward"], "min": offer["min"], "loaded": 0, "status": "wait",
             "station": 0, "depart": 0.0, "arrive": 0.0}
        self.contracts.append(c)
        name = C.ITEMS[c["item"]]["name"]
        hint = "" if any(b.type == "freight" for b in state.buildings.values()) else \
            " Baue einen Frachtbahnhof, damit ein LKW beladen werden kann."
        return True, f"Auftrag angenommen: {c['qty']}× {name} nach {c['city']}.{hint}"

    def cancel(self, state, cid):
        c = self._contract(cid)
        if c is None:
            return False, "Auftrag nicht gefunden."
        if c["status"] == "enroute":
            return False, "Der LKW ist schon unterwegs."
        self._release_truck(state, c)
        free = max(0, state.storage_capacity() - state.inventory_total())
        back = min(free, c["loaded"])
        state.inventory[c["item"]] = state.inventory.get(c["item"], 0) + back
        self.contracts.remove(c)
        extra = f" {back} Stück zurück ins Lager." if back else ""
        return True, f"Auftrag nach {c['city']} storniert.{extra}"

    def load_from_storage(self, state, cid):
        c = self._contract(cid)
        if c is None:
            return False, "Auftrag nicht gefunden."
        if c["status"] == "wait":
            return False, "Noch kein freier LKW – baue einen Frachtbahnhof oder warte, bis ein LKW zurück ist."
        if c["status"] != "loading":
            return False, "Der LKW ist schon unterwegs."
        st = state.buildings.get(c["station"])
        from_station = self._load_from_station(st, c, limit=c["qty"]) if st is not None and st.type == "freight" else 0
        have = state.inventory.get(c["item"], 0)
        need = c["qty"] - c["loaded"]
        n = min(have, need)
        if n <= 0 and from_station <= 0:
            return False, f"Keine {C.ITEMS[c['item']]['name']} im Firmenlager."
        state.inventory[c["item"]] = have - n
        c["loaded"] += n
        return True, f"{n + from_station}× {C.ITEMS[c['item']]['name']} aus dem Lager verladen."

    # ------------------------------------------------------------------ Bahnhof
    def _contract(self, cid):
        return next((c for c in self.contracts if c["id"] == cid), None)

    def _release_truck(self, state, c):
        b = state.buildings.get(c["station"])
        if b is not None and b.type == "freight":
            for t in b.trucks:
                if t["cid"] == c["id"]:
                    t["cid"] = 0
                    t["state"] = "free"

    def station_accept(self, state, b, item):
        """Ware vom Band in einen LKW dieses Bahnhofs laden – sonst ins Bahnhof-Lager (für spätere Aufträge)."""
        for t in b.trucks:
            if t["state"] == "loading":
                c = self._contract(t["cid"])
                if c and c["item"] == item and c["loaded"] < c["qty"]:
                    c["loaded"] += 1
                    return True
        if sum(b.inbuf.values()) < store_capacity(b):
            b.inbuf[item] = b.inbuf.get(item, 0) + 1
            return True
        return False

    def _load_from_station(self, b, c, limit=10):
        """LKW aus dem Bahnhof-Lager beladen (bis zu `limit` Stück je Takt)."""
        have = b.inbuf.get(c["item"], 0)
        n = min(have, c["qty"] - c["loaded"], limit)
        if n > 0:
            c["loaded"] += n
            if have - n > 0:
                b.inbuf[c["item"]] = have - n
            else:
                b.inbuf.pop(c["item"], None)
        return n

    def tick_station(self, state, b, dt):
        n = C.LEVEL_TRUCKS.get(b.level, 1)
        while len(b.trucks) < n:
            b.trucks.append({"state": "free", "cid": 0, "back": 0.0})
        loading = 0
        for t in b.trucks:
            if t["state"] == "away":
                if state.time >= t["back"]:
                    t["state"] = "free"
                    t["cid"] = 0
                continue
            if t["state"] == "loading":
                c = self._contract(t["cid"])
                if c is None:
                    t["state"], t["cid"] = "free", 0
                elif c["loaded"] < c["qty"] and self._load_from_station(b, c) and c["loaded"] < c["qty"]:
                    loading += 1
                    continue
                elif c["loaded"] >= c["qty"]:
                    secs = self.travel_seconds(state, c["min"])
                    c["status"] = "enroute"
                    c["depart"] = state.time
                    c["arrive"] = state.time + secs
                    t["state"] = "away"
                    t["back"] = state.time + secs * (1 + RETURN_FACTOR)
                    state.event(f"LKW fährt los: {c['qty']}× {C.ITEMS[c['item']]['name']} nach {c['city']} "
                                f"(Ankunft in {rules.format_duration(secs)}).", "info")
                    continue
                else:
                    loading += 1
            if t["state"] == "free":
                c = next((c for c in self.contracts if c["status"] == "wait"), None)
                if c is not None:
                    c["status"] = "loading"
                    c["station"] = b.id
                    t["state"] = "loading"
                    t["cid"] = c["id"]
                    loading += 1
        if loading:
            b.status = "working"
        elif any(t["state"] == "away" for t in b.trucks):
            b.status = "trucks_away"
        else:
            b.status = "no_order"

    # ------------------------------------------------------------------ Takt
    def tick(self, state, dt, rng):
        self.offer_timer -= dt
        if self.offer_timer <= 0:
            self.offer_timer = rng.uniform(*OFFER_INTERVAL)
            if len(self.board) < BOARD_SIZE and rules.building_unlocked("freight", state.research.unlocked):
                offer = self.make_offer(state, rng)
                if offer:
                    self.board.append(offer)
        self.board = [o for o in self.board if o["expires"] > state.time]
        for c in list(self.contracts):
            if c["status"] == "enroute" and state.time >= c["arrive"]:
                self.contracts.remove(c)
                state.money += c["reward"]
                self.deliveries += 1
                self.income += c["reward"]
                state.event(f"Lieferung angekommen in {c['city']}: {c['qty']}× {C.ITEMS[c['item']]['name']} "
                            f"(+{rules.format_money(c['reward'])})", "success")
                if self.deliveries % REP_STEP == 0 and rep_level(self.deliveries) <= REP_MAX:
                    state.event(f"Dein Speditions-Ruf steigt auf Stufe {rep_level(self.deliveries)}: "
                                f"bessere Belohnungen!", "success")
            elif c["status"] == "loading":
                b = state.buildings.get(c["station"])
                if b is None or b.type != "freight" or not any(t["cid"] == c["id"] for t in b.trucks):
                    c["status"] = "wait"            # Bahnhof abgerissen: neuer LKW nötig
                    c["station"] = 0

    # ------------------------------------------------------------------ Netzwerk / Speichern
    def snapshot(self, state):
        now = state.time
        return {
            "board": [{"id": o["id"], "city": o["city"], "item": o["item"], "qty": o["qty"],
                       "reward": o["reward"], "min": round(o["min"] * state.travel_mult, 2),
                       "exp": round(o["expires"] - now)} for o in self.board],
            "contracts": [{"id": c["id"], "city": c["city"], "item": c["item"], "qty": c["qty"],
                           "loaded": c["loaded"], "reward": c["reward"], "status": c["status"],
                           "station": c["station"],
                           "eta": round(max(0.0, c["arrive"] - now), 1) if c["status"] == "enroute" else 0,
                           "total": round(c["arrive"] - c["depart"], 1) if c["status"] == "enroute" else
                           round(self.travel_seconds(state, c["min"]), 1)} for c in self.contracts],
            "deliveries": self.deliveries,
            "income": round(self.income, 2),
            "rep": rep_level(self.deliveries),
            "max": MAX_CONTRACTS,
        }

    def to_dict(self):
        return {"board": self.board, "contracts": self.contracts, "next_id": self.next_id,
                "deliveries": self.deliveries, "income": self.income}

    @classmethod
    def from_dict(cls, d, now=0.0):
        f = cls()
        if not isinstance(d, dict):
            return f
        f.next_id = int(d.get("next_id", 1))
        f.deliveries = int(d.get("deliveries", 0))
        f.income = float(d.get("income", 0.0))
        for o in d.get("board", []):
            try:
                if o["item"] in C.ITEMS and o["city"] in CITY_MINUTES:
                    f.board.append({"id": int(o["id"]), "city": o["city"], "item": o["item"], "qty": int(o["qty"]),
                                    "reward": float(o["reward"]), "min": float(o["min"]),
                                    "expires": float(o["expires"])})
            except (KeyError, TypeError, ValueError):
                continue
        for c in d.get("contracts", []):
            try:
                if c["item"] not in C.ITEMS:
                    continue
                f.contracts.append({"id": int(c["id"]), "city": str(c["city"]), "item": c["item"],
                                    "qty": int(c["qty"]), "reward": float(c["reward"]), "min": float(c["min"]),
                                    "loaded": int(c.get("loaded", 0)),
                                    "status": c.get("status") if c.get("status") in ("wait", "loading", "enroute")
                                    else "wait",
                                    "station": int(c.get("station", 0)), "depart": float(c.get("depart", 0.0)),
                                    "arrive": float(c.get("arrive", 0.0))})
            except (KeyError, TypeError, ValueError):
                continue
        ids = [o["id"] for o in f.board] + [c["id"] for c in f.contracts]
        f.next_id = max([f.next_id] + [i + 1 for i in ids])
        return f


def seeded_rng(seed):
    return random.Random(seed * 7 + 3)
