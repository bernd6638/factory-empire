"""
Autoritativer Spielzustand (läuft nur auf dem Server).

GameState enthält Karte, Gebäude, Geld, Lager, Forschung und Markt.
Alle Spieleraktionen laufen über die Methoden `action_*`, die jede Eingabe
prüfen und (ok, nachricht) zurückgeben. Clients schicken nur Wünsche –
entschieden wird ausschließlich hier.
"""

import math
import random
from collections import deque

from . import config as C
from . import rules
from .freight import Freight
from .market import Market
from .production import TICK_FUNCTIONS
from .research import ResearchManager


class Building:
    __slots__ = ("id", "type", "x", "y", "rot", "level", "owner", "progress", "status",
                 "inbuf", "outbuf", "items", "recipe", "active_recipe",
                 "produced", "earned", "stored", "enabled", "filters", "min_pct", "rr", "recent", "trucks")

    def __init__(self, bid, btype, x, y, rot, owner=""):
        self.id = bid
        self.type = btype
        self.x = x
        self.y = y
        self.rot = rot
        self.level = 1
        self.owner = owner
        self.progress = 0.0
        self.status = "idle"
        self.inbuf = {}
        self.outbuf = {}
        self.items = []            # Band/Verteiler: [[item, pos], ...]  Verkäufer: [item, ...]
        self.recipe = C.MACHINE_RECIPES[btype][0] if btype in C.MACHINE_RECIPES else None
        self.active_recipe = None
        self.produced = 0
        self.earned = 0.0
        self.stored = 0
        self.enabled = True
        self.filters = {}          # Sortierer: item -> "L" | "F" | "R"
        self.min_pct = None        # Verkäufer: Mindestaufschlag in Prozent (None = immer)
        self.rr = 0                # Splitter/T-Stück: nächster Ausgang
        self.recent = deque()      # (zeit, menge) für die gemessene Leistung (nicht gespeichert)
        self.trucks = []           # Frachtbahnhof: [{"state": free|loading|away, "cid", "back"}]

    def to_dict(self):
        return {
            "id": self.id, "type": self.type, "x": self.x, "y": self.y, "rot": self.rot,
            "level": self.level, "owner": self.owner, "progress": self.progress,
            "inbuf": self.inbuf, "outbuf": self.outbuf, "items": self.items,
            "recipe": self.recipe, "active_recipe": self.active_recipe,
            "produced": self.produced, "earned": self.earned, "stored": self.stored,
            "enabled": self.enabled, "filters": self.filters, "min_pct": self.min_pct, "rr": self.rr,
            "trucks": self.trucks,
        }

    @classmethod
    def from_dict(cls, d):
        b = cls(int(d["id"]), d["type"], int(d["x"]), int(d["y"]), int(d["rot"]) % 4, str(d.get("owner", "")))
        b.level = max(1, min(int(d.get("level", 1)), C.BUILDINGS[b.type]["max_level"]))
        b.progress = float(d.get("progress", 0.0))
        b.inbuf = {k: int(v) for k, v in d.get("inbuf", {}).items() if k in C.ITEMS}
        b.outbuf = {k: int(v) for k, v in d.get("outbuf", {}).items() if k in C.ITEMS}
        if b.type in C.BELT_LIKE:
            b.items = [[it, float(p)] for it, p in d.get("items", []) if it in C.ITEMS]
            b.items.sort(key=lambda it: -it[1])
        elif b.type == "seller":
            b.items = [it for it in d.get("items", []) if it in C.ITEMS]
        if b.type in C.MACHINE_RECIPES:
            choices = C.MACHINE_RECIPES[b.type]
            b.recipe = d.get("recipe") if d.get("recipe") in choices else choices[0]
        ar = d.get("active_recipe")
        b.active_recipe = ar if ar in C.RECIPES and C.RECIPES[ar]["machine"] == b.type else None
        if ar and b.active_recipe is None:
            b.progress = 0.0
        # Ältere Spielstände: Rezepte sind seit 2.6 auf Spezialfabriken verteilt. Was diese Maschine
        # nicht mehr verarbeiten kann, wird aus dem Eingang entfernt (sonst bliebe es ewig liegen).
        if b.type == "smelter" or b.type in C.MACHINE_RECIPES:
            usable = {i for r in C.RECIPES.values() if r["machine"] == b.type for i in r["inputs"]}
            b.inbuf = {k: v for k, v in b.inbuf.items() if k in usable}
        b.produced = int(d.get("produced", 0))
        b.earned = float(d.get("earned", 0.0))
        b.stored = int(d.get("stored", 0))
        b.enabled = bool(d.get("enabled", True))
        b.filters = {k: v for k, v in d.get("filters", {}).items() if k in C.ITEMS and v in C.SIDE_NAMES}
        b.min_pct = d.get("min_pct") if d.get("min_pct") in C.SELLER_THRESHOLDS else None
        b.rr = int(d.get("rr", 0)) % 3
        if b.type == "freight":
            for t in d.get("trucks", []) or []:
                if isinstance(t, dict) and t.get("state") in ("free", "loading", "away"):
                    b.trucks.append({"state": t["state"], "cid": int(t.get("cid", 0)),
                                     "back": float(t.get("back", 0.0))})
        return b


def _paint_clusters(clusters, rng, deposits, bounds):
    w, h = bounds
    for item, x0, y0, radius in clusters:
        for x in range(int(x0 - radius) - 1, int(x0 + radius) + 2):
            for y in range(int(y0 - radius) - 1, int(y0 + radius) + 2):
                if not (0 <= x < w and 0 <= y < h) or (x, y) in deposits:
                    continue
                if math.hypot(x - x0, y - y0) <= radius + rng.uniform(-0.6, 0.4):
                    deposits[(x, y)] = item


def generate_moon_deposits(seed):
    """Mond: Mondstein, Mondkohle, Titanerz, Helium-3 und Mondeis – in der Mitte je ein Startfeld."""
    rng = random.Random(seed * 7 + 3)
    cx, cy = C.GRID_W // 2, C.GRID_H // 2
    clusters = [("moon_rock", cx - 6, cy + 4, 2.6), ("titanium_ore", cx + 6, cy - 4, 2.3),
                ("moon_coal", cx - 7, cy - 6, 2.2), ("moon_ice", cx + 7, cy + 6, 2.2), ("helium3", cx, cy + 10, 2.0)]
    counts = {"moon_rock": 18, "titanium_ore": 16, "moon_coal": 13, "moon_ice": 12, "helium3": 11}
    for item, n in counts.items():
        for _ in range(n):
            clusters.append((item, rng.randint(4, C.GRID_W - 5), rng.randint(4, C.GRID_H - 5), rng.uniform(1.6, 3.2)))
    deposits = {}
    _paint_clusters(clusters, rng, deposits, (C.GRID_W, C.GRID_H))
    return deposits


def generate_deposits(seed):
    """Erzeugt reproduzierbare Rohstofffelder auf der ganzen Karte. Nahe der Kartenmitte liegt
    garantiert von jedem Rohstoff ein Vorkommen, damit jede neue Fabrik starten kann."""
    rng = random.Random(seed)
    cx, cy = C.GRID_W // 2, C.GRID_H // 2
    clusters = [("iron_ore", cx - 5, cy + 3, 2.7), ("copper_ore", cx + 6, cy - 4, 2.3),
                ("coal", cx - 8, cy - 6, 2.2), ("stone", cx + 8, cy + 6, 2.3), ("sand", cx + 1, cy + 10, 2.2)]
    counts = {"iron_ore": 22, "copper_ore": 16, "coal": 14, "stone": 13, "sand": 12}
    for item, n in counts.items():
        for _ in range(n):
            clusters.append((item, rng.randint(4, C.GRID_W - 5), rng.randint(4, C.GRID_H - 5), rng.uniform(1.6, 3.4)))
    deposits = {}
    _paint_clusters(clusters, rng, deposits, (C.GRID_W, C.GRID_H))
    return deposits


def generate_legacy_deposits(seed):
    """Erzfelder, wie sie bis Version 2.2 auf der 48×48-Karte lagen (für alte Spielstände):
    die alten Felder bleiben genau erhalten, der Rest der großen Karte und die neuen
    Rohstoffe (Kohle, Stein, Sand) kommen dazu."""
    old_w = old_h = 48
    rng = random.Random(seed)
    cx, cy = old_w // 2, old_h // 2
    clusters = [("iron_ore", cx - 5, cy + 3, 2.7), ("copper_ore", cx + 6, cy - 4, 2.3)]
    for _ in range(7):
        clusters.append(("iron_ore", rng.randint(4, old_w - 5), rng.randint(4, old_h - 5), rng.uniform(1.8, 3.2)))
    for _ in range(5):
        clusters.append(("copper_ore", rng.randint(4, old_w - 5), rng.randint(4, old_h - 5), rng.uniform(1.6, 2.8)))
    old = {}
    _paint_clusters(clusters, rng, old, (old_w, old_h))
    # neue Rohstoffe in der Nähe der alten Fabrik, an freien Stellen
    extra = {}
    rng2 = random.Random(seed + 99)
    _paint_clusters([("coal", cx - 10, cy - 9, 2.2), ("stone", cx + 11, cy + 9, 2.3), ("sand", cx - 2, cy + 14, 2.2)],
                    rng2, extra, (old_w, old_h))
    merged = dict(generate_deposits(seed))
    for key in list(merged):
        if key[0] < old_w and key[1] < old_h:        # alten Bereich unverändert lassen
            del merged[key]
    merged.update({k: v for k, v in extra.items() if k not in old})
    merged.update(old)
    return merged


class GameState:
    def __init__(self, seed=C.WORLD_SEED, planet="earth"):
        self.seed = seed
        self.planet = planet if planet in C.PLANETS else "earth"
        self.moon = None               # Mond-Spielstand (GameState mit planet="moon"), erst nach dem ersten Flug
        self.moon_preview = False      # Test-Welt: Mond schon vor Ablauf des Countdowns
        self.player_planets = {}       # Spielername (klein) -> "earth"/"moon": wo jemand zuletzt war
        self.rng = random.Random(seed)
        self.deposits = generate_moon_deposits(seed) if self.planet == "moon" else generate_deposits(seed)
        self.buildings = {}
        self.grid = {}
        self.next_id = 1
        self.money = float(C.MOON_START_MONEY if self.planet == "moon" else C.START_MONEY)
        self.inventory = {item: 0 for item in C.ITEMS}
        self.research = ResearchManager()
        self.rocket_unlocked = False   # Rakete für ROCKET_PRICE freigeschaltet (nur Erde)
        self.market = Market()
        self.time = 0.0
        self.revision = 0              # erhöht sich bei jeder Änderung an Gebäuden
        self.events = []               # Meldungen für alle Spieler
        self.produced = {item: 0 for item in C.ITEMS}
        self.energy_spent = 0.0
        self.energy_due = 0.0          # angefallene, noch nicht abgebuchte Energiekosten
        self.energy_timer = 0.0
        self.energy_log = deque()      # (zeit, betrag) abgerechneter Energie für €/Minute
        self.total_built = 0
        self.freight = Freight()
        self._recompute_modifiers()

    # ------------------------------------------------------------------ Hilfen
    def _recompute_modifiers(self):
        u = self.research.unlocked
        self.speed_mult = rules.speed_multiplier(u)
        self.miner_mult = rules.miner_multiplier(u)
        self.belt_mult = rules.belt_multiplier(u)
        self.price_mult = rules.price_multiplier(u)
        self.cost_mult = rules.cost_multiplier(u)
        self.storage_mult = rules.storage_multiplier(u)
        self.travel_mult = rules.travel_multiplier(u)

    def building_at(self, x, y):
        bid = self.grid.get((x, y))
        return self.buildings.get(bid) if bid is not None else None

    def inventory_total(self):
        return sum(self.inventory.values())

    def storage_capacity(self):
        base = C.BUILDINGS["storage"]["capacity"]
        total = 0.0
        for b in self.buildings.values():
            if b.type == "storage":
                total += base * C.LEVEL_CAPACITY.get(b.level, 1.0)
        return int(total * self.storage_mult)

    def count_production(self, b, item, qty, track_global=True):
        if track_global:
            self.produced[item] = self.produced.get(item, 0) + qty
        b.recent.append((self.time, qty))

    def building_rate(self, b):
        """Gemessene Ausgabe pro Minute (über die letzten RATE_WINDOW Sekunden)."""
        cutoff = self.time - C.RATE_WINDOW
        while b.recent and b.recent[0][0] < cutoff:
            b.recent.popleft()
        return sum(q for _, q in b.recent) * 60.0 / C.RATE_WINDOW

    # ------------------------------------------------------------------ Energie
    def available_money(self):
        """Geld abzüglich bereits angefallener, noch nicht abgebuchter Energiekosten."""
        return self.money - self.energy_due

    def can_afford_energy(self, amount):
        """Kein Arbeitsgang darf starten, wenn das Geld die offenen Energiekosten nicht deckt."""
        return self.money - self.energy_due >= amount

    def add_energy(self, amount):
        self.energy_due += amount

    def _bill_energy(self):
        due = self.energy_due
        if due <= 0:
            return
        self.money -= due
        self.energy_spent += due
        self.energy_due = 0.0
        self.energy_log.append((self.time, due))

    def energy_per_minute(self):
        cutoff = self.time - 60.0
        while self.energy_log and self.energy_log[0][0] < cutoff:
            self.energy_log.popleft()
        return sum(v for _, v in self.energy_log)

    def event(self, text, kind="info"):
        self.events.append({"kind": kind, "text": text})

    def drain_events(self):
        ev, self.events = self.events, []
        return ev

    def _get_building(self, bid):
        if not rules.is_int(bid) or bid not in self.buildings:
            return None
        return self.buildings[bid]

    # ------------------------------------------------------------------ Aktionen
    def check_build(self, btype, x, y, rot):
        return rules.check_build(
            btype, x, y, rot,
            occupied=lambda a, b: (a, b) in self.grid,
            deposit_at=lambda a, b: self.deposits.get((a, b)),
            unlocked=self.research.unlocked,
            money=self.available_money(),
            planet=self.planet,
        )

    def action_build(self, btype, x, y, rot, player="Server"):
        ok, msg = self.check_build(btype, x, y, rot)
        if not ok:
            return False, msg
        spec = C.BUILDINGS[btype]
        self.money -= spec["cost"]
        b = Building(self.next_id, btype, x, y, rot, player)
        if btype in C.MACHINE_RECIPES:
            b.recipe = (rules.machine_recipes(btype, self.planet) or [b.recipe])[0]
        self.next_id += 1
        self.buildings[b.id] = b
        self.grid[(x, y)] = b.id
        self.total_built += 1
        self.revision += 1
        return True, f"{rules.building_name(btype, self.planet)} gebaut (-{spec['cost']} €)."

    def action_demolish(self, bid, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        refund = rules.demolish_refund(b.type, b.level)
        self.money += refund
        del self.buildings[b.id]
        del self.grid[(b.x, b.y)]
        # Lagerbestand darf die neue Kapazität überschreiten – es wird nur nichts mehr angenommen.
        self.revision += 1
        return True, f"{rules.building_name(b.type, self.planet)} abgerissen (+{refund} €)."

    def action_rotate(self, bid, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        b.rot = (b.rot + 1) % 4
        self.revision += 1
        return True, f"{rules.building_name(b.type, self.planet)} gedreht ({C.DIR_NAMES[b.rot]})."

    def action_move(self, bid, x, y, rot, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        ok, msg = rules.check_move(b.type, (b.x, b.y), x, y, rot,
                                   occupied=lambda a, c: (a, c) in self.grid,
                                   deposit_at=lambda a, c: self.deposits.get((a, c)))
        if not ok:
            return False, msg
        del self.grid[(b.x, b.y)]
        b.x, b.y, b.rot = x, y, rot
        self.grid[(x, y)] = b.id
        self.revision += 1
        return True, f"{rules.building_name(b.type, self.planet)} verschoben."

    def action_set_enabled(self, bid, enabled, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        if not isinstance(enabled, bool):
            return False, "Ungültiger Wert."
        b.enabled = enabled
        if not enabled:
            b.status = "off"
        self.revision += 1
        name = rules.building_name(b.type, self.planet)
        return True, f"{name} {'eingeschaltet' if enabled else 'ausgeschaltet'}."

    def action_set_all_enabled(self, enabled, player="Server"):
        if not isinstance(enabled, bool):
            return False, "Ungültiger Wert."
        for b in self.buildings.values():
            b.enabled = enabled
            if not enabled:
                b.status = "off"
        self.revision += 1
        return True, f"Alle Gebäude {'eingeschaltet' if enabled else 'ausgeschaltet'}."

    def action_upgrade(self, bid, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        cost = rules.upgrade_cost(b.type, b.level)
        if cost is None:
            return False, "Maximale Ausbaustufe erreicht."
        if self.available_money() < cost:
            return False, f"Nicht genug Geld ({cost} € benötigt)."
        self.money -= cost
        b.level += 1
        self.revision += 1
        return True, f"{rules.building_name(b.type, self.planet)} auf Stufe {b.level} ausgebaut (-{cost} €)."

    def action_set_recipe(self, bid, recipe, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        if b.type not in C.MACHINE_RECIPES:
            return False, "Nur Montageanlagen und Großfabriken haben wählbare Rezepte."
        if recipe not in C.MACHINE_RECIPES[b.type] or rules.recipe_planet(recipe) != self.planet:
            return False, "Unbekanntes Rezept."
        if not rules.recipe_unlocked(recipe, self.research.unlocked):
            req = C.RESEARCH[C.RECIPES[recipe]["requires"]]["name"]
            return False, f"Rezept benötigt Forschung: {req}."
        if recipe == b.recipe:
            return True, "Rezept unverändert."
        # Eingangspuffer und laufende Produktion zurück ins Firmenlager (soweit Platz ist)
        returned = dict(b.inbuf)
        if b.active_recipe:
            for item, qty in C.RECIPES[b.active_recipe]["inputs"].items():
                returned[item] = returned.get(item, 0) + qty
        free = max(0, self.storage_capacity() - self.inventory_total())
        for item, qty in returned.items():
            moved = min(qty, free)
            self.inventory[item] += moved
            free -= moved
        b.inbuf = {}
        b.active_recipe = None
        b.progress = 0.0
        b.recipe = recipe
        self.revision += 1
        return True, f"Rezept geändert: {C.RECIPES[recipe]['name']}."

    def action_set_filter(self, bid, item, side, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        if b.type != "sorter":
            return False, "Nur Sortierer haben Filter."
        if item not in C.ITEMS:
            return False, "Unbekannte Ware."
        if side not in C.SIDE_NAMES:
            return False, "Ungültige Richtung."
        if side == "F":
            b.filters.pop(item, None)
        else:
            b.filters[item] = side
        self.revision += 1
        return True, f"Sortierer: {C.ITEMS[item]['name']} » {C.SIDE_NAMES[side]}."

    def action_set_threshold(self, bid, pct, player="Server"):
        b = self._get_building(bid)
        if b is None:
            return False, "Gebäude existiert nicht."
        if b.type != "seller":
            return False, "Nur Verkäufer haben einen Mindestpreis."
        if pct is not None and not rules.is_int(pct):
            return False, "Ungültiger Wert."
        if pct not in C.SELLER_THRESHOLDS:
            return False, "Ungültiger Mindestpreis."
        b.min_pct = pct
        self.revision += 1
        return True, f"Verkäufer verkauft {rules.threshold_label(pct).lower()}."

    def action_unlock_rocket(self, player="Server"):
        """Einmalig: Rakete für ROCKET_PRICE € freischalten (danach fliegen alle in dieser Welt kostenlos)."""
        if self.planet != "earth":
            return False, "Die Rakete wird auf der Erde freigeschaltet."
        if self.rocket_unlocked:
            return True, "Die Rakete ist schon freigeschaltet."
        if not rules.moon_open(self.moon_preview):
            return False, "Die Rakete ist noch nicht startklar."
        price = C.ROCKET_PRICE
        if self.available_money() < price:
            return False, f"Nicht genug Geld: Die Rakete kostet {rules.format_money(price)}."
        self.money -= price
        self.rocket_unlocked = True
        return True, f"Rakete freigeschaltet (-{rules.format_money(price)})! Jetzt kann jeder zum Mond fliegen."

    def action_research(self, tech_id, player="Server"):
        ok, msg = self.research.check_start(tech_id, self.available_money(), self.planet)
        if not ok:
            return False, msg
        tech = C.RESEARCH[tech_id]
        self.money -= tech["cost"]
        self.research.start(tech_id)
        return True, f"Forschung gestartet: {tech['name']} (-{tech['cost']} €)."

    def action_sell(self, item, amount, player="Server"):
        if item not in C.ITEMS:
            return False, "Unbekannte Ware."
        available = self.inventory.get(item, 0)
        if amount == "all":
            amount = available
        if not rules.is_int(amount) or amount <= 0:
            return False, "Ungültige Menge."
        if available <= 0:
            return False, f"Keine {C.ITEMS[item]['name']} im Lager."
        amount = min(amount, available)
        revenue = self.market.sell(item, amount, self.price_mult, self.time)
        self.inventory[item] -= amount
        self.money += revenue
        return True, f"{amount}x {C.ITEMS[item]['name']} verkauft (+{revenue:.0f} €)."

    def action_order_accept(self, oid, player="Server"):
        return self.freight.accept(self, oid)

    def action_order_cancel(self, cid, player="Server"):
        return self.freight.cancel(self, cid)

    def action_order_load(self, cid, player="Server"):
        return self.freight.load_from_storage(self, cid)

    def admin_give_money(self, amount):
        if not isinstance(amount, (int, float)) or isinstance(amount, bool) or not math.isfinite(amount):
            return False, "Ungültiger Betrag."
        if abs(amount) > C.ADMIN_MAX_GIVE:
            return False, f"Höchstens {rules.format_money(C.ADMIN_MAX_GIVE)} pro Buchung."
        self.money += float(amount)
        verb = "gutgeschrieben" if amount >= 0 else "abgezogen"
        return True, f"{rules.format_money(abs(amount))} {verb}."

    # ------------------------------------------------------------------ Simulation
    def tick(self, dt):
        self.time += dt
        done = self.research.tick(dt)
        if done:
            self._recompute_modifiers()
            self.revision += 1
            self.event(f"Forschung abgeschlossen: {C.RESEARCH[done]['name']}", "success")
        self.market.tick(dt, self.time, self.rng)
        if self.planet == "earth":
            self.freight.tick(self, dt, self.rng)
        for bid in sorted(self.buildings):
            b = self.buildings[bid]
            if not b.enabled:
                b.status = "off"
                continue
            TICK_FUNCTIONS[b.type](self, b, dt)
        self.energy_timer += dt
        if self.energy_timer >= C.ENERGY_INTERVAL:
            self.energy_timer -= C.ENERGY_INTERVAL
            self._bill_energy()

    # ------------------------------------------------------------------ Netzwerkdaten
    def static_snapshot(self):
        """Selten geänderte Gebäudedaten (nur bei Revisionswechsel gesendet)."""
        out = []
        for b in self.buildings.values():
            cfg = {}
            if b.type == "sorter":
                cfg["filters"] = b.filters
            elif b.type == "seller":
                cfg["min_pct"] = b.min_pct
            out.append([b.id, b.type, b.x, b.y, b.rot, b.level, b.recipe, b.owner, b.enabled, cfg])
        return out

    def dynamic_snapshot(self):
        """Laufend veränderliche Gebäudedaten."""
        out = []
        for b in self.buildings.values():
            rate = round(self.building_rate(b), 2)
            if b.type in C.BELT_LIKE:
                extra = [[it, round(pos, 3)] for it, pos in b.items]
            elif b.type == "seller":
                extra = {"q": list(b.items), "earned": round(b.earned, 1), "rpm": rate}
            elif b.type == "storage":
                extra = {"stored": b.stored}
            elif b.type == "freight":
                trucks = []
                for t in b.trucks:
                    c = self.freight._contract(t["cid"]) if t["cid"] else None
                    trucks.append([t["state"], c["item"] if c else "", c["loaded"] if c else 0,
                                   c["qty"] if c else 0, c["city"] if c else "",
                                   round(max(0.0, t["back"] - self.time)) if t["state"] == "away" else 0])
                extra = {"trucks": trucks, "store": dict(b.inbuf), "cap": C.FREIGHT_STORE.get(b.level, 60)}
            else:
                extra = {"in": b.inbuf, "out": b.outbuf, "ar": b.active_recipe, "made": b.produced, "rpm": rate}
            out.append([b.id, b.status, round(b.progress, 3), extra])
        return out

    def summary_snapshot(self):
        out = {
            "planet": self.planet,
            "money": round(self.money, 2),
            "avail": round(self.available_money(), 2),
            "inv": dict(self.inventory),
            "cap": self.storage_capacity(),
            "research": self.research.snapshot(),
            "market": self.market.snapshot(self.price_mult, self.time),
            "produced": dict(self.produced),
            "energy": round(self.energy_spent, 2),
            "energy_due": round(self.energy_due, 2),
            "energy_min": round(self.energy_per_minute(), 2),
            "energy_next": round(max(0.0, C.ENERGY_INTERVAL - self.energy_timer), 1),
            "time": round(self.time, 2),
            "freight": self.freight.snapshot(self),
            "mods": {"speed": self.speed_mult, "miner": self.miner_mult, "belt": self.belt_mult,
                     "price": self.price_mult, "cost": self.cost_mult, "storage": self.storage_mult},
        }
        if self.planet == "earth":
            out["rocket"] = self.rocket_unlocked
        return out

    def get_moon(self):
        """Mond-Spielstand dieser Welt (wird beim ersten Flug angelegt)."""
        if self.moon is None:
            self.moon = GameState(seed=self.seed + 1969, planet="moon")
        return self.moon

    def deposits_list(self):
        return [[x, y, item] for (x, y), item in self.deposits.items()]

    # ------------------------------------------------------------------ Speichern
    def to_dict(self):
        return {
            "save_version": C.SAVE_VERSION,
            "grid": [C.GRID_W, C.GRID_H],
            "game_version": C.GAME_VERSION,
            "seed": self.seed,
            "time": self.time,
            "money": self.money,
            "inventory": self.inventory,
            "next_id": self.next_id,
            "buildings": [b.to_dict() for b in self.buildings.values()],
            "research": self.research.to_dict(),
            "market": self.market.to_dict(),
            "produced": self.produced,
            "energy_spent": self.energy_spent,
            "energy_due": self.energy_due,
            "energy_timer": self.energy_timer,
            "total_built": self.total_built,
            "freight": self.freight.to_dict(),
            "planet": self.planet,
            "moon_preview": self.moon_preview,
            "rocket_unlocked": self.rocket_unlocked,
            "player_planets": self.player_planets,
            "moon": self.moon.to_dict() if self.moon is not None else None,
        }

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError("Spielstand hat ein ungültiges Format.")
        if int(data.get("save_version", 0)) > C.SAVE_VERSION:
            raise ValueError("Spielstand stammt aus einer neueren Spielversion.")
        planet = data.get("planet", "earth")
        state = cls(seed=int(data.get("seed", C.WORLD_SEED)), planet=planet)
        state.moon_preview = data.get("moon_preview") is True
        pp = data.get("player_planets")
        if isinstance(pp, dict):
            state.player_planets = {str(k)[:20]: v for k, v in pp.items() if v in C.PLANETS}
        if isinstance(data.get("moon"), dict) and state.planet == "earth":
            state.moon = cls.from_dict(data["moon"])
        if data.get("grid") != [C.GRID_W, C.GRID_H] and state.planet == "earth":
            # Spielstand von der kleineren Karte (bis Version 2.2): alte Erzfelder beibehalten
            state.deposits = generate_legacy_deposits(state.seed)
        state.time = float(data.get("time", 0.0))
        state.money = float(data.get("money", C.MOON_START_MONEY if state.planet == "moon" else C.START_MONEY))
        for item, qty in data.get("inventory", {}).items():
            if item in state.inventory:
                state.inventory[item] = max(0, int(qty))
        state.research = ResearchManager.from_dict(data.get("research", {}))
        # jede Welt hat ihren eigenen Forschungsbaum (Erde / Mond)
        state.research.unlocked = {t for t in state.research.unlocked
                                   if t in C.RESEARCH and rules.tech_planet(t) == state.planet}
        if state.research.active and (state.research.active not in C.RESEARCH
                                      or rules.tech_planet(state.research.active) != state.planet):
            state.research.active = None
        state.rocket_unlocked = data.get("rocket_unlocked") is True
        state.market = Market.from_dict(data.get("market", {}))
        for item, qty in data.get("produced", {}).items():
            if item in state.produced:
                state.produced[item] = int(qty)
        state.energy_spent = float(data.get("energy_spent", 0.0))
        state.energy_due = max(0.0, float(data.get("energy_due", 0.0)))
        state.energy_timer = float(data.get("energy_timer", 0.0)) % C.ENERGY_INTERVAL
        state.total_built = int(data.get("total_built", 0))
        state.freight = Freight.from_dict(data.get("freight", {}))
        max_id = 0
        for bd in data.get("buildings", []):
            if bd.get("type") not in C.BUILDINGS or not rules.building_on_planet(bd.get("type"), state.planet):
                continue
            b = Building.from_dict(bd)
            if not rules.in_bounds(b.x, b.y) or (b.x, b.y) in state.grid or b.id in state.buildings:
                continue
            state.buildings[b.id] = b
            state.grid[(b.x, b.y)] = b.id
            max_id = max(max_id, b.id)
        state.next_id = max(int(data.get("next_id", 1)), max_id + 1)
        state._recompute_modifiers()
        state.revision += 1
        return state
