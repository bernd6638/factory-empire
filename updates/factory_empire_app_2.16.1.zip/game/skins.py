"""
Skins: Farb-Looks für alles, was man platzieren kann (und für die Rakete).

Jeder Skin ist "<gebäude>:<stil>". Stile haben eine Seltenheit, die den Preis in Erfolgspunkten
bestimmt (1 Erfolg = 1 Punkt). Server und Client nutzen dieselben Tabellen.
"""

from . import config as C

RARITIES = [
    # id, Name, Preis (Erfolgspunkte), Farbe in der Oberfläche, Gewicht im Glücksrad
    ("rare", "Selten", 7, (0.35, 0.65, 1.0), 60),
    ("super", "Superselten", 15, (0.55, 0.4, 1.0), 25),
    ("epic", "Episch", 23, (0.95, 0.35, 0.85), 11),
    ("legendary", "Legendär", 50, (1.0, 0.72, 0.2), 4),
]
RARITY = {r[0]: {"name": r[1], "price": r[2], "color": r[3], "weight": r[4]} for r in RARITIES}

STYLES = [
    # id, Name, Seltenheit, Tönung (r, g, b) – wird mit der Grundfarbe multipliziert
    ("cherry", "Kirschrot", "rare", (1.3, 0.55, 0.5)),
    ("sky", "Himmelblau", "rare", (0.6, 0.85, 1.35)),
    ("mint", "Mintgrün", "rare", (0.6, 1.3, 0.8)),
    ("sand", "Wüstensand", "rare", (1.25, 1.08, 0.7)),
    ("carbon", "Carbon", "super", (0.42, 0.43, 0.48)),
    ("copper", "Kupfer", "super", (1.4, 0.8, 0.5)),
    ("violet", "Violett", "super", (1.05, 0.6, 1.4)),
    ("gold", "Gold", "epic", (1.55, 1.18, 0.42)),
    ("ice", "Eis", "epic", (0.8, 1.18, 1.6)),
    ("lava", "Lava", "epic", (1.7, 0.6, 0.25)),
    ("diamond", "Diamant", "legendary", (1.35, 1.65, 1.75)),
    ("midnight", "Mitternacht", "legendary", (0.38, 0.42, 0.95)),
]
STYLE = {s[0]: {"name": s[1], "rarity": s[2], "tint": s[3]} for s in STYLES}

ROCKET = "rocket"


def targets():
    """Alles, wofür es Skins gibt: jedes platzierbare Gebäude plus die Rakete."""
    return list(C.BUILDINGS) + [ROCKET]


def skin_id(target, style):
    return f"{target}:{style}"


def parse(sid):
    if not isinstance(sid, str) or ":" not in sid:
        return None, None
    target, style = sid.split(":", 1)
    if (target in C.BUILDINGS or target == ROCKET) and style in STYLE:
        return target, style
    return None, None


def valid(sid):
    return parse(sid)[0] is not None


def all_ids():
    return [skin_id(t, s[0]) for t in targets() for s in STYLES]


def price(sid):
    _, style = parse(sid)
    return RARITY[STYLE[style]["rarity"]]["price"] if style else None


def rarity(sid):
    _, style = parse(sid)
    return STYLE[style]["rarity"] if style else None


def tint(sid):
    _, style = parse(sid)
    return STYLE[style]["tint"] if style else None


def target_name(target, planet="earth"):
    if target == ROCKET:
        return "Rakete"
    from . import rules
    return rules.building_name(target, planet)


def display_name(sid, planet="earth"):
    target, style = parse(sid)
    if not target:
        return "?"
    return f"{target_name(target, planet)} „{STYLE[style]['name']}“"


# ----------------------------------------------------------------------------- Glücksrad
WHEEL = [
    # Art, Wert, Beschriftung
    ("money", 2_500, "2.500"),
    ("skin", "rare", "Skin"),
    ("money", 10_000, "10.000"),
    ("skin", "super", "Skin+"),
    ("money", 5_000, "5.000"),
    ("skin", "rare", "Skin"),
    ("money", 25_000, "25.000"),
    ("skin", "epic", "Skin!"),
]
WHEEL_WEIGHTS = [16, 15, 11, 8, 15, 15, 6, 4]
