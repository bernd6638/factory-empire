"""
Bündelung der Gebäudegrafik für große Fabriken.

Problem: Jedes Gebäude besteht aus mehreren Einzelteilen (Grundkörper, Band, Pfeile, Lampe ...).
Bei hunderten Gebäuden sind das tausende Zeichenaufrufe pro Bild (mit Schatten doppelt so viele) –
das bremst jede Grafikkarte, egal wie schnell.

Lösung: Die Karte ist in Abschnitte (CHUNK × CHUNK Felder) geteilt. Für jeden Abschnitt werden die
unbeweglichen Teile aller fertig gebauten Gebäude zu wenigen großen Modellen zusammengefasst
(Panda3D flattenStrong). Bewegliche Teile (Rotoren, Greifarme, Waren, Lampen) bleiben einzeln, werden
aber nur in Kameranähe gezeigt und animiert. Für entfernte Abschnitte gibt es ein zweites,
vollständiges Bündel (inklusive beweglicher Teile in Ruhestellung) – dort fällt pro Gebäude kein
einziger Einzelaufruf mehr an.

Gebäude, die sich gerade ändern (neu gebaut, gedreht, versetzt, ausgebaut ...), werden kurz aus dem
Bündel genommen und einzeln gezeigt; sobald sie zur Ruhe gekommen sind, wird ihr Abschnitt neu gebündelt.
"""

import math
import time

from panda3d.core import (BoundingSphere, Geom, GeomNode, GeomTriangles, GeomVertexData, GeomVertexFormat,
                          GeomVertexWriter, NodePath, Point3, RigidBodyCombiner, TextureStage, TransparencyAttrib)
from ursina import Entity, Vec2, load_texture

from . import config as C
from . import graphics
from . import textures

CHUNK = 10
SETTLE_TIME = 0.7          # so lange muss ein Gebäude unverändert sein, bevor es gebündelt wird
MAX_REBUILDS_PER_FRAME = 2


def _holder(shader, tex=None, builtin_tex=None):
    e = Entity(add_to_scene_entities=False, shader=shader)
    t = textures.texture(tex) if tex else (load_texture(builtin_tex) if builtin_tex else None)
    if t is not None:
        e.setTexture(t._texture, 1)
    return e


class Chunk:
    __slots__ = ("key", "views", "near_nodes", "far_nodes", "shadow_node", "dirty_at", "is_far", "center",
                 "lamp_node", "lamp_index", "lamp_vdata", "items_np", "items_dirty", "items_t", "item_park")

    def __init__(self, key):
        self.key = key
        self.views = set()
        self.near_nodes = []
        self.far_nodes = []
        self.shadow_node = None
        self.lamp_node = None
        self.lamp_index = {}
        self.lamp_vdata = None
        self.items_np = None          # Waren auf Bändern: ein RigidBodyCombiner je Abschnitt
        self.items_dirty = False
        self.items_t = 0.0
        self.item_park = {}           # geparkte Waren je Sorte (unter dem Boden, kein Neu-Bündeln nötig)
        self.dirty_at = 0.0           # 0 = aktuell, sonst Zeitpunkt der letzten Änderung
        self.is_far = False
        cx, cz = key
        self.center = Point3((cx + 0.5) * CHUNK - 0.5, 0.5, (cz + 0.5) * CHUNK - 0.5)


class Batcher:
    def __init__(self):
        lit = graphics.lit_shader()
        unlit = graphics.unlit()
        self.bodies = _holder(lit, "metal")
        self.belts = _holder(lit, "belt")
        self.arrows = _holder(unlit, builtin_tex="arrow_right")
        self.arrows.setTransparency(TransparencyAttrib.M_alpha)
        self.arrows.setDepthWrite(False)
        self.far = _holder(lit, "metal")
        self.far_belts = _holder(lit, "belt")
        self.shadows = _holder(unlit, "blob")
        self.shadows.setTransparency(TransparencyAttrib.M_alpha)
        self.shadows.setDepthWrite(False)
        self.shadows.setLightOff()
        self.shadows.setBin("transparent", 0)
        self.lamps = Entity(add_to_scene_entities=False, shader=unlit)
        self.lamps.setLightOff()
        self.items = _holder(lit, "metal")
        self.chunks = {}
        self.offset = 0.0
        self._blob = None

    # ------------------------------------------------------------------ Verwaltung
    @staticmethod
    def key_for(x, y):
        return (int(x) // CHUNK, int(y) // CHUNK)

    def add(self, view):
        ch = self.chunks.get(self.key_for(view.x, view.y))
        if ch is None:
            ch = self.chunks[self.key_for(view.x, view.y)] = Chunk(self.key_for(view.x, view.y))
        ch.views.add(view)
        view.chunk = ch
        view.touch()
        ch.dirty_at = time.time()

    def remove(self, view):
        """Gebäude weg: Abschnitt sofort ohne es neu bündeln (sonst bliebe es sichtbar)."""
        ch = getattr(view, "chunk", None)
        if ch is None:
            return
        view.clear_items()
        ch.views.discard(view)
        view.chunk = None
        if view.batched:
            self._rebuild(ch)
        if ch.views:
            ch.dirty_at = ch.dirty_at or time.time()

    def changed(self, view):
        """Gebäude ändert sich gerade: aus dem Bündel nehmen, einzeln zeigen, später neu bündeln."""
        ch = getattr(view, "chunk", None)
        new_key = self.key_for(view.x, view.y)
        if ch is not None and ch.key != new_key:               # versetzt in anderen Abschnitt
            view.clear_items()
            self.remove(view)
            self.add(view)
            return
        if ch is None:
            self.add(view)
            return
        view.touch()
        if view.batched:
            self._rebuild(ch)
        ch.dirty_at = time.time()

    def clear(self):
        for ch in self.chunks.values():
            self._drop_nodes(ch)
            if ch.items_np is not None:
                ch.items_np.removeNode()
            ch.item_park = {}
        self.chunks = {}

    # ------------------------------------------------------------------ Waren auf Bändern
    # Alle Waren eines Abschnitts hängen an einem RigidBodyCombiner: Panda3D fasst sie zu einem
    # Modell zusammen und bewegt die einzelnen Waren trotzdem frei. Statt hunderter Zeichenaufrufe
    # gibt es je Abschnitt nur noch einen – deshalb sind Waren jetzt auch aus der Ferne sichtbar.
    def items_node(self, ch):
        if ch.items_np is None:
            ch.items_np = NodePath(RigidBodyCombiner("items"))
            ch.items_np.reparentTo(self.items)
        return ch.items_np

    def mark_items(self, ch):
        ch.items_dirty = True

    def take_item(self, ch, item, factory):
        """Ware für ein Band in diesem Abschnitt. Wiederverwendet geparkte Waren derselben Sorte,
        damit der Abschnitt nur selten neu zusammengefasst werden muss (das kostet Zeit)."""
        park = ch.item_park.get(item)
        if park:
            return park.pop()
        np = factory(self.items_node(ch), item)
        np.setPos(ch.center.x, -4.0, ch.center.z)      # erst unsichtbar, bis das Band sie platziert
        ch.items_dirty = True
        return np

    PARK_MAX = 12                                  # geparkte Waren je Sorte und Abschnitt (Rest wird gelöscht)

    def park_item(self, ch, np, item):
        park = ch.item_park.setdefault(item, [])
        if len(park) >= self.PARK_MAX:             # zu viele unsichtbare Waren kosten Grafikleistung
            np.removeNode()
            ch.items_dirty = True
            return
        np.setPos(ch.center.x, -4.0, ch.center.z)                   # unter dem Boden: unsichtbar, bleibt im Bündel
        park.append(np)

    def _collect_items(self, now):
        best = None
        for ch in self.chunks.values():
            if ch.items_dirty and ch.items_np is not None and now - ch.items_t > 0.15:
                if best is None or ch.items_t < best.items_t:
                    best = ch
        if best is not None:                       # höchstens ein Abschnitt pro Bild
            best.items_dirty = False
            best.items_t = now
            best.items_np.node().collect()

    # ------------------------------------------------------------------ pro Frame
    def update(self, dt, focus, detail_radius, belt_speed):
        """focus: (x, z) Blickpunkt der Kamera; detail_radius: bis zu dieser Entfernung (waagerecht,
        Abschnittsrand) werden Gebäude einzeln mit allen beweglichen Teilen gezeigt."""
        # Bänder in allen Bündeln laufen gemeinsam (wie in bekannten Fabrikspielen)
        self.offset = (self.offset - belt_speed * dt) % 1.0
        self.belts.setTexOffset(TextureStage.getDefault(), 0, self.offset)
        self.belts.set_shader_input("texture_offset", Vec2(0, self.offset))
        self.arrows.setTexOffset(TextureStage.getDefault(), self.offset, 0)
        self.arrows.set_shader_input("texture_offset", Vec2(self.offset, 0))

        now = time.time()
        self._collect_items(now)
        rebuilt = 0
        fx, fz = focus
        for ch in self.chunks.values():
            d = math.hypot(ch.center.x - fx, ch.center.z - fz) - CHUNK * 0.71
            far = d > detail_radius
            if far != ch.is_far:
                ch.is_far = far
                self._apply_lod(ch)
            if ch.dirty_at and rebuilt < MAX_REBUILDS_PER_FRAME and now - ch.dirty_at > SETTLE_TIME:
                if all(now - v.changed_at > SETTLE_TIME for v in ch.views):
                    self._rebuild(ch)
                    rebuilt += 1

    def near_views(self):
        for ch in self.chunks.values():
            if not ch.is_far:
                yield from ch.views

    def far_belt_views(self):
        for ch in self.chunks.values():
            if ch.is_far:
                for v in ch.views:
                    if v.items:
                        yield v

    # ------------------------------------------------------------------ Aufbau
    def _drop_nodes(self, ch):
        for n in ch.near_nodes + ch.far_nodes:
            n.removeNode()
        ch.near_nodes = []
        ch.far_nodes = []
        for n in (ch.shadow_node, ch.lamp_node):
            if n is not None:
                n.removeNode()
        ch.shadow_node = ch.lamp_node = None
        ch.lamp_index = {}
        ch.lamp_vdata = None

    def _blob_mesh(self):
        if self._blob is None:
            from ursina import Mesh, Vec3
            s = 0.68
            self._blob = Mesh(vertices=[Vec3(-s, 0.012, -s), Vec3(s, 0.012, -s), Vec3(s, 0.012, s), Vec3(-s, 0.012, s)],
                              triangles=[(0, 2, 1), (0, 3, 2)], uvs=[Vec2(0, 0), Vec2(1, 0), Vec2(1, 1), Vec2(0, 1)],
                              colors=[(1, 1, 1, 1)] * 4)
        return self._blob

    def _rebuild(self, ch):
        """Fasst alle ruhenden Gebäude des Abschnitts zusammen."""
        self._drop_nodes(ch)
        ch.dirty_at = 0.0
        now = time.time()
        body = self.bodies.attachNewNode("b")
        belt = self.belts.attachNewNode("bl")
        arrow = self.arrows.attachNewNode("ar")
        far = self.far.attachNewNode("f")
        far_belt = self.far_belts.attachNewNode("fb")
        shadow = self.shadows.attachNewNode("s")
        included = []
        for v in ch.views:
            if now - v.changed_at <= SETTLE_TIME or v.spawn_t < 1.0:
                ch.dirty_at = ch.dirty_at or now          # später nochmal versuchen
                v.set_batched(False)
                continue
            mat = v.root.getMat()
            # Grundkörper (inkl. Abschalt-Tönung)
            for target in (body, far):
                cp = v.body_mesh().copyTo(target)
                cp.setMat(mat)
                tint = v.color_tint()
                if tint != (1, 1, 1, 1):
                    cp.setColorScale(*tint)
            # Kontaktschatten
            if v.type not in C.BELT_LIKE:
                cp = self._blob_mesh().copyTo(shadow)
                cp.setMat(mat)
            # Band und Pfeile
            p = v.parts
            if "belt" in p:
                for part, targets in ((p["belt"], (belt, far_belt)), (p["arrows"], (arrow,))):
                    if part.model:
                        for target in targets:
                            cp = part.model.copyTo(target)
                            cp.setMat(part.model.getMat(v.root.getParent()))
            # bewegliche Teile in Ruhestellung nur im Fern-Bündel
            for part in v.mesh_parts():
                cp = part.mesh_src.copyTo(far)
                cp.setMat(part.getMat(v.root.getParent()))
                if tint != (1, 1, 1, 1):
                    cp.setColorScale(*tint)
            included.append(v)
        for n in (body, belt, arrow, far, far_belt, shadow):
            n.flattenStrong()
        ch.near_nodes = [body, belt, arrow]
        ch.far_nodes = [far, far_belt]
        ch.shadow_node = shadow
        self._build_lamps(ch, included)
        for v in ch.views:
            v.set_batched(v in included)
        self._apply_lod(ch)

    # ------------------------------------------------------------------ Statuslampen
    # Alle Lampen eines Abschnitts sind EIN Modell; ändert sich ein Status, werden nur die
    # Farben der 6 Ecken dieser einen Lampe überschrieben.
    _OCTA = [(0, 1, 0), (0, -1, 0), (1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1)]
    _OCTA_TRIS = [(0, 4, 2), (0, 2, 5), (0, 5, 3), (0, 3, 4), (1, 2, 4), (1, 5, 2), (1, 3, 5), (1, 4, 3)]

    def _build_lamps(self, ch, views):
        views = [v for v in views if v.lamp is not None]
        if not views:
            return
        vdata = GeomVertexData("lamps", GeomVertexFormat.getV3c4(), Geom.UHStatic)
        vdata.setNumRows(len(views) * 6)
        vw = GeomVertexWriter(vdata, "vertex")
        cw = GeomVertexWriter(vdata, "color")
        tris = GeomTriangles(Geom.UHStatic)
        parent = views[0].root.getParent()
        r = 0.075
        for i, v in enumerate(views):
            c = v.lamp_rgba()
            center = v.lamp.getPos(parent)
            for (x, y, z) in self._OCTA:
                vw.addData3(center.x + x * r, center.y + y * r * 1.2, center.z + z * r)
                cw.addData4(*c)
            o = i * 6
            for a, b, d in self._OCTA_TRIS:
                tris.addVertices(o + a, o + b, o + d)
            ch.lamp_index[v] = o
        geom = Geom(vdata)
        geom.addPrimitive(tris)
        node = GeomNode("lamps")
        node.addGeom(geom)
        ch.lamp_node = self.lamps.attachNewNode(node)
        ch.lamp_vdata = node.modifyGeom(0).modifyVertexData()

    def set_lamp(self, view, rgba):
        ch = getattr(view, "chunk", None)
        if ch is None or view not in ch.lamp_index or ch.lamp_node is None:
            return
        cw = GeomVertexWriter(ch.lamp_vdata, "color")
        cw.setRow(ch.lamp_index[view])
        for _ in range(6):
            cw.setData4(*rgba)

    def _apply_lod(self, ch):
        for n in ch.near_nodes:
            n.hide() if ch.is_far else n.show()
        for n in ch.far_nodes:
            n.show() if ch.is_far else n.hide()
        for v in ch.views:
            v.set_far(ch.is_far)


def visible_test():
    """Liefert eine Funktion (x, z, radius) -> bool: liegt der Punkt im Sichtbereich der Kamera?"""
    from ursina import application, camera
    cam = application.base.cam
    lens_bounds = camera.lens.makeBounds()
    mat = application.base.render.getMat(cam)

    def test(x, z, r=1.8, y=0.5):
        p = mat.xformPoint(Point3(x, y, z))
        return lens_bounds.contains(BoundingSphere(p, r)) != 0
    return test


def distance(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)
