"""
Gemeinsame Spielregeln.

Diese Funktionen werden sowohl vom Server (verbindliche Prüfung) als auch vom
Client (Vorschau beim Platzieren und Anzeige) verwendet. Dadurch zeigt die
Vorschau exakt dieselben Fehlermeldungen und Werte, die der Server später
liefern würde. Das Modul hat keine Abhängigkeit zu Ursina oder zum Netzwerk.
"""

from . import config as C


def in_bounds(x, y):
    return 0 <= x < C.GRID_W and 0 <= y < C.GRID_H


def front_tile(x, y, rot):
    dx, dy = C.DIRS[rot % 4]
    return x + dx, y + dy


def back_tile(x, y, rot):
    dx, dy = C.DIRS[rot % 4]
    return x - dx, y - dy


def side_rot(rot, side):
    """Weltrichtung eines relativen Ausgangs: F = vorne, L = links, R = rechts."""
    return {"F": rot, "L": (rot + 3) % 4, "R": (rot + 1) % 4}[side] % 4


def side_tile(x, y, rot, side):
    return front_tile(x, y, side_rot(rot, side))


def feeds_into(btype, x, y, rot, target):
    """Gibt das Gebäude (Typ, Position, Drehung) etwas auf das Feld `target` aus?"""
    target = tuple(target)
    if btype in C.ROUTER_TYPES:
        return any(side_tile(x, y, rot, s) == target for s in C.BUILDINGS[btype].get("outputs", []))
    if btype in ("storage", "seller", "freight"):
        return False
    return front_tile(x, y, rot) == target


def curve_side(x, y, rot, get):
    """Förderband-Kurve: Kommt der einzige Zulauf von links oder rechts (von einem Band, dessen
    Ausgang hierher zeigt) und von hinten nichts, ist das Band eine Kurve: "L" oder "R", sonst None.
    get(x, y) -> (typ, drehung) oder None."""
    bx, by = back_tile(x, y, rot)
    back = get(bx, by)
    if back is not None and feeds_into(back[0], bx, by, back[1], (x, y)):
        return None
    found = side_feeds(x, y, rot, get)
    return found[0] if len(found) == 1 else None


def side_feeds(x, y, rot, get):
    """Seiten ("L"/"R"), von denen ein Nachbar (Band, Splitter, T-Stück, Sortierer, Maschine) hier einspeist."""
    found = []
    for side in ("L", "R"):
        sx, sy = side_tile(x, y, rot, side)
        nb = get(sx, sy)
        if nb is not None and feeds_into(nb[0], sx, sy, nb[1], (x, y)):
            found.append(side)
    return found


def join_side(x, y, rot, get):
    """T-Stück-Optik: Band läuft geradeaus (Zulauf von hinten) und genau eine Seite speist zusätzlich ein."""
    bx, by = back_tile(x, y, rot)
    back = get(bx, by)
    if back is None or not feeds_into(back[0], bx, by, back[1], (x, y)):
        return None
    found = side_feeds(x, y, rot, get)
    return found[0] if len(found) == 1 else None


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def building_requires(btype, planet="earth"):
    """Forschung, die ein Gebäude auf diesem Planeten braucht (None = von Anfang an)."""
    if planet == "moon" and btype in C.MOON_BUILDING_INFO:
        return C.MOON_BUILDING_INFO[btype][1]
    return C.EARTH_BUILDING_INFO[btype][1] if btype in C.EARTH_BUILDING_INFO else C.BUILDINGS[btype]["requires"]


def building_name(btype, planet="earth"):
    if planet == "moon" and btype in C.MOON_BUILDING_INFO:
        return C.MOON_BUILDING_INFO[btype][0]
    return C.EARTH_BUILDING_INFO[btype][0]


def apply_planet_texts(planet):
    """Nur im Client: Namen, Beschreibungen und Forschungs-Voraussetzungen der Gebäude auf den
    aktuellen Planeten umstellen (auf dem Mond heißen sie anders, können aber dasselbe)."""
    for btype, spec in C.BUILDINGS.items():
        info = C.MOON_BUILDING_INFO.get(btype) if planet == "moon" else None
        name, req, desc = info if info else C.EARTH_BUILDING_INFO[btype]
        spec["name"], spec["requires"], spec["desc"] = name, req, desc


def building_unlocked(btype, unlocked, planet="earth"):
    req = building_requires(btype, planet)
    return req is None or req in unlocked


def tech_planet(tech_id):
    return C.RESEARCH[tech_id].get("planet", "earth")


def research_ids(planet="earth"):
    return [t for t in C.RESEARCH if tech_planet(t) == planet]


def research_tabs(planet="earth"):
    return [(k, n) for k, n in C.RESEARCH_TABS if C.RESEARCH_TAB_PLANET.get(k, "earth") == planet]


# ----------------------------------------------------------------------------- Planeten (Erde / Mond)
def recipe_planet(recipe_id):
    return C.RECIPES[recipe_id].get("planet", "earth")


def machine_recipes(btype, planet="earth"):
    """Wählbare Rezepte einer Maschine auf diesem Planeten (in Anzeigereihenfolge)."""
    return [r for r in C.MACHINE_RECIPES.get(btype, ()) if recipe_planet(r) == planet]


def smelter_recipes(planet="earth"):
    return [rid for rid, r in C.RECIPES.items() if r["machine"] == "smelter" and r.get("planet", "earth") == planet]


def item_order(planet="earth"):
    return C.MOON_ITEM_ORDER if planet == "moon" else C.ITEM_ORDER


def deposit_items(planet="earth"):
    return C.MOON_DEPOSIT_ITEMS if planet == "moon" else C.DEPOSIT_ITEMS


def building_on_planet(btype, planet="earth"):
    return planet != "moon" or btype in C.MOON_BUILDINGS


def building_order(planet="earth"):
    return [b for b in C.BUILDING_ORDER if building_on_planet(b, planet)]


def currency(planet="earth"):
    return C.CURRENCY.get(planet, "€")


def moon_open(preview=False, now=None):
    """Ist der Flug zum Mond freigegeben? Nach Ablauf des Countdowns für alle, vorher nur in der Test-Welt."""
    import time as _t
    return bool(preview) or (now if now is not None else _t.time()) >= C.COUNTDOWN_TARGET


def check_test_code(code):
    import hashlib
    code = "".join(str(code).split()).upper()
    return hashlib.sha256(code.encode()).hexdigest() == C.TEST_WORLD_CODE_SHA


def recipe_unlocked(recipe_id, unlocked):
    req = C.RECIPES[recipe_id]["requires"]
    return req is None or req in unlocked


def upgrade_cost(btype, level):
    """Kosten für das Upgrade von `level` auf `level + 1` (None = nicht möglich)."""
    spec = C.BUILDINGS[btype]
    if level >= spec["max_level"]:
        return None
    return int(round(spec["cost"] * C.UPGRADE_COST_FACTOR * level))


def demolish_refund(btype, level):
    spec = C.BUILDINGS[btype]
    total = spec["cost"]
    for lvl in range(1, level):
        total += upgrade_cost(btype, lvl) or 0
    return int(total * C.DEMOLISH_REFUND)


def _check_tile(btype, x, y, rot, occupied, deposit_at):
    if btype not in C.BUILDINGS:
        return False, "Unbekannter Gebäudetyp."
    if not (is_int(x) and is_int(y) and is_int(rot)):
        return False, "Ungültige Koordinaten."
    if rot not in (0, 1, 2, 3):
        return False, "Ungültige Ausrichtung."
    if not in_bounds(x, y):
        return False, "Außerhalb der Baufläche."
    if occupied(x, y):
        return False, "Feld ist bereits belegt."
    if btype == "miner" and deposit_at(x, y) is None:
        return False, "Miner nur auf Erzvorkommen platzierbar."
    return True, "OK"


def check_build(btype, x, y, rot, *, occupied, deposit_at, unlocked, money, planet="earth"):
    """Prüft, ob ein Gebäude gebaut werden darf.

    occupied(x, y)   -> bool    ist die Kachel belegt?
    deposit_at(x, y) -> str|None  Erzvorkommen auf der Kachel
    Rückgabe: (ok: bool, grund: str)
    """
    if btype not in C.BUILDINGS:
        return False, "Unbekannter Gebäudetyp."
    spec = C.BUILDINGS[btype]
    if not building_on_planet(btype, planet):
        return False, f"{building_name(btype, 'earth')} gibt es auf dem Mond nicht."
    if not building_unlocked(btype, unlocked, planet):
        req = C.RESEARCH[building_requires(btype, planet)]["name"]
        return False, f"{building_name(btype, planet)} benötigt Forschung: {req}."
    ok, msg = _check_tile(btype, x, y, rot, occupied, deposit_at)
    if not ok:
        return ok, msg
    if money < spec["cost"]:
        return False, f"Nicht genug Geld ({spec['cost']} € benötigt)."
    return True, "OK"


def check_move(btype, from_xy, x, y, rot, *, occupied, deposit_at):
    """Prüft das Verschieben eines Gebäudes. Das eigene Feld zählt als frei."""
    return _check_tile(btype, x, y, rot, lambda a, b: (a, b) != tuple(from_xy) and occupied(a, b), deposit_at)


# ----------------------------------------------------------------------------- Forschungseffekte
def _effect_product(unlocked, key):
    value = 1.0
    for tid in unlocked:
        tech = C.RESEARCH.get(tid)
        if tech and key in tech["effects"]:
            value *= tech["effects"][key]
    return value


def speed_multiplier(unlocked):
    return _effect_product(unlocked, "speed_mult")


def miner_multiplier(unlocked):
    return _effect_product(unlocked, "miner_mult")


def storage_multiplier(unlocked):
    return _effect_product(unlocked, "storage_mult")


def travel_multiplier(unlocked):
    return _effect_product(unlocked, "travel_mult")


def belt_multiplier(unlocked):
    return _effect_product(unlocked, "belt_mult")


def price_multiplier(unlocked):
    return _effect_product(unlocked, "price_mult")


def cost_multiplier(unlocked):
    return _effect_product(unlocked, "cost_mult")


def check_research(tech_id, unlocked, active, money, planet="earth"):
    if tech_id not in C.RESEARCH:
        return False, "Unbekannte Technologie."
    tech = C.RESEARCH[tech_id]
    if tech_planet(tech_id) != planet:
        return False, ("Diese Forschung gibt es nur auf dem Mond." if planet == "earth"
                       else "Diese Forschung gibt es nur auf der Erde.")
    if tech_id in unlocked:
        return False, f"{tech['name']} ist bereits erforscht."
    if active:
        return False, "Es läuft bereits eine Forschung."
    missing = [C.RESEARCH[r]["name"] for r in tech["requires"] if r not in unlocked]
    if missing:
        return False, "Voraussetzung fehlt: " + ", ".join(missing)
    if money < tech["cost"]:
        return False, f"Nicht genug Geld ({tech['cost']} € benötigt)."
    return True, "OK"


# ----------------------------------------------------------------------------- Produktionsraten
def machine_speed(btype, level, speed_mult=1.0, miner_mult=1.0):
    speed = C.LEVEL_SPEED.get(level, 1.0) * speed_mult
    if btype == "miner":
        speed *= miner_mult
    return speed


def recipe_rate(recipe_id, speed):
    """Ausgaben pro Minute eines Rezepts bei gegebener Geschwindigkeit: {item: menge}."""
    r = C.RECIPES[recipe_id]
    runs = 60.0 / r["time"] * speed
    return {item: qty * runs for item, qty in r["outputs"].items()}


def recipe_energy_per_min(recipe_id, speed, cost_mult=1.0):
    r = C.RECIPES[recipe_id]
    return 60.0 / r["time"] * speed * r["cost"] * cost_mult


def theoretical_rates(btype, level, *, recipe=None, ore=None, speed_mult=1.0, miner_mult=1.0, planet="earth"):
    """Höchstleistung pro Minute eines Gebäudes auf einer Stufe.

    Rückgabe: Liste von (beschriftung, wert_pro_minute).
    """
    speed = machine_speed(btype, level, speed_mult, miner_mult)
    spec = C.BUILDINGS[btype]
    if btype == "miner":
        name = C.ITEMS[ore]["name"] if ore in C.ITEMS else "Erz"
        return [(name, 60.0 / spec["time"] * speed)]
    if btype == "smelter":
        out = []
        for rid in smelter_recipes(planet):
            for item, rate in recipe_rate(rid, speed).items():
                label = C.ITEMS[item]["name"]
                out.append((label, rate))
        return out
    if btype in C.MACHINE_RECIPES and recipe in C.RECIPES:
        return [(C.ITEMS[i]["name"], v) for i, v in recipe_rate(recipe, speed).items()]
    if btype == "seller":
        return [("Verkäufe", 60.0 / spec["time"] * speed)]
    return []


# ----------------------------------------------------------------------------- Verkäufer
def threshold_label(pct):
    if pct is None:
        return "Immer"
    return f"ab {pct:+d} %"


def price_ok(current_price, base_price, pct):
    """Darf der Verkäufer zum aktuellen Preis verkaufen?"""
    if pct is None:
        return True
    return current_price >= base_price * (1.0 + pct / 100.0) - 1e-9


def format_money(value):
    """Formatiert Geldbeträge im deutschen Stil: 12.345 €"""
    sign = "-" if value < 0 else ""
    return sign + f"{abs(int(value)):,}".replace(",", ".") + " €"


def format_rate(value):
    if value >= 100:
        return f"{value:.0f}"
    if value >= 10:
        return f"{value:.1f}".replace(".", ",")
    return f"{value:.2f}".replace(".", ",")


def format_duration(seconds):
    """12 s · 4:05 min · 1:02 h"""
    seconds = max(0, int(round(seconds)))
    if seconds < 60:
        return f"{seconds} s"
    if seconds < 3600:
        return f"{seconds // 60}:{seconds % 60:02d} min"
    return f"{seconds // 3600}:{seconds % 3600 // 60:02d} h"


# ----------------------------------------------------------------------------- Tastenbelegung
def keymap(custom=None):
    """Aktion -> Taste (Standard plus eigene Belegung aus den Einstellungen)."""
    keys = dict(C.DEFAULT_KEYS)
    for action, key in (custom or {}).items():
        if action in keys and isinstance(key, str) and key and key not in C.RESERVED_KEYS:
            keys[action] = key
    return keys


def rebind(custom, action, key):
    """Neue Taste für eine Aktion. Ist die Taste schon vergeben, bekommt die andere Aktion die alte Taste
    (Tausch). Gibt die neue eigene Belegung zurück (nur Abweichungen vom Standard)."""
    if action not in C.DEFAULT_KEYS or not key or key in C.RESERVED_KEYS:
        return dict(custom or {})
    keys = keymap(custom)
    old = keys[action]
    for other, k in keys.items():
        if k == key and other != action:
            keys[other] = old
    keys[action] = key
    return {a: k for a, k in keys.items() if C.DEFAULT_KEYS[a] != k}


def key_label(key):
    names = {"space": "Leertaste", "tab": "Tab"}
    if key in names:
        return names[key]
    return key.upper() if len(key) <= 3 else key.replace(" arrow", "").capitalize()

