"""
Start über eine heruntergeladene Spielversion (automatische Updates).

Updates werden nicht in den Programmordner geschrieben (der ist auf dem Mac oft schreibgeschützt),
sondern in den Spielstand-Ordner: <saves>/update/app. Beim Start prüfen main.py und server.py hier,
ob dort eine NEUERE Version liegt – wenn ja, wird diese gestartet. Klappt das nicht (z. B. Datei
beschädigt), startet einfach die mitgelieferte Version.
"""

import os
import re
import runpy
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _version_of(app_dir):
    try:
        with open(os.path.join(app_dir, "game", "config.py"), encoding="utf-8") as f:
            m = re.search(r'^GAME_VERSION\s*=\s*"([\d.]+)"', f.read(), re.M)
        return tuple(int(p) for p in m.group(1).split(".")) if m else None
    except (OSError, ValueError):
        return None


def data_dir():
    env = os.environ.get("FACTORY_EMPIRE_DATA") or "saves"
    return os.path.abspath(os.path.join(HERE, env))


def overlay_dir():
    """Neueste heruntergeladene Version: <saves>/update/app-<version> (None = keine)."""
    root = os.path.join(data_dir(), "update")
    best, best_v = None, None
    try:
        names = os.listdir(root)
    except OSError:
        return None
    for name in names:
        path = os.path.join(root, name)
        if not name.startswith("app-") or os.path.exists(os.path.join(path, "BROKEN")):
            continue
        v = _version_of(path)
        if v and (best_v is None or v > best_v):
            best, best_v = path, v
    return best


def run_newer(script):
    """script: "main.py" oder "server.py". Kehrt nur zurück, wenn keine neuere Version vorliegt."""
    if os.environ.get("FE_OVERLAY") or os.environ.get("FE_NO_UPDATE"):
        return
    app = overlay_dir()
    if app is None:
        return
    target = os.path.join(app, script)
    if not os.path.exists(target):
        return
    mine, theirs = _version_of(HERE), _version_of(app)
    if not theirs or not mine or theirs <= mine:
        return
    os.environ["FE_OVERLAY"] = "1"
    os.environ["FE_BASE_DIR"] = HERE                      # für den Neustart nach einem Update
    os.environ["FACTORY_EMPIRE_DATA"] = data_dir()        # Spielstände bleiben, wo sie sind
    sys.path.insert(0, app)
    sys.argv[0] = target
    try:
        os.chdir(app)
        runpy.run_path(target, run_name="__main__")
    except SystemExit:
        raise
    except BaseException as exc:                          # neue Version kaputt: mitgelieferte nutzen
        import traceback
        traceback.print_exc()
        print(f"[Update] Version im Update-Ordner startet nicht ({exc!r}) – nutze mitgelieferte Version.")
        try:
            with open(os.path.join(app, "BROKEN"), "w") as f:
                f.write(repr(exc))
        except OSError:
            pass
        os.environ.pop("FE_OVERLAY", None)
        sys.path.remove(app)
        os.chdir(HERE)
        for name in [m for m in sys.modules if m == "game" or m.startswith("game.")]:
            del sys.modules[name]
        return
    sys.exit(0)
