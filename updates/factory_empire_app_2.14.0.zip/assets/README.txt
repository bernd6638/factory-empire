Factory Empire benötigt keine externen Grafik- oder Audiodateien.

Alle 3D-Modelle werden beim Start prozedural aus Grundkörpern erzeugt (game/models.py),
alle Soundeffekte werden mit Pygame prozedural synthetisiert (game/audio.py).
Die Himmelstextur und die Pfeiltextur der Förderbänder stammen aus dem Ursina-Paket.

Dieser Ordner ist für eigene Erweiterungen gedacht (z. B. Texturen oder Modelle).
