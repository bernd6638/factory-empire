"""
Netzwerk-Client.

Läuft in einem Hintergrund-Thread, damit das Spiel nie auf das Netzwerk
wartet. Empfangene Nachrichten landen in einer Warteschlange, die der
Spielclient einmal pro Frame abarbeitet (`poll()`).
Unabhängig von Ursina – wird auch von den automatischen Tests genutzt.
"""

import queue
import socket
import threading
import time

from . import config as C
from . import protocol


class ConnectionFailed(Exception):
    """Verständliche Fehlermeldung für den Spieler."""


def describe_socket_error(exc, host, port):
    if isinstance(exc, ConnectionRefusedError):
        return (f"Verbindung zu {host}:{port} abgelehnt. Läuft der Server? "
                f"Stimmt der Port ({port})?")
    if isinstance(exc, socket.timeout):
        return (f"Zeitüberschreitung bei {host}:{port}. Prüfe die IP-Adresse, die Portfreigabe für TCP {port} "
                f"im Router des Hosts und ob dessen Firewall Python/Port {port} erlaubt.")
    if isinstance(exc, socket.gaierror):
        return f"Adresse '{host}' wurde nicht gefunden. Bitte IP-Adresse prüfen (z. B. 192.168.1.20)."
    if isinstance(exc, OSError) and getattr(exc, "errno", None) in (51, 65, 101, 113, 10051, 10065):
        return f"Netzwerk/Host {host} nicht erreichbar. Bist du mit dem richtigen WLAN/LAN verbunden?"
    return f"Verbindungsfehler: {exc}"


def split_host_port(host, port):
    """Erlaubt Eingaben wie '87.1.2.3:5555', 'name.duckdns.org:6000' oder '[2a02::1]:5555'.
    Entfernt außerdem versehentlich eingefügte 'http://' und Leerzeichen."""
    host = (host or "").strip()
    for prefix in ("http://", "https://", "tcp://"):
        if host.lower().startswith(prefix):
            host = host[len(prefix):]
    host = host.rstrip("/")
    if host.startswith("[") and "]" in host:                 # [IPv6]:port
        inner, _, rest = host[1:].partition("]")
        host = inner
        if rest.startswith(":") and rest[1:].isdigit():
            port = rest[1:]
    elif host.count(":") == 1:                                 # IPv4/Name:port
        h, p = host.split(":")
        if p.isdigit():
            host, port = h, p
    return host or C.DEFAULT_HOST, port


class NetworkClient:
    def __init__(self):
        self.sock = None
        self.inbox = queue.Queue()
        self.connected = False
        self.player_id = None
        self.welcome = None
        self._send_lock = threading.Lock()
        self._thread = None
        self._rid = 0
        self.ping_ms = None
        self.bytes_received = 0

    # ------------------------------------------------------------------
    def connect(self, host, port, name, timeout=C.CONNECT_TIMEOUT, password=""):
        """Baut die Verbindung auf und wartet auf 'welcome'. Wirft ConnectionFailed."""
        host, port = split_host_port(host, port)
        try:
            port = int(port)
            if not 0 < port < 65536:
                raise ValueError
        except (TypeError, ValueError):
            raise ConnectionFailed("Ungültiger Port. Bitte eine Zahl zwischen 1 und 65535 eingeben.")
        try:
            sock = socket.create_connection((host, port), timeout=timeout)
        except OSError as exc:
            raise ConnectionFailed(describe_socket_error(exc, host, port)) from exc

        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        try:
            hello = {"t": "hello", "name": name, "version": C.PROTOCOL_VERSION}
            if password:
                hello["password"] = password
            sock.sendall(protocol.encode(hello))
            reader = sock.makefile("rb")
            line = reader.readline(C.MAX_MESSAGE_BYTES * 64)
            if not line:
                raise ConnectionFailed("Server hat die Verbindung sofort geschlossen.")
            msg = protocol.decode(line)
        except socket.timeout:
            sock.close()
            raise ConnectionFailed("Server antwortet nicht auf die Anmeldung. Ist das wirklich ein Factory-Empire-Server?")
        except (OSError, protocol.ProtocolError) as exc:
            sock.close()
            raise ConnectionFailed(f"Anmeldung fehlgeschlagen: {exc}") from exc

        if msg.get("t") == "error":
            sock.close()
            raise ConnectionFailed(msg.get("msg", "Server hat die Verbindung abgelehnt."))
        if msg.get("t") != "welcome":
            sock.close()
            raise ConnectionFailed("Unerwartete Antwort vom Server.")

        sock.settimeout(None)
        self.sock = sock
        self.connected = True
        self.welcome = msg
        self.player_id = msg["id"]
        self._thread = threading.Thread(target=self._recv_loop, args=(reader,), daemon=True)
        self._thread.start()
        return msg

    def _recv_loop(self, reader):
        reason = "Verbindung zum Server verloren."
        try:
            while self.connected:
                line = reader.readline(C.MAX_MESSAGE_BYTES * 64)
                if not line:
                    reason = "Der Server hat die Verbindung beendet."
                    break
                self.bytes_received += len(line)
                try:
                    msg = protocol.decode(line) if len(line) <= C.MAX_MESSAGE_BYTES else self._decode_big(line)
                except protocol.ProtocolError:
                    continue
                if msg["t"] == "pong" and isinstance(msg.get("ts"), (int, float)):
                    self.ping_ms = int((time.time() - msg["ts"]) * 1000)
                    continue
                if msg["t"] == "error":
                    reason = msg.get("msg", reason)
                self.inbox.put(msg)
        except OSError:
            pass
        finally:
            was_connected = self.connected
            self.connected = False
            if was_connected:
                self.inbox.put({"t": "_disconnected", "reason": reason})

    @staticmethod
    def _decode_big(line):
        # Zustandsnachrichten großer Fabriken dürfen größer sein als Client-Nachrichten
        import json
        msg = json.loads(line.decode("utf-8"))
        if not isinstance(msg, dict) or "t" not in msg:
            raise protocol.ProtocolError("Ungültige Nachricht")
        return msg

    # ------------------------------------------------------------------
    def send(self, message):
        if not self.connected or self.sock is None:
            return False
        data = protocol.encode(message)
        try:
            with self._send_lock:
                self.sock.sendall(data)
            return True
        except OSError:
            self.connected = False
            self.inbox.put({"t": "_disconnected", "reason": "Senden fehlgeschlagen – Verbindung verloren."})
            return False

    def action(self, action, **fields):
        self._rid += 1
        self.send({"t": "action", "a": action, "rid": self._rid, **fields})
        return self._rid

    def ping(self):
        self.send({"t": "ping", "ts": time.time()})

    def poll(self, limit=500):
        messages = []
        for _ in range(limit):
            try:
                messages.append(self.inbox.get_nowait())
            except queue.Empty:
                break
        return messages

    def close(self):
        if self.connected:
            try:
                self.send({"t": "bye"})
            except Exception:
                pass
        self.connected = False
        if self.sock:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None
