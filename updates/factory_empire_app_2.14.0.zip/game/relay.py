"""
Online spielen ohne IP-Adresse und Router-Freigabe: Raum-Codes über einen Vermittlungsserver.

Der Host baut eine ausgehende Verbindung zu einem öffentlichen Vermittlungsserver auf
(Standard: bore.pub, ein kostenloser Dienst; Protokoll von "bore", github.com/ekzhang/bore).
Der Vermittlungsserver öffnet dafür einen öffentlichen Port – dessen Nummer ist der
Raum-Code. Mitspieler verbinden sich mit <Vermittlungsserver>:<Code>; jede Verbindung wird
über eine zweite ausgehende Verbindung des Hosts zum lokalen Spielserver durchgereicht.
Weil der Host nur ausgehende Verbindungen braucht, funktioniert das hinter jedem Router,
auch bei DS-Lite/Carrier-NAT – ohne Portfreigabe.

Protokoll (TCP-Port 7835, JSON-Nachrichten, jeweils mit Null-Byte abgeschlossen):
  Host -> Server  {"Hello": 0}            gewünschter Port (0 = beliebig)
  Server -> Host  {"Hello": 41234}        zugeteilter öffentlicher Port
  Server -> Host  "Heartbeat"             regelmäßig
  Server -> Host  {"Connection": "<uuid>"} ein Mitspieler hat sich verbunden
  Host -> Server  (neue Verbindung) {"Accept": "<uuid>"}, danach rohe Daten in beide Richtungen
"""

import json
import logging
import os
import re
import socket
import threading
import time

log = logging.getLogger("relay")

DEFAULT_RELAY = "bore.pub"
CONTROL_PORT = 7835
MAX_FRAME = 256
TIMEOUT = 8.0


def relay_host():
    """Adresse des Vermittlungsservers (für Tests oder einen eigenen Server per Umgebungsvariable)."""
    return os.environ.get("FACTORY_EMPIRE_RELAY", DEFAULT_RELAY).strip() or DEFAULT_RELAY


def parse_room_code(text):
    """'41234', 'FE-41234', ' fe 41234 ' -> 41234; alles andere -> None."""
    if not isinstance(text, str):
        return None
    m = re.fullmatch(r"\s*(?:fe\s*[-:]?\s*)?(\d{4,5})\s*", text, re.IGNORECASE)
    if not m:
        return None
    port = int(m.group(1))
    return port if 1024 <= port <= 65535 else None


def format_room_code(port):
    return f"FE-{port}"


# Lokale Quellports der Verbindungen, die über den Vermittlungsserver kommen. Der Spielserver
# erkennt daran, dass ein Mitspieler NICHT auf diesem PC sitzt (sonst wäre er wegen 127.0.0.1
# automatisch Admin).
RELAYED_PORTS = set()
_ports_lock = threading.Lock()


def is_relayed(port):
    with _ports_lock:
        return port in RELAYED_PORTS


class RelayError(Exception):
    pass


class _Framed:
    """Liest/schreibt null-terminierte JSON-Nachrichten; überzählige Bytes bleiben im Puffer."""

    def __init__(self, sock):
        self.sock = sock
        self.buf = b""

    def send(self, obj):
        self.sock.sendall(json.dumps(obj, separators=(",", ":")).encode() + b"\0")

    def recv(self):
        while b"\0" not in self.buf:
            if len(self.buf) > MAX_FRAME:
                raise RelayError("Ungültige Antwort des Vermittlungsservers.")
            chunk = self.sock.recv(4096)
            if not chunk:
                return None
            self.buf += chunk
        frame, self.buf = self.buf.split(b"\0", 1)
        try:
            return json.loads(frame.decode())
        except ValueError as exc:
            raise RelayError("Ungültige Antwort des Vermittlungsservers.") from exc


def _pipe(src, dst):
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
    except OSError:
        pass
    finally:
        for s in (src, dst):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


class RelayHost:
    """Hält die Verbindung zum Vermittlungsserver und leitet Mitspieler zum lokalen Server durch."""

    def __init__(self, local_port, host=None, control_port=CONTROL_PORT, on_status=None):
        self.local_port = int(local_port)
        self.host = host or relay_host()
        self.control_port = control_port
        self.on_status = on_status          # Rückruf(text) bei Verbindungsverlust/-wiederherstellung
        self.public_port = None
        self._ctrl = None
        self._stop = threading.Event()
        self._thread = None

    # ------------------------------------------------------------------ Aufbau
    def _open_control(self, wanted_port=0):
        sock = socket.create_connection((self.host, self.control_port), timeout=TIMEOUT)
        sock.settimeout(TIMEOUT)
        framed = _Framed(sock)
        framed.send({"Hello": int(wanted_port)})
        msg = framed.recv()
        if isinstance(msg, dict) and "Hello" in msg:
            sock.settimeout(None)
            return framed, int(msg["Hello"])
        sock.close()
        if isinstance(msg, dict) and "Error" in msg:
            raise RelayError(f"Vermittlungsserver meldet: {msg['Error']}")
        if isinstance(msg, dict) and "Challenge" in msg:
            raise RelayError("Der Vermittlungsserver verlangt ein Passwort (nicht unterstützt).")
        raise RelayError("Keine gültige Antwort vom Vermittlungsserver.")

    def start(self):
        """Verbindet sich und liefert den Raum-Code (öffentlicher Port). Wirft RelayError/OSError."""
        try:
            self._ctrl, self.public_port = self._open_control(0)
        except OSError as exc:
            raise RelayError(f"Vermittlungsserver {self.host} nicht erreichbar ({exc}).") from exc
        self._thread = threading.Thread(target=self._control_loop, daemon=True, name="relay-control")
        self._thread.start()
        log.info("Online über %s: Raum-Code %s", self.host, format_room_code(self.public_port))
        return self.public_port

    def stop(self):
        self._stop.set()
        if self._ctrl:
            try:
                self._ctrl.sock.close()
            except OSError:
                pass

    # ------------------------------------------------------------------ Betrieb
    def _control_loop(self):
        while not self._stop.is_set():
            try:
                msg = self._ctrl.recv()
            except (OSError, RelayError):
                msg = None
            if msg is None:
                if self._stop.is_set():
                    return
                self._reconnect()
                continue
            if isinstance(msg, dict) and "Connection" in msg:
                threading.Thread(target=self._handle_connection, args=(msg["Connection"],), daemon=True,
                                 name="relay-conn").start()
            elif isinstance(msg, dict) and "Error" in msg:
                log.warning("Vermittlungsserver: %s", msg["Error"])
            # "Heartbeat" und Unbekanntes ignorieren

    def _reconnect(self):
        """Verbindung zum Vermittlungsserver verloren: mit demselben Raum-Code neu anmelden."""
        if self.on_status:
            self.on_status("lost")
        delay = 2.0
        while not self._stop.is_set():
            try:
                self._ctrl, port = self._open_control(self.public_port or 0)
                if port != self.public_port:
                    self.public_port = port
                    log.warning("Neuer Raum-Code: %s", format_room_code(port))
                if self.on_status:
                    self.on_status("ok")
                return
            except (OSError, RelayError) as exc:
                log.info("Vermittlungsserver noch nicht wieder erreichbar: %s", exc)
                self._stop.wait(delay)
                delay = min(delay * 1.5, 30.0)

    def _handle_connection(self, conn_id):
        remote = local = None
        try:
            remote = socket.create_connection((self.host, self.control_port), timeout=TIMEOUT)
            framed = _Framed(remote)
            framed.send({"Accept": conn_id})
            local = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            local.settimeout(TIMEOUT)
            local.bind(("127.0.0.1", 0))
            local_port = local.getsockname()[1]
            with _ports_lock:
                RELAYED_PORTS.add(local_port)        # vor dem Verbinden eintragen (kein Wettlauf)
            local.connect(("127.0.0.1", self.local_port))
            remote.settimeout(None)
            local.settimeout(None)
            if framed.buf:
                local.sendall(framed.buf)
        except OSError as exc:
            log.info("Mitspieler-Verbindung über Vermittlung fehlgeschlagen: %s", exc)
            for s in (remote, local):
                if s:
                    s.close()
            return
        t = threading.Thread(target=_pipe, args=(remote, local), daemon=True)
        t.start()
        _pipe(local, remote)
        t.join(timeout=5)
        remote.close()
        local.close()
        with _ports_lock:
            RELAYED_PORTS.discard(local_port)


def wait_until(predicate, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if predicate():
            return True
        time.sleep(0.02)
    return False
