"""
Markt mit dynamischen Preisen.

Jeder Verkauf sättigt den Markt ein wenig (Preis sinkt), danach erholt sich
der Preis langsam in Richtung eines Nachfrageniveaus, das sich alle
MARKET_DEMAND_INTERVAL Sekunden zufällig verändert. So lohnt es sich,
mehrere Produkte zu verkaufen statt nur eines in riesigen Mengen.
"""

from collections import deque

from . import config as C


class Market:
    def __init__(self):
        self.prices = {item: spec["price"] for item, spec in C.ITEMS.items()}
        self.demand = {item: 1.0 for item in C.ITEMS}
        self.history = {item: [spec["price"]] for item, spec in C.ITEMS.items()}
        self.sold = {item: 0 for item in C.ITEMS}
        self.revenue = {item: 0.0 for item in C.ITEMS}
        self.total_revenue = 0.0
        self._recent = deque()            # (zeitpunkt, betrag) für Einnahmen/Minute
        self._demand_timer = 0.0
        self._history_timer = 0.0

    # ------------------------------------------------------------------
    def base_price(self, item):
        return C.ITEMS[item]["price"]

    def sell_price(self, item, price_mult=1.0):
        return self.prices[item] * price_mult

    def sell(self, item, quantity, price_mult, now):
        """Verkauft `quantity` Stück und gibt den Erlös zurück."""
        if item not in self.prices or quantity <= 0:
            return 0.0
        floor = self.base_price(item) * C.MARKET_MIN_FACTOR
        total = 0.0
        price = self.prices[item]
        for _ in range(quantity):
            total += price * price_mult
            price = max(floor, price * (1.0 - C.MARKET_SATURATION))
        self.prices[item] = price
        self.sold[item] += quantity
        self.revenue[item] += total
        self.total_revenue += total
        self._recent.append((now, total))
        return total

    def income_per_minute(self, now):
        while self._recent and now - self._recent[0][0] > 60.0:
            self._recent.popleft()
        return sum(amount for _, amount in self._recent)

    # ------------------------------------------------------------------
    def tick(self, dt, now, rng):
        self._demand_timer += dt
        if self._demand_timer >= C.MARKET_DEMAND_INTERVAL:
            self._demand_timer = 0.0
            lo, hi = C.MARKET_DEMAND_RANGE
            for item in self.demand:
                # sanfte Zufallsbewegung statt wilder Sprünge
                target = self.demand[item] + rng.uniform(-0.15, 0.15)
                self.demand[item] = max(lo, min(hi, target))

        blend = 1.0 - (1.0 - C.MARKET_RECOVERY) ** dt
        for item, price in self.prices.items():
            target = self.base_price(item) * self.demand[item]
            self.prices[item] = price + (target - price) * blend

        self._history_timer += dt
        if self._history_timer >= C.MARKET_HISTORY_INTERVAL:
            self._history_timer = 0.0
            for item, price in self.prices.items():
                hist = self.history[item]
                hist.append(round(price, 2))
                if len(hist) > C.MARKET_HISTORY_LEN:
                    del hist[0]

    # ------------------------------------------------------------------
    def snapshot(self, price_mult, now):
        return {
            "prices": {i: round(p * price_mult, 2) for i, p in self.prices.items()},
            "history": {i: [round(v * price_mult, 2) for v in h[-12:]] for i, h in self.history.items()},
            "sold": dict(self.sold),
            "revenue": {i: round(v, 2) for i, v in self.revenue.items()},
            "total": round(self.total_revenue, 2),
            "per_min": round(self.income_per_minute(now), 2),
        }

    def to_dict(self):
        return {
            "prices": self.prices,
            "demand": self.demand,
            "history": self.history,
            "sold": self.sold,
            "revenue": self.revenue,
            "total_revenue": self.total_revenue,
            "demand_timer": self._demand_timer,
            "history_timer": self._history_timer,
        }

    @classmethod
    def from_dict(cls, data):
        m = cls()
        for key in ("prices", "demand", "sold", "revenue"):
            stored = data.get(key, {})
            target = getattr(m, key)
            for item in target:
                if item in stored:
                    target[item] = type(target[item])(stored[item])
        for item, hist in data.get("history", {}).items():
            if item in m.history and isinstance(hist, list):
                m.history[item] = [float(v) for v in hist][-C.MARKET_HISTORY_LEN:] or m.history[item]
        m.total_revenue = float(data.get("total_revenue", 0.0))
        m._demand_timer = float(data.get("demand_timer", 0.0))
        m._history_timer = float(data.get("history_timer", 0.0))
        return m
