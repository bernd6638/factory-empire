"""
Grafikqualität.

"hoch":    Ursinas lit_with_shadows_shader + Schattenwurf der Sonne
           (benötigt eine Grafikkarte mit OpenGL 3.2+, also praktisch jeder
           Windows-PC und Mac der letzten zehn Jahre).
"niedrig": klassische Panda3D-Beleuchtung ohne Schatten. Läuft auch auf
           sehr alten Grafikchips, Remote-Desktops und Software-Renderern.

Mit "auto" wird bei erkannten Software-Renderern automatisch "niedrig" gewählt.
"""

import sys

from ursina.shaders import unlit_shader

QUALITY = {"high": True}

SOFTWARE_RENDERERS = ("llvmpipe", "softpipe", "swrast", "gdi generic", "microsoft basic render", "software")


def configure(mode, renderer_name=""):
    mode = (mode or "auto").lower()
    if sys.platform == "darwin":
        # macOS hat nur das OpenGL-Core-Profile: ohne Shader (Modus "niedrig") bliebe die Szene schwarz
        mode = "high"
    if mode in ("low", "niedrig"):
        QUALITY["high"] = False
    elif mode in ("high", "hoch"):
        QUALITY["high"] = True
    else:
        name = (renderer_name or "").lower()
        QUALITY["high"] = not any(s in name for s in SOFTWARE_RENDERERS)
    if QUALITY["high"]:
        # weiche Schattenkanten mit 2x2 statt 4x4 Abtastungen: kaum sichtbar, aber viel schneller
        try:
            from ursina.shaders import lit_with_shadows_shader
            lit_with_shadows_shader.default_input["shadow_samples"] = 2
            lit_with_shadows_shader.default_input["shadow_blur"] = 0.004
        except Exception:
            pass
    if not QUALITY["high"]:
        # Container-Entities dürfen keinen eigenen Shader setzen, sonst würden
        # Kind-Objekte unbeleuchtet dargestellt. Ohne Shader greift die
        # klassische Panda3D-Beleuchtung.
        from ursina import Entity
        Entity.default_shader = None
    return QUALITY["high"]


def shadow_resolution(quality="medium"):
    """Größe der Schattenkarte je Qualitätsstufe. Macs (OpenGL läuft dort über eine
    Übersetzungsschicht) bekommen eine Stufe kleiner."""
    import os
    env = os.environ.get("FACTORY_EMPIRE_SHADOW", "")
    if env.isdigit() and int(env) >= 256:
        return int(env)
    res = {"high": 4096, "medium": 2048, "low": 1024}.get(quality, 2048)
    if sys.platform == "darwin":
        res = max(1024, res // 2)
    return res


def high():
    return QUALITY["high"]


_FAST_VERTEX = """#version 150
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelViewMatrix;
uniform mat3 p3d_NormalMatrix;
in vec4 vertex;
in vec3 normal;
in vec4 p3d_Color;
in vec2 p3d_MultiTexCoord0;
uniform vec2 texture_scale;
uniform vec2 texture_offset;
out vec2 texcoords;
out vec4 vertex_color;
out vec3 normal_vector;
out vec3 view_pos;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * vertex;
    view_pos = (p3d_ModelViewMatrix * vertex).xyz;
    normal_vector = normalize(p3d_NormalMatrix * normal);
    texcoords = (p3d_MultiTexCoord0 * texture_scale) + texture_offset;
    vertex_color = p3d_Color;
}
"""

# Beleuchtung (ab 2.9.1 realistischer): Himmelslicht von oben (bläulich) und Bodenreflexion von
# unten (warm), Sonnenlicht mit weichem Glanzpunkt, filmischer Tonwert-Verlauf und Luftperspektive.
_FAST_FRAGMENT = """#version 150
uniform struct {
    vec4 position;
    vec3 color;
} p3d_LightSource[1];
uniform mat4 p3d_ViewMatrix;
uniform sampler2D p3d_Texture0;
uniform vec4 p3d_ColorScale;
uniform vec4 fe_fog;          // rgb = Dunstfarbe, a = Stärke (0 = aus)
uniform vec2 fe_fog_range;    // Beginn, Ende (volle Stärke)
in vec2 texcoords;
in vec4 vertex_color;
in vec3 normal_vector;
in vec3 view_pos;
out vec4 fragment_color;
void main() {
    vec4 albedo = texture(p3d_Texture0, texcoords) * p3d_ColorScale * vertex_color;
    vec3 N = normalize(normal_vector);
    vec3 L = normalize(p3d_LightSource[0].position.xyz);
    vec3 sun = p3d_LightSource[0].color;
    float ndl = max(dot(N, L), 0.0);
    vec3 up = normalize((p3d_ViewMatrix * vec4(0.0, 0.0, 1.0, 0.0)).xyz);
    float hemi = dot(N, up) * 0.5 + 0.5;
    vec3 ambient = mix(vec3(0.40, 0.36, 0.31), vec3(0.60, 0.68, 0.82), hemi) * 0.75;
    vec3 V = normalize(-view_pos);
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 40.0) * 0.18 * ndl;
    float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.06;
    vec3 c = albedo.rgb * (ambient + sun * ndl * 1.05) + sun * spec + vec3(0.55, 0.65, 0.8) * rim * hemi;
    c *= 1.32;                                   // Belichtung
    c = c / (1.0 + c * 0.22);                    // weicher Übergang in den Lichtern (filmisch)
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(lum), c, 1.10);                 // etwas kräftigere Farben
    float d = length(view_pos);
    float f = clamp((d - fe_fog_range.x) / (fe_fog_range.y - fe_fog_range.x), 0.0, 1.0);
    c = mix(c, fe_fog.rgb, f * f * fe_fog.a);
    fragment_color = vec4(c, albedo.a);
}
"""

_FAST = {}


def fast_lit_shader():
    """Schneller Licht-Shader ohne Schatten: gleiche Optik wie Ursinas Licht-Shader im
    beleuchteten Bereich, aber nur ein Bruchteil der Rechenarbeit pro Bildpunkt."""
    if "shader" not in _FAST:
        from ursina import Vec2
        from ursina.shader import Shader
        _FAST["shader"] = Shader(name="fe_fast_lit", language=Shader.GLSL, vertex=_FAST_VERTEX,
                                 fragment=_FAST_FRAGMENT,
                                 default_input={"texture_scale": Vec2(1, 1), "texture_offset": Vec2(0, 0)})
    return _FAST["shader"]


def set_fast(on):
    """Schatten aus -> schneller Shader für alle danach erzeugten Objekte (beim Start gesetzt)."""
    QUALITY["fast"] = bool(on)


def lit_shader():
    """Shader für beleuchtete 3D-Objekte (None = feste Panda3D-Beleuchtung)."""
    if QUALITY["high"]:
        if QUALITY.get("fast"):
            return fast_lit_shader()
        from ursina.shaders import lit_with_shadows_shader
        return lit_with_shadows_shader
    return None


def unlit():
    return unlit_shader


FOG = {"color": (0.74, 0.81, 0.88), "range": (55.0, 240.0)}


def set_fog(color=None, rng=None, strength=1.0):
    """Dunst zur Laufzeit ändern (Mond: schwarz und weit weg, All: aus)."""
    import builtins
    from panda3d.core import Fog, Vec2, Vec4
    render = builtins.base.render
    r, g, b = color or FOG["color"]
    start, end = rng or FOG["range"]
    render.setShaderInput("fe_fog", Vec4(r, g, b, float(strength)))
    render.setShaderInput("fe_fog_range", Vec2(start, end))
    if not QUALITY["high"]:
        if strength <= 0:
            render.clearFog()
        else:
            fog = Fog("dunst")
            fog.setColor(r, g, b)
            fog.setLinearRange(start, end * 1.15)
            render.setFog(fog)


def setup_fog(render):
    """Luftperspektive: entfernte Landschaft verblasst im Dunst (wirkt deutlich echter).
    Schneller Shader: eigener Nebel; ohne Shader ("niedrig"): Panda3D-Nebel."""
    from panda3d.core import Fog, Vec2, Vec4
    r, g, b = FOG["color"]
    start, end = FOG["range"]
    render.setShaderInput("fe_fog", Vec4(r, g, b, 1.0))
    render.setShaderInput("fe_fog_range", Vec2(start, end))
    if not QUALITY["high"]:
        fog = Fog("dunst")
        fog.setColor(r, g, b)
        fog.setLinearRange(start, end * 1.15)
        render.setFog(fog)
