"""
Partikeleffekte: Rauch, Funken, Staub, Münzen und Bau-Staubwolken.

Ein fester Pool an Billboard-Quads wird wiederverwendet, damit auch bei
vielen Maschinen keine neuen Objekte pro Frame entstehen.
"""

import random

from . import textures

KINDS = {
    #          Farbe RGBA                 Lebensdauer  Größe (start, ende)  Auftrieb  Streuung
    "smoke":  ((0.55, 0.55, 0.58, 0.55), (2.2, 3.2), (0.18, 0.75), 0.55, 0.12),
    "spark":  ((1.00, 0.70, 0.25, 1.00), (0.25, 0.5), (0.07, 0.02), -1.5, 1.2),
    "dust":   ((0.55, 0.42, 0.32, 0.6), (0.6, 1.0), (0.12, 0.35), 0.25, 0.5),
    "coin":   ((1.00, 0.84, 0.25, 1.00), (0.7, 0.9), (0.12, 0.08), 1.6, 0.4),
    "poof":   ((0.85, 0.85, 0.82, 0.7), (0.5, 0.8), (0.25, 0.7), 0.4, 1.6),
    "steam":  ((0.95, 0.95, 1.00, 0.4), (1.2, 1.8), (0.12, 0.5), 0.7, 0.15),
    # Raketenstart (eigener großer Partikel-Pool in rocket.py)
    "cloud":  ((0.93, 0.93, 0.95, 0.62), (3.5, 6.0), (2.2, 10.0), 0.5, 1.6),
    "fog":    ((0.90, 0.92, 0.96, 0.30), (4.0, 7.0), (3.0, 9.0), 0.08, 0.7),
    "vent":   ((0.97, 0.98, 1.00, 0.55), (1.4, 2.4), (0.5, 3.0), -0.6, 0.35),
    "fire":   ((1.00, 0.62, 0.22, 1.00), (0.2, 0.45), (1.8, 0.5), 0.0, 0.5),
    "flare":  ((1.00, 0.92, 0.70, 1.00), (0.08, 0.16), (2.6, 1.2), 0.0, 0.2),
    "dust_m": ((0.62, 0.62, 0.64, 0.55), (2.0, 3.5), (1.0, 6.0), 0.25, 2.2),
}


class Particles:
    """Alle Partikel werden in EIN Modell geschrieben (sprites.SpriteBatch) – ein Zeichenaufruf statt
    einem pro Rauchwölkchen."""

    def __init__(self, size=260, name="particles"):
        from . import sprites
        self.max = size
        self.active = []            # je Partikel: [x, y, z, vx, vy, vz, alter, dauer, s0, s1, r, g, b, a, schwerkraft]
        self.batch = sprites.SpriteBatch(textures.texture("glow"), name, bin_order=10)
        self.enabled = True
        self.distant = False         # weit herausgezoomt: Maschinenrauch & Co. weglassen (unsichtbar klein)

    def emit(self, pos, kind, count=1, direction=None, force=False):
        if not self.enabled or (self.distant and not force):
            return
        rgba, life, size, lift, spread = KINDS[kind]
        px, py, pz = pos[0], pos[1], pos[2]
        grav = 4.0 if kind in ("spark", "coin") else 0.0
        uni = random.uniform
        for _ in range(count):
            if len(self.active) >= self.max:
                return
            if kind == "spark":
                vx, vy, vz = uni(-1, 1), uni(1.0, 2.2), uni(-1, 1)
            else:
                vx, vy, vz = uni(-spread, spread), lift + uni(0, abs(lift) * 0.5), uni(-spread, spread)
            if direction is not None:
                vx += direction[0]
                vy += direction[1]
                vz += direction[2]
            self.active.append([px + uni(-0.05, 0.05), py, pz + uni(-0.05, 0.05), vx, vy, vz, 0.0,
                                uni(*life), size[0], size[1], rgba[0], rgba[1], rgba[2], rgba[3], grav])

    def update(self, dt):
        if not self.active:
            if self.batch.count:
                self.batch.clear()
            return
        still = []
        out = []
        damp = 1 - 0.6 * dt
        for p in self.active:
            p[6] += dt
            t = p[6] / p[7]
            if t >= 1.0:
                continue
            p[4] -= p[14] * dt
            p[0] += p[3] * dt
            p[1] += p[4] * dt
            p[2] += p[5] * dt
            p[3] *= damp
            p[4] *= damp
            p[5] *= damp
            h = (p[8] + (p[9] - p[8]) * t) * 0.5
            a = p[13] * (1 - t) * min(1.0, p[6] * 8)
            out.append((p[0], p[1], p[2], h, h, p[10], p[11], p[12], a))
            still.append(p)
        self.active = still
        self.batch.write(out)

    def clear(self):
        self.active = []
        self.batch.clear()


PARTICLES = {"inst": None}


def get():
    if PARTICLES["inst"] is None:
        PARTICLES["inst"] = Particles()
    return PARTICLES["inst"]
