"""
Soundeffekte – hier kommt Pygame zum Einsatz.

Pygame wird ausschließlich für Audio verwendet (pygame.mixer). Die Klänge
werden beim Start prozedural erzeugt (Sinus/Rauschen), daher sind keine
Audiodateien nötig. Grafik und Eingabe laufen komplett über Ursina, es
gibt also keine zwei konkurrierenden Fenster- oder Rendersysteme.

Ist Pygame nicht installiert oder hat das System kein Audiogerät, läuft
das Spiel einfach ohne Ton weiter.
"""

import math
import os
import random
import struct

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

RATE = 22050


def _render(duration, func, volume=0.35):
    n = int(RATE * duration)
    frames = bytearray()
    for i in range(n):
        t = i / RATE
        env = min(1.0, t * 200) * max(0.0, 1.0 - t / duration) ** 1.6
        v = max(-1.0, min(1.0, func(t) * env * volume))
        s = int(v * 32767)
        frames += struct.pack("<hh", s, s)
    return bytes(frames)


def _tone(freq):
    return lambda t: math.sin(2 * math.pi * freq * t)


def _sweep(f0, f1, duration):
    return lambda t: math.sin(2 * math.pi * (f0 + (f1 - f0) * t / duration / 2) * t)


ROCKET_SOUNDS = ("rocket_launch", "rocket_land", "beep", "clang", "whoosh")


class Audio:
    def __init__(self, enabled=True):
        self.enabled = False
        self.sounds = {}
        self.volume = 0.8
        if not enabled:
            return
        try:
            import pygame
            pygame.mixer.pre_init(RATE, -16, 2, 512)
            pygame.mixer.init()
            self._pygame = pygame
        except Exception as exc:          # kein Audiogerät, kein Pygame ...
            print(f"[Audio] Ton deaktiviert: {exc}")
            return
        rng = random.Random(7)
        defs = {
            "click": _render(0.05, _tone(1200), 0.18),
            "build": _render(0.22, lambda t: 0.7 * math.sin(2 * math.pi * 140 * t) + 0.3 * rng.uniform(-1, 1), 0.5),
            "demolish": _render(0.35, lambda t: rng.uniform(-1, 1) * 0.8 + 0.4 * math.sin(2 * math.pi * 70 * t), 0.4),
            "error": _render(0.25, lambda t: 0.6 * math.sin(2 * math.pi * 160 * t) + 0.4 * math.sin(2 * math.pi * 166 * t), 0.4),
            "sell": _render(0.3, lambda t: math.sin(2 * math.pi * (1318 if t > 0.08 else 988) * t), 0.25),
            "research": _render(0.6, lambda t: math.sin(2 * math.pi * (523 if t < 0.15 else 659 if t < 0.3 else 784) * t), 0.3),
            "upgrade": _render(0.35, _sweep(400, 900, 0.35), 0.3),
            "message": _render(0.12, _tone(880), 0.15),
        }
        try:
            for name, data in defs.items():
                self.sounds[name] = pygame.mixer.Sound(buffer=data)
            self.enabled = True
        except Exception as exc:
            print(f"[Audio] Ton deaktiviert: {exc}")

        self.music_volume = 0.45
        self.ambient_volume = 0.7
        self._music = []
        self._music_i = 0
        self._ambient = {}
        self._birds = []
        self._bird_t = 2.0
        self._levels = {"wind": 0.0, "factory": 0.0}
        self.air = 1.0                     # Mond: keine Luft -> kein Wind, keine Vögel
        self.rocket_volume = 0.35          # eigener Regler für Raketenstart, Landung und Countdown
        self.achievement_volume = 0.6      # eigener Regler für den Erfolgs-Klang
        if self.enabled:
            self._load_ambience()

    # ------------------------------------------------------------------ Musik & Umgebung
    def _load_ambience(self):
        """Musik und Umgebungsgeräusche aus assets/sounds (erzeugt mit tools/generate_audio.py)."""
        pygame = self._pygame
        folder = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "sounds")
        try:
            pygame.mixer.set_num_channels(20)
            pygame.mixer.set_reserved(2)              # Kanal 0 = Wind, 1 = Fabrik
            for name, ch in (("wind", 0), ("factory", 1)):
                path = os.path.join(folder, name + ".ogg")
                if os.path.exists(path):
                    snd = pygame.mixer.Sound(path)
                    chan = pygame.mixer.Channel(ch)
                    chan.play(snd, loops=-1)
                    chan.set_volume(0.0)
                    self._ambient[name] = chan
            for i in range(1, 9):
                path = os.path.join(folder, f"bird_{i}.ogg")
                if os.path.exists(path):
                    self._birds.append(pygame.mixer.Sound(path))
            for name in ("rocket_launch", "rocket_land", "beep", "clang", "whoosh", "achievement"):
                path = os.path.join(folder, name + ".ogg")
                if os.path.exists(path):
                    self.sounds[name] = pygame.mixer.Sound(path)
            self._music = [os.path.join(folder, f) for f in sorted(os.listdir(folder)) if f.startswith("music_")]
            random.shuffle(self._music)
        except Exception as exc:
            print(f"[Audio] Musik/Umgebung nicht verfügbar: {exc}")

    def update(self, dt, in_game=False, zoom=30.0, busy=0.0):
        """Jedes Bild aufrufen. zoom: Kameraabstand, busy: 0..1 wie viel in der Fabrik gerade arbeitet."""
        if not self.enabled:
            return
        pygame = self._pygame
        # Musik: Playlist im Wechsel, sanft eingeblendet
        try:
            mv = self.music_volume * 0.55
            if self._music and mv > 0.001:
                if not pygame.mixer.music.get_busy():
                    path = self._music[self._music_i % len(self._music)]
                    self._music_i += 1
                    pygame.mixer.music.load(path)
                    pygame.mixer.music.play(fade_ms=4000)
                pygame.mixer.music.set_volume(mv)
            elif pygame.mixer.music.get_busy():
                pygame.mixer.music.stop()
        except Exception:
            self._music = []
        av = self.ambient_volume
        # Fabrik: lauter, je näher die Kamera und je mehr arbeitet; Natur dafür etwas leiser
        near = max(0.0, min(1.0, (60.0 - zoom) / 45.0))
        factory = av * (0.75 * busy * (0.35 + 0.65 * near)) if in_game else 0.0
        wind = av * (0.45 if in_game else 0.35) * (1.0 - 0.4 * busy * near) * self.air
        k = min(1.0, dt * 1.5)
        for name, target in (("wind", wind), ("factory", factory)):
            cur = self._levels[name] = self._levels[name] + (target - self._levels[name]) * k
            chan = self._ambient.get(name)
            if chan is not None:
                chan.set_volume(cur)
        # Vögel zwitschern zufällig mal links, mal rechts, mal nah, mal fern
        if self._birds and av > 0.01 and self.air > 0.5:
            self._bird_t -= dt
            if self._bird_t <= 0:
                self._bird_t = random.uniform(1.5, 6.0) * (1.0 + busy * near)
                chan = pygame.mixer.find_channel()
                if chan is not None:
                    snd = random.choice(self._birds)
                    vol = av * random.uniform(0.25, 0.7) * (1.0 - 0.5 * busy * near)
                    pan = random.uniform(0.0, 1.0)
                    chan.play(snd)
                    chan.set_volume(vol * (1 - pan) * 1.4, vol * pan * 1.4)

    def play(self, name, volume=1.0):
        if not self.enabled:
            return
        snd = self.sounds.get(name)
        if snd:
            if name in ROCKET_SOUNDS:
                volume *= self.rocket_volume
            elif name == "achievement":
                volume *= self.achievement_volume / max(0.05, self.volume)   # unabhängig von "Effekte"
            snd.set_volume(max(0.0, min(1.0, self.volume * volume)))
            snd.play()

    def stop(self, name):
        snd = self.sounds.get(name) if self.enabled else None
        if snd:
            snd.fadeout(400)

    def shutdown(self):
        if self.enabled:
            try:
                self._pygame.mixer.music.stop()
                self._pygame.mixer.quit()
            except Exception:
                pass
