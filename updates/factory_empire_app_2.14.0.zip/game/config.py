"""
Zentrale Spielkonfiguration von Factory Empire.

Alle Balancing-Werte (Kosten, Zeiten, Preise, Forschung) stehen hier, damit
Server und Client garantiert mit denselben Daten arbeiten. Änderungen an
dieser Datei wirken sich sofort auf Wirtschaft und Produktion aus.
"""

import os

# Ordner für Spielstände, Einstellungen und Logs. Standard: "saves" im Spielordner.
# Die macOS-App setzt FACTORY_EMPIRE_DATA auf ~/Library/Application Support/Factory Empire,
# weil der Inhalt einer .app nicht beschreibbar sein muss.
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.abspath(os.path.join(PROJECT_DIR, os.environ.get("FACTORY_EMPIRE_DATA") or "saves"))

GAME_TITLE = "Factory Empire"
GAME_VERSION = "2.14.0"
PROTOCOL_VERSION = 6

# Discord-Status (Rich Presence): ID der Anwendung aus dem Discord Developer Portal.
# Leer = aus. Bilder ("logo") werden dort unter "Rich Presence > Art Assets" hochgeladen.
DISCORD_APP_ID = "1566260196190326826"

# Automatische Updates: Adresse der Update-Beschreibung (update.json). Leer = keine Updates.
UPDATE_URL = "https://raw.githubusercontent.com/bernd6638/factory-empire/main/update.json"
# Stand der mitgelieferten Laufzeit (Python + Bibliotheken). Braucht ein Update eine neuere Laufzeit,
# kann es nicht automatisch installiert werden – dann muss das Spiel einmal neu heruntergeladen werden.
RUNTIME_VERSION = 1

# Countdown über der geheimen Baustelle (Unix-Zeit, UTC): 08.11.2026, 03:15 Uhr deutscher Zeit
COUNTDOWN_TARGET = 1794104100

# ---------------------------------------------------------------------------
# Netzwerk
# ---------------------------------------------------------------------------
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 5600
MAX_MESSAGE_BYTES = 64 * 1024          # Maximale Größe einer einzelnen JSON-Nachricht
MAX_PLAYERS = 8
CLIENT_MSG_RATE = 40                   # erlaubte Nachrichten pro Sekunde je Client
CLIENT_MSG_BURST = 80                  # Puffer für kurze Spitzen
HANDSHAKE_TIMEOUT = 5.0                # Sekunden, bis "hello" eintreffen muss
CONNECT_TIMEOUT = 5.0
ADMIN_MAX_GIVE = 100_000_000           # Höchstbetrag pro Admin-Geldbuchung

# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------
TICK_RATE = 20                         # Simulationsschritte pro Sekunde (Server)
SNAPSHOT_RATE = 10                     # Zustandsübertragungen pro Sekunde
SNAPSHOT_STAGGER = 5                   # jedes Gebäude spätestens alle 5 Übertragungen (0,5 s) komplett
FULL_SNAPSHOT_EVERY = 30               # alle 3 s alle Gebäude (falls eine Teil-Übertragung verloren ging)
AUTOSAVE_INTERVAL = 60.0               # Sekunden
ENERGY_INTERVAL = 5.0                  # Energiekosten werden alle 5 Sekunden abgerechnet
RATE_WINDOW = 60.0                     # Zeitfenster für die gemessene Produktion pro Minute
SAVE_VERSION = 2
DEFAULT_SAVE_FILE = os.path.join(DATA_DIR, "factory.json")
BANS_FILE = os.path.join(DATA_DIR, "bans.json")
SINGLEPLAYER_SAVE_FILE = os.path.join(DATA_DIR, "singleplayer.json")     # Platz 1 (auch ältere Spielstände)
SINGLEPLAYER_SLOTS = 5


def singleplayer_slot_file(slot):
    """Spielstand-Datei für Einzelspieler-Platz 1-5 (Platz 1 = bisheriger Einzelspieler-Stand)."""
    slot = max(1, min(SINGLEPLAYER_SLOTS, int(slot)))
    return SINGLEPLAYER_SAVE_FILE if slot == 1 else os.path.join(DATA_DIR, f"singleplayer_{slot}.json")


MULTIPLAYER_SLOTS = 5


def multiplayer_slot_file(slot):
    """Spielstand-Datei für Mehrspieler-Platz 1-5 (Platz 1 = bisheriger Mehrspieler-Stand factory.json)."""
    slot = max(1, min(MULTIPLAYER_SLOTS, int(slot)))
    if slot == 1:
        return DEFAULT_SAVE_FILE
    return os.path.join(os.path.dirname(DEFAULT_SAVE_FILE), f"multiplayer_{slot}.json")

GRID_W = 96
GRID_H = 96
WORLD_SEED = 1337

START_MONEY = 2500.0

# Richtungen: 0 = Nord (+y), 1 = Ost (+x), 2 = Süd (-y), 3 = West (-x)
DIRS = [(0, 1), (1, 0), (0, -1), (-1, 0)]
DIR_NAMES = ["Nord", "Ost", "Süd", "West"]

# Ausgänge von Verteilern relativ zur Blickrichtung
SIDE_NAMES = {"L": "Links", "F": "Vorne", "R": "Rechts"}

# ---------------------------------------------------------------------------
# Gegenstände
# ---------------------------------------------------------------------------
ITEMS = {
    "iron_ore":   {"name": "Eisenerz",     "color": (0.52, 0.33, 0.28), "price": 4.0},
    "copper_ore": {"name": "Kupfererz",    "color": (0.80, 0.48, 0.22), "price": 5.0},
    "iron_bar":   {"name": "Eisenbarren",  "color": (0.75, 0.78, 0.82), "price": 14.0},
    "copper_bar": {"name": "Kupferbarren", "color": (0.93, 0.55, 0.25), "price": 16.0},
    "steel":      {"name": "Stahl",        "color": (0.42, 0.47, 0.55), "price": 40.0},
    "gear":       {"name": "Zahnrad",      "color": (0.60, 0.63, 0.70), "price": 36.0},
    "wire":       {"name": "Kupferdraht",  "color": (0.98, 0.70, 0.30), "price": 11.0},
    "circuit":    {"name": "Schaltkreis",  "color": (0.20, 0.80, 0.40), "price": 125.0},
    "motor":      {"name": "Motor",        "color": (0.85, 0.25, 0.22), "price": 320.0},
    # --- ab Version 2.3: weitere Rohstoffe und Produkte
    "coal":        {"name": "Kohle",        "color": (0.16, 0.16, 0.18), "price": 5.0},
    "stone":       {"name": "Stein",        "color": (0.62, 0.60, 0.56), "price": 3.0},
    "sand":        {"name": "Sand",         "color": (0.92, 0.80, 0.52), "price": 3.0},
    "brick":       {"name": "Ziegel",       "color": (0.72, 0.30, 0.20), "price": 12.0},
    "glass":       {"name": "Glas",         "color": (0.62, 0.86, 0.95), "price": 14.0},
    "concrete":    {"name": "Beton",        "color": (0.70, 0.71, 0.72), "price": 15.0},
    "steel_beam":  {"name": "Stahlträger",  "color": (0.36, 0.42, 0.52), "price": 95.0},
    "battery":     {"name": "Batterie",     "color": (0.25, 0.70, 0.35), "price": 70.0},
    "computer":    {"name": "Computer",     "color": (0.25, 0.30, 0.40), "price": 480.0},
    "solar_panel": {"name": "Solarmodul",   "color": (0.18, 0.30, 0.65), "price": 420.0},
    "house":       {"name": "Fertighaus",   "color": (0.90, 0.85, 0.75), "price": 380.0},
    "robot":       {"name": "Roboter",      "color": (0.95, 0.75, 0.20), "price": 1500.0},
    "ecar":        {"name": "Elektroauto",  "color": (0.20, 0.55, 0.85), "price": 2900.0},
    # --- ab Version 2.6: Chemie und Elektronik
    "plastic":     {"name": "Kunststoff",   "color": (0.90, 0.92, 0.95), "price": 18.0},
    "processor":   {"name": "Prozessor",    "color": (0.30, 0.34, 0.42), "price": 330.0},
}
ITEM_ORDER = ["iron_ore", "copper_ore", "coal", "stone", "sand",
              "iron_bar", "copper_bar", "steel", "brick", "glass",
              "gear", "wire", "concrete", "steel_beam", "plastic", "battery", "circuit", "processor",
              "motor", "computer", "solar_panel", "house", "robot", "ecar"]

# Rohstoffvorkommen auf der Karte
DEPOSIT_ITEMS = ["iron_ore", "copper_ore", "coal", "stone", "sand"]

# ---------------------------------------------------------------------------
# Rezepte (cost = Energiekosten je Arbeitsgang)
# ---------------------------------------------------------------------------
RECIPES = {
    # --- Schmelze (wählt das Rezept automatisch nach dem angelieferten Erz)
    "smelt_iron":   {"name": "Eisen schmelzen",  "machine": "smelter",   "inputs": {"iron_ore": 1},
                     "outputs": {"iron_bar": 1},   "time": 2.5, "cost": 1.0, "requires": None},
    "smelt_copper": {"name": "Kupfer schmelzen", "machine": "smelter",   "inputs": {"copper_ore": 1},
                     "outputs": {"copper_bar": 1}, "time": 2.5, "cost": 1.0, "requires": None},
    # --- Hochofen
    "steel_coal":   {"name": "Stahl mit Kohle",  "machine": "blast_furnace", "inputs": {"iron_bar": 1, "coal": 1},
                     "outputs": {"steel": 1},      "time": 3.0, "cost": 1.5, "requires": "steelworks"},
    "steel":        {"name": "Stahl (2 Eisen)",  "machine": "blast_furnace", "inputs": {"iron_bar": 2},
                     "outputs": {"steel": 1},      "time": 4.0, "cost": 2.0, "requires": "steelworks"},
    "steel_beam":   {"name": "Stahlträger",      "machine": "blast_furnace", "inputs": {"steel": 2},
                     "outputs": {"steel_beam": 1}, "time": 4.0, "cost": 2.5, "requires": "construction"},
    # --- Baustoffwerk
    "brick":        {"name": "Ziegel brennen",   "machine": "kiln",      "inputs": {"stone": 2},
                     "outputs": {"brick": 1},      "time": 2.5, "cost": 1.0, "requires": "materials"},
    "glass":        {"name": "Glas schmelzen",   "machine": "kiln",      "inputs": {"sand": 2},
                     "outputs": {"glass": 1},      "time": 3.0, "cost": 1.2, "requires": "materials"},
    "concrete":     {"name": "Beton mischen",    "machine": "kiln",      "inputs": {"stone": 1, "sand": 1},
                     "outputs": {"concrete": 1},   "time": 2.5, "cost": 1.0, "requires": "construction"},
    # --- Montageanlage (Mechanik)
    "gear":         {"name": "Zahnrad",          "machine": "assembler", "inputs": {"iron_bar": 2},
                     "outputs": {"gear": 1},       "time": 3.0, "cost": 2.0, "requires": None},
    "wire":         {"name": "Kupferdraht",      "machine": "assembler", "inputs": {"copper_bar": 1},
                     "outputs": {"wire": 2},       "time": 2.0, "cost": 1.0, "requires": None},
    "motor":        {"name": "Motor",            "machine": "assembler", "inputs": {"gear": 2, "steel": 1, "wire": 2},
                     "outputs": {"motor": 1},      "time": 8.0, "cost": 8.0, "requires": "motors"},
    # --- Chemiewerk
    "plastic":      {"name": "Kunststoff",       "machine": "chemical",  "inputs": {"coal": 2},
                     "outputs": {"plastic": 1},    "time": 3.0, "cost": 1.5, "requires": "chemistry"},
    "battery":      {"name": "Batterie",         "machine": "chemical",  "inputs": {"copper_bar": 1, "coal": 1, "wire": 1},
                     "outputs": {"battery": 1},    "time": 4.0, "cost": 3.0, "requires": "batteries"},
    # --- Elektronikwerk
    "circuit":      {"name": "Schaltkreis",      "machine": "electronics", "inputs": {"wire": 3, "plastic": 1},
                     "outputs": {"circuit": 1},    "time": 5.0, "cost": 4.0, "requires": "electronics"},
    "processor":    {"name": "Prozessor",        "machine": "electronics", "inputs": {"circuit": 2, "glass": 1},
                     "outputs": {"processor": 1},  "time": 6.0, "cost": 5.0, "requires": "computing"},
    "computer":     {"name": "Computer",         "machine": "electronics",
                     "inputs": {"processor": 1, "plastic": 2, "glass": 1, "wire": 2},
                     "outputs": {"computer": 1},   "time": 8.0, "cost": 8.0, "requires": "computing"},
    # --- Großfabrik (Endprodukte)
    "solar_panel":  {"name": "Solarmodul",       "machine": "factory",   "inputs": {"glass": 2, "circuit": 1, "steel_beam": 1},
                     "outputs": {"solar_panel": 1}, "time": 7.0, "cost": 8.0, "requires": "solar_tech"},
    "house":        {"name": "Fertighaus",       "machine": "factory",   "inputs": {"brick": 4, "concrete": 2, "glass": 2, "steel_beam": 1},
                     "outputs": {"house": 1},      "time": 10.0, "cost": 9.0, "requires": "prefab"},
    "robot":        {"name": "Roboter",          "machine": "factory",   "inputs": {"motor": 1, "computer": 1, "steel_beam": 1},
                     "outputs": {"robot": 1},      "time": 14.0, "cost": 20.0, "requires": "robotics"},
    "ecar":         {"name": "Elektroauto",      "machine": "factory",
                     "inputs": {"motor": 2, "battery": 4, "steel_beam": 2, "computer": 1, "plastic": 2},
                     "outputs": {"ecar": 1},       "time": 20.0, "cost": 35.0, "requires": "emobility"},
}
# Maschinen, bei denen man das Rezept im Infofenster auswählt
MACHINE_RECIPES = {
    "blast_furnace": ["steel_coal", "steel", "steel_beam"],
    "kiln":          ["brick", "glass", "concrete"],
    "assembler":     ["gear", "wire", "motor"],
    "chemical":      ["plastic", "battery"],
    "electronics":   ["circuit", "processor", "computer"],
    "factory":       ["solar_panel", "house", "robot", "ecar"],
}
# ---------------------------------------------------------------------------
# Mond (ab Version 2.10): eigene Rohstoffe, Rezepte und Währung (Mooncoins)
# Rezepte mit "planet": "moon" gibt es nur auf dem Mond, alle anderen nur auf der Erde.
# ---------------------------------------------------------------------------
PLANETS = ("earth", "moon")
MOON_START_MONEY = 3000.0
CURRENCY = {"earth": "€", "moon": "MC"}
MOON_ITEMS = {
    "moon_rock":     {"name": "Mondstein",         "color": (0.74, 0.74, 0.76), "price": 4.0},
    "moon_coal":     {"name": "Mondkohle",         "color": (0.10, 0.11, 0.16), "price": 5.0},
    "titanium_ore":  {"name": "Titanerz",          "color": (0.55, 0.62, 0.78), "price": 7.0},
    "helium3":       {"name": "Helium-3",          "color": (0.55, 0.95, 0.88), "price": 9.0},
    "moon_ice":      {"name": "Mondeis",           "color": (0.82, 0.93, 1.00), "price": 6.0},
    "titanium_bar":  {"name": "Titanbarren",       "color": (0.80, 0.84, 0.92), "price": 22.0},
    "water":         {"name": "Wasser",            "color": (0.25, 0.55, 0.95), "price": 14.0},
    "moon_brick":    {"name": "Mondziegel",        "color": (0.58, 0.57, 0.60), "price": 12.0},
    "moon_concrete": {"name": "Mondbeton",         "color": (0.86, 0.86, 0.84), "price": 30.0},
    "titan_alloy":   {"name": "Titanlegierung",    "color": (0.48, 0.55, 0.72), "price": 60.0},
    "rocket_fuel":   {"name": "Raketentreibstoff", "color": (0.98, 0.45, 0.15), "price": 45.0},
    "fusion_cell":   {"name": "Fusionszelle",      "color": (0.35, 1.00, 0.70), "price": 120.0},
    "titan_frame":   {"name": "Titanrahmen",       "color": (0.68, 0.72, 0.82), "price": 150.0},
    "habitat":       {"name": "Mondhabitat",       "color": (0.95, 0.95, 0.98), "price": 900.0},
    "rover":         {"name": "Mondrover",         "color": (0.95, 0.80, 0.25), "price": 1600.0},
}
ITEMS.update(MOON_ITEMS)
MOON_ITEM_ORDER = ["moon_rock", "moon_coal", "titanium_ore", "helium3", "moon_ice",
                   "titanium_bar", "water", "moon_brick", "moon_concrete", "titan_alloy",
                   "rocket_fuel", "fusion_cell", "titan_frame", "habitat", "rover"]
MOON_DEPOSIT_ITEMS = ["moon_rock", "moon_coal", "titanium_ore", "helium3", "moon_ice"]
MOON_RECIPES = {
    "smelt_titanium": {"name": "Titan schmelzen",   "machine": "smelter", "inputs": {"titanium_ore": 1},
                       "outputs": {"titanium_bar": 1}, "time": 2.5, "cost": 1.0},
    "melt_ice":       {"name": "Eis schmelzen",     "machine": "smelter", "inputs": {"moon_ice": 1},
                       "outputs": {"water": 1},      "time": 2.0, "cost": 0.8},
    "moon_brick":     {"name": "Mondziegel pressen", "machine": "kiln",   "inputs": {"moon_rock": 2},
                       "outputs": {"moon_brick": 1}, "time": 2.5, "cost": 1.0},
    "moon_concrete":  {"name": "Mondbeton mischen", "machine": "kiln",    "inputs": {"moon_rock": 1, "water": 1},
                       "outputs": {"moon_concrete": 1}, "time": 3.0, "cost": 1.2},
    "titan_alloy":    {"name": "Titanlegierung",    "machine": "blast_furnace",
                       "inputs": {"titanium_bar": 1, "moon_coal": 1},
                       "outputs": {"titan_alloy": 1}, "time": 3.5, "cost": 1.8},
    "rocket_fuel":    {"name": "Raketentreibstoff", "machine": "chemical", "inputs": {"helium3": 1, "water": 1},
                       "outputs": {"rocket_fuel": 1}, "time": 3.0, "cost": 1.6},
    "fusion_cell":    {"name": "Fusionszelle",      "machine": "chemical",
                       "inputs": {"helium3": 2, "titanium_bar": 1},
                       "outputs": {"fusion_cell": 1}, "time": 5.0, "cost": 3.0},
    "titan_frame":    {"name": "Titanrahmen",       "machine": "assembler", "inputs": {"titan_alloy": 2},
                       "outputs": {"titan_frame": 1}, "time": 4.0, "cost": 2.5},
    "habitat":        {"name": "Mondhabitat",       "machine": "factory",
                       "inputs": {"moon_brick": 4, "moon_concrete": 2, "titan_frame": 1},
                       "outputs": {"habitat": 1},    "time": 10.0, "cost": 9.0},
    "rover":          {"name": "Mondrover",         "machine": "factory",
                       "inputs": {"titan_frame": 2, "fusion_cell": 2, "rocket_fuel": 2},
                       "outputs": {"rover": 1},      "time": 14.0, "cost": 16.0},
}
_MOON_RECIPE_REQ = {"moon_concrete": "m_concrete", "fusion_cell": "m_fusion", "rover": "m_rover"}
for _rid, _r in MOON_RECIPES.items():
    _r.update(requires=_MOON_RECIPE_REQ.get(_rid), planet="moon")
    RECIPES[_rid] = _r
    if _r["machine"] in MACHINE_RECIPES:
        MACHINE_RECIPES[_r["machine"]].append(_rid)
# Mond-Versionen der Gebäude: anderer Name, anderer Look, eigene Forschung – gleiche Funktion
MOON_BUILDING_INFO = {
    "miner":         ("Mondbohrer", None,
                      "Bohrt Mond-Erz aus dem Regolith. Muss auf einem Vorkommen stehen. Gibt nach vorne aus."),
    "storage":       ("Kuppellager", None,
                      "Lagert angelieferte Waren unter einer Druckkuppel. Von dort manuell verkaufbar (M)."),
    "conveyor":      ("Magnetband", "m_belts",
                      "Schwebebahn für Waren in Pfeilrichtung. Nimmt von hinten und von den Seiten an."),
    "seller":        ("Raumfracht-Händler", "m_trade",
                      "Schickt angelieferte Waren zur Erde und verkauft sie automatisch. Mindestpreis einstellbar."),
    "splitter":      ("Magnetweiche", "m_routing",
                      "Nimmt von hinten an und verteilt abwechselnd nach vorne, links und rechts."),
    "tpiece":        ("Magnet-T-Weiche", "m_routing",
                      "Nimmt von hinten an und verteilt abwechselnd nach links und rechts."),
    "sorter":        ("Magnetsortierer", "m_sorting",
                      "Schickt jede Warenart in die eingestellte Richtung. Nicht eingestellte Waren gehen nach vorne."),
    "smelter":       ("Plasmaschmelze", "m_smelt",
                      "Schmilzt Titanerz zu Barren und Mondeis zu Wasser. Nimmt von allen Seiten an, gibt nach vorne aus."),
    "kiln":          ("Regolithpresse", "m_regolith",
                      "Presst Mondziegel aus Mondstein und mischt Mondbeton. Rezept wählbar."),
    "blast_furnace": ("Titanschmiede", "m_titan",
                      "Schmiedet Titanlegierung aus Titanbarren und Mondkohle."),
    "assembler":     ("Robotermontage", "m_assembly",
                      "Roboterarme bauen Titanrahmen aus Titanlegierung."),
    "chemical":      ("Helium-Raffinerie", "m_helium",
                      "Macht Raketentreibstoff und Fusionszellen aus Helium-3. Rezept wählbar."),
    "factory":       ("Mondwerft", "m_shipyard",
                      "Baut Mondhabitate und Mondrover – die wertvollsten Waren des Mondes. Rezept wählbar."),
}

# Forschungsbaum des Mondes (eigene Reiter, bezahlt in Mooncoins)
MOON_RESEARCH = {
    # --- Reiter m: Gebäude & Produkte
    "m_belts":    {"name": "Magnetbahn", "cost": 400, "time": 12, "requires": [],
                   "effects": {"unlock": "conveyor"}, "tab": "m", "pos": (0, 0),
                   "desc": "Schaltet Magnetbänder frei."},
    "m_trade":    {"name": "Mondhandel", "cost": 1200, "time": 20, "requires": ["m_belts"],
                   "effects": {"unlock": "seller"}, "tab": "m", "pos": (1, 0),
                   "desc": "Raumfracht-Händler verkaufen Waren automatisch zur Erde."},
    "m_routing":  {"name": "Magnetweichen", "cost": 1000, "time": 18, "requires": ["m_belts"],
                   "effects": {"unlock": "splitter"}, "tab": "m", "pos": (1, 1),
                   "desc": "Schaltet Magnetweiche und Magnet-T-Weiche frei."},
    "m_sorting":  {"name": "Magnetsortierung", "cost": 2500, "time": 25, "requires": ["m_routing"],
                   "effects": {"unlock": "sorter"}, "tab": "m", "pos": (2, 1),
                   "desc": "Schaltet Magnetsortierer frei."},
    "m_smelt":    {"name": "Plasmaschmelzen", "cost": 700, "time": 16, "requires": [],
                   "effects": {"unlock": "smelter"}, "tab": "m", "pos": (0, 2),
                   "desc": "Plasmaschmelze: Titanbarren aus Titanerz, Wasser aus Mondeis."},
    "m_regolith": {"name": "Regolithverarbeitung", "cost": 1600, "time": 22, "requires": ["m_smelt"],
                   "effects": {"unlock": "kiln"}, "tab": "m", "pos": (1, 2),
                   "desc": "Regolithpresse: Mondziegel aus Mondstein."},
    "m_concrete": {"name": "Mondbeton", "cost": 5000, "time": 35, "requires": ["m_regolith"],
                   "effects": {"unlock_recipe": "moon_concrete"}, "tab": "m", "pos": (2, 2),
                   "desc": "Regolithpresse mischt Mondbeton aus Mondstein und Wasser."},
    "m_titan":    {"name": "Titanschmiede", "cost": 6000, "time": 35, "requires": ["m_smelt"],
                   "effects": {"unlock": "blast_furnace"}, "tab": "m", "pos": (1, 3),
                   "desc": "Titanschmiede: Titanlegierung aus Titanbarren und Mondkohle."},
    "m_assembly": {"name": "Robotermontage", "cost": 9000, "time": 40, "requires": ["m_titan"],
                   "effects": {"unlock": "assembler"}, "tab": "m", "pos": (2, 3),
                   "desc": "Robotermontage baut Titanrahmen."},
    "m_helium":   {"name": "Helium-Raffinerie", "cost": 4000, "time": 30, "requires": ["m_smelt"],
                   "effects": {"unlock": "chemical"}, "tab": "m", "pos": (1, 4),
                   "desc": "Helium-Raffinerie macht Raketentreibstoff aus Helium-3 und Wasser."},
    "m_fusion":   {"name": "Fusionstechnik", "cost": 16000, "time": 55, "requires": ["m_helium"],
                   "effects": {"unlock_recipe": "fusion_cell"}, "tab": "m", "pos": (2, 4),
                   "desc": "Helium-Raffinerie baut Fusionszellen."},
    "m_shipyard": {"name": "Mondwerft", "cost": 22000, "time": 60, "requires": ["m_assembly", "m_concrete"],
                   "effects": {"unlock": "factory"}, "tab": "m", "pos": (3, 3),
                   "desc": "Mondwerft baut Mondhabitate."},
    "m_rover":    {"name": "Rover-Bau", "cost": 50000, "time": 90, "requires": ["m_shipyard", "m_fusion"],
                   "effects": {"unlock_recipe": "rover"}, "tab": "m", "pos": (4, 3),
                   "desc": "Mondwerft baut Mondrover – das wertvollste Produkt des Mondes."},
    # --- Reiter n: Verbesserungen
    "m_storage_2": {"name": "Druckkuppel II", "cost": 1500, "time": 20, "requires": [],
                    "effects": {"storage_mult": 2.0}, "tab": "n", "pos": (0, 0),
                    "desc": "Verdoppelt die Kapazität aller Kuppellager."},
    "m_storage_3": {"name": "Tiefkuppel", "cost": 6000, "time": 35, "requires": ["m_storage_2"],
                    "effects": {"storage_mult": 2.0}, "tab": "n", "pos": (1, 0),
                    "desc": "Verdoppelt die Lagerkapazität erneut."},
    "m_drill_1":  {"name": "Diamantbohrkopf", "cost": 2000, "time": 22, "requires": [],
                   "effects": {"miner_mult": 1.5}, "tab": "n", "pos": (0, 1),
                   "desc": "Mondbohrer fördern 50 % schneller."},
    "m_drill_2":  {"name": "Laserbohrer", "cost": 9000, "time": 45, "requires": ["m_drill_1"],
                   "effects": {"miner_mult": 1.5}, "tab": "n", "pos": (1, 1),
                   "desc": "Mondbohrer fördern nochmal 50 % schneller."},
    "m_belt_1":   {"name": "Supraleiter-Bänder", "cost": 3000, "time": 25, "requires": ["m_belts"],
                   "effects": {"belt_mult": 1.5}, "tab": "n", "pos": (0, 2),
                   "desc": "Magnetbänder laufen 50 % schneller."},
    "m_belt_2":   {"name": "Quantenbahn", "cost": 12000, "time": 50, "requires": ["m_belt_1"],
                   "effects": {"belt_mult": 1.5}, "tab": "n", "pos": (1, 2),
                   "desc": "Magnetbänder laufen nochmal 50 % schneller."},
    "m_speed_1":  {"name": "Mondautomatik", "cost": 4000, "time": 30, "requires": [],
                   "effects": {"speed_mult": 1.25}, "tab": "n", "pos": (0, 3),
                   "desc": "Alle Maschinen arbeiten 25 % schneller."},
    "m_speed_2":  {"name": "KI-Steuerung", "cost": 15000, "time": 55, "requires": ["m_speed_1"],
                   "effects": {"speed_mult": 1.25}, "tab": "n", "pos": (1, 3),
                   "desc": "Alle Maschinen arbeiten nochmal 25 % schneller."},
    "m_solar":    {"name": "Mond-Solarfelder", "cost": 5000, "time": 35, "requires": [],
                   "effects": {"cost_mult": 0.8}, "tab": "n", "pos": (0, 4),
                   "desc": "Energiekosten sinken um 20 % – auf dem Mond scheint die Sonne 14 Tage am Stück."},
    "m_export":   {"name": "Erd-Export", "cost": 8000, "time": 40, "requires": ["m_trade"],
                   "effects": {"price_mult": 1.2}, "tab": "n", "pos": (0, 5),
                   "desc": "Mond-Waren bringen 20 % mehr Mooncoins."},
}
ROCKET_PRICE = 7_000_000           # einmalig freischalten (je Welt), danach fliegt jeder kostenlos

# Gebäude, die es auf dem Mond gibt (kein Frachtbahnhof – dort gibt es keine Städte, kein Elektronikwerk)
MOON_BUILDINGS = ("miner", "smelter", "conveyor", "seller", "storage", "assembler", "splitter", "tpiece",
                  "sorter", "factory", "kiln", "blast_furnace", "chemical")
# Geheimer Code für die Test-Welt mit Mond-Vorschau (nur der SHA-256 steht hier)
TEST_WORLD_CODE_SHA = "4351b637523d41ab1022ef2dabb9965fd65efc8fb25783d66ec61ed0ca39e7f4"

ASSEMBLER_RECIPES = MACHINE_RECIPES["assembler"]
RECIPE_MACHINES = tuple(MACHINE_RECIPES)

# ---------------------------------------------------------------------------
# Gebäude
# category: production | logistics | trade   (Gruppierung im Kaufmenü)
# ---------------------------------------------------------------------------
BUILDINGS = {
    "miner": {
        "name": "Miner", "hotkey": "1", "cost": 300, "requires": None, "max_level": 3, "category": "production",
        "time": 2.0, "out_cap": 4,
        "desc": "Fördert Erz. Muss auf einem Erzvorkommen stehen. Gibt nach vorne aus.",
    },
    "smelter": {
        "name": "Schmelze", "hotkey": "2", "cost": 600, "requires": "smelting", "max_level": 3, "category": "production",
        "in_cap": 6, "out_cap": 6,
        "desc": "Schmilzt Eisen- und Kupfererz zu Barren. Nimmt von allen Seiten an, gibt nach vorne aus.",
    },
    "conveyor": {
        "name": "Förderband", "hotkey": "3", "cost": 20, "requires": "logistics", "max_level": 1, "category": "logistics",
        "capacity": 3,
        "desc": "Transportiert Gegenstände in Pfeilrichtung. Nimmt von hinten und von den Seiten an.",
    },
    "seller": {
        "name": "Verkäufer", "hotkey": "4", "cost": 800, "requires": "auto_sell", "max_level": 3, "category": "trade",
        "time": 0.6, "in_cap": 4,
        "desc": "Verkauft angelieferte Waren automatisch. Mindestpreis im Infofenster einstellbar.",
    },
    "storage": {
        "name": "Lager", "hotkey": "5", "cost": 400, "requires": None, "max_level": 3, "category": "trade",
        "capacity": 200,
        "desc": "Lagert angelieferte Waren im Firmenlager. Von dort manuell verkaufbar (M).",
    },
    "assembler": {
        "name": "Montageanlage", "hotkey": "6", "cost": 1500, "requires": "advanced_production", "max_level": 3,
        "category": "production", "in_cap": 8, "out_cap": 6,
        "desc": "Mechanik: Zahnräder, Kupferdraht und Motoren. Rezept im Infofenster wählbar.",
    },
    "splitter": {
        "name": "Splitter", "hotkey": "7", "cost": 60, "requires": "belt_routing", "max_level": 1, "category": "logistics",
        "capacity": 2, "outputs": ["F", "L", "R"],
        "desc": "Nimmt von hinten an und verteilt abwechselnd nach vorne, links und rechts.",
    },
    "tpiece": {
        "name": "T-Stück", "hotkey": "8", "cost": 50, "requires": "belt_routing", "max_level": 1, "category": "logistics",
        "capacity": 2, "outputs": ["L", "R"],
        "desc": "Nimmt von hinten an und verteilt abwechselnd nach links und rechts.",
    },
    "factory": {
        "name": "Großfabrik", "hotkey": "0", "cost": 6000, "requires": "factory_hall", "max_level": 3,
        "category": "production", "in_cap": 12, "out_cap": 4,
        "desc": "Baut Endprodukte: Solarmodule, Fertighäuser, Roboter und Elektroautos. Rezept wählbar.",
    },
    "blast_furnace": {
        "name": "Hochofen", "hotkey": "", "cost": 2500, "requires": "steelworks", "max_level": 3,
        "category": "production", "in_cap": 8, "out_cap": 6,
        "desc": "Kocht Stahl (Eisen + Kohle oder 2 Eisen) und walzt Stahlträger. Rezept wählbar.",
    },
    "kiln": {
        "name": "Baustoffwerk", "hotkey": "", "cost": 1200, "requires": "materials", "max_level": 3,
        "category": "production", "in_cap": 8, "out_cap": 6,
        "desc": "Brennt Ziegel aus Stein, schmilzt Glas aus Sand und mischt Beton. Rezept wählbar.",
    },
    "chemical": {
        "name": "Chemiewerk", "hotkey": "", "cost": 3500, "requires": "chemistry", "max_level": 3,
        "category": "production", "in_cap": 8, "out_cap": 6,
        "desc": "Macht Kunststoff aus Kohle und baut Batterien. Rezept wählbar.",
    },
    "electronics": {
        "name": "Elektronikwerk", "hotkey": "", "cost": 4500, "requires": "electronics", "max_level": 3,
        "category": "production", "in_cap": 10, "out_cap": 4,
        "desc": "Fertigt Schaltkreise, Prozessoren und Computer. Rezept wählbar.",
    },
    "freight": {
        "name": "Frachtbahnhof", "hotkey": "", "cost": 3000, "requires": "freight", "max_level": 3,
        "category": "trade",
        "desc": "LKW-Verladestation für Aufträge (O). Nimmt Waren von allen Seiten an und belädt damit den "
                "LKW des Auftrags. Jede Ausbaustufe bringt einen weiteren LKW.",
    },
    "sorter": {
        "name": "Sortierer", "hotkey": "9", "cost": 150, "requires": "sorting", "max_level": 1, "category": "logistics",
        "capacity": 2, "outputs": ["F", "L", "R"],
        "desc": "Schickt jede Warenart in die eingestellte Richtung. Nicht eingestellte Waren gehen nach vorne.",
    },
}
BUILDING_ORDER = ["miner", "smelter", "conveyor", "seller", "storage", "assembler", "splitter", "tpiece", "sorter",
                  "factory", "kiln", "blast_furnace", "chemical", "electronics", "freight"]
ROUTER_TYPES = ("splitter", "tpiece", "sorter")
BELT_LIKE = ("conveyor",) + ROUTER_TYPES      # flache Gebäude, über die man laufen kann
CATEGORIES = [("production", "Produktion"), ("logistics", "Logistik"), ("trade", "Lager & Handel")]

LEVEL_SPEED = {1: 1.0, 2: 1.5, 3: 2.0}           # Produktionsgeschwindigkeit je Ausbaustufe
LEVEL_CAPACITY = {1: 1.0, 2: 1.5, 3: 2.0}        # Lagerkapazität je Ausbaustufe
LEVEL_TRUCKS = {1: 1, 2: 2, 3: 3}                 # LKW je Frachtbahnhof-Stufe
UPGRADE_COST_FACTOR = 0.8                         # Upgradekosten = Baukosten * Faktor * aktuelle Stufe
DEMOLISH_REFUND = 0.5                             # Rückerstattung beim Abriss

BELT_SPEED = 1.25                                 # Kacheln pro Sekunde
BELT_SPACING = 0.34                               # Mindestabstand der Gegenstände auf einem Band

# Verkäufer: verkauft nur, wenn der Marktpreis mindestens X % über dem Grundpreis liegt
SELLER_THRESHOLDS = [None, -10, 0, 5, 10, 15, 20, 25]   # None = immer verkaufen

# ---------------------------------------------------------------------------
# Forschung
# "pos" bestimmt nur die Darstellung im Forschungsbaum (Spalte, Zeile).
# Effekte: unlock (Gebäude), unlock_recipe, speed_mult, miner_mult, storage_mult,
#          belt_mult, price_mult, cost_mult (Multiplikatoren werden multipliziert)
# ---------------------------------------------------------------------------
RESEARCH = {
    "logistics": {
        "name": "Logistik", "cost": 400, "time": 12, "requires": [],
        "effects": {'unlock': 'conveyor'}, "tab": "a", "pos": (0, 0),
        "desc": "Schaltet Förderbänder frei.",
    },
    "smelting": {
        "name": "Schmelztechnik", "cost": 700, "time": 18, "requires": [],
        "effects": {'unlock': 'smelter'}, "tab": "a", "pos": (0, 2),
        "desc": "Schaltet Schmelzen frei (Eisen- und Kupferbarren).",
    },
    "auto_sell": {
        "name": "Automatischer Verkauf", "cost": 1200, "time": 22, "requires": ['logistics'],
        "effects": {'unlock': 'seller'}, "tab": "a", "pos": (1, 0),
        "desc": "Schaltet Verkäufer frei.",
    },
    "freight": {
        "name": "Spedition", "cost": 2500, "time": 25, "requires": ['auto_sell'],
        "effects": {'unlock': 'freight'}, "tab": "a", "pos": (2, 0),
        "desc": "Frachtbahnhof und Auftragsbörse (O): LKW liefern Waren in andere Städte - gut bezahlt.",
    },
    "highway": {
        "name": "Autobahnanbindung", "cost": 12000, "time": 50, "requires": ['freight'],
        "effects": {'travel_mult': 0.7}, "tab": "a", "pos": (3, 0),
        "desc": "LKW-Fahrten dauern 30 % kürzer.",
    },
    "belt_routing": {
        "name": "Verteiltechnik", "cost": 1000, "time": 18, "requires": ['logistics'],
        "effects": {'unlock': 'splitter'}, "tab": "a", "pos": (1, 1),
        "desc": "Schaltet Splitter und T-Stück frei.",
    },
    "materials": {
        "name": "Baustoffe", "cost": 1500, "time": 20, "requires": ['smelting'],
        "effects": {'unlock': 'kiln'}, "tab": "a", "pos": (1, 2),
        "desc": "Baustoffwerk: Ziegel aus Stein, Glas aus Sand.",
    },
    "advanced_production": {
        "name": "Fortgeschrittene Produktion", "cost": 5000, "time": 40, "requires": ['smelting', 'logistics'],
        "effects": {'unlock': 'assembler'}, "tab": "a", "pos": (1, 3),
        "desc": "Montageanlage: Zahnräder und Kupferdraht.",
    },
    "chemistry": {
        "name": "Chemie", "cost": 4000, "time": 35, "requires": ['smelting'],
        "effects": {'unlock': 'chemical'}, "tab": "a", "pos": (1, 5),
        "desc": "Chemiewerk: Kunststoff aus Kohle.",
    },
    "sorting": {
        "name": "Sortiertechnik", "cost": 2500, "time": 25, "requires": ['belt_routing'],
        "effects": {'unlock': 'sorter'}, "tab": "a", "pos": (2, 1),
        "desc": "Schaltet den Sortierer frei.",
    },
    "steelworks": {
        "name": "Stahlverhüttung", "cost": 7000, "time": 40, "requires": ['advanced_production'],
        "effects": {'unlock': 'blast_furnace'}, "tab": "a", "pos": (2, 3),
        "desc": "Hochofen: Stahl aus Eisen und Kohle.",
    },
    "electronics": {
        "name": "Elektronik", "cost": 8000, "time": 45, "requires": ['advanced_production', 'chemistry'],
        "effects": {'unlock': 'electronics'}, "tab": "a", "pos": (2, 4),
        "desc": "Elektronikwerk: Schaltkreise aus Draht und Kunststoff.",
    },
    "batteries": {
        "name": "Akkutechnik", "cost": 9000, "time": 45, "requires": ['chemistry', 'advanced_production'],
        "effects": {'unlock_recipe': 'battery'}, "tab": "a", "pos": (2, 5),
        "desc": "Chemiewerk baut Batterien.",
    },
    "construction": {
        "name": "Bauindustrie", "cost": 6000, "time": 40, "requires": ['materials', 'steelworks'],
        "effects": {'unlock_recipe': ['concrete', 'steel_beam']}, "tab": "a", "pos": (3, 2),
        "desc": "Beton (Baustoffwerk) und Stahlträger (Hochofen).",
    },
    "motors": {
        "name": "Motorenbau", "cost": 20000, "time": 70, "requires": ['steelworks', 'electronics'],
        "effects": {'unlock_recipe': 'motor'}, "tab": "a", "pos": (3, 3),
        "desc": "Montageanlagen bauen Motoren.",
    },
    "computing": {
        "name": "Computertechnik", "cost": 16000, "time": 60, "requires": ['electronics'],
        "effects": {'unlock_recipe': ['processor', 'computer']}, "tab": "a", "pos": (3, 4),
        "desc": "Elektronikwerk: Prozessoren und Computer.",
    },
    "factory_hall": {
        "name": "Großfertigung", "cost": 18000, "time": 60, "requires": ['construction', 'electronics'],
        "effects": {'unlock': 'factory'}, "tab": "a", "pos": (4, 2),
        "desc": "Schaltet die Großfabrik für Endprodukte frei.",
    },
    "solar_tech": {
        "name": "Solarmodule", "cost": 22000, "time": 60, "requires": ['factory_hall'],
        "effects": {'unlock_recipe': 'solar_panel'}, "tab": "a", "pos": (5, 0),
        "desc": "Großfabrik baut Solarmodule.",
    },
    "prefab": {
        "name": "Fertighausbau", "cost": 20000, "time": 60, "requires": ['factory_hall'],
        "effects": {'unlock_recipe': 'house'}, "tab": "a", "pos": (5, 1),
        "desc": "Großfabrik baut Fertighäuser.",
    },
    "robotics": {
        "name": "Robotik", "cost": 45000, "time": 90, "requires": ['factory_hall', 'motors', 'computing'],
        "effects": {'unlock_recipe': 'robot'}, "tab": "a", "pos": (5, 3),
        "desc": "Großfabrik baut Roboter.",
    },
    "emobility": {
        "name": "Elektromobilität", "cost": 80000, "time": 120, "requires": ['batteries', 'factory_hall', 'motors', 'computing'],
        "effects": {'unlock_recipe': 'ecar'}, "tab": "a", "pos": (5, 5),
        "desc": "Großfabrik baut Elektroautos - das wertvollste Produkt.",
    },
    "storage_2": {
        "name": "Erweiterte Lagerung", "cost": 1500, "time": 20, "requires": ['logistics'],
        "effects": {'storage_mult': 2.0}, "tab": "b", "pos": (0, 0),
        "desc": "Verdoppelt die Kapazität aller Lager.",
    },
    "storage_3": {
        "name": "Hochregallager", "cost": 6000, "time": 35, "requires": ['storage_2', 'automation_1'],
        "effects": {'storage_mult': 2.0}, "tab": "b", "pos": (1, 0),
        "desc": "Verdoppelt die Lagerkapazität erneut.",
    },
    "logistics_center": {
        "name": "Logistikzentrum", "cost": 25000, "time": 70, "requires": ['storage_3', 'automation_2'],
        "effects": {'storage_mult': 2.0}, "tab": "b", "pos": (2, 0),
        "desc": "Nochmals doppelte Lagerkapazität.",
    },
    "automation_1": {
        "name": "Automatisierung I", "cost": 2500, "time": 30, "requires": ['logistics', 'smelting'],
        "effects": {'speed_mult': 1.25}, "tab": "b", "pos": (0, 1),
        "desc": "+25 % Produktionsgeschwindigkeit aller Maschinen.",
    },
    "automation_2": {
        "name": "Automatisierung II", "cost": 12000, "time": 60, "requires": ['automation_1', 'advanced_production'],
        "effects": {'speed_mult': 1.4}, "tab": "b", "pos": (1, 1),
        "desc": "Weitere +40 % Produktionsgeschwindigkeit.",
    },
    "automation_3": {
        "name": "Automatisierung III", "cost": 40000, "time": 90, "requires": ['automation_2', 'motors'],
        "effects": {'speed_mult': 1.5}, "tab": "b", "pos": (2, 1),
        "desc": "Weitere +50 % Produktionsgeschwindigkeit.",
    },
    "automation_4": {
        "name": "Automatisierung IV", "cost": 120000, "time": 150, "requires": ['automation_3', 'computing'],
        "effects": {'speed_mult': 1.5}, "tab": "b", "pos": (3, 1),
        "desc": "Weitere +50 % - vollautomatische Fertigung.",
    },
    "fast_belts": {
        "name": "Schnelle Förderbänder", "cost": 3000, "time": 25, "requires": ['automation_1'],
        "effects": {'belt_mult': 1.6}, "tab": "b", "pos": (1, 2),
        "desc": "Förderbänder laufen 60 % schneller.",
    },
    "express_belts": {
        "name": "Express-Bänder", "cost": 15000, "time": 55, "requires": ['fast_belts', 'automation_2'],
        "effects": {'belt_mult': 1.5}, "tab": "b", "pos": (2, 2),
        "desc": "Förderbänder laufen nochmals 50 % schneller.",
    },
    "maglev_belts": {
        "name": "Magnetschwebebänder", "cost": 60000, "time": 100, "requires": ['express_belts', 'electronics'],
        "effects": {'belt_mult': 1.4}, "tab": "b", "pos": (3, 2),
        "desc": "Nochmals +40 % Bandgeschwindigkeit.",
    },
    "deep_drilling": {
        "name": "Tiefbohrung", "cost": 1800, "time": 24, "requires": ['smelting'],
        "effects": {'miner_mult': 1.3}, "tab": "b", "pos": (0, 3),
        "desc": "Miner fördern 30 % schneller.",
    },
    "mega_drill": {
        "name": "Großbohrer", "cost": 14000, "time": 50, "requires": ['deep_drilling', 'automation_2'],
        "effects": {'miner_mult': 1.5}, "tab": "b", "pos": (2, 3),
        "desc": "Miner fördern weitere 50 % schneller.",
    },
    "diamond_drill": {
        "name": "Diamantbohrer", "cost": 50000, "time": 90, "requires": ['mega_drill', 'steelworks'],
        "effects": {'miner_mult': 1.5}, "tab": "b", "pos": (3, 3),
        "desc": "Nochmals +50 % Fördermenge.",
    },
    "efficiency": {
        "name": "Energieeffizienz", "cost": 3500, "time": 30, "requires": ['automation_1'],
        "effects": {'cost_mult': 0.5}, "tab": "b", "pos": (1, 4),
        "desc": "Halbiert die Energiekosten der Produktion.",
    },
    "solar": {
        "name": "Solarenergie", "cost": 10000, "time": 50, "requires": ['efficiency'],
        "effects": {'cost_mult': 0.6}, "tab": "b", "pos": (2, 4),
        "desc": "Senkt die Energiekosten um weitere 40 %.",
    },
    "heat_recovery": {
        "name": "Abwärmenutzung", "cost": 30000, "time": 70, "requires": ['solar', 'steelworks'],
        "effects": {'cost_mult': 0.75}, "tab": "b", "pos": (3, 4),
        "desc": "Energiekosten nochmals -25 %.",
    },
    "fusion": {
        "name": "Fusionsreaktor", "cost": 150000, "time": 180, "requires": ['heat_recovery', 'computing'],
        "effects": {'cost_mult': 0.4}, "tab": "b", "pos": (4, 4),
        "desc": "Energiekosten -60 % - fast kostenlose Energie.",
    },
    "market_analysis": {
        "name": "Marktanalyse", "cost": 4000, "time": 30, "requires": ['auto_sell'],
        "effects": {'price_mult': 1.15}, "tab": "b", "pos": (0, 5),
        "desc": "+15 % Verkaufserlöse.",
    },
    "market_power": {
        "name": "Marktmacht", "cost": 9000, "time": 45, "requires": ['market_analysis'],
        "effects": {'price_mult': 1.15}, "tab": "b", "pos": (1, 5),
        "desc": "Weitere +15 % Verkaufserlöse.",
    },
    "trade_network": {
        "name": "Welthandel", "cost": 30000, "time": 80, "requires": ['market_power', 'motors'],
        "effects": {'price_mult': 1.25}, "tab": "b", "pos": (2, 5),
        "desc": "+25 % Verkaufserlöse auf alle Waren.",
    },
    "export": {
        "name": "Exportverträge", "cost": 70000, "time": 110, "requires": ['trade_network', 'computing'],
        "effects": {'price_mult': 1.2}, "tab": "b", "pos": (3, 5),
        "desc": "Weitere +20 % Erlöse.",
    },
    "brand": {
        "name": "Weltmarke", "cost": 160000, "time": 160, "requires": ['export', 'emobility'],
        "effects": {'price_mult': 1.25}, "tab": "b", "pos": (4, 5),
        "desc": "Deine Marke ist weltbekannt: +25 % Erlöse.",
    },
}
RESEARCH_TABS = [("a", "Gebäude & Produkte"), ("b", "Verbesserungen")]
# ---------------------------------------------------------------------------
# Markt
# ---------------------------------------------------------------------------
MARKET_SATURATION = 0.003     # Preisverfall pro verkauftem Stück (0,3 %)
MARKET_MIN_FACTOR = 0.45      # Preis fällt nie unter 45 % des Grundpreises
MARKET_RECOVERY = 0.015       # Erholung je Sekunde Richtung Nachfrageniveau
MARKET_DEMAND_INTERVAL = 30.0 # Sekunden zwischen Nachfrageänderungen
MARKET_DEMAND_RANGE = (0.85, 1.25)
MARKET_HISTORY_INTERVAL = 5.0
MARKET_HISTORY_LEN = 36

# ---------------------------------------------------------------------------
# Statuscodes (Server -> Client)
# ---------------------------------------------------------------------------
STATUS = {
    "idle":          {"text": "Leerlauf",                 "level": "warn"},
    "working":       {"text": "Produziert",               "level": "ok"},
    "no_input":      {"text": "Wartet auf Material",      "level": "warn"},
    "blocked":       {"text": "Ausgang blockiert",        "level": "error"},
    "no_output":     {"text": "Keine Ausgangsverbindung", "level": "error"},
    "bad_output":    {"text": "Ungültige Verbindung",     "level": "error"},
    "no_money":      {"text": "Kein Geld für Energie",    "level": "error"},
    "no_deposit":    {"text": "Kein Erzvorkommen",        "level": "error"},
    "full":          {"text": "Lager voll",               "level": "error"},
    "ok":            {"text": "Bereit",                   "level": "ok"},
    "off":           {"text": "Ausgeschaltet",            "level": "off"},
    "waiting_price": {"text": "Wartet auf Mindestpreis",  "level": "warn"},
    "no_order":      {"text": "Kein Auftrag (O drücken)", "level": "warn"},
    "trucks_away":   {"text": "Alle LKW unterwegs",       "level": "ok"},
}
STATUS_CODES = list(STATUS.keys())

# Spielerfarben (RGB 0..1)
PLAYER_COLORS = [
    (0.95, 0.55, 0.15), (0.20, 0.65, 0.95), (0.35, 0.85, 0.40), (0.90, 0.30, 0.55),
    (0.75, 0.55, 0.95), (0.95, 0.85, 0.25), (0.30, 0.90, 0.85), (0.95, 0.35, 0.30),
]


# ---------------------------------------------------------------------------
# Mond: Forschung und Gebäudenamen einhängen (die Erd-Tabellen sind oben vollständig definiert)
# ---------------------------------------------------------------------------
EARTH_BUILDING_INFO = {b: (v["name"], v["requires"], v["desc"]) for b, v in BUILDINGS.items()}
for _tid, _t in MOON_RESEARCH.items():
    _t["planet"] = "moon"
RESEARCH.update(MOON_RESEARCH)
RESEARCH_TABS = RESEARCH_TABS + [("m", "Mond: Gebäude & Produkte"), ("n", "Mond: Verbesserungen")]
RESEARCH_TAB_PLANET = {"a": "earth", "b": "earth", "m": "moon", "n": "moon"}


# ---------------------------------------------------------------------------
# Tastenbelegung (in den Optionen unter "Steuerung" änderbar)
# ---------------------------------------------------------------------------
KEY_ACTIONS = [
    ("buy_menu", "Kaufmenü", "q"),
    ("research", "Forschung", "r"),
    ("market", "Markt", "m"),
    ("orders", "Aufträge", "o"),
    ("chat", "Chat", "t"),
    ("rocket", "Rakete starten", "l"),
    ("rotate", "Drehen", "e"),
    ("demolish", "Abriss-Werkzeug", "x"),
    ("select", "Auswahl-Werkzeug", "space"),
    ("upgrade", "Ausbauen", "u"),
    ("move", "Versetzen", "g"),
    ("toggle", "Ein/Aus", "p"),
    ("help", "Hilfe", "f1"),
    ("admin", "Admin-Panel", "f2"),
    ("save", "Speichern", "f5"),
    ("load", "Laden", "f9"),
]
DEFAULT_KEYS = {a: k for a, _, k in KEY_ACTIONS}
# diese Tasten sind fest vergeben (Kamera, Gebäude 1-0, Menü ...)
RESERVED_KEYS = {"w", "a", "s", "d", "up arrow", "down arrow", "left arrow", "right arrow", "escape", "enter",
                 "f11", "delete", "backspace", "shift", "control", "alt", "tab"} | {str(i) for i in range(10)}

