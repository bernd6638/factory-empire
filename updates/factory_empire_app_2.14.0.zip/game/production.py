"""
Produktionslogik der Maschinen (läuft ausschließlich auf dem Server).

Jede Funktion bekommt den Spielzustand, das Gebäude und die Zeitspanne dt.
Maschinen produzieren nur, wenn alle Voraussetzungen erfüllt sind:
eingeschaltet, Rohstoffe im Eingang, Platz im Ausgang und genug Geld für die
Energie. Energiekosten werden nicht sofort, sondern gesammelt alle
ENERGY_INTERVAL Sekunden abgebucht (siehe GameState.tick).
"""

from . import config as C
from . import logistics
from . import rules


def machine_speed(state, b):
    return rules.machine_speed(b.type, b.level, state.speed_mult, state.miner_mult)


def tick_miner(state, b, dt):
    ore = state.deposits.get((b.x, b.y))
    if ore is None:
        b.status = "no_deposit"
        return
    push_state = logistics.push_outputs(state, b)
    spec = C.BUILDINGS["miner"]
    if sum(b.outbuf.values()) < spec["out_cap"]:
        b.progress += dt * machine_speed(state, b) / spec["time"]
        if b.progress >= 1.0:
            b.progress = 0.0
            b.outbuf[ore] = b.outbuf.get(ore, 0) + 1
            b.produced += 1
            state.count_production(b, ore, 1)
        b.status = "working"
    else:
        b.status = push_state or "blocked"
    if push_state in logistics.ERROR_STATES:
        b.status = push_state


def _available_recipes(state, b):
    if b.type in C.MACHINE_RECIPES:
        rid = b.recipe
        if rid in C.RECIPES and rules.recipe_unlocked(rid, state.research.unlocked):
            return [rid]
        return []
    return [rid for rid, r in C.RECIPES.items()
            if r["machine"] == b.type and rules.recipe_unlocked(rid, state.research.unlocked)]


def _inputs_ready(b, recipe):
    return all(b.inbuf.get(item, 0) >= qty for item, qty in recipe["inputs"].items())


def tick_crafter(state, b, dt):
    """Gemeinsame Logik für Schmelze und Montageanlage."""
    spec = C.BUILDINGS[b.type]
    push_state = logistics.push_outputs(state, b)

    if b.active_recipe:
        recipe = C.RECIPES[b.active_recipe]
        if b.progress < 1.0:
            b.progress = min(1.0, b.progress + dt * machine_speed(state, b) / recipe["time"])
            b.status = "working"
        if b.progress >= 1.0:
            out_needed = sum(recipe["outputs"].values())
            if sum(b.outbuf.values()) + out_needed <= spec["out_cap"]:
                for item, qty in recipe["outputs"].items():
                    b.outbuf[item] = b.outbuf.get(item, 0) + qty
                    state.count_production(b, item, qty)
                b.produced += out_needed
                b.active_recipe = None
                b.progress = 0.0
                b.status = "working"
            else:
                b.status = push_state or "blocked"
    else:
        candidates = [rid for rid in _available_recipes(state, b) if _inputs_ready(b, C.RECIPES[rid])]
        if not candidates:
            b.status = "no_input"
        else:
            # Rezept mit dem größten Vorrat zuerst (verhindert Verstopfen eines Eingangs)
            candidates.sort(key=lambda rid: -sum(b.inbuf.get(i, 0) for i in C.RECIPES[rid]["inputs"]))
            rid = candidates[0]
            recipe = C.RECIPES[rid]
            energy = recipe["cost"] * state.cost_mult
            if not state.can_afford_energy(energy):
                b.status = "no_money"
            else:
                state.add_energy(energy)
                for item, qty in recipe["inputs"].items():
                    b.inbuf[item] -= qty
                    if b.inbuf[item] <= 0:
                        del b.inbuf[item]
                b.active_recipe = rid
                b.progress = 0.0
                b.status = "working"

    if push_state in logistics.ERROR_STATES:
        b.status = push_state


def tick_seller(state, b, dt):
    if not b.items:
        b.progress = 0.0
        b.status = "no_input"
        return
    item = b.items[0]
    current = state.market.prices.get(item, 0.0)
    if not rules.price_ok(current, state.market.base_price(item), b.min_pct):
        b.progress = 0.0
        b.status = "waiting_price"
        return
    b.progress += dt * machine_speed(state, b) / C.BUILDINGS["seller"]["time"]
    b.status = "working"
    if b.progress >= 1.0:
        b.progress = 0.0
        b.items.pop(0)
        revenue = state.market.sell(item, 1, state.price_mult, state.time)
        state.money += revenue
        b.earned += revenue
        state.count_production(b, item, 1, track_global=False)


def tick_storage(state, b, dt):
    b.status = "full" if state.inventory_total() >= state.storage_capacity() else "ok"


TICK_FUNCTIONS = {
    "miner": tick_miner,
    "smelter": tick_crafter,
    "assembler": tick_crafter,
    "factory": tick_crafter,
    "seller": tick_seller,
    "storage": tick_storage,
    "freight": lambda state, b, dt: state.freight.tick_station(state, b, dt),
    "conveyor": logistics.tick_conveyor,
    "splitter": logistics.tick_router,
    "tpiece": logistics.tick_router,
    "sorter": logistics.tick_router,
}
for _machine in C.MACHINE_RECIPES:              # alle Fabriken mit wählbarem Rezept
    TICK_FUNCTIONS.setdefault(_machine, tick_crafter)
