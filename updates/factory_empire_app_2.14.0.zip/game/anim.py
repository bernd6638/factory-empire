"""
Kleine Animations-Bibliothek für Oberfläche und Welt.

tween(fn, dauer, ...) ruft fn(wert) jeden Frame mit einem geglätteten Wert von 0 bis 1 auf.
Läuft über update(dt) aus der Hauptschleife – unabhängig von Ursinas Sequenzen, damit sich
Animationen gezielt abbrechen/ersetzen lassen (key) und Fehler an gelöschten Objekten das
Spiel nie stören.
"""

import math

from panda3d.core import TransparencyAttrib


# ---------------------------------------------------------------- Kurven
def linear(t):
    return t


def out_cubic(t):
    return 1 - (1 - t) ** 3


def in_cubic(t):
    return t ** 3


def in_out_cubic(t):
    return 4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


def out_back(t, s=1.55):
    t -= 1
    return t * t * ((s + 1) * t + s) + 1


def out_elastic(t):
    if t <= 0 or t >= 1:
        return t
    return 2 ** (-10 * t) * math.sin((t * 10 - 0.75) * (2 * math.pi) / 3) + 1


def lerp(a, b, t):
    return a + (b - a) * t


def approach(cur, target, dt, speed=12.0):
    """Exponentielles Annähern – bildratenunabhängig."""
    return target + (cur - target) * math.exp(-speed * dt)


# ---------------------------------------------------------------- Tweens
class _Tween:
    __slots__ = ("fn", "dur", "delay", "ease", "done", "key", "t")

    def __init__(self, fn, dur, delay, ease, done, key):
        self.fn, self.dur, self.delay, self.ease, self.done, self.key = fn, max(1e-4, dur), delay, ease, done, key
        self.t = 0.0


_tweens = []


def tween(fn, dur, delay=0.0, ease=out_cubic, done=None, key=None, start=True):
    """fn(v) mit v = ease(0..1) über dur Sekunden. Gleicher key ersetzt eine laufende Animation."""
    if key is not None:
        cancel(key)
    tw = _Tween(fn, dur, delay, ease, done, key)
    _tweens.append(tw)
    if start:
        _safe(tw.fn, tw.ease(0.0))
    return tw


def cancel(key, finish=False):
    for tw in [t for t in _tweens if t.key == key]:
        _tweens.remove(tw)
        if finish:
            _safe(tw.fn, 1.0)
            if tw.done:
                _safe(tw.done)


def running(key):
    return any(t.key == key for t in _tweens)


def update(dt):
    if not _tweens:
        return
    for tw in list(_tweens):
        if tw.delay > 0:
            tw.delay -= dt
            continue
        tw.t += dt
        k = min(1.0, tw.t / tw.dur)
        ok = _safe(tw.fn, tw.ease(k))
        if not ok and k < 1.0:
            _safe(tw.fn, 1.0)                         # wenigstens den Endzustand herstellen
        if k >= 1.0 or not ok:
            if tw in _tweens:
                _tweens.remove(tw)
            if ok and tw.done:
                _safe(tw.done)


_reported = set()


def _safe(fn, *args):
    try:
        fn(*args)
        return True
    except Exception as exc:     # z. B. Objekt inzwischen gelöscht – Animation einfach beenden
        name = getattr(fn, "__qualname__", repr(fn))
        if name not in _reported:                 # einmal ins Protokoll (client.log) schreiben
            _reported.add(name)
            import traceback
            print(f"[Animation] {name}: {exc!r}")
            traceback.print_exc()
        return False


# ---------------------------------------------------------------- Hilfen
def set_alpha(node, a):
    """Blendet einen ganzen Teilbaum (Fenster, Text, ...) ein/aus."""
    if a >= 0.999:
        node.setAlphaScale(1.0)
        if node.hasPythonTag("fe_tr"):          # nur selbst gesetzte Transparenz wieder entfernen
            node.clearPythonTag("fe_tr")
            node.clearTransparency()
    else:
        if not node.hasTransparency():
            node.setTransparency(TransparencyAttrib.M_alpha)
            node.setPythonTag("fe_tr", True)
        node.setAlphaScale(max(0.0, a))


def pop(entity, base, amount=0.12, dur=0.35, key=None):
    """Kurzes Aufploppen (Skalierung) – für Erfolgsmomente."""
    bx, by = (base, base) if not isinstance(base, (tuple, list)) else base[:2]

    def f(v):
        k = 1 + amount * math.sin(v * math.pi) * (1 - v * 0.3)
        entity.scale_x = bx * k
        entity.scale_y = by * k
    return tween(f, dur, ease=linear, key=key or ("pop", id(entity)),
                 done=lambda: (setattr(entity, "scale_x", bx), setattr(entity, "scale_y", by)))
