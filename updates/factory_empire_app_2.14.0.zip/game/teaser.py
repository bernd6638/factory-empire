"""
Geheime Baustelle: In der Ecke vor dem Fabrikgelände steht eine abgesperrte Plattform mit Bauzäunen,
Kran, abgedecktem Bauwerk, Warnleuchten und Scheinwerfern. Darüber schwebt ein Countdown bis zum
nächsten großen Update (COUNTDOWN_TARGET in config.py, für alle Spieler dieselbe Uhrzeit).
"""

import math
import random
import time

from panda3d.core import TransparencyAttrib
from ursina import Entity, Text, Vec3, color

from . import config as C
from . import effects
from . import graphics
from . import models
from . import textures

CENTER = (-9.0, -9.0)          # vor der Nordwest-Ecke des Fabrikgeländes (x, z)
RADIUS = 7.5                   # Bereich, der eben bleibt und frei von Bäumen ist
HALF = 3.6                     # halbe Kantenlänge des Bauzaun-Quadrats


def in_area(x, z, extra=0.0):
    return math.hypot(x - CENTER[0], z - CENTER[1]) < RADIUS + extra


def remaining():
    return max(0, int(C.COUNTDOWN_TARGET - time.time()))


def countdown_text(sec):
    if sec <= 0:
        return "JETZT!"
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return f"{d}T {h:02d}:{m:02d}:{s:02d}" if d else f"{h:02d}:{m:02d}:{s:02d}"


def _glow_quad(parent, pos, scale, col):
    e = Entity(parent=parent, model="quad", texture=textures.texture("glow"), position=pos, scale=scale,
               billboard=True, shader=graphics.unlit(), color=col, add_to_scene_entities=False)
    e.setTransparency(TransparencyAttrib.M_alpha)
    e.setDepthWrite(False)
    e.setLightOff()
    e.setFogOff()
    e.setBin("fixed", 8)
    return e


class Teaser:
    def __init__(self, ground_y=0.0):
        cx, cz = CENTER
        lit = graphics.lit_shader()
        self.root = Entity(position=(cx, ground_y, cz), add_to_scene_entities=False)
        self.t = random.random() * 10
        self._fx_t = 0.0

        # ---------- Plattform, Zäune, Baustellen-Deko (ein Modell)
        mb = models.MeshBuilder(1.2)
        mb.add("cyl", (0, 0.18, 0), (7.4, 0.36, 7.4), (0.46, 0.47, 0.5))                 # Betonplattform
        mb.add("cyl", (0, 0.37, 0), (7.0, 0.03, 7.0), (0.36, 0.37, 0.4))
        for i in range(16):                                                              # Warnstreifen am Rand
            a = i / 16 * 2 * math.pi
            mb.add("box", (math.cos(a) * 3.62, 0.25, math.sin(a) * 3.62), (0.5, 0.2, 0.06),
                   models.YELLOW if i % 2 else models.DARK, (0, -math.degrees(a) + 90, 0))
        # Bauzäune (Mobilzaun-Elemente auf Betonfüßen)
        n = 7
        for side in range(4):
            for k in range(n):
                f = -HALF + (k + 0.5) * (2 * HALF / n)
                if side == 3 and k == n // 2:
                    continue                                                             # Einfahrt
                x, z, rot = [(f, -HALF, 0), (HALF, f, 90), (f, HALF, 0), (-HALF, f, 90)][side]
                w = 2 * HALF / n - 0.04
                for dx in (-w / 2, w / 2):
                    px, pz = (x + dx, z) if rot == 0 else (x, z + dx)
                    mb.add("box", (px, 0.42, pz), (0.28, 0.12, 0.14), (0.62, 0.62, 0.6), (0, rot, 0))  # Fuß
                    mb.add("cyl8", (px, 1.05, pz), (0.04, 1.2, 0.04), (0.78, 0.8, 0.82))             # Pfosten
                for y in (0.5, 1.6):                                                                 # Rahmen
                    mb.add("box", (x, y, z), (w, 0.035, 0.035), (0.78, 0.8, 0.82), (0, rot, 0))
                mb.add("box", (x, 1.05, z), (w - 0.02, 1.06, 0.012), (0.55, 0.57, 0.6), (0, rot, 0))   # Gitter
                mb.add("box", (x, 1.18, z), (w - 0.04, 0.26, 0.03), (0.9, 0.18, 0.15), (0, rot, 0))    # Plane
                mb.add("box", (x, 1.18, z), (w * 0.5, 0.1, 0.035), (0.96, 0.96, 0.94), (0, rot, 0))
        # abgedecktes Bauwerk in der Mitte
        mb.add("box", (0.3, 1.25, 0.2), (2.4, 1.8, 2.0), (0.14, 0.22, 0.42))                 # Plane
        mb.add("wedge", (0.3, 2.45, 0.2), (2.5, 0.6, 2.1), (0.12, 0.19, 0.38))
        for zz in (-0.5, 0.2, 0.9):
            mb.add("box", (0.3, 1.25, zz), (2.45, 0.06, 0.06), (0.95, 0.75, 0.15))           # Spanngurte
        # Material und Container
        mb.add("box", (-2.3, 0.75, 1.9), (1.4, 0.75, 0.62), (0.2, 0.45, 0.62))               # Container
        mb.add("box", (-2.3, 0.75, 1.585), (1.3, 0.62, 0.01), (0.16, 0.36, 0.5))
        for i in range(3):
            mb.add("cyl8", (2.4, 0.5 + i * 0.13, -2.0 + i * 0.02), (0.12, 1.5, 0.12), (0.5, 0.36, 0.3),
                   (0, 0, 90))                                                               # Stahlrohre
        for i in range(2):
            mb.add("box", (-2.4, 0.45 + i * 0.18, -2.1), (0.9, 0.16, 0.9), models.WOOD)          # Paletten
        mb.add("cone6", (1.9, 0.62, 2.6), (0.22, 0.45, 0.22), (0.98, 0.45, 0.1))             # Leitkegel
        mb.add("cone6", (-0.9, 0.62, 3.0), (0.22, 0.45, 0.22), (0.98, 0.45, 0.1))
        # Kranturm
        mb.add("box", (-2.4, 0.5, -0.3), (0.9, 0.3, 0.9), (0.55, 0.55, 0.55))
        for i in range(10):
            mb.add("box", (-2.4, 0.95 + i * 0.6, -0.3), (0.42, 0.6, 0.42), models.YELLOW)
            mb.add("box", (-2.4, 0.95 + i * 0.6, -0.3), (0.44, 0.04, 0.44), models.DARK)
        self.static = Entity(parent=self.root, model=mb.build(ao=False), shader=lit, add_to_scene_entities=False)
        tex = textures.texture("metal")
        if tex is not None:
            self.static.setTexture(tex._texture, 1)

        # ---------- drehender Kranausleger mit Haken
        jb = models.MeshBuilder(1.2)
        jb.add("box", (1.4, 0, 0), (5.6, 0.32, 0.32), models.YELLOW)
        jb.add("box", (-1.2, -0.05, 0), (1.4, 0.5, 0.6), (0.55, 0.55, 0.55))                 # Gegengewicht
        jb.add("box", (0, 0.5, 0), (0.5, 0.7, 0.5), models.YELLOW)                           # Kabine
        jb.add("box", (0.26, 0.55, 0), (0.02, 0.3, 0.35), (0.6, 0.8, 0.95))
        self.jib = Entity(parent=self.root, model=jb.build(), position=(-2.4, 6.9, -0.3), shader=lit,
                          add_to_scene_entities=False)
        self.cable = Entity(parent=self.jib, model="cube", position=(3.0, -1.2, 0), scale=(0.03, 2.4, 0.03),
                            color=color.rgba(0.15, 0.15, 0.15, 1), shader=lit, add_to_scene_entities=False)
        hb = models.MeshBuilder(1.2)
        hb.add("box", (0, 0, 0), (0.6, 0.6, 0.6), (0.72, 0.38, 0.2))                         # Last (Kiste)
        hb.add("box", (0, 0.31, 0), (0.62, 0.04, 0.62), models.DARK)
        self.hook = Entity(parent=self.jib, model=hb.build(), position=(3.0, -2.7, 0), shader=lit,
                           add_to_scene_entities=False)
        if tex is not None:
            self.jib.setTexture(tex._texture, 1)
            self.hook.setTexture(tex._texture, 1)

        # ---------- Warnleuchten an den Ecken (blinken) und Scheinwerfer
        self.beacons = []
        for i, (x, z) in enumerate(((-HALF, -HALF), (HALF, -HALF), (HALF, HALF), (-HALF, HALF))):
            Entity(parent=self.root, model="cube", position=(x, 1.72, z), scale=(0.12, 0.1, 0.12),
                   color=color.rgba(0.2, 0.2, 0.2, 1), shader=lit, add_to_scene_entities=False)
            bulb = Entity(parent=self.root, model="sphere", position=(x, 1.85, z), scale=0.17,
                          shader=graphics.unlit(), color=color.rgba(1, 0.55, 0.05, 1), add_to_scene_entities=False)
            bulb.setLightOff()
            halo = _glow_quad(self.root, (x, 1.85, z), 1.1, color.rgba(1, 0.55, 0.1, 0.8))
            self.beacons.append((bulb, halo, i * 0.5))
        self.beams = []
        for i, (x, z) in enumerate(((HALF - 0.3, HALF - 0.3), (-HALF + 0.3, -HALF + 0.3))):
            pivot = Entity(parent=self.root, position=(x, 0.5, z), add_to_scene_entities=False)
            beam = Entity(parent=pivot, model=models.mesh_from_parts([("cone", (0, 0, 0), (2.6, 14.0, 2.6),
                                                                       (1, 0.95, 0.8))]),
                          position=(0, 7.0, 0), rotation=(180, 0, 0), shader=graphics.unlit(),
                          color=color.rgba(1, 0.95, 0.75, 0.13), add_to_scene_entities=False)
            beam.setTransparency(TransparencyAttrib.M_alpha)
            beam.setDepthWrite(False)
            beam.setTwoSided(True)
            beam.setLightOff()
            beam.setBin("fixed", 6)
            Entity(parent=self.root, model="cube", position=(x, 0.5, z), scale=(0.5, 0.3, 0.5),
                   color=color.rgba(0.2, 0.2, 0.22, 1), shader=lit, add_to_scene_entities=False)
            self.beams.append((pivot, i * math.pi))

        # ---------- schwebender Countdown
        self.holo = Entity(parent=self.root, position=(0, 10.5, 0), add_to_scene_entities=False)
        self.board = Entity(parent=self.holo, billboard=True, add_to_scene_entities=False)
        self.halo = _glow_quad(self.holo, (0, 0, 0.05), (19, 9), color.rgba(1, 0.55, 0.1, 0.35))
        from ursina import Quad
        frame = Entity(parent=self.board, model=Quad(radius=0.06, aspect=12.4 / 5.0), scale=(12.4, 5.0),
                       position=(0, 0, 0.02), color=color.rgba(1, 0.6, 0.15, 0.9), shader=graphics.unlit(),
                       add_to_scene_entities=False)
        back = Entity(parent=self.board, model=Quad(radius=0.06, aspect=12.0 / 4.6), scale=(12.0, 4.6),
                      position=(0, 0, 0.01), color=color.rgba(0.04, 0.05, 0.07, 0.86), shader=graphics.unlit(),
                      add_to_scene_entities=False)
        for e in (frame, back):
            e.setTransparency(TransparencyAttrib.M_alpha)
            e.setLightOff()
            e.setFogOff()
            e.setDepthWrite(False)
            e.setTwoSided(True)
            e.setBin("fixed", 8)
        self.title = Text(parent=self.board, text="NEUES UPDATE IN", origin=(0, 0),
                          position=(0, 1.45, 0), scale=26, color=color.rgba(1, 1, 1, 0.95))
        self.clock = Text(parent=self.board, text=countdown_text(remaining()), origin=(0, 0),
                          position=(0, 0.05, 0), scale=58, color=color.rgba(1, 0.68, 0.15, 1))
        self.sub = Text(parent=self.board, text="Streng geheim  ·  Betreten verboten", origin=(0, 0),
                        position=(0, -1.55, 0), scale=17, color=color.rgba(1, 1, 1, 0.65))
        for t in (self.title, self.clock, self.sub):
            t.setLightOff()
            t.setFogOff()
            t.setBin("fixed", 9)
            t.setTwoSided(True)
            t.setDepthWrite(False)
        self.ring = Entity(parent=self.root, model=models.mesh_from_parts([("cyl", (0, 0, 0), (7.6, 0.04, 7.6),
                                                                             (1, 0.6, 0.15))]),
                           position=(0, 0.395, 0), shader=graphics.unlit(), color=color.rgba(1, 0.6, 0.15, 0.25),
                           add_to_scene_entities=False)
        self.ring.setTransparency(TransparencyAttrib.M_alpha)
        self.ring.setDepthWrite(False)
        self.ring.setLightOff()
        self._last_sec = None
        self.force_zero = False        # Test-Welt/Enthüllung: so tun, als sei der Countdown abgelaufen

    # ------------------------------------------------------------------ Animation
    def update(self, dt, cam_pos=None):
        self.t += dt
        t = self.t
        sec = 0 if self.force_zero else remaining()
        if sec != self._last_sec:
            self._last_sec = sec
            self.clock.text = countdown_text(sec)
            if sec <= 0:
                self.title.text = "DAS UPDATE IST DA!"
        # schwebender Countdown: sanftes Auf und Ab, Pulsieren im Sekundentakt
        pulse = 1.0 + 0.045 * max(0.0, math.cos((time.time() % 1.0) * math.pi * 2)) ** 6
        self.holo.y = 10.5 + math.sin(t * 1.3) * 0.25
        self.clock.scale = 58 * pulse
        self.halo.color = color.rgba(1, 0.55, 0.1, 0.28 + 0.12 * math.sin(t * 2.2))
        self.ring.color = color.rgba(1, 0.6, 0.15, 0.12 + 0.12 * (0.5 + 0.5 * math.sin(t * 3)))
        # Kran dreht sich hin und her, Last pendelt
        self.jib.rotation_y = 40 * math.sin(t * 0.18) + 20
        self.hook.y = -2.7 + math.sin(t * 0.5) * 0.6
        self.cable.scale_y = 2.4 - math.sin(t * 0.5) * 0.6
        self.cable.y = -1.2 + math.sin(t * 0.5) * 0.3
        self.hook.rotation_y = t * 12
        # Warnleuchten blinken abwechselnd
        for bulb, halo, ph in self.beacons:
            on = (t * 1.6 + ph) % 1.0 < 0.45
            bulb.color = color.rgba(1, 0.55, 0.05, 1) if on else color.rgba(0.35, 0.18, 0.05, 1)
            halo.enabled = on
        # Scheinwerfer schwenken
        for pivot, ph in self.beams:
            pivot.rotation_y = math.degrees(t * 0.45 + ph)
            pivot.rotation_x = 18 + 8 * math.sin(t * 0.7 + ph)
        # Schweißfunken am verhüllten Bauwerk, aufsteigende Glut
        self._fx_t += dt
        if self._fx_t > 0.18:
            self._fx_t = 0.0
            near = cam_pos is None or (cam_pos[0] - CENTER[0]) ** 2 + (cam_pos[2] - CENTER[1]) ** 2 < 90 ** 2
            if near:
                fx = effects.get()
                r = self.root.getPos()
                if random.random() < 0.55:
                    fx.emit(Vec3(r[0] + random.uniform(-1.2, 1.6), r[1] + random.uniform(0.6, 2.2),
                                 r[2] + 1.25), "spark", 4, force=True)
                if random.random() < 0.3:
                    fx.emit(Vec3(r[0] + random.uniform(-1, 1), r[1] + 2.8, r[2] + random.uniform(-1, 1)),
                            "steam", 1, force=True)
