"""
Spielstand-Plätze: Einzel- und Mehrspieler haben je 5 Plätze, jeder Platz ist eine eigene Welt.

Mehrspieler-Platz 1 ist der bisherige Mehrspieler-Spielstand (saves/factory.json).
Welten aus Version 2.5/2.6 (Ordner saves/worlds/) werden beim ersten Start automatisch auf freie
Mehrspieler-Plätze verschoben.
"""

import json
import os
import random
import time

from . import config as C

WORLDS_DIR = os.path.join(C.DATA_DIR, "worlds")      # alter Ordner (nur noch für die Übernahme)


def _describe(path):
    """Kurzinfo zur Welt: Anzahl Gebäude, Geld, zuletzt gespielt. Fehlerhafte Dateien -> None."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or "buildings" not in data:
        return None                                # z. B. bans.json – kein Spielstand
    try:
        mtime = os.path.getmtime(path)
        stamp = time.strftime("%d.%m.%Y", time.localtime(mtime))
    except OSError:
        mtime, stamp = 0.0, "?"
    buildings = data.get("buildings") or []
    money = data.get("money", 0)
    return {"buildings": len(buildings), "money": money, "date": stamp, "mtime": mtime}


def describe_line(world):
    from . import rules
    return (f"{world['buildings']} Gebäude · {rules.format_money(world['money'])} · "
            f"zuletzt {world['date']}")


def slots_info(slot_file, count):
    """Kurzinfo-Zeile je Platz (None = leerer Platz)."""
    out = []
    for n in range(1, count + 1):
        path = slot_file(n)
        info = _describe(path) if os.path.exists(path) else None
        out.append(describe_line(info) if info else None)
    return out


def migrate_worlds():
    """Welten aus saves/worlds/ (Version 2.5/2.6) auf freie Mehrspieler-Plätze verschieben,
    die zuletzt gespielte zuerst. Gibt die Liste (alter Name, Platz) zurück."""
    if not os.path.isdir(WORLDS_DIR):
        return []
    found = []
    for fn in os.listdir(WORLDS_DIR):
        if fn.endswith(".json"):
            path = os.path.join(WORLDS_DIR, fn)
            info = _describe(path)
            if info:
                found.append((info["mtime"], fn, path))
    found.sort(reverse=True)
    moved = []
    for _, fn, path in found:
        free = [n for n in range(1, C.MULTIPLAYER_SLOTS + 1) if not os.path.exists(C.multiplayer_slot_file(n))]
        if not free:
            break
        try:
            os.replace(path, C.multiplayer_slot_file(free[0]))
            moved.append((fn[:-5], free[0]))
        except OSError:
            pass
    return moved


def new_seed():
    return random.randint(1, 2_000_000_000)
