"""
Mond-Update: Rakete auf der Startrampe (an der Stelle der früheren geheimen Baustelle), die Enthüllung
nach Ablauf des Countdowns und die Kinofahrt zum Mond und zurück.

    LaunchPad        Startrampe mit Rakete, Turm, Zugangsbrücke, Flutlicht, Dampf und "KLICK MICH!"-Schild
    Rocket           das Raketenmodell (Hauptstufe, Booster, Triebwerksflammen)
    RevealSequence   Enthüllung: Baustelle verschwindet im Dampf, die Rakete steht da
    LaunchSequence   Brücke fällt weg -> Countdown -> Start -> Flug durchs All -> Landung
"""

import math
import random
import time

from panda3d.core import TransparencyAttrib
from ursina import Entity, Quad, Text, Vec3, camera, color, mouse

from . import effects
from . import graphics
from . import models
from . import textures
from .space import additive, glow

MOUNT_TOP = 1.55            # Höhe der Raketenunterkante über der Plattform
ARM_Y = 14.4                # Höhe der Zugangsbrücke
TOWER_X = 3.1               # Abstand des Turms zur Raketenachse
WHITE = (0.93, 0.94, 0.95)
ORANGE = (0.98, 0.52, 0.12)
RED = (0.72, 0.14, 0.12)


def look_from(pos, target):
    """Kamera auf pos setzen und auf target ausrichten – ohne Seitenneigung (Horizont bleibt gerade)."""
    d = target - pos
    yaw = math.degrees(math.atan2(d.x, d.z))
    pitch = -math.degrees(math.atan2(d.y, math.hypot(d.x, d.z)))
    camera.world_position = pos
    camera.world_rotation = Vec3(pitch, yaw, 0)


def orbit_lerp(center, a, b, k):
    """Kamerafahrt von a nach b im Bogen um center (statt quer durch den Startturm)."""
    da, db = a - center, b - center
    aa, ab = math.atan2(da.x, da.z), math.atan2(db.x, db.z)
    diff = (ab - aa + math.pi) % (2 * math.pi) - math.pi
    ra, rb = math.hypot(da.x, da.z), math.hypot(db.x, db.z)
    ang = aa + diff * k
    r = ra + (rb - ra) * k
    return center + Vec3(math.sin(ang) * r, da.y + (db.y - da.y) * k, math.cos(ang) * r)


def _ease(t):
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


# ============================================================================= Rakete
class Rocket:
    def __init__(self, parent, pos=(0, 0, 0)):
        lit = graphics.lit_shader()
        self.root = Entity(parent=parent, position=pos, add_to_scene_entities=False)
        mb = models.MeshBuilder(1.0)
        dark, steel = models.DARK, models.STEEL
        for dx, dz in ((-0.42, -0.42), (0.42, -0.42), (-0.42, 0.42), (0.42, 0.42), (0, 0)):
            mb.add("frustum", (dx, 0.33, dz), (0.62, 0.66, 0.62), (0.22, 0.22, 0.24), (180, 0, 0))   # Düsen
        mb.add("cyl", (0, 1.05, 0), (2.2, 0.8, 2.2), (0.24, 0.25, 0.28))                    # Triebwerksteil
        mb.add("cyl", (0, 5.5, 0), (2.2, 8.2, 2.2), WHITE)                                  # Hauptstufe
        mb.add("cyl", (0, 2.1, 0), (2.23, 0.5, 2.23), dark)                                 # Ringe
        mb.add("cyl", (0, 8.9, 0), (2.23, 0.5, 2.23), ORANGE)
        mb.add("cyl", (0, 10.0, 0), (2.2, 0.9, 2.2), (0.2, 0.21, 0.23))                     # Zwischenstufe
        mb.add("cyl", (0, 12.0, 0), (1.85, 3.2, 1.85), WHITE)                               # Oberstufe
        mb.add("cyl", (0, 13.0, 0), (1.87, 0.25, 1.87), ORANGE)
        mb.add("frustum", (0, 14.4, 0), (1.85, 1.6, 1.85), WHITE)                           # Kapsel
        for a in range(0, 360, 60):                                                          # Fenster
            r = math.radians(a)
            mb.add("box", (math.cos(r) * 0.78, 14.45, math.sin(r) * 0.78), (0.1, 0.22, 0.18), (0.12, 0.22, 0.4),
                   (0, -a, 0))
        mb.add("cone", (0, 15.9, 0), (1.15, 1.4, 1.15), WHITE)                              # Rettungsturm
        mb.add("cyl8", (0, 17.1, 0), (0.1, 1.4, 0.1), steel)
        mb.add("cone6", (0, 17.95, 0), (0.18, 0.4, 0.18), RED)
        for k in range(4):                                                                   # Flossen
            a = k * 90 + 45
            r = math.radians(a)
            mb.add("box", (math.cos(r) * 1.25, 1.9, math.sin(r) * 1.25), (0.9, 1.9, 0.1), ORANGE, (0, -a, 0))
        self.core = Entity(parent=self.root, model=mb.build(), shader=lit, add_to_scene_entities=False)
        tex = textures.texture("metal")
        if tex is not None:
            self.core.setTexture(tex._texture, 1)
        # Schriftzug längs auf der Hauptstufe
        self.label = Text(parent=self.core, text="FACTORY EMPIRE", origin=(0, 0), position=(0, 5.4, -1.115),
                          rotation=(0, 0, 90), scale=17, color=color.rgba(0.1, 0.13, 0.22, 1))
        self.label.__dict__["_raw"] = True
        self.label.text = "FACTORY EMPIRE"
        self.label.setLightOff()
        self.label2 = Text(parent=self.core, text="FACTORY EMPIRE", origin=(0, 0), position=(0, 5.4, 1.115),
                           rotation=(0, 180, 90), scale=17, color=color.rgba(0.1, 0.13, 0.22, 1))
        self.label2.__dict__["_raw"] = True
        self.label2.setLightOff()
        # Booster links und rechts
        bb = models.MeshBuilder(1.0)
        bb.add("frustum", (0, 0.35, 0), (0.6, 0.7, 0.6), (0.22, 0.22, 0.24), (180, 0, 0))
        bb.add("cyl", (0, 4.2, 0), (0.95, 7.2, 0.95), WHITE)
        bb.add("cyl", (0, 2.0, 0), (0.97, 0.35, 0.97), dark)
        bb.add("cone", (0, 8.4, 0), (0.95, 1.2, 0.95), WHITE)
        bb.add("box", (0, 5.0, 0), (0.06, 0.2, 1.4), steel)                                  # Halterung
        booster_model = bb.build()
        self.boosters = []
        for side in (-1, 1):
            e = Entity(parent=self.root, model=booster_model, position=(side * 1.6, 0.4, 0), shader=lit,
                       add_to_scene_entities=False)
            if tex is not None:
                e.setTexture(tex._texture, 1)
            e.side = side
            self.boosters.append(e)
        # Flammen (additiv, unbeleuchtet)
        self.flames = []
        self.flames.append(self._flame((0, 0, 0), 1.0))
        for b in self.boosters:
            self.flames.append(self._flame((0, 0, 0), 0.55, parent=b))
        self.glow = glow(self.root, (0, -1.2, 0), 9, color.rgba(1, 0.6, 0.25, 0.9), bin_order=11)
        self.power = 0.0
        self.vacuum = False
        self.firing = False
        self._t = random.random() * 10
        self.set_firing(False)

    def _flame(self, pos, size, parent=None):
        fm = models.mesh_from_parts([
            ("cone", (0, -2.6, 0), (1.9, 5.2, 1.9), (1.0, 0.45, 0.12), (180, 0, 0)),
            ("cone", (0, -1.7, 0), (1.15, 3.4, 1.15), (1.0, 0.82, 0.45), (180, 0, 0)),
            ("cone", (0, -0.9, 0), (0.6, 1.8, 0.6), (1.0, 1.0, 0.92), (180, 0, 0)),
        ])
        e = Entity(parent=parent or self.root, model=fm, position=pos, scale=size, shader=graphics.unlit(),
                   color=color.rgba(1, 1, 1, 0.85), add_to_scene_entities=False)
        additive(e)
        e.setTwoSided(True)
        e.setBin("fixed", 12)
        e.base = size
        return e

    def reset(self):
        self.root.rotation = (self.root.rotation_x, 0, 0)
        for b in self.boosters:
            b.position = (b.side * 1.6, 0.4, 0)
            b.rotation = (0, 0, 0)
            b.enabled = True
            b.sep_v = None

    def show_boosters(self, on):
        for b in self.boosters:
            b.enabled = on

    def separate_boosters(self, t):
        """t: Sekunden seit der Abtrennung (< 0 = noch dran)."""
        for i, b in enumerate(self.boosters):
            if t <= 0 or not b.enabled:
                continue
            b.position = Vec3(b.side * (1.6 + t * 2.4), 0.4 - t * 3.5 - t * t * 1.2, t * 0.6)
            b.rotation = (t * 8, 0, b.side * t * 26)
            self.flames[1 + i].enabled = t < 0.4
            if t > 5:
                b.enabled = False

    def set_firing(self, on, power=1.0, vacuum=False):
        self.firing = on
        self.power = power if on else 0.0
        self.vacuum = vacuum
        for f in self.flames:
            f.enabled = on
        self.glow.enabled = on

    def update(self, dt):
        self._t += dt
        if not self.firing:
            return
        p = self.power
        for i, f in enumerate(self.flames):
            fl = 1.0 + 0.12 * math.sin(self._t * 47 + i * 2.1) + random.uniform(-0.06, 0.06)
            wide = 1.35 if self.vacuum else 1.0
            f.scale = Vec3(f.base * wide * (0.6 + 0.4 * p), f.base * p * fl * (0.8 if self.vacuum else 1.0),
                           f.base * wide * (0.6 + 0.4 * p))
        self.glow.scale = (5 if self.vacuum else 9) * (0.4 + 0.6 * p) * (1 + random.uniform(-0.06, 0.06))
        self.glow.color = color.rgba(1, 0.6, 0.25, 0.65 + 0.3 * p)
        a = 0.55 if self.vacuum else 0.85
        for f in self.flames:
            f.alpha_target = a
            f.color = color.rgba(1, 1, 1, a)

    def nozzle_world(self):
        return self.root.world_position


# ============================================================================= Startrampe
class LaunchPad:
    YAW = 65             # Turm steht – von der Fabrik aus gesehen – seitlich neben der Rakete (Brücke gut sichtbar)

    def __init__(self, center, ground_y=0.0, planet="earth"):
        cx, cz = center
        self.center = Vec3(cx, ground_y, cz)
        self.planet = planet
        lit = graphics.lit_shader()
        self.root = Entity(position=self.center, rotation_y=self.YAW, add_to_scene_entities=False)
        self.on_click = None
        self.busy = False
        self.t = random.random() * 10
        self._vent_t = 0.0
        self.fx = effects.Particles(1800, name="rocketfx")
        self.fx.distant = False
        self.fx.batch.holder.setFogOff()

        mb = models.MeshBuilder(1.2)
        mb.add("cyl", (0, 0.18, 0), (7.4, 0.36, 7.4), (0.46, 0.47, 0.5))                  # Betonplattform
        mb.add("cyl", (0, 0.37, 0), (7.0, 0.03, 7.0), (0.38, 0.39, 0.42))
        for i in range(24):                                                               # Warnstreifen
            a = i / 24 * 2 * math.pi
            mb.add("box", (math.cos(a) * 3.62, 0.25, math.sin(a) * 3.62), (0.5, 0.2, 0.06),
                   models.YELLOW if i % 2 else models.DARK, (0, -math.degrees(a) + 90, 0))
        mb.add("box", (0, 0.39, 0), (7.0, 0.02, 1.4), (0.12, 0.12, 0.13))                 # Flammengraben
        mb.add("box", (0, 0.4, 0), (1.3, 0.04, 1.3), (0.08, 0.08, 0.09))
        for dx, dz in ((-1.1, -1.1), (1.1, -1.1), (-1.1, 1.1), (1.1, 1.1)):                 # Starttisch
            mb.add("box", (dx, 0.85, dz), (0.35, 1.0, 0.35), (0.3, 0.31, 0.34))
        mb.add("box", (0, 1.42, 0), (3.0, 0.22, 3.0), (0.32, 0.33, 0.36))
        mb.add("box", (0, 1.42, 0), (1.6, 0.24, 1.6), (0.12, 0.12, 0.13))
        # Startturm (Gitterturm) mit Aufzug
        tx = TOWER_X
        for dx, dz in ((-0.6, -0.6), (0.6, -0.6), (-0.6, 0.6), (0.6, 0.6)):
            mb.add("box", (tx + dx, 9.2, dz), (0.16, 17.6, 0.16), RED)
        for i in range(15):
            y = 1.0 + i * 1.18
            for (a, b, rot) in (((tx, -0.6), (1.2, 0.08), 0), ((tx, 0.6), (1.2, 0.08), 0),
                                ((tx - 0.6, 0), (0.08, 1.2), 0), ((tx + 0.6, 0), (0.08, 1.2), 0)):
                mb.add("box", (a[0], y, a[1]), (b[0], 0.08, b[1]), RED)
            mb.add("box", (tx, y + 0.59, -0.6), (1.6, 0.06, 0.06), RED, (0, 0, 42 if i % 2 else -42))
            mb.add("box", (tx, y + 0.59, 0.6), (1.6, 0.06, 0.06), RED, (0, 0, -42 if i % 2 else 42))
            mb.add("box", (tx + 0.6, y + 0.59, 0), (0.06, 0.06, 1.6), RED, (42 if i % 2 else -42, 0, 0))
        mb.add("box", (tx, 18.1, 0), (1.5, 0.25, 1.5), (0.3, 0.3, 0.32))                 # Plattform oben
        mb.add("cyl8", (tx, 21.0, 0), (0.12, 5.8, 0.12), models.STEEL)                    # Blitzableiter
        mb.add("box", (tx + 0.2, 7.0, 0), (0.6, 1.2, 0.6), (0.85, 0.86, 0.88))            # Aufzug
        mb.add("box", (tx - 0.75, ARM_Y - 0.35, 0), (0.3, 0.12, 1.0), (0.3, 0.3, 0.32))   # Brückenlager
        # Flutlichtmasten an den Ecken
        self._lights = [(-3.0, -3.0), (3.0, 3.0), (-3.0, 3.0)]
        for (lx, lz) in self._lights:
            mb.add("cyl8", (lx, 3.0, lz), (0.14, 6.0, 0.14), (0.35, 0.36, 0.4))
            mb.add("box", (lx, 6.1, lz), (0.8, 0.45, 0.25), (0.25, 0.26, 0.3))
        # Tanks und Leitungen
        mb.add("cyl", (-2.6, 1.1, -1.9), (1.0, 1.6, 1.0), WHITE)
        mb.add("dome", (-2.6, 1.9, -1.9), (1.0, 0.8, 1.0), WHITE)
        mb.add("cyl", (-1.5, 1.0, -2.6), (0.8, 1.3, 0.8), (0.75, 0.78, 0.82))
        mb.add("box", (0.6, 0.55, -2.4), (2.6, 0.12, 0.12), models.STEEL)
        self.static = Entity(parent=self.root, model=mb.build(ao=False), shader=lit, add_to_scene_entities=False)
        tex = textures.texture("metal")
        if tex is not None:
            self.static.setTexture(tex._texture, 1)

        # Zugangsbrücke (dreht vom Turm weg und fällt dann zur Seite)
        self.arm_pivot = Entity(parent=self.root, position=(TOWER_X - 0.7, ARM_Y, 0), add_to_scene_entities=False)
        ab = models.MeshBuilder(1.2)
        length = TOWER_X - 0.7 - 0.95
        ab.add("box", (-length / 2, 0, 0), (length, 0.12, 0.75), (0.35, 0.36, 0.38))         # Laufsteg
        for z in (-0.37, 0.37):
            ab.add("box", (-length / 2, 0.5, z), (length, 0.05, 0.05), models.YELLOW)        # Geländer
            for k in range(4):
                ab.add("box", (-0.1 - k * length / 3.4, 0.25, z), (0.04, 0.5, 0.04), models.STEEL)
        ab.add("box", (-length + 0.15, 0.5, 0), (0.5, 1.1, 0.95), (0.92, 0.92, 0.94))        # "White Room"
        ab.add("box", (-length - 0.11, 0.5, 0), (0.04, 0.85, 0.6), (0.12, 0.13, 0.16))       # Luke
        ab.add("box", (-length / 2, -0.35, 0), (length, 0.08, 0.1), RED, (0, 0, 8))          # Strebe
        self.arm = Entity(parent=self.arm_pivot, model=ab.build(), shader=lit, add_to_scene_entities=False)
        # Versorgungsleitung (fällt beim Zünden ab)
        self.umb_pivot = Entity(parent=self.root, position=(TOWER_X - 0.7, 9.6, 0), add_to_scene_entities=False)
        ub = models.MeshBuilder(1.2)
        ub.add("box", (-(TOWER_X - 1.75) / 2, 0, 0), (TOWER_X - 1.75, 0.14, 0.3), (0.3, 0.31, 0.34))
        ub.add("cyl8", (-(TOWER_X - 1.75) / 2, -0.12, 0.08), (0.07, TOWER_X - 1.75, 0.07), models.DARK, (0, 0, 90))
        self.umb = Entity(parent=self.umb_pivot, model=ub.build(), shader=lit, add_to_scene_entities=False)

        self.rocket = Rocket(self.root, (0, MOUNT_TOP, 0))

        # Flutlicht-Kegel, auf die Rakete gerichtet
        self.beams = []
        for (lx, lz) in self._lights:
            beam = Entity(parent=self.root, model=models.mesh_from_parts([("cone", (0, 0, 0), (3.2, 15.0, 3.2),
                                                                           (1, 0.95, 0.8))]),
                          position=(lx, 6.1, lz), shader=graphics.unlit(), color=color.rgba(1, 0.96, 0.8, 0.09),
                          add_to_scene_entities=False)
            beam.look_at(self.root.world_position + Vec3(0, 11, 0))
            beam.rotation_x += 90                             # Kegelspitze liegt am Scheinwerfer
            beam.setPos(beam, Vec3(0, 7.5, 0))
            beam.setTransparency(TransparencyAttrib.M_alpha)
            beam.setDepthWrite(False)
            beam.setTwoSided(True)
            beam.setLightOff()
            beam.setFogOff()
            beam.setBin("fixed", 6)
            lamp = glow(self.root, (lx, 6.15, lz), 1.6, color.rgba(1, 0.95, 0.8, 0.9), bin_order=7)
            self.beams.append((beam, lamp))
        # rote Warnleuchten am Turm
        self.beacons = []
        for y in (18.35, 23.9):
            bulb = Entity(parent=self.root, model="sphere", position=(TOWER_X, y, 0), scale=0.22,
                          shader=graphics.unlit(), color=color.rgba(1, 0.1, 0.05, 1), add_to_scene_entities=False)
            bulb.setLightOff()
            halo = glow(self.root, (TOWER_X, y, 0), 1.5, color.rgba(1, 0.15, 0.1, 0.9), bin_order=7)
            self.beacons.append((bulb, halo))

        # schwebendes Schild "KLICK MICH!"
        self.holo = Entity(parent=self.root, position=(0, 24.0, 0), add_to_scene_entities=False)
        self.board = Entity(parent=self.holo, billboard=True, add_to_scene_entities=False)
        self.halo = glow(self.holo, (0, 0, 0.05), (20, 8), color.rgba(1, 0.55, 0.1, 0.3), bin_order=8)
        frame = Entity(parent=self.board, model=Quad(radius=0.06, aspect=12.4 / 4.4), scale=(12.4, 4.4),
                       position=(0, 0, 0.02), color=color.rgba(1, 0.6, 0.15, 0.9), shader=graphics.unlit(),
                       add_to_scene_entities=False)
        back = Entity(parent=self.board, model=Quad(radius=0.06, aspect=12.0 / 4.0), scale=(12.0, 4.0),
                      position=(0, 0, 0.01), color=color.rgba(0.04, 0.05, 0.07, 0.86), shader=graphics.unlit(),
                      add_to_scene_entities=False)
        for e in (frame, back):
            e.setTransparency(TransparencyAttrib.M_alpha)
            e.setLightOff()
            e.setFogOff()
            e.setDepthWrite(False)
            e.setTwoSided(True)
            e.setBin("fixed", 8)
        self.title = Text(parent=self.board, text="KLICK MICH!", origin=(0, 0), position=(0, 0.45, 0),
                          scale=62, color=color.rgba(1, 0.68, 0.15, 1))
        self.sub = Text(parent=self.board, text="", origin=(0, 0), position=(0, -1.15, 0), scale=19,
                        color=color.rgba(1, 1, 1, 0.8))
        for t in (self.title, self.sub):
            t.setLightOff()
            t.setFogOff()
            t.setBin("fixed", 9)
            t.setTwoSided(True)
            t.setDepthWrite(False)
        self.arrow = Entity(parent=self.holo, model=models.mesh_from_parts([("cone", (0, 0, 0), (1.3, 1.2, 1.3),
                                                                              (1, 0.68, 0.15))]),
                            position=(0, -3.4, 0), rotation=(180, 0, 0), shader=graphics.unlit(),
                            add_to_scene_entities=False)
        self.arrow.setLightOff()
        self.arrow.setFogOff()
        self.set_planet(planet)

        # unsichtbare Klickfläche um die Rakete
        # Ursina findet Klickziele nur in scene.entities -> diese beiden müssen dort eingetragen sein
        self.clicker = Entity(parent=self.root, collider="box", position=(0, 10, 0), scale=(4.4, 19, 4.4))
        self.clicker.on_click = self._clicked
        self.sign_click = Entity(parent=self.board, collider="box", scale=(12.4, 4.4, 0.2))
        self.sign_click.on_click = self._clicked

    # ------------------------------------------------------------------
    def set_planet(self, planet, locked=None):
        self.planet = planet
        if locked is not None:
            self.locked = locked
        for beam, lamp in getattr(self, "beams", ()):
            beam.enabled = lamp.enabled and planet != "moon"
        if planet == "moon":
            self.set_sign("ZURÜCK ZUR ERDE", "Klick auf die Rakete oder drücke L", self.holo.enabled)
        elif getattr(self, "locked", False):
            from . import config as C
            from . import rules
            self.set_sign("KLICK MICH!", f"Rakete freischalten: {rules.format_money(C.ROCKET_PRICE)}",
                          self.holo.enabled)
        else:
            self.set_sign("KLICK MICH!", "Zum Mond fliegen  ·  Klick auf die Rakete oder drücke L", self.holo.enabled)

    def set_sign(self, title, sub, visible=True):
        if self.title.text != title:
            self.title.text = title
        if self.sub.text != sub:
            self.sub.text = sub
        self.holo.enabled = visible

    def _clicked(self):
        if not self.busy and self.on_click is not None:
            self.on_click()

    @property
    def enabled(self):
        return self.root.enabled

    @enabled.setter
    def enabled(self, on):
        self.root.enabled = on
        if not on:
            self.fx.clear()

    def set_lights(self, n):
        """n Flutlichter an (für die Enthüllung nacheinander). Auf dem Mond sieht man keine Lichtkegel."""
        for i, (beam, lamp) in enumerate(self.beams):
            lamp.enabled = i < n
            beam.enabled = i < n and self.planet != "moon"

    def reset(self):
        """Rakete wieder auf den Starttisch, Brücke und Leitung angedockt."""
        self.rocket.root.position = (0, MOUNT_TOP, 0)
        self.rocket.reset()
        self.rocket.set_firing(False)
        self.arm_pivot.rotation = (0, 0, 0)
        self.umb_pivot.rotation = (0, 0, 0)
        self.arm.enabled = self.umb.enabled = True
        self.holo.enabled = True
        self.set_lights(len(self.beams))
        self.busy = False

    def destroy(self):
        from ursina import destroy
        self.fx.clear()
        try:
            self.fx.batch.holder.removeNode()
        except Exception:
            pass
        destroy(self.root)

    # ------------------------------------------------------------------ Animation
    def rot(self, v):
        """Richtung vom Rampen- ins Weltkoordinatensystem drehen."""
        a = math.radians(self.YAW)
        x, y, z = v[0], v[1], v[2]
        return Vec3(x * math.cos(a) + z * math.sin(a), y, -x * math.sin(a) + z * math.cos(a))

    def world(self, v):
        return self.root.world_position + self.rot(v)

    def emit(self, local, kind, count=1, direction=None):
        d = self.rot(direction) if direction is not None else None
        self.fx.emit(self.world(local), kind, count, direction=d, force=True)

    def update(self, dt, cam_pos=None):
        if not self.root.enabled:
            return
        self.t += dt
        t = self.t
        self.rocket.update(dt)
        # Schild schwebt und pulsiert, bei Mauskontakt größer
        hover = mouse.hovered_entity in (self.clicker, self.sign_click) and not self.busy
        self.holo.y = 24.0 + math.sin(t * 1.3) * 0.3
        pulse = 1.0 + 0.06 * max(0.0, math.sin(t * 4.0)) ** 4 + (0.08 if hover else 0.0)
        self.board.scale = pulse
        self.halo.color = color.rgba(1, 0.55, 0.1, (0.45 if hover else 0.25) + 0.1 * math.sin(t * 2.2))
        self.arrow.y = -3.4 - abs(math.sin(t * 3.0)) * 0.6
        self.arrow.rotation_y = t * 90
        for i, (bulb, halo) in enumerate(self.beacons):
            on = (t * 1.1 + i * 0.5) % 1.0 < 0.5
            bulb.color = color.rgba(1, 0.1, 0.05, 1) if on else color.rgba(0.3, 0.05, 0.03, 1)
            halo.enabled = on
        # Dampf: Sauerstoff entweicht an der Oberstufe, Bodennebel um den Starttisch
        self._vent_t += dt
        near = cam_pos is None or (cam_pos[0] - self.center.x) ** 2 + (cam_pos[2] - self.center.z) ** 2 < 140 ** 2
        if near and self._vent_t > 0.09 and not self.rocket.firing and self.rocket.root.y < MOUNT_TOP + 0.1:
            self._vent_t = 0.0
            ry = self.rocket.root.y
            if random.random() < 0.7:
                a = random.uniform(0, 2 * math.pi)
                self.emit((math.cos(a) * 0.95, ry + random.choice((10.4, 12.6)), math.sin(a) * 0.95), "vent", 1,
                          direction=(math.cos(a) * 0.8, -0.2, math.sin(a) * 0.8))
            if random.random() < 0.45:
                a = random.uniform(0, 2 * math.pi)
                r = random.uniform(1.0, 3.2)
                self.emit((math.cos(a) * r, 0.6, math.sin(a) * r), "fog", 1,
                          direction=(math.cos(a) * 0.4, 0.05, math.sin(a) * 0.4))
        self.fx.update(dt)


# ============================================================================= Kino-Hilfen
class Cinema:
    """Schwarze Balken oben/unten, Abblende und große Bildunterschriften."""

    def __init__(self):
        self.top = Entity(parent=camera.ui, model="quad", color=color.black, scale=(4, 0.13), y=0.57, z=-5)
        self.bottom = Entity(parent=camera.ui, model="quad", color=color.black, scale=(4, 0.13), y=-0.57, z=-5)
        self.fade = Entity(parent=camera.ui, model="quad", color=color.rgba(0, 0, 0, 0), scale=(4, 2), z=-6)
        self.fade.setTransparency(TransparencyAttrib.M_alpha)
        self.shadow = Text(parent=camera.ui, text="", origin=(0, 0), y=0.044, x=0.004, scale=2.6, z=-6.9,
                           color=color.rgba(0, 0, 0, 0))
        self.caption = Text(parent=camera.ui, text="", origin=(0, 0), y=0.05, scale=2.6, z=-7,
                            color=color.rgba(1, 1, 1, 0))
        self.small = Text(parent=camera.ui, text="", origin=(0, 0), y=-0.4, scale=1.3, z=-7,
                          color=color.rgba(1, 1, 1, 0))
        self.skip = Text(parent=camera.ui, text="", origin=(0.5, 0), x=0.84, y=-0.47, scale=0.85, z=-7,
                         color=color.rgba(1, 1, 1, 0.45))
        self._bars = 0.0

    def bars(self, k):
        self._bars = k
        h = 0.13 * k
        self.top.scale_y = self.bottom.scale_y = max(0.0001, h)
        self.top.y = 0.5 - h / 2
        self.bottom.y = -0.5 + h / 2
        self.top.enabled = self.bottom.enabled = k > 0.001

    def set_fade(self, a):
        self.fade.color = color.rgba(0, 0, 0, max(0.0, min(1.0, a)))
        self.fade.enabled = a > 0.001

    def say(self, text, small="", size=2.6):
        if self.caption.text != text:
            self.caption.text = text
            self.shadow.text = text
        if self.small.text != small:
            self.small.text = small
        self.size(size)

    def size(self, s):
        self.caption.scale = s
        self.shadow.scale = s

    def caption_alpha(self, a, small_a=None):
        self.caption.color = color.rgba(1, 0.97, 0.9, max(0.0, min(1.0, a)))
        self.shadow.color = color.rgba(0, 0, 0, max(0.0, min(1.0, a)) * 0.6)
        self.small.color = color.rgba(1, 1, 1, max(0.0, min(1.0, a if small_a is None else small_a)))

    def destroy(self):
        from ursina import destroy
        for e in (self.top, self.bottom, self.fade, self.caption, self.shadow, self.small, self.skip):
            destroy(e)


class _Sequence:
    """Gemeinsame Basis: übernimmt die Kamera, blendet die Oberfläche aus und gibt am Ende alles zurück."""

    def __init__(self, client):
        self.client = client
        self.t = 0.0
        self.done = False
        self.cin = Cinema()
        self._shake = 0.0
        c = client
        c._close_windows()
        c.hud.hide()
        c.info.hide()
        c.ghost.enabled = False
        c.hover_frame.enabled = False
        c.cam.active = False
        self._saved_far = camera.clip_plane_far
        from ursina import scene
        pos = Vec3(camera.world_position)
        camera.parent = scene
        camera.world_position = pos

    def look(self, pos, target):
        sx = (random.uniform(-1, 1) * self._shake)
        sy = (random.uniform(-1, 1) * self._shake)
        look_from(Vec3(pos) + Vec3(sx, sy, 0), Vec3(target) + Vec3(sx * 0.3, sy * 0.3, 0))

    def finish(self, focus=None, distance=30.0):
        if self.done:
            return
        self.done = True
        c = self.client
        self.cin.destroy()
        space = getattr(self, "space", None)
        if space is not None:
            space.end()
        try:
            c.world.set_sky_visible(True)
            c.world.restore_background()
            graphics.set_fog(*c.world.fog_settings())
        except Exception:
            pass
        camera.clip_plane_far = self._saved_far
        c.cam.attach()
        c.cam.active = True
        if focus is not None:
            c.cam.focus(focus[0], focus[1])
            c.cam.distance = c.cam.target_distance = distance
            c.cam.pitch = 38
        if c._in_game():
            c.hud.show()

    def skip(self):
        pass


# ============================================================================= Enthüllung
class RevealSequence(_Sequence):
    """Der Countdown ist abgelaufen: Die Baustelle verschwindet im Dampf, die Rakete steht da."""

    DURATION = 11.0

    def __init__(self, client, pad, teaser):
        super().__init__(client)
        self.pad = pad
        self.teaser = teaser
        self.swapped = False
        self.lights_on = 0
        self.cin.skip.text = "Esc: überspringen"
        self.c0 = Vec3(pad.center)
        self.start_cam = Vec3(camera.world_position)
        pad.enabled = False
        pad.busy = True
        if teaser is not None:
            teaser.root.enabled = True
            teaser.force_zero = True
        client.audio.play("upgrade")

    def skip(self):
        self.t = max(self.t, self.DURATION - 0.6)
        self._swap()
        self.pad.set_lights(len(self.pad.beams))

    def _swap(self):
        if self.swapped:
            return
        self.swapped = True
        if self.teaser is not None:
            self.teaser.root.enabled = False
        self.pad.enabled = True
        self.pad.reset()
        self.pad.busy = True
        self.pad.set_lights(0)
        self.pad.holo.enabled = False

    def update(self, dt):
        self.t += dt
        t = self.t
        c0 = self.c0
        cin = self.cin
        cin.bars(_ease(t / 1.0) * (1 - _ease((t - self.DURATION + 1.0) / 1.0)))
        # Kamera: Anflug, dann langsame Kreisfahrt um die Rampe
        a = math.radians(22 + t * 4.5)                 # nur über der Fabrikseite (dort stehen keine Bäume)
        dist = 54 - 8 * _ease(t / 7)
        orbit = c0 + Vec3(math.sin(a) * dist, 9 + 4 * _ease(t / 8), math.cos(a) * dist)
        k = _ease(t / 2.2)
        pos = orbit_lerp(c0, self.start_cam, orbit, k)
        self._shake = 0.12 if 2.4 < t < 3.8 else 0.0
        self.look(pos, c0 + Vec3(0, 7 + 4 * _ease((t - 4) / 4), 0))
        # Texte
        if t < 2.6:
            cin.say("DER COUNTDOWN IST ABGELAUFEN")
            cin.caption_alpha(_ease((t - 0.3) / 0.6) * (1 - _ease((t - 2.0) / 0.5)))
        elif 6.0 < t < 10.6:
            cin.say("DAS MOND-UPDATE IST DA!", "Klick auf die Rakete, um zum Mond zu fliegen")
            cin.caption_alpha(_ease((t - 6.0) / 0.6) * (1 - _ease((t - 9.9) / 0.6)),
                              _ease((t - 7.4) / 0.6) * (1 - _ease((t - 9.9) / 0.6)))
        else:
            cin.caption_alpha(0)
        # gewaltiger Dampfausstoß, in dem die Baustelle verschwindet
        if 2.3 < t < 6.5:
            n = 10 if t < 4.0 else 4
            for _ in range(n):
                ang = random.uniform(0, 2 * math.pi)
                r = random.uniform(0, 4.5)
                self.pad.fx.emit(c0 + Vec3(math.cos(ang) * r, random.uniform(0.3, 5.0), math.sin(ang) * r),
                                 "cloud", 1, direction=(math.cos(ang) * random.uniform(1, 4), random.uniform(0.3, 2.2),
                                                        math.sin(ang) * random.uniform(1, 4)), force=True)
        if 2.3 < t < 2.4 and not getattr(self, "_boom", False):
            self._boom = True
            self.client.audio.play("clang", 0.7)
            self.client.audio.play("whoosh")
        if t > 3.6:
            self._swap()
        # Flutlichter gehen nacheinander an
        if self.swapped:
            want = min(len(self.pad.beams), int((t - 4.6) / 0.7) + 1) if t > 4.6 else 0
            if want > self.lights_on:
                self.lights_on = want
                self.pad.set_lights(want)
                self.client.audio.play("build", 0.8)
        if t > 9.2:
            self.pad.holo.enabled = True
        # Partikel der Rampe laufen auch, während sie (noch) unsichtbar ist
        if not self.pad.enabled:
            self.pad.fx.update(dt)
        if t >= self.DURATION:
            self.pad.busy = False
            self.pad.reset()
            self.finish(focus=(c0.x + 10, c0.z + 10), distance=52)


# ============================================================================= Start, Flug, Landung
class LaunchSequence(_Sequence):
    """Brücke fällt weg -> Countdown -> Start -> Flug durchs All -> Landung auf dem Ziel."""

    T_IGNITE = 4.0
    T_LIFT = 4.6
    T_FADE = 10.4
    T_SPACE = 11.2

    def __init__(self, client, pad, dest):
        super().__init__(client)
        self.pad = pad
        self.dest = dest
        self.phase = "launch"
        self.c0 = Vec3(pad.center)
        self.start_cam = Vec3(camera.world_position)
        self.travel_sent = False
        self.wait_t = 0.0
        self.land_t = 0.0
        self.events = set()
        self.space = None
        pad.busy = True
        pad.holo.enabled = False
        self.ground_kind = "dust_m" if pad.planet == "moon" else "cloud"

    def _once(self, key):
        if key in self.events:
            return False
        self.events.add(key)
        return True

    # ---------------------------------------------------------------- Netzwerk
    def on_world(self, planet):
        """Server hat uns auf den anderen Himmelskörper gesetzt: Landung beginnt."""
        if self.phase == "wait":
            self.phase = "land"
            self.land_t = 0.0
            if self.space is not None:
                self.space.end()
            self.client.world.restore_background()
            self.client.world.set_sky_visible(True)
            pad = self.client.world.launchpad
            self.pad = pad
            if pad is not None:
                pad.enabled = True
                pad.reset()
                pad.busy = True
                pad.holo.enabled = False
                pad.rocket.show_boosters(False)
                pad.rocket.root.y = MOUNT_TOP + 46
                pad.rocket.set_firing(True, 0.9)
                self.c0 = Vec3(pad.center)
                self.ground_kind = "dust_m" if planet == "moon" else "cloud"
            self.client.audio.play("rocket_land")
            graphics.set_fog(*self.client.world.fog_settings())
            camera.clip_plane_far = self._saved_far

    def on_failed(self, msg):
        self.client.hud.toast_show(msg, "error", 3)
        self._restore_world_view()
        self.pad.reset()
        self.finish(focus=(self.c0.x + 10, self.c0.z + 10), distance=52)

    def _restore_world_view(self):
        if self.space is not None:
            self.space.end()
        w = self.client.world
        w.set_sky_visible(True)
        graphics.set_fog(*w.fog_settings())
        camera.clip_plane_far = self._saved_far
        self.client.audio.stop("rocket_launch")

    # ---------------------------------------------------------------- Ablauf
    def update(self, dt):
        self.t += dt
        if self.phase == "launch":
            self._launch(dt)
        elif self.phase == "space":
            self._space(dt)
        elif self.phase == "wait":
            self.wait_t += dt
            self.cin.set_fade(1.0)
            if self.wait_t > 10:
                self.on_failed("Keine Antwort vom Server – Flug abgebrochen.")
        elif self.phase == "land":
            self._land(dt)

    def _launch(self, dt):
        t = self.t
        pad, cin, c0 = self.pad, self.cin, self.c0
        rk = pad.rocket
        audio = self.client.audio
        cin.bars(_ease(t / 0.8))
        # --- Brücke schwenkt weg und fällt zur Seite, Versorgungsleitung fällt beim Zünden
        if 0.6 < t < 2.2:
            k = _ease((t - 0.6) / 0.9)
            pad.arm_pivot.rotation_y = -105 * k
            if t > 1.5:
                f = (t - 1.5) / 0.7
                pad.arm_pivot.rotation_z = -min(1.0, f * f) * 72 + (math.sin(f * 14) * 4 * (1 - f) if f < 1 else 0)
                if self._once("clang"):
                    audio.play("clang")
        if t > self.T_IGNITE - 0.2:
            k = _ease((t - self.T_IGNITE + 0.2) / 0.5)
            pad.umb_pivot.rotation_z = -80 * k
        # --- Countdown 3, 2, 1
        for i, n in enumerate(("3", "2", "1")):
            ts = 1.4 + i * 1.0
            if ts <= t < ts + 1.0:
                cin.say(n, size=4.0)
                f = (t - ts)
                cin.size(4.0 * (1.4 - 0.4 * _ease(f / 0.25)))
                cin.caption_alpha(1 - _ease((f - 0.6) / 0.35))
                if self._once("beep" + n):
                    audio.play("beep")
        if self.T_LIFT <= t < self.T_LIFT + 1.6:
            cin.say("START!", "Auf zum Mond" if self.dest == "moon" else "Zurück zur Erde", size=3.6)
            f = t - self.T_LIFT
            cin.caption_alpha(_ease(f / 0.2) * (1 - _ease((f - 1.1) / 0.4)))
        elif t > self.T_LIFT + 1.6 and t < self.T_LIFT + 1.7:
            cin.caption_alpha(0)
        # --- Zündung: Flammen, gewaltige Wolken aus dem Flammengraben, Beben
        if t > self.T_IGNITE - 0.3 and self._once("roar"):
            audio.play("rocket_launch")
        if t >= self.T_IGNITE:
            power = _ease((t - self.T_IGNITE) / 0.5)
            if not rk.firing:
                rk.set_firing(True, power)
            rk.power = power
            nz = rk.root.world_position
            base_y = rk.root.y
            # Wolken seitlich aus dem Graben (nur solange die Rakete tief ist)
            if base_y < MOUNT_TOP + 22:
                n = 7 if self.ground_kind == "cloud" else 5
                for _ in range(n):
                    side = random.choice((-1, 1))
                    sp = random.uniform(5, 11)
                    pad.emit((side * random.uniform(0.5, 2.5), 0.6, random.uniform(-0.6, 0.6)), self.ground_kind, 1,
                             direction=(side * sp, random.uniform(0.5, 2.5), random.uniform(-1.5, 1.5)))
                for _ in range(2):
                    a = random.uniform(0, 2 * math.pi)
                    pad.fx.emit(c0 + Vec3(math.cos(a) * 1.5, 0.8, math.sin(a) * 1.5), self.ground_kind, 1,
                                direction=(math.cos(a) * 6, 1.5, math.sin(a) * 6), force=True)
            # Feuer und Rauchsäule direkt am Triebwerk
            for _ in range(3):
                pad.fx.emit(nz + Vec3(random.uniform(-0.5, 0.5), -1.2, random.uniform(-0.5, 0.5)), "fire", 1,
                            direction=(random.uniform(-1, 1), -random.uniform(8, 14), random.uniform(-1, 1)), force=True)
            if t > self.T_LIFT:
                for _ in range(3):
                    pad.fx.emit(nz + Vec3(random.uniform(-0.7, 0.7), -random.uniform(2.5, 5.0), random.uniform(-0.7, 0.7)),
                                "cloud", 1, direction=(random.uniform(-1, 1), -3.0, random.uniform(-1, 1)), force=True)
            self._shake = 0.05 + 0.3 * _ease((t - self.T_IGNITE) / 1.0) * (1 - _ease((t - 8.0) / 2.0))
        # --- Abheben: beschleunigt nach oben
        if t > self.T_LIFT:
            lt = t - self.T_LIFT
            rk.root.y = MOUNT_TOP + 0.5 * 3.2 * lt * lt + 0.4 * lt
            rk.root.rotation_z = min(6.0, lt * lt * 0.25)          # leichtes Neigen (Gravity Turn)
        # --- Kamera
        rpos = rk.root.world_position
        if t < 2.4:
            k = _ease(t / 1.6)
            shot = c0 + Vec3(33, 10.0, 26)
            self.look(orbit_lerp(c0, self.start_cam, shot, k), c0 + Vec3(0, 11.5, 0))
        elif t < self.T_LIFT + 1.4:
            f = t - 2.4
            self.look(c0 + Vec3(37 - f * 1.0, 6.0, 30 - f * 0.8), c0 + Vec3(0, 9.5, 0))
        elif t < self.T_LIFT + 3.6:
            self.look(c0 + Vec3(33, 5.0, 27), rpos + Vec3(0, 6, 0))
        else:
            lt = t - self.T_LIFT - 3.6
            self.look(rpos + Vec3(12 + lt, -8 - lt * 2.5, 9 + lt), rpos + Vec3(0, 9, 0))
        # --- Abblende und Wechsel ins All
        if t > self.T_FADE:
            cin.set_fade(_ease((t - self.T_FADE) / 0.7))
        if t >= self.T_SPACE:
            self.phase = "space"
            self.space_t = 0.0
            self._shake = 0.0
            pad.fx.clear()
            rk.set_firing(False)
            audio.stop("rocket_launch")
            audio.play("whoosh", 0.8)
            if self.space is None:
                from .space import SpaceScene
                self.space = SpaceScene()
            self.client.world.set_sky_visible(False)
            graphics.set_fog(strength=0.0)
            camera.clip_plane_far = 1600
            self.space.begin(self.dest)

    def _space(self, dt):
        self.space_t += dt
        t = self.space_t
        sp = self.space
        cin = self.cin
        sp.update(t, dt)
        cin.set_fade(1 - _ease(t / 0.6) if t < 1 else _ease((t - sp.DURATION + 0.8) / 0.8))
        title = "AUF DEM WEG ZUM MOND" if self.dest == "moon" else "AUF DEM WEG ZUR ERDE"
        cin.say(title, "384.400 km", size=2.4)
        cin.caption_alpha(_ease((t - 1.0) / 0.6) * (1 - _ease((t - 4.6) / 0.6)))
        if t >= sp.DURATION and not self.travel_sent:
            self.travel_sent = True
            self.phase = "wait"
            self.wait_t = 0.0
            cin.caption_alpha(0)
            self.client.request_travel(self.dest)

    def _land(self, dt):
        self.land_t += dt
        t = self.land_t
        pad, cin = self.pad, self.cin
        if pad is None:
            self.finish()
            return
        c0 = self.c0
        rk = pad.rocket
        cin.set_fade(1 - _ease(t / 0.8))
        dur = 4.3
        k = min(1.0, t / dur)
        h = 46 * (1 - k) ** 2.2
        rk.root.y = MOUNT_TOP + h
        if t < dur:
            rk.power = 0.45 + 0.5 * (1 - k)
            if h < 16:
                for _ in range(4):
                    a = random.uniform(0, 2 * math.pi)
                    sp = random.uniform(3, 8)
                    pad.fx.emit(c0 + Vec3(math.cos(a), 0.5, math.sin(a)), self.ground_kind, 1,
                                direction=(math.cos(a) * sp, random.uniform(0.2, 1.4), math.sin(a) * sp), force=True)
            pad.fx.emit(rk.root.world_position + Vec3(0, -1.2, 0), "fire", 2,
                        direction=(0, -9, 0), force=True)
            self._shake = 0.08 * (1 - k)
        elif rk.firing:
            rk.set_firing(False)
            self._shake = 0.0
        self.look(c0 + Vec3(37 - t * 0.8, 8 + h * 0.3, 30), c0 + Vec3(0, 9 + h * 0.8, 0))
        welcome = "WILLKOMMEN AUF DEM MOND" if self.dest == "moon" else "WILLKOMMEN ZURÜCK AUF DER ERDE"
        small = "Hier bezahlst du mit Mooncoins (MC)" if self.dest == "moon" else "Hier zählen wieder Euro"
        if t > dur + 0.2:
            cin.say(welcome, small, size=2.4)
            f = t - dur - 0.2
            cin.caption_alpha(_ease(f / 0.5) * (1 - _ease((f - 2.4) / 0.5)))
            cin.bars(1 - _ease((f - 2.4) / 0.8))
        if t > dur + 3.4:
            pad.busy = False
            pad.reset()
            pad.rocket.show_boosters(False)
            pad.set_planet(self.dest)
            self.finish(focus=(c0.x + 10, c0.z + 10), distance=52)


def now():
    return time.time()
