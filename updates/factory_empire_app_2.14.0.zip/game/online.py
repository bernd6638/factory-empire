"""
Online-Hilfen für den Server: Adressen ermitteln und Router-Port automatisch freigeben.

* UPnP (IGD): Viele Router (FritzBox, Speedport, TP-Link …) erlauben Programmen,
  selbst eine Portfreigabe anzulegen. Der Server versucht das beim Start und
  entfernt die Freigabe beim Beenden wieder. Reine Python-Standardbibliothek,
  keine zusätzlichen Pakete.
* Öffentliche IP: zuerst beim Router erfragen (UPnP), zusätzlich über einen
  kostenlosen Dienst (api.ipify.org) gegenprüfen. Stimmen beide nicht überein,
  hängt der Anschluss hinter Carrier-NAT/DS-Lite – dann ist IPv4 von außen
  nicht erreichbar und es wird ein Hinweis ausgegeben.
"""

import ipaddress
import logging
import re
import socket
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

log = logging.getLogger("factory.online")

SSDP_ADDR = ("239.255.255.250", 1900)
SEARCH_TARGETS = [
    "urn:schemas-upnp-org:device:InternetGatewayDevice:2",
    "urn:schemas-upnp-org:device:InternetGatewayDevice:1",
    "urn:schemas-upnp-org:service:WANIPConnection:1",
    "urn:schemas-upnp-org:service:WANPPPConnection:1",
]
WAN_SERVICES = ("WANIPConnection", "WANPPPConnection")
DESCRIPTION = "Factory Empire"


# ----------------------------------------------------------------------------- Adressen
def local_ipv4():
    """IPv4-Adresse dieses Rechners im Heimnetz (es werden keine Daten gesendet)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


def global_ipv6():
    """Öffentliche IPv6-Adresse dieses Rechners, falls vorhanden."""
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
    except OSError:
        return None
    try:
        s.connect(("2001:4860:4860::8888", 80))
        addr = ipaddress.ip_address(s.getsockname()[0].split("%")[0])
        return str(addr) if addr.is_global else None
    except (OSError, ValueError):
        return None
    finally:
        s.close()


def public_ipv4_from_internet(timeout=4.0):
    for url in ("https://api.ipify.org", "https://ipv4.icanhazip.com"):
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                text = resp.read(64).decode().strip()
            return str(ipaddress.IPv4Address(text))
        except (OSError, ValueError):
            continue
    return None


def is_public_ipv4(ip):
    try:
        addr = ipaddress.IPv4Address(ip)
    except (ValueError, TypeError):
        return False
    # 100.64.0.0/10 = Carrier-NAT des Providers
    return addr.is_global and addr not in ipaddress.IPv4Network("100.64.0.0/10")


# ----------------------------------------------------------------------------- UPnP
def parse_ssdp_location(data):
    match = re.search(rb"^location:\s*(\S+)\s*$", data, re.IGNORECASE | re.MULTILINE)
    return match.group(1).decode(errors="ignore") if match else None


def _strip_ns(tag):
    return tag.split("}", 1)[-1]


def parse_device_description(xml_text, location):
    """Sucht im Gerätebeschreibungs-XML den WAN-Dienst. Gibt (control_url, service_type) zurück."""
    root = ET.fromstring(xml_text)
    base = location
    for el in root.iter():
        if _strip_ns(el.tag) == "URLBase" and el.text and el.text.strip():
            base = el.text.strip()
    for service in root.iter():
        if _strip_ns(service.tag) != "service":
            continue
        fields = {_strip_ns(c.tag): (c.text or "").strip() for c in service}
        stype = fields.get("serviceType", "")
        if any(name in stype for name in WAN_SERVICES) and fields.get("controlURL"):
            return urllib.parse.urljoin(base, fields["controlURL"]), stype
    return None, None


def _soap(control_url, service_type, action, args, timeout=4.0):
    body_args = "".join(f"<{k}>{v}</{k}>" for k, v in args)
    body = (
        '<?xml version="1.0"?>'
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
        's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
        f'<u:{action} xmlns:u="{service_type}">{body_args}</u:{action}>'
        "</s:Body></s:Envelope>"
    ).encode()
    req = urllib.request.Request(control_url, data=body, method="POST", headers={
        "Content-Type": 'text/xml; charset="utf-8"',
        "SOAPAction": f'"{service_type}#{action}"',
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode(errors="ignore")


def _soap_value(xml_text, name):
    match = re.search(rf"<{name}>([^<]*)</{name}>", xml_text)
    return match.group(1).strip() if match else None


class UPnPPortMapper:
    def __init__(self, port):
        self.port = port
        self.control_url = None
        self.service_type = None
        self.local_ip = None
        self.mapped = False
        self.router_ip = None

    def discover(self, timeout=2.5):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        sock.settimeout(timeout)
        locations = []
        try:
            for st in SEARCH_TARGETS:
                msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
                       f'MAN: "ssdp:discover"\r\nMX: 2\r\nST: {st}\r\n\r\n').encode()
                sock.sendto(msg, SSDP_ADDR)
            while True:
                try:
                    data, _addr = sock.recvfrom(4096)
                except socket.timeout:
                    break
                loc = parse_ssdp_location(data)
                if loc and loc not in locations:
                    locations.append(loc)
        except OSError as exc:
            log.debug("SSDP fehlgeschlagen: %s", exc)
        finally:
            sock.close()

        for loc in locations:
            try:
                with urllib.request.urlopen(loc, timeout=4) as resp:
                    xml_text = resp.read()
                control, stype = parse_device_description(xml_text, loc)
            except (OSError, ET.ParseError) as exc:
                log.debug("Gerätebeschreibung %s nicht lesbar: %s", loc, exc)
                continue
            if control:
                self.control_url, self.service_type = control, stype
                host = urllib.parse.urlparse(loc).hostname
                self.router_ip = host
                self.local_ip = self._local_ip_towards(host)
                return True
        return False

    @staticmethod
    def _local_ip_towards(host):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((host, 1900))
            return s.getsockname()[0]
        except OSError:
            return local_ipv4()
        finally:
            s.close()

    def external_ip(self):
        try:
            return _soap_value(_soap(self.control_url, self.service_type, "GetExternalIPAddress", []),
                               "NewExternalIPAddress")
        except OSError:
            return None

    def add_mapping(self):
        last_error = None
        for lease in (0, 86400):          # manche Router akzeptieren nur befristete Freigaben
            try:
                _soap(self.control_url, self.service_type, "AddPortMapping", [
                    ("NewRemoteHost", ""), ("NewExternalPort", self.port), ("NewProtocol", "TCP"),
                    ("NewInternalPort", self.port), ("NewInternalClient", self.local_ip),
                    ("NewEnabled", 1), ("NewPortMappingDescription", DESCRIPTION),
                    ("NewLeaseDuration", lease)])
                self.mapped = True
                return True, None
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode(errors="ignore")
                last_error = _soap_value(detail, "errorDescription") or f"HTTP {exc.code}"
            except OSError as exc:
                last_error = str(exc)
        return False, last_error

    def remove_mapping(self):
        if not self.mapped:
            return
        try:
            _soap(self.control_url, self.service_type, "DeletePortMapping", [
                ("NewRemoteHost", ""), ("NewExternalPort", self.port), ("NewProtocol", "TCP")])
            log.info("UPnP: Portfreigabe %s im Router wieder entfernt.", self.port)
        except OSError:
            pass
        self.mapped = False


# ----------------------------------------------------------------------------- Bericht
def setup_online(port, use_upnp=True, report=None):
    """Ermittelt alle Adressen, versucht die Portfreigabe und gibt einen Bericht aus.

    Rückgabe: UPnPPortMapper (zum späteren Entfernen der Freigabe) oder None.
    Ist `report` ein dict, werden die Ergebnisse dort zusätzlich eingetragen
    (lan, public, ipv6, port, upnp_ok, upnp_error, cgnat) – das Spiel zeigt sie dem Host an.
    """
    lines = ["", "=" * 66, "  ONLINE-MODUS – so können Freunde beitreten", "=" * 66]
    lan = local_ipv4()
    mapper = None
    router_ext = None
    upnp_ok = False
    upnp_error = None if use_upnp else "abgeschaltet (--no-upnp)."

    if use_upnp:
        mapper = UPnPPortMapper(port)
        if mapper.discover():
            router_ext = mapper.external_ip()
            upnp_ok, upnp_error = mapper.add_mapping()
        else:
            upnp_error = "Kein UPnP-fähiger Router gefunden (oder UPnP ist im Router abgeschaltet)."

    public = public_ipv4_from_internet()
    v6 = global_ipv6()

    if lan:
        lines.append(f"  Im selben WLAN/LAN:   {lan}   Port {port}")
    if public:
        lines.append(f"  Über das Internet:    {public}   Port {port}")
    if v6:
        lines.append(f"  Über IPv6:            {v6}   Port {port}")
    if not public and not router_ext:
        lines.append("  Öffentliche IP konnte nicht ermittelt werden – nachsehen auf wieistmeineip.de")
    lines.append("")

    cgnat = (router_ext is not None and not is_public_ipv4(router_ext)) or \
            (router_ext and public and router_ext != public)
    if upnp_ok and not cgnat:
        lines.append(f"  [OK] Port {port} wurde automatisch im Router freigegeben (UPnP).")
        lines.append(f"       Freunde geben im Spiel ein:  {public or router_ext}  und Port {port}")
    elif upnp_ok and cgnat:
        lines.append("  [!] Router-Freigabe ist zwar gesetzt, aber dein Anschluss hat KEINE eigene")
        lines.append("      öffentliche IPv4-Adresse (DS-Lite/Carrier-NAT). Von außen klappt IPv4 nicht.")
        if v6:
            lines.append(f"      Versuch es über IPv6: {v6} (IPv6-Freigabe im Router nötig, siehe README)")
        lines.append("      Sonst: Tailscale/ZeroTier oder einen gemieteten Server nutzen (README).")
    else:
        lines.append(f"  [!] Automatische Portfreigabe nicht möglich: {upnp_error}")
        lines.append(f"      Bitte im Router TCP-Port {port} auf {lan or 'diesen PC'} weiterleiten")
        lines.append("      (FritzBox: Internet > Freigaben > Portfreigaben). Anleitung: README.md.")
        if public:
            lines.append(f"      Danach treten Freunde bei mit:  {public}  und Port {port}")
    lines.append("  Firewall: Beim ersten Start die Frage nach Netzwerkzugriff mit ZULASSEN beantworten.")
    if report is not None:
        report.update({"lan": lan, "public": public or (router_ext if router_ext and is_public_ipv4(router_ext) else None),
                       "ipv6": v6, "port": port, "upnp_ok": bool(upnp_ok), "upnp_error": upnp_error,
                       "cgnat": bool(cgnat)})
    lines.append("=" * 66)
    print("\n".join(lines), flush=True)
    return mapper if upnp_ok else None
