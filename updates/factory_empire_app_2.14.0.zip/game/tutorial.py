"""
Tutorial für neue Spiele.

Startet automatisch, wenn man eine frische Welt betritt (Einzelspieler oder Mehrspieler):
noch kein Gebäude, keine Forschung. Jeder Schritt erklärt eine Sache und prüft selbst,
ob sie erledigt ist – dann geht es mit einem kurzen Erfolgseffekt weiter.
Hilfen: pulsierender Rahmen um den passenden Knopf der Hotbar und ein hüpfender
Pfeil in der Welt über dem Feld, auf das man bauen soll.
"""

import math
import time

from ursina import Entity, Vec3, color, destroy

from . import anim
from . import config as C
from . import graphics
from . import models
from .ui_base import ACCENT, BUTTON, BUTTON_ACCENT, GOOD, MUTED, PANEL_SOLID, TEXT, Btn, Label, ProgressBar, panel, rect


def _count(state, btype):
    return sum(1 for row in state.static.values() if row[1] == btype)


def _miner_on(state, ore):
    return any(row[1] == "miner" and state.deposits.get((row[2], row[3])) == ore for row in state.static.values())


# Jeder Schritt: Titel, Text, Bedingung (client -> bool), Hotbar-Hervorhebung, Welt-Ziel
STEPS = [
    {
        "title": "Willkommen bei Factory Empire!",
        "text": "Du startest mit 2.500 € und einer leeren Fabrikfläche. Bewege die Kamera: WASD fährt, "
                "rechte Maustaste gedrückt halten dreht, das Mausrad zoomt. Probier es kurz aus.",
        "done": lambda c: c.tutorial.cam_moved > 6.0,
    },
    {
        "title": "Erz abbauen: Miner",
        "text": "Drück 1 (oder klick unten auf den Miner) und setz ihn auf ein rötliches Eisenerz-Feld - der Pfeil "
                "zeigt eins. Mit E drehst du das Gebäude: Der Ausgang zeigt in Pfeilrichtung auf ein freies Feld.",
        "hotbar": "miner", "target": "iron",
        "done": lambda c: _miner_on(c.state, "iron_ore"),
    },
    {
        "title": "Lager bauen",
        "text": "Bau ein Lager (Taste 5) direkt vor den Ausgang des Miners. Das geförderte Erz landet dann im "
                "Firmenlager - oben in der Leiste siehst du deinen Bestand.",
        "hotbar": "storage", "target": "front_of_miner",
        "done": lambda c: c.state.inventory_total() > 0,
    },
    {
        "title": "Erstes Geld verdienen",
        "text": "Öffne den Markt mit M und verkaufe dein Erz (\"Alle\"). Preise sinken bei großen Mengen und "
                "erholen sich mit der Zeit.",
        "done": lambda c: (c.state.market or {}).get("total", 0) > 0,
    },
    {
        "title": "Forschung: Logistik",
        "text": "Öffne den Forschungsbaum mit R und starte \"Logistik\". Forschung kostet Geld und dauert ein paar "
                "Sekunden - sie schaltet Förderbänder frei.",
        "done": lambda c: "logistics" in c.state.unlocked or bool(c.state.research_active),
    },
    {
        "title": "Förderbänder",
        "text": "Sobald Logistik erforscht ist: Förderband (3) wählen und mit gedrückter linker Maustaste eine "
                "Reihe ziehen. Bänder transportieren in Pfeilrichtung und nehmen von hinten und den Seiten an. "
                "Baue mindestens 3 Bänder.",
        "hotbar": "conveyor",
        "done": lambda c: _count(c.state, "conveyor") >= 3,
    },
    {
        "title": "Schmelze: aus Erz wird Barren",
        "text": "Erforsche \"Schmelztechnik\" (R) und bau eine Schmelze (2). Verbinde: Miner -> Bänder -> Schmelze -> "
                "Band -> Lager. Eisenbarren sind etwa dreimal so viel wert wie Erz.",
        "hotbar": "smelter",
        "done": lambda c: c.state.inventory.get("iron_bar", 0) > 0
        or (c.state.market or {}).get("sold", {}).get("iron_bar", 0) > 0,
    },
    {
        "title": "Gebäude prüfen",
        "text": "Klick ein Gebäude an. Das Infofenster zeigt Status, Leistung pro Minute je Ausbaustufe und Knöpfe "
                "zum Drehen (E), Versetzen (G), Ausschalten (P) und Ausbauen (U). Die Lampe auf jeder Maschine: "
                "grün = arbeitet, gelb = wartet, rot = Problem.",
        "done": lambda c: c.selected is not None,
    },
    {
        "title": "Automatisch verkaufen",
        "text": "Erforsche \"Automatischer Verkauf\" und bau einen Verkäufer (4) ans Ende einer Kette. Er verkauft "
                "ohne dein Zutun - im Infofenster kannst du einen Mindestpreis einstellen.",
        "hotbar": "seller",
        "done": lambda c: _count(c.state, "seller") >= 1,
    },
    {
        "title": "Geschafft - jetzt wird es groß!",
        "text": "Jedes Material hat seine eigene Fabrik: Baustoffwerk (Ziegel, Glas), Hochofen (Stahl), "
                "Chemiewerk (Kunststoff), Elektronikwerk (Computer) und Großfabrik (Roboter, E-Autos). "
                "F1 zeigt alle Tasten, Esc öffnet das Menü. Viel Spaß!",
        "done": None,                       # nur mit "Fertig"
    },
]


class Tutorial:
    W, H = 0.78, 0.235

    def __init__(self, client, anchors):
        self.c = client
        self.active = False
        self.index = 0
        self.cam_moved = 0.0
        self._cam_last = None
        self._done_at = None
        self._t = 0.0
        self.root = Entity(parent=anchors["t"], position=(0, -0.105, -0.2), enabled=False)
        w, h = self.W, self.H
        panel(self.root, -w / 2, 0, w, h, PANEL_SOLID, radius=0.02)
        self.bar_accent = rect(self.root, -w / 2 + 0.014, 0, w - 0.028, 0.005, ACCENT)
        self.step_lbl = Label(self.root, "", -w / 2 + 0.025, -0.022, size=0.68, col=ACCENT)
        self.title = Label(self.root, "", -w / 2 + 0.025, -0.048, size=1.15, col=TEXT)
        self.text = Label(self.root, "", -w / 2 + 0.025, -0.092, size=0.72, col=MUTED, wordwrap=80)
        self.progress = ProgressBar(self.root, -w / 2 + 0.025, -h + 0.034, 0.3, 0.008, col=ACCENT)
        self.check = Label(self.root, "", -w / 2 + 0.34, -h + 0.045, size=0.72, col=GOOD)
        self.next_btn = Btn(self.root, "Weiter", w / 2 - 0.085, -h + 0.04, 0.13, 0.042, self.next_step,
                            col=BUTTON_ACCENT, size=0.75)
        self.skip_btn = Btn(self.root, "Tutorial beenden", w / 2 - 0.25, -h + 0.04, 0.18, 0.042, self.close,
                            col=BUTTON, size=0.66)
        # Hotbar-Hervorhebung und Pfeil in der Welt
        self.ring = None
        self.arrow = Entity(model=models.mesh_from_parts([
            ("cone", (0, 0, 0), (0.55, 0.7, 0.55), (0.98, 0.62, 0.16), (180, 0, 0)),
            ("cyl", (0, 0.6, 0), (0.18, 0.6, 0.18), (0.98, 0.62, 0.16))]),
            shader=graphics.unlit(), enabled=False)
        self.arrow.setLightOff()

    # ------------------------------------------------------------------ Steuerung
    @staticmethod
    def is_fresh_world(state):
        return not state.static and not state.unlocked and not state.research_active

    def start(self):
        self.active = True
        self.index = 0
        self.cam_moved = 0.0
        self._cam_last = None
        self.root.enabled = True
        root = self.root

        def f(v):
            root.y = -0.105 + 0.12 * (1 - v)
            root.scale = 0.9 + 0.1 * v
            anim.set_alpha(root, v)
        anim.tween(f, 0.5, delay=1.2, ease=anim.out_back, key="tut_in")
        self._show_step()

    def close(self):
        was = self.active
        self.active = False
        self.arrow.enabled = False
        self._clear_ring()
        root = self.root
        if not was or not root.enabled:
            root.enabled = False
            return

        def f(v):
            root.y = -0.105 + 0.1 * v
            anim.set_alpha(root, 1 - v)

        def done():
            if not self.active:
                root.enabled = False
            root.y = -0.105
            anim.set_alpha(root, 1)
        anim.tween(f, 0.25, ease=anim.in_cubic, key="tut_in", done=done)

    def next_step(self):
        if not self.active:
            return
        if self.index >= len(STEPS) - 1:
            self.close()
            self.c.hud.toast_show("Tutorial abgeschlossen - viel Erfolg mit deinem Imperium!", "success", 4)
            return
        self.index += 1
        self._show_step()

    def _show_step(self):
        step = STEPS[self.index]
        self._done_at = None
        self.step_lbl.set(f"TUTORIAL  ·  Schritt {self.index + 1} von {len(STEPS)}")
        self.title.set(step["title"])
        self.text.set(step["text"])
        self.check.set(" ")
        self.progress.set(self.index / (len(STEPS) - 1))
        last = step["done"] is None
        self.next_btn.set_text("Fertig" if last else "Überspringen")
        self.next_btn.set_color(BUTTON_ACCENT if last else BUTTON)
        # "Neuer Schritt"-Effekt: Titel und Text gleiten von rechts herein
        tl, tx = self.title, self.text
        x_t, x_x = -self.W / 2 + 0.025, -self.W / 2 + 0.025

        def f(v):
            tl.x = x_t + 0.05 * (1 - v)
            tx.x = x_x + 0.05 * (1 - min(1.0, v * 1.1))
            anim.set_alpha(tl, v)
            anim.set_alpha(tx, v)
        anim.tween(f, 0.4, ease=anim.out_cubic, key="tut_step")
        self._clear_ring()
        if step.get("hotbar"):
            slot = self.c.hud.slots.get(step["hotbar"])
            if slot:
                btn = slot["btn"]
                self.ring = Entity(parent=btn.parent, model="quad", position=(btn.x, btn.y, btn.z + 0.005),
                                   scale=btn.scale_x * 1.22, color=color.rgba(0.98, 0.62, 0.16, 0.9))
        self.arrow.enabled = False

    def _clear_ring(self):
        if self.ring is not None:
            destroy(self.ring)
            self.ring = None

    # ------------------------------------------------------------------ pro Frame
    def update(self, dt):
        if not self.active:
            return
        self._t += dt
        cam = self.c.cam
        pos = (cam.x, cam.z, cam.yaw, cam.target_distance)
        if anim.running("cam_intro"):              # Kamera-Einflug zählt nicht als "selbst bewegt"
            pos = None
        if self._cam_last is not None and pos is not None:
            self.cam_moved += sum(abs(a - b) for a, b in zip(pos, self._cam_last))
        self._cam_last = pos

        step = STEPS[self.index]
        if self.ring is not None:
            k = 0.5 + 0.5 * math.sin(self._t * 6)
            self.ring.color = color.rgba(0.98, 0.62, 0.16, 0.35 + 0.55 * k)
        self._update_arrow(step)

        if step["done"] is None or self._done_at is not None:
            if self._done_at is not None and time.time() - self._done_at > 1.4:
                self.next_step()
            return
        try:
            done = step["done"](self.c)
        except Exception:
            done = False
        if done:
            self._done_at = time.time()
            self.check.set("Erledigt!", GOOD)
            self.next_btn.set_text("Weiter")
            self.next_btn.set_color(BUTTON_ACCENT)
            anim.pop(self.root, 1.0, 0.05, 0.35)
            anim.pop(self.check, self.check.scale_x, 0.5, 0.45)
            self.c.audio.play("research")
            self._clear_ring()

    def _update_arrow(self, step):
        target = None
        state = self.c.state
        kind = step.get("target")
        if kind == "iron":
            target = self._nearest_free_deposit("iron_ore")
        elif kind == "front_of_miner":
            for row in state.static.values():
                if row[1] == "miner":
                    dx, dy = C.DIRS[row[4]]
                    target = (row[2] + dx, row[3] + dy)
                    break
        if target is None or self._done_at is not None:
            self.arrow.enabled = False
            return
        self.arrow.enabled = True
        bob = abs(math.sin(self._t * 3.2)) * 0.45
        self.arrow.position = Vec3(target[0], 1.4 + bob, target[1])
        self.arrow.rotation_y += 90 * 0.016

    def _nearest_free_deposit(self, ore):
        state = self.c.state
        cx, cz = (self.c.cam.x, self.c.cam.z)
        best, best_d = None, 1e9
        for (x, y), item in state.deposits.items():
            if item != ore or (x, y) in state.grid:
                continue
            d = (x - cx) ** 2 + (y - cz) ** 2
            if d < best_d:
                best, best_d = (x, y), d
        return best
