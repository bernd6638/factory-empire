"""
Discord-Status ("Rich Presence"): Discord zeigt bei deinem Profil an, dass du Factory Empire
spielst – mit Logo, Spielmodus, Geld, Anzahl Maschinen und Spielzeit.

Funktioniert, wenn die Discord-App auf demselben Rechner läuft. Läuft Discord nicht oder fehlt das
Paket pypresence, passiert einfach nichts (das Spiel läuft ganz normal weiter).
Alles läuft in einem eigenen Hintergrund-Thread, damit das Spiel nie auf Discord warten muss.
"""

import os
import threading
import time

from . import config as C

UPDATE_EVERY = 15.0           # Discord erlaubt etwa eine Aktualisierung alle 15 Sekunden
RETRY_EVERY = 30.0            # Discord nicht gefunden: so oft neu versuchen


def app_id():
    """Discord-Anwendungs-ID: aus config.py, zum Testen auch per Umgebungsvariable."""
    return os.environ.get("FACTORY_EMPIRE_DISCORD_ID", "").strip() or C.DISCORD_APP_ID


class DiscordPresence:
    def __init__(self):
        self.enabled = False
        self.info = {"details": "Im Hauptmenü", "state": None}
        self._sent = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self.connected = False

    def start(self, enabled=True):
        self.enabled = bool(enabled) and bool(app_id())
        if self.enabled and self._thread is None:
            self._thread = threading.Thread(target=self._run, name="discord-rpc", daemon=True)
            self._thread.start()

    def set_enabled(self, on):
        if on and not self.enabled:
            self.start(True)
        elif not on:
            self.enabled = False

    def set_info(self, details, state=None, start=None, party=None):
        """details: obere Zeile, state: untere Zeile, start: Unix-Zeit für "seit ...", party: (n, max)."""
        from .i18n import tr
        details, state = tr(details), (tr(state) if state else state)
        with self._lock:
            self.info = {"details": details[:120], "state": state[:120] if state else None,
                         "start": int(start) if start else None, "party": party}

    def stop(self):
        self._stop.set()

    # ------------------------------------------------------------------ Hintergrund-Thread
    def _run(self):
        import asyncio
        try:
            from pypresence import Presence
        except Exception:
            print("[Discord] pypresence nicht installiert – Discord-Status aus.")
            return
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        rpc = None
        while not self._stop.is_set():
            if not self.enabled:
                if rpc is not None:
                    try:
                        rpc.clear()
                        rpc.close()
                    except Exception:
                        pass
                    rpc, self._sent, self.connected = None, None, False
                self._stop.wait(2.0)
                continue
            if rpc is None:
                try:
                    rpc = Presence(app_id(), loop=loop)
                    rpc.connect()
                    self.connected = True
                    self._sent = None
                    print("[Discord] verbunden – Status wird angezeigt.")
                except Exception:
                    rpc, self.connected = None, False
                    self._stop.wait(RETRY_EVERY)
                    continue
            with self._lock:
                info = dict(self.info)
            if info != self._sent:
                try:
                    kw = {"details": info["details"], "large_image": "logo",
                          "large_text": f"Factory Empire {C.GAME_VERSION}"}
                    if info.get("state"):
                        kw["state"] = info["state"]
                    if info.get("start"):
                        kw["start"] = info["start"]
                    if info.get("party"):
                        kw["party_size"] = list(info["party"])
                    rpc.update(**kw)
                    self._sent = info
                except Exception:
                    try:
                        rpc.close()
                    except Exception:
                        pass
                    rpc, self.connected = None, False      # Discord geschlossen: später neu verbinden
                    self._stop.wait(RETRY_EVERY)
                    continue
            self._stop.wait(UPDATE_EVERY)
        if rpc is not None:
            try:
                rpc.clear()
                rpc.close()
            except Exception:
                pass


_INST = {"p": None}


def get():
    if _INST["p"] is None:
        _INST["p"] = DiscordPresence()
    return _INST["p"]


def started_at():
    return int(time.time())
