"""
Speichern und Laden von Spielständen (JSON).

* Atomares Schreiben: erst in eine temporäre Datei, dann umbenennen.
  Ein Absturz während des Speicherns kann den alten Spielstand nicht zerstören.
* Vor jedem Überschreiben wird der vorherige Stand als *.bak gesichert.
* Ist die Hauptdatei beschädigt, wird automatisch die Sicherung geladen.
"""

import json
import os
import shutil
import time

from .simulation import GameState


class SaveError(Exception):
    pass


def save_game(state, path):
    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = state.to_dict()
    data["saved_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
            f.flush()
            os.fsync(f.fileno())
        if os.path.exists(path):
            shutil.copy2(path, path + ".bak")
        os.replace(tmp, path)
    except OSError as exc:
        raise SaveError(f"Speichern fehlgeschlagen: {exc}") from exc
    return path


def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        return GameState.from_dict(json.load(f))


def load_game(path):
    """Lädt einen Spielstand. Gibt (state, info) zurück oder wirft SaveError."""
    path = os.path.abspath(path)
    if not os.path.exists(path) and not os.path.exists(path + ".bak"):
        raise SaveError("Kein Spielstand vorhanden.")
    try:
        return _read(path), f"Spielstand geladen: {os.path.basename(path)}"
    except (OSError, ValueError, KeyError, TypeError) as exc:
        backup = path + ".bak"
        if os.path.exists(backup):
            try:
                return _read(backup), f"Hauptdatei beschädigt ({exc}) – Sicherung geladen."
            except (OSError, ValueError, KeyError, TypeError):
                pass
        raise SaveError(f"Spielstand konnte nicht geladen werden: {exc}") from exc


def save_exists(path):
    return os.path.exists(path) or os.path.exists(path + ".bak")
