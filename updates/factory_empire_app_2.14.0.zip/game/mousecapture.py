"""
Eigene Maussteuerung für die Ego-Perspektive und den Vollbildmodus.

Warum nicht Ursinas ``mouse.locked``?
    Ursina schickt beim Sperren/Entsperren jedes Mal sein eigenes, beim Start
    gespeichertes Fenster-Eigenschaften-Objekt (Größe, Position, Rahmen) an das
    Fenster. Dadurch sprang das Spiel nach Esc aus dem Vollbild zurück in ein
    kleines Fenster, und die Mausbewegung in der Ego-Perspektive war unzuverlässig.

Hier werden nur die Eigenschaften angefordert, die sich wirklich ändern sollen
(Mauszeiger sichtbar/versteckt, Maus im Fenster halten). Die Mausbewegung wird
jedes Bild aus dem Abstand zur Fenstermitte berechnet; danach wird der Zeiger
wieder in die Mitte gesetzt. Das funktioniert unter Windows, macOS und Linux.
"""

from panda3d.core import WindowProperties
from ursina import application, window


def _win():
    base = application.base
    return getattr(base, "win", None) if base else None


def sync_ursina_window(undecorated=None, size=None, origin=None, cursor_hidden=None, mouse_mode=None):
    """Hält Ursinas gespeichertes Fensterobjekt synchron, damit Ursina-interne
    Aufrufe unsere Einstellungen (z. B. Vollbild) nicht rückgängig machen."""
    try:
        if undecorated is not None:
            window.setUndecorated(undecorated)
        if size is not None:
            window.setSize(int(size[0]), int(size[1]))
        if origin is not None:
            window.setOrigin(int(origin[0]), int(origin[1]))
        if cursor_hidden is not None:
            window.setCursorHidden(cursor_hidden)
        if mouse_mode is not None:
            window.setMouseMode(mouse_mode)
    except Exception:
        pass


class MouseCapture:
    DEG_PER_PIXEL = 0.12

    def __init__(self):
        self.captured = False
        self.soft = False                 # Vollbild: eigener, gezeichneter Mauszeiger statt Systemzeiger
        self.confine_when_free = False
        self.dx = 0.0
        self.dy = 0.0
        self._skip = 0
        self._had_focus = True

    # ------------------------------------------------------------------
    def apply(self):
        """Fordert Zeiger-Sichtbarkeit und Mausmodus passend zum Zustand an."""
        win = _win()
        if win is None:
            return
        wp = WindowProperties()
        hidden = self.captured or self.soft
        wp.setCursorHidden(hidden)
        mode = WindowProperties.M_confined if (self.captured or self.confine_when_free) else WindowProperties.M_absolute
        wp.setMouseMode(mode)
        win.requestProperties(wp)
        sync_ursina_window(cursor_hidden=hidden, mouse_mode=mode)

    def set_captured(self, on):
        on = bool(on)
        if on == self.captured:
            return
        self.captured = on
        self.dx = self.dy = 0.0
        self._skip = 2                    # erste Bilder ignorieren (kein Sprung beim Einfangen)
        self.apply()
        if on:
            self._center()

    def _center(self):
        win = _win()
        if win is None:
            return
        try:
            win.movePointer(0, win.getXSize() // 2, win.getYSize() // 2)
        except Exception:
            pass

    # ------------------------------------------------------------------
    def update(self):
        """Einmal pro Bild aufrufen. Sammelt die Mausbewegung in Pixeln, bis consume() sie abholt."""
        win = _win()
        if win is None:
            return 0.0, 0.0
        try:
            props = win.getProperties()
            # Manche Systeme melden den Fokus nicht: dann als "im Vordergrund" behandeln
            focus = props.getForeground() if props.hasForeground() else True
        except Exception:
            focus = True
        if focus and not self._had_focus:
            # Zurück im Spiel (z. B. nach Alt+Tab): Einstellungen erneut anwenden
            self.apply()
            self._skip = 2
            if self.captured:
                self._center()
        self._had_focus = focus
        if not self.captured or not focus:
            self.dx = self.dy = 0.0
            return 0.0, 0.0
        md = win.getPointer(0)
        cx, cy = win.getXSize() // 2, win.getYSize() // 2
        if self._skip > 0:
            self._skip -= 1
        elif md.getInWindow():
            dx = float(md.getX() - cx)
            dy = float(md.getY() - cy)
            # Ausreißer (z. B. durch Fensterwechsel) verwerfen
            if abs(dx) < win.getXSize() * 0.4 and abs(dy) < win.getYSize() * 0.4:
                self.dx += dx
                self.dy += dy
        if md.getX() != cx or md.getY() != cy:
            win.movePointer(0, cx, cy)
        return self.dx, self.dy

    def consume(self, sensitivity=1.0):
        """Drehung in Grad (yaw, pitch) seit dem letzten Aufruf; setzt den Zähler zurück."""
        k = self.DEG_PER_PIXEL * sensitivity
        out = (self.dx * k, self.dy * k)
        self.dx = self.dy = 0.0
        return out
