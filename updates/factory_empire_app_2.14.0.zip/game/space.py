"""
Weltraum: Sternenhimmel, Erde und Mond als Kugeln mit eingebackenem Licht (unbeleuchteter Shader,
dadurch unabhängig von Sonne, Nebel und Schatten der Spielwelt) und die Flugszene zwischen Erde und Mond.

Die Flugszene liegt weit über der Spielwelt (ORIGIN). Die Kamera sieht dort wegen der Sichtweite
(clip_plane_far) nichts von der Fabrik darunter.
"""

import math
import random

from panda3d.core import ColorBlendAttrib, TransparencyAttrib
from ursina import Entity, Mesh, Vec3, camera, color

from . import graphics
from . import textures

ORIGIN = Vec3(0, 6000, 0)
SUN_DIR = Vec3(-0.5, 0.45, -0.74).normalized()      # Richtung zur Sonne (für das eingebackene Licht)


# ----------------------------------------------------------------------------- 3D-Rauschen
def _h3(ix, iy, iz, seed):
    n = (ix * 374761393 + iy * 668265263 + iz * 1442695041 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def noise3(x, y, z, seed=1):
    ix, iy, iz = math.floor(x), math.floor(y), math.floor(z)
    fx, fy, fz = x - ix, y - iy, z - iz
    fx, fy, fz = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy), fz * fz * (3 - 2 * fz)

    def lerp(a, b, t):
        return a + (b - a) * t
    c = [[[_h3(ix + i, iy + j, iz + k, seed) for k in (0, 1)] for j in (0, 1)] for i in (0, 1)]
    x00 = lerp(c[0][0][0], c[1][0][0], fx)
    x10 = lerp(c[0][1][0], c[1][1][0], fx)
    x01 = lerp(c[0][0][1], c[1][0][1], fx)
    x11 = lerp(c[0][1][1], c[1][1][1], fx)
    return lerp(lerp(x00, x10, fy), lerp(x01, x11, fy), fz)


def fbm3(x, y, z, seed=1, octaves=4):
    total, amp, norm, f = 0.0, 1.0, 0.0, 1.0
    for o in range(octaves):
        total += noise3(x * f, y * f, z * f, seed + o * 17) * amp
        norm += amp
        amp *= 0.5
        f *= 2.0
    return total / norm


# ----------------------------------------------------------------------------- Planeten
def _earth_color(n):
    x, y, z = n
    lat = abs(y)
    land = fbm3(x * 1.6 + 3, y * 1.6, z * 1.6, seed=7, octaves=5)
    if lat > 0.86 + (land - 0.5) * 0.12:
        base = (0.93, 0.95, 0.98)                                   # Polkappen
    elif land > 0.53:
        dry = fbm3(x * 3 + 9, y * 3, z * 3, seed=21, octaves=3)
        green = (0.22, 0.45, 0.20)
        desert = (0.70, 0.58, 0.36)
        k = max(0.0, min(1.0, (dry - 0.45) * 3.0 + (0.25 - lat) * 1.2))
        base = tuple(green[i] * (1 - k) + desert[i] * k for i in range(3))
        if land > 0.66:
            base = tuple(c * 0.85 + 0.12 for c in base)               # Gebirge
    else:
        deep = max(0.0, min(1.0, (0.53 - land) * 5))
        base = (0.10 * (1 - deep) + 0.04 * deep, 0.32 * (1 - deep) + 0.16 * deep, 0.62 * (1 - deep) + 0.45 * deep)
    cloud = fbm3(x * 2.4 + 40, y * 3.2, z * 2.4, seed=33, octaves=4)
    c = max(0.0, min(1.0, (cloud - 0.55) * 3.2))
    return tuple(base[i] * (1 - c) + 0.97 * c for i in range(3))


def _moon_color(n):
    x, y, z = n
    mare = fbm3(x * 1.3 + 5, y * 1.3, z * 1.3, seed=12, octaves=4)
    g = 0.66 - max(0.0, mare - 0.52) * 1.4
    g += (fbm3(x * 9, y * 9, z * 9, seed=4, octaves=3) - 0.5) * 0.12
    # Krater: helle Ränder, dunkle Mitte
    cr = fbm3(x * 14 + 1, y * 14, z * 14, seed=55, octaves=2)
    if cr > 0.70:
        g -= (cr - 0.70) * 1.1
    elif 0.64 < cr <= 0.70:
        g += 0.06
    return (g * 0.98, g * 0.98, g * 1.02)


def planet_mesh(kind, seg=64, rings=40, light=SUN_DIR, ambient=0.05):
    """Kugel (Radius 0,5) mit Farben und Licht in den Eckpunkten."""
    col_fn = _earth_color if kind == "earth" else _moon_color
    verts, cols, tris, norms = [], [], [], []
    lx, ly, lz = light.x, light.y, light.z
    for i in range(rings + 1):
        phi = math.pi * i / rings
        y, rr = math.cos(phi), math.sin(phi)
        for j in range(seg + 1):
            th = 2 * math.pi * j / seg
            n = (rr * math.cos(th), y, rr * math.sin(th))
            verts.append(Vec3(n[0] * 0.5, n[1] * 0.5, n[2] * 0.5))
            norms.append(Vec3(*n))
            r, g, b = col_fn(n)
            d = n[0] * lx + n[1] * ly + n[2] * lz
            lit = ambient + (1 - ambient) * max(0.0, min(1.0, d * 1.15 + 0.08)) ** 0.8
            if kind == "earth" and -0.15 < d < 0.25:                  # Abendrot an der Tag-Nacht-Grenze
                k = 1 - abs(d - 0.05) / 0.2
                r, g, b = r + 0.25 * k, g + 0.08 * k, b - 0.05 * k
            cols.append(color.rgba(min(1, r * lit), min(1, g * lit), min(1, b * lit), 1))
    w = seg + 1
    for i in range(rings):
        for j in range(seg):
            a = i * w + j
            tris += [(a, a + w + 1, a + 1), (a, a + w, a + w + 1)]
    return Mesh(vertices=verts, triangles=tris, colors=cols, normals=norms)


_MESHES = {}


def cached_planet(kind):
    if kind not in _MESHES:
        light = Vec3(-0.35, 0.4, -0.85).normalized() if kind == "moon" else SUN_DIR
        _MESHES[kind] = planet_mesh(kind, light=light, ambient=0.12 if kind == "moon" else 0.05)
    return _MESHES[kind]


def additive(e):
    e.setTransparency(TransparencyAttrib.M_alpha)
    e.setAttrib(ColorBlendAttrib.make(ColorBlendAttrib.MAdd, ColorBlendAttrib.OIncomingAlpha, ColorBlendAttrib.OOne))
    e.setDepthWrite(False)
    e.setLightOff()
    e.setFogOff()
    return e


def glow(parent, pos, scale, col, bin_order=4):
    e = Entity(parent=parent, model="quad", texture=textures.texture("glow"), position=pos, scale=scale,
               billboard=True, shader=graphics.unlit(), color=col, add_to_scene_entities=False)
    additive(e)
    e.setBin("fixed", bin_order)
    return e


def make_planet(parent, kind, pos, radius, halo=None):
    e = Entity(parent=parent, model=cached_planet(kind), position=pos, scale=radius * 2,
               shader=graphics.unlit(), add_to_scene_entities=False)
    e.setLightOff()
    e.setFogOff()
    e.halo = None
    if halo is not None:
        e.halo = glow(parent, pos, radius * 2.7, halo, bin_order=2)
    return e


def star_field(parent, radius=780, count=1400, seed=9):
    """Sternenhimmel als Punktwolke (folgt der Kamera, damit er unendlich weit weg wirkt)."""
    rng = random.Random(seed)
    verts, cols = [], []
    for _ in range(count):
        z = rng.uniform(-1, 1)
        a = rng.uniform(0, 2 * math.pi)
        r = math.sqrt(1 - z * z)
        verts.append(Vec3(r * math.cos(a) * radius, z * radius, r * math.sin(a) * radius))
        b = rng.random() ** 2.2
        tint = rng.choice(((1, 1, 1), (0.8, 0.88, 1), (1, 0.93, 0.8)))
        cols.append(color.rgba(tint[0], tint[1], tint[2], 0.25 + 0.75 * b))
    e = Entity(parent=parent, model=Mesh(vertices=verts, colors=cols, mode="point", thickness=2.2),
               shader=graphics.unlit(), add_to_scene_entities=False)
    e.setTransparency(TransparencyAttrib.M_alpha)
    e.setLightOff()
    e.setFogOff()
    e.setDepthWrite(False)
    e.setBin("background", 1)
    big = []
    for _ in range(90):
        z = rng.uniform(-1, 1)
        a = rng.uniform(0, 2 * math.pi)
        r = math.sqrt(1 - z * z)
        big.append(Vec3(r * math.cos(a) * radius, z * radius, r * math.sin(a) * radius))
    b = Entity(parent=e, model=Mesh(vertices=big, mode="point", thickness=4.0), color=color.rgba(1, 1, 1, 0.9),
               shader=graphics.unlit(), add_to_scene_entities=False)
    b.setLightOff()
    b.setFogOff()
    return e


# ----------------------------------------------------------------------------- Flugszene
class SpaceScene:
    """Flug zwischen Erde und Mond (ca. 7 Sekunden)."""

    DURATION = 7.5

    def __init__(self):
        from .rocket import Rocket
        self.root = Entity(position=ORIGIN, add_to_scene_entities=False)
        self.stars = star_field(self.root)
        self.earth = make_planet(self.root, "earth", (0, -330, 120), 320, halo=color.rgba(0.35, 0.6, 1.0, 0.45))
        self.earth.rotation = (80, 20, 0)                     # Äquator statt Nordpol zur Kamera
        self.moon = make_planet(self.root, "moon", (40, 90, 800), 60)
        self.sun = glow(self.root, (-520, 330, 560), 150, color.rgba(1, 0.95, 0.82, 0.9), bin_order=3)
        self.rocket = Rocket(self.root, (0, 0, 0))
        self.rocket.root.rotation_x = 90                     # Spitze zeigt nach vorne (+z)
        self.root.enabled = False
        self.dest = "moon"

    def begin(self, dest):
        from ursina import window
        self.dest = dest
        self.root.enabled = True
        self._bg = window.color
        window.color = color.black
        self.rocket.reset()
        self.rocket.show_boosters(dest == "moon")
        self.rocket.set_firing(True, 0.75, vacuum=True)

    def end(self):
        from ursina import window
        if self.root.enabled and getattr(self, "_bg", None) is not None:
            window.color = self._bg
        self.root.enabled = False
        self.rocket.set_firing(False)

    def update(self, t, dt):
        """t: Sekunden seit Beginn. Bewegt Planeten, Rakete und Kamera."""
        e = min(1.0, t / self.DURATION)
        s = e * e * (3 - 2 * e)
        home, target = (self.earth, self.moon) if self.dest == "moon" else (self.moon, self.earth)
        home_r = 320 if home is self.earth else 140
        targ_r = 60 if target is self.moon else 70
        home.scale = home_r * 2
        target.scale = targ_r * 2
        home.position = Vec3(0, -home_r - 12 - 520 * s, 120 - 260 * s)
        target.position = Vec3(40 - 30 * s, 95 - 70 * s, 820 - 600 * s)
        for p in (home, target):
            if p.halo is not None:
                p.halo.position = p.position
                p.halo.scale = p.scale_x * 1.35
        # Rakete: Booster werden nach gut einer Sekunde abgetrennt
        r = self.rocket
        r.root.position = Vec3(math.sin(t * 0.7) * 0.4, math.sin(t * 0.9) * 0.3, 0)
        r.root.rotation_z = math.sin(t * 0.5) * 4
        if self.dest == "moon":
            r.separate_boosters(t - 1.3)
        r.update(dt)
        # Kamera: hinter der Rakete, langsam herumschwenkend
        a = math.radians(-82 + 34 * s)                       # schräg von der Seite: Flamme als Strahl
        dist = 20 + 3 * math.sin(t * 0.6)
        cam = Vec3(math.sin(a) * dist, 4.0 - 1.5 * s, -math.cos(a) * dist)
        from .rocket import look_from
        look_from(ORIGIN + cam, ORIGIN + Vec3(0, 0, 5))
        self.stars.world_position = camera.world_position
