"""
Viele kleine, zur Kamera gedrehte Bildchen (Partikel, Warnschilder) in EINEM Modell.

Früher war jedes Rauchwölkchen und jedes Warnschild ein eigenes Objekt mit eigenem Zeichenaufruf –
bei großen Fabriken mehrere hundert pro Bild. Eine SpriteBatch schreibt alle Bildchen eines Typs
pro Bild in einen gemeinsamen Vertex-Puffer: ein einziger Zeichenaufruf, egal wie viele es sind.
Die Ausrichtung zur Kamera wird dabei direkt in die Eckpunkte gerechnet.
"""

from array import array

from panda3d.core import (Geom, GeomNode, GeomTriangles, GeomVertexArrayFormat, GeomVertexData,
                          GeomVertexFormat, OmniBoundingVolume, TransparencyAttrib)
from ursina import Entity

from . import graphics

_FORMAT = None


def _format():
    global _FORMAT
    if _FORMAT is None:
        a = GeomVertexArrayFormat()
        a.addColumn("vertex", 3, Geom.NT_float32, Geom.C_point)
        a.addColumn("color", 4, Geom.NT_float32, Geom.C_color)
        a.addColumn("texcoord", 2, Geom.NT_float32, Geom.C_texcoord)
        _FORMAT = GeomVertexFormat.registerFormat(GeomVertexFormat(a))
    return _FORMAT


def camera_axes():
    """Rechts- und Oben-Vektor der Kamera in Weltkoordinaten."""
    import builtins
    base = builtins.base
    q = base.cam.getQuat(base.render)
    r, u = q.getRight(), q.getUp()
    return (r.x, r.y, r.z), (u.x, u.y, u.z)


class SpriteBatch:
    def __init__(self, texture, name="sprites", bin_order=10, depth_test=True):
        self.holder = Entity(shader=graphics.unlit(), add_to_scene_entities=False)
        if texture is not None:
            self.holder.setTexture(getattr(texture, "_texture", texture), 1)
        self.vdata = GeomVertexData(name, _format(), Geom.UH_dynamic)
        self.prim = GeomTriangles(Geom.UH_dynamic)
        geom = Geom(self.vdata)
        geom.addPrimitive(self.prim)
        node = GeomNode(name)
        node.addGeom(geom)
        node.setBounds(OmniBoundingVolume())      # Inhalt ändert sich ständig: nie wegschneiden
        node.setFinal(True)
        self.np = self.holder.attachNewNode(node)
        self.holder.setTransparency(TransparencyAttrib.M_alpha)
        self.holder.setDepthWrite(False)
        self.holder.setLightOff()
        self.holder.setTwoSided(True)
        self.holder.setBin("fixed", bin_order)
        if not depth_test:
            self.holder.setDepthTest(False)
        self.count = 0

    def write(self, sprites, axes=None):
        """sprites: Folge von (x, y, z, halbe_breite, halbe_höhe, r, g, b, a)."""
        (rx, ry, rz), (ux, uy, uz) = axes or camera_axes()
        buf = array("f")
        ext = buf.extend
        n = 0
        for x, y, z, hw, hh, r, g, b, a in sprites:
            ax, ay, az = rx * hw, ry * hw, rz * hw
            bx, by, bz = ux * hh, uy * hh, uz * hh
            x0, y0, z0 = x - ax - bx, y - ay - by, z - az - bz       # unten links
            x1, y1, z1 = x + ax - bx, y + ay - by, z + az - bz       # unten rechts
            x2, y2, z2 = x + ax + bx, y + ay + by, z + az + bz       # oben rechts
            x3, y3, z3 = x - ax + bx, y - ay + by, z - az + bz       # oben links
            ext((x0, y0, z0, r, g, b, a, 0.0, 0.0,
                 x1, y1, z1, r, g, b, a, 1.0, 0.0,
                 x2, y2, z2, r, g, b, a, 1.0, 1.0,
                 x0, y0, z0, r, g, b, a, 0.0, 0.0,
                 x2, y2, z2, r, g, b, a, 1.0, 1.0,
                 x3, y3, z3, r, g, b, a, 0.0, 1.0))
            n += 1
        self.vdata.setNumRows(n * 6)
        if n:
            self.vdata.modifyArray(0).modifyHandle().copyDataFrom(buf)
        if n != self.count:
            self.prim.clearVertices()
            if n:
                self.prim.addConsecutiveVertices(0, n * 6)
                self.prim.closePrimitive()
            self.count = n

    def clear(self):
        self.write(())

    def set_visible(self, on):
        self.holder.show() if on else self.holder.hide()
