"""
Mond-Landschaft: graues Regolith mit Kratern und Felsbrocken, schwarzer Sternenhimmel und die Erde,
die über dem Horizont steht. Die Fabrikfläche bleibt eben (Bauraster), die Startrampe steht an der
gleichen Stelle wie auf der Erde.
"""

import math
import random

from ursina import Entity, Mesh, Vec2, Vec3, camera, color

from . import config as C
from . import graphics
from . import models
from . import textures
from .space import make_planet, star_field
from .world import MARGIN, factory_distance, fbm, _value_noise

FLOOR_TINT = (0.50, 0.50, 0.52)
ORE_GROUND = {"moon_rock": (0.72, 0.72, 0.74), "moon_coal": (0.13, 0.13, 0.17), "titanium_ore": (0.42, 0.48, 0.62),
              "helium3": (0.36, 0.62, 0.58), "moon_ice": (0.80, 0.88, 0.95)}
PAD = (-9.0, -9.0)


def _craters(seed=1969):
    rng = random.Random(seed)
    out = []
    cx, cz = C.GRID_W / 2, C.GRID_H / 2
    tries = 0
    while len(out) < 46 and tries < 2000:
        tries += 1
        r = rng.choice((rng.uniform(3, 7), rng.uniform(6, 14), rng.uniform(12, 26)))
        a = rng.uniform(0, 2 * math.pi)
        d = rng.uniform(70, 160)
        x, z = cx + math.cos(a) * d, cz + math.sin(a) * d
        if factory_distance(x, z) < r + MARGIN + 6 or math.hypot(x - PAD[0], z - PAD[1]) < r + 14:
            continue
        out.append((x, z, r, r * rng.uniform(0.18, 0.28)))
    # kleine Krater direkt am Rand der Fabrik
    while len(out) < 80 and tries < 5000:
        tries += 1
        r = rng.uniform(1.5, 4.0)
        a = rng.uniform(0, 2 * math.pi)
        d = rng.uniform(56, 85)
        x, z = cx + math.cos(a) * d, cz + math.sin(a) * d
        if factory_distance(x, z) < r + MARGIN + 2 or math.hypot(x - PAD[0], z - PAD[1]) < r + 12:
            continue
        out.append((x, z, r, r * 0.25))
    return out


CRATERS = _craters()


def crater_term(x, z):
    """Höhenänderung durch Krater und Wert 0..1 'wie tief im Krater' (für die Farbe)."""
    h, inside, rim = 0.0, 0.0, 0.0
    for cx, cz, r, depth in CRATERS:
        dx, dz = x - cx, z - cz
        if abs(dx) > r * 1.6 or abs(dz) > r * 1.6:
            continue
        q = math.sqrt(dx * dx + dz * dz) / r
        if q < 1.0:
            h += -depth * (1 - q * q) + depth * 0.35
            inside = max(inside, 1 - q)
        if q < 1.6:
            b = math.exp(-((q - 1.0) / 0.2) ** 2)
            h += depth * 0.35 * b * (1 if q >= 1 else 0)
            rim = max(rim, b)
    return h, inside, rim


def moon_height(x, z):
    d = factory_distance(x, z)
    if d <= MARGIN:
        return 0.0
    t = min(1.0, (d - MARGIN) / 14.0)
    t = t * t * (3 - 2 * t)
    base = (fbm(x / 26.0, z / 26.0, seed=71) - 0.42) * 6.0
    far = min(9.0, max(0.0, d - 60.0) * 0.1) * fbm(x / 40.0, z / 40.0, 75)
    h = base * t + far
    c, _, _ = crater_term(x, z)
    h += c * t
    td = math.hypot(x - PAD[0], z - PAD[1])            # Startrampe: eben
    if td < 12.5:
        k = max(0.0, (td - 7.5) / 5.0)
        h *= k * k * (3 - 2 * k)
    return h


class MoonEnvironment:
    def __init__(self, center):
        self.center = center
        lit = graphics.lit_shader()
        self.root = Entity(add_to_scene_entities=False)
        self.terrain = Entity(parent=self.root, model=self._terrain_mesh(), shader=lit,
                              texture=textures.texture("rock"), add_to_scene_entities=False)
        self.boulders = Entity(parent=self.root, model=self._boulders(), shader=lit,
                               texture=textures.texture("rock"), add_to_scene_entities=False)
        self.stars = star_field(self.root, radius=820, count=1800, seed=19)
        # die Erde über dem Horizont (in Blickrichtung der Startkamera)
        a = math.radians(35)
        dist = 640
        pos = Vec3(center.x + math.sin(a) * dist, 92, center.z + math.cos(a) * dist)
        self.earth = make_planet(self.root, "earth", pos, 72, halo=color.rgba(0.35, 0.6, 1.0, 0.4))
        self.root.enabled = False

    def _terrain_mesh(self):
        size, step = 170.0, 2.5
        x0, z0 = self.center.x - size, self.center.z - size
        n = int(size * 2 / step) + 1
        heights = [[moon_height(x0 + i * step, z0 + j * step) for j in range(n)] for i in range(n)]
        verts, cols, uvs, norms, tris = [], [], [], [], []
        for i in range(n):
            for j in range(n):
                x, z = x0 + i * step, z0 + j * step
                h = heights[i][j]
                hl, hr = heights[max(i - 1, 0)][j], heights[min(i + 1, n - 1)][j]
                hd, hu = heights[i][max(j - 1, 0)], heights[i][min(j + 1, n - 1)]
                nx, ny, nz = hl - hr, 2 * step, hd - hu
                ln = math.sqrt(nx * nx + ny * ny + nz * nz)
                norms.append(Vec3(nx / ln, ny / ln, nz / ln))
                verts.append(Vec3(x, h - 0.04, z))
                uvs.append(Vec2(x / 5.0, z / 5.0))
                v = fbm(x / 11.0, z / 11.0, 13)
                g = 0.46 + (v - 0.5) * 0.16
                mare = fbm(x / 60.0, z / 60.0, 91)
                if mare > 0.55:
                    g -= (mare - 0.55) * 0.5
                _, inside, rim = crater_term(x, z)
                g = g - inside * 0.12 + rim * 0.1
                if factory_distance(x, z) < MARGIN + 0.5:
                    g = 0.47
                cols.append(color.rgba(g, g, g * 1.03, 1))
        for i in range(n - 1):
            for j in range(n - 1):
                a = i * n + j
                b = (i + 1) * n + j
                tris += [(a, b, b + 1), (a, b + 1, a + 1)]
        return Mesh(vertices=verts, triangles=tris, colors=cols, uvs=uvs, normals=norms)

    def _boulders(self):
        rng = random.Random(1972)
        mb = models.MeshBuilder(2.0)
        placed = 0
        while placed < 260:
            x = self.center.x + rng.uniform(-150, 150)
            z = self.center.z + rng.uniform(-150, 150)
            d = factory_distance(x, z)
            if d < MARGIN + 0.8 or math.hypot(x - PAD[0], z - PAD[1]) < 9:
                continue
            placed += 1
            s = rng.uniform(0.25, 1.0) * (2.6 if d > 25 and rng.random() < 0.2 else 1.0)
            g = rng.uniform(0.42, 0.6)
            y = moon_height(x, z) + s * 0.15
            mb.add("ico", (x, y, z), (s, s * rng.uniform(0.5, 0.8), s * rng.uniform(0.7, 1.1)), (g, g, g * 1.02),
                   (rng.uniform(-20, 20), rng.uniform(0, 180), rng.uniform(-20, 20)))
            if rng.random() < 0.5:
                s2 = s * 0.45
                mb.add("ico", (x + s * 0.6, y - s * 0.1, z + s * 0.3), (s2, s2 * 0.7, s2), (g * 0.9, g * 0.9, g * 0.92))
        return mb.build()

    def set_enabled(self, on):
        self.root.enabled = on

    def update(self, dt):
        if self.root.enabled:
            self.stars.world_position = camera.world_position


def floor_tint(i, j):
    """Grundfarbe der Baufläche auf dem Mond (statt Rasen): grau mit Flecken und feinen Kratern."""
    x, z = i - 0.5, j - 0.5
    big = fbm(x * 0.05, z * 0.05, seed=601, octaves=3)
    spot = _value_noise(x * 0.2, z * 0.2, 613)
    k = 0.92 + (big - 0.5) * 0.3 + (spot - 0.5) * 0.08
    r, g, b = FLOOR_TINT
    return (r * k, g * k, b * k * 1.02)
