"""
Bausteine der Benutzeroberfläche: Farben, Anker für die GUI-Skalierung,
Panels, Beschriftungen, Icons, Knöpfe, Fortschrittsbalken, Schieberegler,
Schalter und Fenster.

GUI-Skalierung
--------------
Alle Elemente hängen an "Ankern" (Ecken, Kanten, Mitte des Bildschirms).
Beim Ändern der GUI-Größe wird nur der Maßstab der Anker geändert – jedes
Element bleibt an seiner Bildschirmecke und wächst bzw. schrumpft von dort
aus. Ursina verschiebt die Anker automatisch, wenn sich das
Seitenverhältnis des Fensters ändert (z. B. beim Wechsel in den Vollbildmodus).
"""

import textwrap

from ursina import Button, Entity, Quad, Text, Vec3, Vec4, camera, color, mouse, time as utime, window

from . import anim, textures
from . import config as C

# ---------------------------------------------------------------- Farben
ACCENT = color.rgba(0.98, 0.62, 0.16, 1)
ACCENT_DIM = color.rgba(0.52, 0.33, 0.10, 1)
ACCENT_SOFT = color.rgba(0.98, 0.62, 0.16, 0.18)
PANEL = color.rgba(0.07, 0.08, 0.10, 0.88)
PANEL_SOLID = color.rgba(0.085, 0.095, 0.115, 1)
PANEL_LIGHT = color.rgba(0.14, 0.15, 0.18, 1)
PANEL_EDGE = color.rgba(1, 1, 1, 0.07)
CARD = color.rgba(0.13, 0.14, 0.17, 1)
CARD_HOVER = color.rgba(0.19, 0.2, 0.24, 1)
BUTTON = color.rgba(0.18, 0.19, 0.23, 1)
BUTTON_LOCKED = color.rgba(0.11, 0.115, 0.13, 1)
BUTTON_DANGER = color.rgba(0.40, 0.13, 0.13, 1)
BUTTON_GOOD = color.rgba(0.13, 0.36, 0.19, 1)
BUTTON_ACCENT = color.rgba(0.50, 0.32, 0.09, 1)
TEXT = color.rgba(0.94, 0.95, 0.97, 1)
MUTED = color.rgba(0.58, 0.61, 0.67, 1)
FAINT = color.rgba(0.40, 0.42, 0.47, 1)
GOOD = color.rgba(0.38, 0.93, 0.50, 1)
WARN = color.rgba(1.0, 0.78, 0.22, 1)
BAD = color.rgba(1.0, 0.38, 0.32, 1)
GOLD = color.rgba(1.0, 0.83, 0.32, 1)
BLUE = color.rgba(0.38, 0.68, 1.0, 1)
OFF = color.rgba(0.55, 0.57, 0.62, 1)
LEVEL_COLORS = {"ok": GOOD, "warn": WARN, "error": BAD, "off": OFF}
KIND_COLORS = {"info": TEXT, "success": GOOD, "warn": WARN, "error": BAD, "chat": BLUE}


def rgb(c, a=1.0):
    return color.rgba(c[0], c[1], c[2], a)


# ---------------------------------------------------------------- Anker
class Anchors:
    POSITIONS = {
        "tl": (-0.5, 0.5), "t": (0, 0.5), "tr": (0.5, 0.5),
        "l": (-0.5, 0), "c": (0, 0), "r": (0.5, 0),
        "bl": (-0.5, -0.5), "b": (0, -0.5), "br": (0.5, -0.5),
    }

    def __init__(self):
        self.scale = 1.0
        self.items = {}
        a = window.aspect_ratio
        for name, (fx, fy) in self.POSITIONS.items():
            self.items[name] = Entity(parent=camera.ui, position=(fx * a, fy, 0))

    def __getitem__(self, name):
        return self.items[name]

    def set_scale(self, s):
        self.scale = s
        for e in self.items.values():
            e.scale = s

    def refresh_positions(self):
        a = window.aspect_ratio
        for name, (fx, fy) in self.POSITIONS.items():
            self.items[name].x = fx * a


# ---------------------------------------------------------------- Grundelemente
def panel(parent, x, y, w, h, col=PANEL, radius=0.012, z=0, collider=True, edge=True):
    """Abgerundetes Rechteck mit linker oberer Ecke bei (x, y), weichem Schatten, Glanzkante und feinem Rand."""
    if edge:
        # weicher Schlagschatten (zwei Lagen) für Tiefe
        for grow, a in ((0.014, 0.10), (0.006, 0.16)):
            Entity(parent=parent, model=Quad(radius=radius + grow, aspect=(w + 2 * grow) / max(h + 2 * grow, 1e-4)),
                   origin=(-0.5, 0.5), position=(x - grow + 0.004, y + grow - 0.007, z + 0.003),
                   scale=(w + 2 * grow, h + 2 * grow), color=color.rgba(0, 0, 0, a))

        Entity(parent=parent, model=Quad(radius=radius + 0.002, aspect=(w + 0.004) / max(h + 0.004, 1e-4)),
               origin=(-0.5, 0.5), position=(x - 0.002, y + 0.002, z + 0.001), scale=(w + 0.004, h + 0.004),
               color=PANEL_EDGE)
    return Entity(parent=parent, model=Quad(radius=radius, aspect=w / max(h, 1e-4)), origin=(-0.5, 0.5),
                  position=(x, y, z), scale=(w, h), color=col, collider="box" if collider else None)


def rect(parent, x, y, w, h, col, z=-0.01, origin=(-0.5, 0.5)):
    return Entity(parent=parent, model="quad", origin=origin, position=(x, y, z), scale=(w, h), color=col)


def icon_name(name):
    """Auf dem Mond: Gebäude-Icons im Mond-Look (<name>_moon.png), falls vorhanden."""
    from . import models
    if models.PLANET["cur"] == "moon" and name in C.MOON_BUILDING_INFO and textures.icon(name + "_moon"):
        return name + "_moon"
    return name


def icon(parent, name, x, y, size, z=-0.02, col=color.white, origin=(-0.5, 0.5)):
    tex = textures.icon(icon_name(name))
    e = Entity(parent=parent, model="quad", texture=tex, origin=origin, position=(x, y, z), scale=size,
               color=col if tex else color.rgba(1, 1, 1, 0))
    return e


class Label(Text):
    """Text, der nur neu gerendert wird, wenn sich der Inhalt ändert (mit eigenem Zeilenumbruch)."""

    def __init__(self, parent, text, x, y, size=1.0, col=TEXT, origin=(-0.5, 0.5), z=-0.02, tags=False,
                 wordwrap=0, raw=False, max_w=0, **kw):
        self._wrap = wordwrap
        self._size, self._max_w = size, max_w
        self.__dict__["_fe_wrap"] = self._wrapped      # Zeilenumbruch nach dem Übersetzen
        self.__dict__["_raw"] = raw                    # raw: nie übersetzen (Namen, Chat)
        super().__init__(parent=parent, text=text or " ", position=(x, y, z), scale=size, color=col,
                         origin=origin, use_tags=tags, **kw)
        if max_w:
            self.__dict__["_fe_after"] = self._fit     # nach Sprachwechsel neu einpassen
            self._fit()

    def _fit(self):
        """Zu lange Texte (z. B. in anderen Sprachen) werden verkleinert statt überzustehen."""
        if not self._max_w:
            return
        try:
            w = self.width * self._size
        except Exception:
            return
        k = min(1.0, self._max_w / w) if w > 0 else 1.0
        self.scale = (self._size * k, self._size * k)

    def _wrapped(self, text):
        if not self._wrap:
            return text
        return "\n".join(textwrap.fill(line, self._wrap) if line else "" for line in text.split("\n"))

    def set(self, text, col=None, raw=None):
        text = text if text else " "
        if raw is not None and raw != self.__dict__.get("_raw"):
            self.__dict__["_raw"] = raw
            self.__dict__.pop("_fe_src", None)
        if text != self.__dict__.get("_fe_src"):
            self.text = text
            if self._max_w:
                self._fit()
        if col is not None and col != self.color:
            self.color = col


class ProgressBar:
    def __init__(self, parent, x, y, w, h, col=ACCENT, bg=color.rgba(1, 1, 1, 0.09), z=-0.02):
        self.w = w
        self.bg = Entity(parent=parent, model=Quad(radius=0.5, aspect=w / h), origin=(-0.5, 0.5),
                         position=(x, y, z), scale=(w, h), color=bg)
        self.fill = Entity(parent=parent, model="quad", origin=(-0.5, 0.5), position=(x, y, z - 0.001),
                           scale=(0.0001, h), color=col)

    def set(self, ratio, col=None):
        self.fill.scale_x = max(0.0001, self.w * max(0.0, min(1.0, ratio)))
        if col is not None:
            self.fill.color = col

    @property
    def enabled(self):
        return self.bg.enabled

    @enabled.setter
    def enabled(self, value):
        self.bg.enabled = value
        self.fill.enabled = value


class AnimButton(Button):
    """Knopf mit weichen Übergängen: Farbe blendet über, beim Überfahren wächst er leicht,
    beim Drücken federt er ein. followers: zusätzliche Elemente (z. B. Icons), die mitwachsen."""

    HOVER_SCALE = 1.045
    PRESS_SCALE = 0.955

    def __init__(self, *args, **kwargs):
        self.followers = []
        self.lift = 0.0                     # Hotbar: Icon hebt sich beim Überfahren
        super().__init__(*args, **kwargs)
        self.highlight_scale = 1
        self.pressed_scale = 1
        self._h = 0.0                       # 0 = normal, 1 = überfahren
        self._p = 0.0                       # 1 = gedrückt
        self._applied = None
        self._fix_text()

    def text_size_setter(self, value, temp=False):
        """Ursina setzt die Schriftgröße absolut (unabhängig von GUI-Größe und Fenster-Verkleinerung) –
        dadurch ragte Text bei kleiner GUI aus den Knöpfen. Hier skaliert er mit dem Knopf mit."""
        if not temp:
            self._text_size = value
        self._fix_text(value)

    def _fix_text(self, size=None):
        te = getattr(self, "text_entity", None)
        if not te:
            return
        size = getattr(self, "_text_size", 1) if size is None else size
        # Ziel: Schrift relativ zum Elternelement des Knopfes so groß wie ein Label mit derselben Größe.
        # (Nicht über Ursinas "Welt"-Skalierung – die ist bei ausgeblendeten Fenstern falsch und
        # ergab riesige Schrift.)
        sx, sy = self.scale_x or 1, self.scale_y or 1
        te.scale = Vec3(size / sx, size / sy, 1)

    def add_follower(self, entity):
        self.followers.append((entity, Vec3(entity.scale), Vec3(entity.position)))

    def _target(self):
        hov = self.hovered and not self.disabled
        return (1.0 if hov else 0.0), (1.0 if hov and mouse.left else 0.0)

    def update(self):
        th, tp = self._target()
        dt = min(utime.dt, 0.1)
        self._h = anim.approach(self._h, th, dt, 16)
        self._p = anim.approach(self._p, tp, dt, 30)
        if abs(self._h - th) < 0.002:
            self._h = th
        if abs(self._p - tp) < 0.002:
            self._p = tp
        self._apply()

    def _apply(self, force=False):
        if not self.model:
            return
        key = (round(self._h, 3), round(self._p, 3), tuple(self.color))
        if key == self._applied and not force:
            return
        self._applied = key
        base, hi, pr = Vec4(*self.color), Vec4(*self.highlight_color), Vec4(*self.pressed_color)
        col = base + (hi - base) * self._h
        col = col + (pr - col) * self._p
        self.model.setColorScale(col)
        k = 1 + (self.HOVER_SCALE - 1) * self._h - (1 - self.PRESS_SCALE) * self._p
        self.model.setScale(Vec3(k, k, 1))
        for ent, sc, pos in self.followers:
            ent.scale = sc * (1 + (k - 1) * 1.8)
            ent.y = pos.y + self.lift * self._h - self.lift * 0.4 * self._p

    # Eigene Hover-Behandlung: Ursina setzt beim Überfahren die Textgröße neu (über die Welt-Skalierung).
    # Das ergibt auf manchen Systemen (Mac/Retina) riesige Schrift – Farbe/Größe übernimmt hier update().
    def on_mouse_enter(self):
        if getattr(self, "tooltip", None):
            self.tooltip.enabled = True
        self._apply(force=True)

    def on_mouse_exit(self):
        if getattr(self, "tooltip", None):
            self.tooltip.enabled = False
        self._apply(force=True)

    def input(self, key):
        super().input(key)
        if key in ("left mouse down", "left mouse up"):
            self._apply(force=True)


class Btn(AnimButton):
    """Knopf mit Mittelpunkt (x, y), optional mit Icon links vom Text."""

    def __init__(self, parent, text, x, y, w, h, on_click, col=BUTTON, size=0.85, z=-0.03, text_color=TEXT,
                 icon_name=None, tooltip=None):
        super().__init__(parent=parent, text=text, position=(x, y, z), scale=(w, h), color=col, radius=0.22,
                         text_size=size, text_color=text_color)
        self.base_color = col
        self.highlight_color = col.tint(0.14)
        self.pressed_color = col.tint(-0.08)
        self.on_click = on_click
        self.icon_entity = None
        self._fix_text(size)
        if icon_name:
            self.icon_entity = Entity(parent=self, model="quad", texture=textures.icon(icon_name),
                                      position=(-0.5 + (h * 0.55) / w, 0, -0.02), scale=(h * 0.72 / w, 0.72))
            if self.text_entity:
                self.text_entity.x += (h * 0.35) / w
            self.add_follower(self.icon_entity)

    def set_color(self, col):
        if col != self.base_color:
            self.base_color = col
            self.color = col
            self.highlight_color = col.tint(0.14)
            self.pressed_color = col.tint(-0.08)
            self._apply(force=True)

    def set_text(self, text):
        te = self.text_entity
        if te is None or te.__dict__.get("_fe_src", te.text) != text:
            self.text = text
            self._fix_text()


class Slider:
    """Schieberegler mit Wertanzeige. on_change(wert) wird beim Ziehen und Klicken aufgerufen."""

    def __init__(self, parent, x, y, w, lo, hi, value, on_change, fmt=lambda v: f"{v:.2f}", step=0.0, z=-0.03,
                 on_release=None):
        self.lo, self.hi, self.step = lo, hi, step
        self.w = w
        self.on_change = on_change
        self.on_release = on_release
        self.fmt = fmt
        self.track = Entity(parent=parent, model=Quad(radius=0.5, aspect=w / 0.014), position=(x + w / 2, y, z),
                            scale=(w, 0.014), color=color.rgba(1, 1, 1, 0.12), collider="box")
        self.fill = Entity(parent=parent, model="quad", origin=(-0.5, 0), position=(x, y, z - 0.001),
                           scale=(0.001, 0.014), color=ACCENT)
        self.knob = Entity(parent=parent, model=Quad(radius=0.5), position=(x, y, z - 0.002), scale=0.03,
                           color=TEXT, collider="box")
        self.label = Label(parent, "", x + w + 0.02, y + 0.012, size=0.85, col=TEXT)
        self.x = x
        self.dragging = False
        self.value = value
        self._apply(value, notify=False)
        self.track.on_click = self._start
        self.knob.on_click = self._start
        self.updater = Entity(parent=parent)
        self.updater.update = self._update
        self.updater.input = self._input

    def _input(self, key):
        # Mausrad über dem Regler: einen Schritt (z. B. 1 %) feiner einstellen
        if key not in ("scroll up", "scroll down"):
            return
        if mouse.hovered_entity not in (self.track, self.knob, self.label):
            return
        step = self.step or (self.hi - self.lo) / 100
        self._apply(self.value + (step if key == "scroll up" else -step))
        if self.on_release:
            self.on_release(self.value)

    def _start(self):
        self.dragging = True
        self._from_mouse()

    def _from_mouse(self):
        # Mausposition (UI-Koordinaten) relativ zur Schiene umrechnen – funktioniert bei jeder GUI-Größe
        width = self.track.get_scale(camera.ui).x
        if width <= 0:
            return
        left = self.track.get_pos(camera.ui).x - width / 2
        ratio = (mouse.x - left) / width
        self._apply(self.lo + max(0.0, min(1.0, ratio)) * (self.hi - self.lo))

    def _update(self):
        if self.dragging:
            if mouse.left:
                self._from_mouse()
            else:
                self.dragging = False
                if self.on_release:
                    self.on_release(self.value)

    def _apply(self, value, notify=True):
        if self.step:
            value = round(value / self.step) * self.step
        value = max(self.lo, min(self.hi, value))
        changed = abs(value - self.value) > 1e-9
        self.value = value
        ratio = (value - self.lo) / (self.hi - self.lo) if self.hi > self.lo else 0
        self.fill.scale_x = max(0.001, self.w * ratio)
        self.knob.x = self.x + self.w * ratio
        self.label.set(self.fmt(value))
        if notify and changed and self.on_change:
            self.on_change(value)

    def set_value(self, value):
        self._apply(value, notify=False)


class Toggle:
    """An/Aus-Schalter."""

    def __init__(self, parent, x, y, value, on_change, z=-0.03):
        self.value = value
        self.on_change = on_change
        self.bg = Button(parent=parent, position=(x + 0.035, y, z), scale=(0.07, 0.034), radius=0.5,
                         color=BUTTON_GOOD if value else BUTTON)
        self.bg.on_click = self.toggle
        self.knob = Entity(parent=parent, model=Quad(radius=0.5), scale=0.026, color=TEXT,
                           position=(x + (0.052 if value else 0.018), y, z - 0.01))
        self.x = x

    def toggle(self):
        self.set(not self.value, notify=True)

    def set(self, value, notify=False):
        self.value = value
        self.knob.x = self.x + (0.052 if value else 0.018)
        col = BUTTON_GOOD if value else BUTTON
        self.bg.color = col
        self.bg.highlight_color = col.tint(0.12)
        if notify and self.on_change:
            self.on_change(value)


class Choice:
    """Auswahl mit Pfeilen: « Wert ». options: Liste von (wert, anzeigetext)."""

    def __init__(self, parent, x, y, w, options, value, on_change, z=-0.03, raw=False):
        self.options = options
        self.on_change = on_change
        self.index = next((i for i, (v, _) in enumerate(options) if v == value), 0)
        bw = 0.04
        self.prev = Btn(parent, "«", x + bw / 2, y, bw, 0.036, lambda: self.step(-1), size=0.8, z=z)
        self.next = Btn(parent, "»", x + w - bw / 2, y, bw, 0.036, lambda: self.step(1), size=0.8, z=z)
        panel(parent, x + bw + 0.006, y + 0.018, w - 2 * bw - 0.012, 0.036, PANEL_LIGHT, radius=0.008, z=z,
              collider=False, edge=False)
        self.label = Label(parent, "", x + w / 2, y + 0.011, size=0.8, origin=(0, 0.5), z=z - 0.01, raw=raw)
        self._show()

    @property
    def value(self):
        return self.options[self.index][0]

    def _show(self):
        self.label.set(self.options[self.index][1])

    def step(self, d):
        self.index = (self.index + d) % len(self.options)
        self._show()
        anim.pop(self.label, self.label.scale_x, 0.15, 0.22)
        if self.on_change:
            self.on_change(self.value)

    def set(self, value):
        self.index = next((i for i, (v, _) in enumerate(self.options) if v == value), self.index)
        self._show()

    def set_options(self, options, value=None):
        self.options = options
        self.index = next((i for i, (v, _) in enumerate(options) if v == value), 0)
        self._show()


# ---------------------------------------------------------------- Fenster
class Window:
    """Zentriertes Fenster mit Titelzeile, Icon, Schatten und Schließen-Knopf.

    Große Fenster werden automatisch verkleinert, wenn sie bei der gewählten
    GUI-Größe nicht mehr auf den Bildschirm passen.
    """

    def __init__(self, anchors, title, w, h, on_close, z=-0.3, icon_name=None):
        self.anchors = anchors
        self.w, self.h = w, h
        self.root = Entity(parent=anchors["c"], z=z, enabled=False)
        # Schatten
        Entity(parent=self.root, model=Quad(radius=0.03, aspect=(w + 0.04) / (h + 0.04)), origin=(-0.5, 0.5),
               position=(-w / 2 - 0.02, h / 2 + 0.01, 0.002), scale=(w + 0.04, h + 0.04), color=color.rgba(0, 0, 0, 0.28))
        self.bg = panel(self.root, -w / 2, h / 2, w, h, PANEL_SOLID, radius=0.018)
        rect(self.root, -w / 2 + 0.012, h / 2, w - 0.024, 0.005, ACCENT, z=-0.01)
        tx = -w / 2 + 0.03
        if icon_name:
            icon(self.root, icon_name, tx, h / 2 - 0.022, 0.045)
            tx += 0.058
        self.title = Label(self.root, title, tx, h / 2 - 0.026, size=1.5, col=TEXT)
        self.close_btn = Btn(self.root, "×", w / 2 - 0.036, h / 2 - 0.042, 0.046, 0.046, on_close,
                             col=color.rgba(0.28, 0.13, 0.13, 1), size=1.3)
        Label(self.root, "Esc", w / 2 - 0.068, h / 2 - 0.03, size=0.65, col=FAINT, origin=(0.5, 0.5))

    def fit(self):
        """Passt die Fenstergröße an, falls es mit der GUI-Größe nicht auf den Bildschirm passt."""
        s = self.anchors.scale
        max_w = window.aspect_ratio * 0.97
        max_h = 0.97
        k = min(1.0, max_w / (self.w * s), max_h / (self.h * s))
        self.root.scale = k

    @property
    def visible(self):
        return self.root.enabled and not self._closing

    _closing = False

    def show(self):
        self.fit()
        k = self.root.scale_x
        self._closing = False
        self.root.enabled = True
        root = self.root

        def f(v):
            s = k * (0.9 + 0.1 * v)
            root.scale = (s, s, 1)
            root.y = -0.025 * (1 - v)
        anim.tween(f, 0.32, ease=anim.out_back, key=("win", id(self)))
        anim.tween(lambda v: anim.set_alpha(root, v), 0.18, key=("win_a", id(self)))

    def hide(self):
        if not self.root.enabled or self._closing:
            return
        self._closing = True
        root = self.root
        k = root.scale_x

        def f(v):
            s = k * (1 - 0.06 * v)
            root.scale = (s, s, 1)
            anim.set_alpha(root, 1 - v)

        def done():
            if self._closing:
                root.enabled = False
                self._closing = False
                anim.set_alpha(root, 1)
                root.y = 0
        anim.cancel(("win_a", id(self)))
        anim.tween(f, 0.13, ease=anim.in_cubic, key=("win", id(self)), done=done)

    def toggle(self):
        if self.visible:
            self.hide()
        else:
            self.show()
