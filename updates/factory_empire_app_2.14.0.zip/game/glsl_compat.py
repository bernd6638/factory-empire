"""
GLSL-Anpassung für macOS.

macOS stellt OpenGL nur als "Core Profile" (3.2 bis 4.1) bereit und ist dabei strenger
als die Treiber unter Windows und Linux:
  * "#version" muss ganz am Anfang des Shaders stehen (einige Ursina-Shader beginnen
    mit einer Leerzeile),
  * "#version 130" wird nicht angenommen, erst ab 140,
  * mehr als "#version 410" gibt es nicht.
Ohne Anpassung schlägt das Kompilieren fehl und das Fenster bleibt schwarz.

apply() wird vor dem Erzeugen des Ursina-Fensters aufgerufen und korrigiert die
Shader-Quelltexte unmittelbar vor dem Kompilieren. Auf anderen Systemen ändert sich nichts.
"""

import re
import sys

_VERSION = re.compile(r"^[ \t]*#version[ \t]+(\d+)([^\n]*)$", re.MULTILINE)


def fix_source(src, core_profile=None):
    if core_profile is None:
        core_profile = sys.platform == "darwin"
    if not core_profile or not isinstance(src, str) or not src.strip():
        return src
    m = _VERSION.search(src)
    if not m:
        return src
    version = int(m.group(1))
    suffix = m.group(2).strip()
    new = 140 if version < 140 else min(version, 410)
    if new >= 330 and suffix == "":
        suffix = "core"
    head = f"#version {new}" + (f" {suffix}" if suffix else "")
    body = (src[:m.start()] + src[m.end():]).lstrip("\n")
    return head + "\n" + body


def apply(force=False):
    """Hängt die Korrektur in Ursinas Shader-Kompilierung ein (nur auf macOS, außer force=True)."""
    if sys.platform != "darwin" and not force:
        return False
    from ursina import shader as ushader
    cls = ushader.Shader
    if getattr(cls, "_fe_glsl_compat", False):
        return True
    original = cls.compile

    def compile(self, shader_includes=True):
        if getattr(self, "language", None) == cls.GLSL:
            for part in ("vertex", "fragment", "geometry"):
                src = getattr(self, part, None)
                if isinstance(src, str) and src:
                    if shader_includes:
                        src = ushader.do_shader_includes(src)
                    object.__setattr__(self, part, fix_source(src, core_profile=True))
            return original(self, shader_includes=False)
        return original(self, shader_includes)

    cls.compile = compile
    cls._fe_glsl_compat = True
    _patch_transparency()
    _patch_fonts()
    # Beim Import von Ursina wurden einige Shader schon (fehlerhaft) kompiliert – neu übersetzen
    for sh in list(ushader.imported_shaders.values()):
        if getattr(sh, "compiled", False) and getattr(sh, "language", None) == cls.GLSL:
            sh.compile()
    return True


class _MacTransparency:
    """Ersatz für TransparencyAttrib in Ursinas Entity-Modul.

    Ursina gibt jedem Modell den Modus M_dual. Der braucht den "Alpha-Test" der alten
    OpenGL-Pipeline, den es im Core Profile von macOS nicht gibt: Teil- oder ganz
    durchsichtige Flächen werden dort deckend gezeichnet (Ursinas unsichtbares
    Bildschirm-Overlay färbt dann das ganze Bild schwarz). Auf dem Mac nehmen wir
    deshalb normales Alpha-Blending (M_alpha)."""

    def __init__(self, real):
        self._real = real
        self.M_dual = real.M_alpha

    def __getattr__(self, name):
        return getattr(self._real, name)


def _patch_transparency():
    from panda3d.core import TransparencyAttrib
    import ursina.entity as uentity
    if not isinstance(uentity.TransparencyAttrib, _MacTransparency):
        uentity.TransparencyAttrib = _MacTransparency(TransparencyAttrib)


class _MacFontPool:
    """Ersatz für FontPool in Ursinas Text-Modul.

    Panda3D legt Schrift-Glyphen standardmäßig in reinen Alpha-Texturen ab. Dieses Format
    gibt es im Core Profile von macOS nicht – die Texturen bleiben dort leer und jeder Text
    wird unsichtbar (oder als Block) gezeichnet. Mit einer minimal abweichenden
    Hintergrundfarbe legt Panda3D die Glyphen als RGBA-Textur an; der Alpha-Kanal (den
    Ursinas Text-Shader liest) bleibt dabei unverändert."""

    def __init__(self, real):
        self._real = real

    def load_font(self, *args, **kwargs):
        font = self._real.load_font(*args, **kwargs)
        try:
            font.clear()
            font.setFg((1, 1, 1, 1))
            font.setBg((1, 1, 0.996, 0))
        except Exception:
            pass
        return font

    loadFont = load_font

    def __getattr__(self, name):
        return getattr(self._real, name)


def _patch_fonts():
    import ursina.text as utext
    if not isinstance(utext.FontPool, _MacFontPool):
        utext.FontPool = _MacFontPool(utext.FontPool)


def refresh_entities():
    """Nach dem Erzeugen des Ursina-Fensters aufrufen: Objekte, die schon vor apply() einen
    Shader bekommen haben (z. B. Ursinas unsichtbares Bildschirm-Overlay), erhalten die
    korrigierte Fassung. Ohne das überdeckt das Overlay auf Macs das ganze Bild schwarz."""
    if sys.platform != "darwin":
        return 0
    from ursina import camera, scene
    from ursina.shader import Shader
    entities = list(scene.entities)
    for name in ("overlay",):
        e = getattr(camera, name, None)
        if e is not None:
            entities.append(e)
    from panda3d.core import TransparencyAttrib
    count = 0
    for e in entities:
        model = getattr(e, "_model", None)
        if model is not None and model.getTransparency() == TransparencyAttrib.M_dual:
            model.setTransparency(TransparencyAttrib.M_alpha)
        sh = getattr(e, "_shader", None)
        if isinstance(sh, Shader) and getattr(sh, "_shader", None) is not None:
            if hasattr(e, "text_nodes"):
                e.shader = sh          # Text setzt den Shader auf seine eigenen Knoten
            else:
                e.setShader(sh._shader)
            count += 1
    return count
