"""
Laden der mitgelieferten Texturen und Icons aus assets/.

Fehlt eine Datei (z. B. weil jemand den assets-Ordner gelöscht hat), wird
None zurückgegeben – das Spiel läuft dann mit einfarbigen Flächen weiter.
"""

import os

from panda3d.core import SamplerState
from ursina import Texture

ASSET_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
_cache = {}


def _load(path, smooth=True):
    if path in _cache:
        return _cache[path]
    tex = None
    if os.path.exists(path):
        try:
            tex = Texture(path)
            pt = tex._texture
            pt.setMagfilter(SamplerState.FT_linear)
            # Mipmaps + anisotrope Filterung: kein Flimmern auf entfernten Flächen
            pt.setMinfilter(SamplerState.FT_linear_mipmap_linear if smooth else SamplerState.FT_linear)
            pt.setAnisotropicDegree(4 if smooth else 1)
        except Exception as exc:                 # beschädigte Datei: ohne Textur weiter
            print(f"[Textur] {os.path.basename(path)} nicht ladbar: {exc}")
            tex = None
    _cache[path] = tex
    return tex


def texture(name):
    return _load(os.path.join(ASSET_DIR, "textures", name + ".png"))


def icon(name):
    return _load(os.path.join(ASSET_DIR, "icons", name + ".png"), smooth=False)
