"""Factory Empire – Spielpaket (Server-Logik, Netzwerk, Client-Darstellung)."""
